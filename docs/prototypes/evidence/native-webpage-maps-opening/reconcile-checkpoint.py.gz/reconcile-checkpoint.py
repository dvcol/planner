from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-webpage-maps-opening'
reference=None
executions=[]
for phase in ['maps-opening-phone-trial','maps-opening-dark-tablet']:
    packet=root/phase
    inputs=json.loads((packet/'source-sha256.json').read_text())
    if reference is None:reference=inputs
    assert inputs==reference
    assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
    boundary=json.loads((packet/'boundary-validation.json').read_text())
    assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
    summary=json.loads((packet/'test-summary.json').read_text())
    assert summary['result']=='Passed' and summary['passedTests']==summary['totalTestCount']==1 and summary['failedTests']==summary['skippedTests']==0
    captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
    inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
    assert len(captures)==len(inspected)==3 and set(inspected)=={capture['file'] for capture in captures}
    for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256']
    attachment=json.loads((packet/'foreground-attachment-manifest.json').read_text())
    assert hashlib.sha256((packet/attachment['file']).read_bytes()).hexdigest()==attachment['sha256']
    observation=json.loads((packet/attachment['file']).read_text())
    assert observation['mapsBecameForeground'] and observation['mapsState']==4
    assert observation['confirmedExternalTarget']=='maps://?ll=35,139' and observation['originalBookmark'].endswith('/external-app-policy')
    if 'dark-tablet' in phase:assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal']
    executions.append({'phase':phase,'passedFunctions':1,'retainedOriginalCaptures':3,'inspectedOriginalCaptures':3,'retainedProducts':boundary['retainedProductCount']})
mac=root/'maps-opening-mac-compiler'
assert json.loads((mac/'source-sha256.json').read_text())==reference
boundary=json.loads((mac/'boundary-validation.json').read_text())
assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences'] and boundary['retainedProductCount']==9
unchanged=json.loads((root/'unchanged-production-and-journeys.json').read_text())
assert unchanged['existingJourneyBodiesUnchanged'] and unchanged['changedInputs']==['PlannerNavigationUITests/SavedBrowserJourneyTests.swift']
assert not subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerShareMobile','PlannerShareMac'],text=True).strip()
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(reference),'nativeExecutions':executions,'totalPassedNativeExecutions':2,'distinctNativeFunctions':1,'totalRetainedOriginalCaptures':6,'totalInspectedOriginalCaptures':6,'productionChanged':False,'existingJourneyBodiesUnchanged':True,'macCompiler':{'phase':mac.name,'retainedProducts':9,'runtimeCredit':False},'limits':['The exact Planner Maps confirmation, actual Maps foreground transition and preserved reader/bookmark are qualified on phone/dark iPad.','External captures show black launch content; Maps coordinate rendering, completed onboarding and readiness are not claimed.','Mail/Phone activation, other content/owner handoffs, actual Mac UI, physical devices, broad accessibility and final whole-app polish remain open.','Existing cancellation/generated-redirect journeys are unchanged and keep their preceding checkpoint evidence without new execution credit.'],'meaning':'All final source inputs match; source/product boundaries validated before reuse, and original captures and state attachments reconcile. Only one native test method is added; shipping production and the HTTP helper are unchanged.'}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'reconcile-checkpoint.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'passedNativeExecutions':2,'distinctFunctions':1,'originalCaptures':6,'sourceInputs':len(reference),'macCompilerProducts':9,'productionChanged':False}))
