from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
base=repository/'docs/prototypes/evidence'
report={'core':[],'nativeCurrent':[],'macCompiler':[],'manualImports':[],'earlierNativeSourceDeltas':[],'limitations':['No actual Mac UI, protected signing, physical convergence or complete whole-app polish credit.']}
def read(packet,name): return json.loads((packet/name).read_text())
def verify_sources(packet,prefix=None):
 manifest=read(packet,'source-sha256.json')
 if prefix: manifest={name:digest for name,digest in manifest.items() if name.startswith(prefix)}
 differences=[name for name,digest in manifest.items() if not (repository/name).is_file() or hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
 assert not differences,differences
 return manifest
for name in ['fresh-local-values-contexts-affected-mac','fresh-local-values-contexts-affected-tablet']:
 packet=base/'native-import-fresh-local-values'/name
 manifest=verify_sources(packet,'Packages/PlannerCore/');validation=read(packet,'boundary-validation.json');execution=read(packet,'execution.json');cleanup=read(packet,'fixture-cleanup.json')
 assert validation['exitCode']==0 and all(value==0 for value in cleanup['diagnosticCounts'].values()) and cleanup['success']
 report['core'].append({'packet':str(packet.relative_to(repository)),'inputs':len(manifest),'functions':len(execution['cases']) if 'cases' in execution else execution['summary']['passedTests'],'fixtures':cleanup['fixtureCount'],'sqliteUnlinkWarnings':0})
current=verify_sources(base/'native-webpage-restored-context/map-observed-camera-live-refresh-qualified')
for root,name in [('native-webpage-restored-context','map-observed-camera-live-refresh-qualified'),('native-itinerary-toolbar-compatibility','map-live-refresh-final-phone-regressions'),('native-itinerary-toolbar-compatibility','map-live-refresh-final-repeated-tablet')]:
 packet=base/root/name
 assert verify_sources(packet)==current
 validation=read(packet,'boundary-validation.json')
 assert validation['exitCode']==0 and validation['failedTests']==0 and validation['skippedTests']==0
 report['nativeCurrent'].append({'packet':str(packet.relative_to(repository)),'inputs':len(current),'passedTests':validation['passedTests'],'products':validation['productCount']})
for name in ['map-live-refresh-final-mac-compiler','map-live-refresh-final-mac-fixture-compiler']:
 packet=base/'native-itinerary-toolbar-compatibility'/name
 assert verify_sources(packet)==current
 validation=read(packet,'boundary-validation.json');assert validation['exitCode']==0 and validation['runtimeCredit'] is False
 report['macCompiler'].append({'packet':str(packet.relative_to(repository)),'inputs':len(current),'products':len(read(packet,'product-sha256.json')),'runtimeCredit':False})
for name in ['fresh-local-values-native-phone-root-export','fresh-local-values-native-dark-tablet-final']:
 packet=base/'native-import-fresh-local-values'/name
 delivered=read(packet,'delivered-file-validation.json')['results']
 assert set(delivered)=={'Skip','Denied','Restored','Repeated','Relaunched'}
 for result in delivered.values():
  content=gzip.decompress((packet/result['retained']).read_bytes())
  assert result['completeGraphMatches'] and hashlib.sha256(content).hexdigest()==result['sha256']
 assert delivered['Skip']['sha256']==delivered['Denied']['sha256']
 assert len({delivered[phase]['sha256'] for phase in ['Restored','Repeated','Relaunched']})==1
 report['manualImports'].append({'packet':str(packet.relative_to(repository)),'completeGraphComparisons':len(delivered),'restoredRepeatedRelaunchedByteIdentical':True})
for root,name in [('native-import-fresh-local-values','fresh-local-values-native-phone-root-export'),('native-import-fresh-local-values','fresh-local-values-native-dark-tablet-final'),('native-webpage-restored-context','browser-restored-contexts-phone-final'),('native-webpage-restored-context','browser-restored-entries-dark-tablet-final')]:
 packet=base/root/name
 manifest=read(packet,'source-sha256.json')
 changed=[path for path,digest in manifest.items() if current.get(path)!=digest]
 assert all(path in ['Planner/Scenes/SavedMapCollectionView.swift','Planner/Scenes/SavedPlannerView.swift'] or path.startswith(('PlannerFixtureUITests/','PlannerNavigationUITests/')) for path in changed),changed
 report['earlierNativeSourceDeltas'].append({'packet':str(packet.relative_to(repository)),'changedPaths':changed,'explanation':'Later production changes are Map projection/camera refresh. UI-test differences include camera/marker checks, wide-layout browser setup and manual import relaunch-export ordering. Core restoration and represented browser Return production remain unchanged; each original execution keeps its captured test source.'})
checks=read(base/'native-import-fresh-local-values/local-final-checks','validation.json')
assert checks['exitCode']==0 and checks['diffCheckExitCode']==0
for path,digest in checks['sourceSha256'].items():assert hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest
report['strictFormatSwiftFileCount']=len(checks['sourceSha256'])
subprocess.run(['git','diff','--check'],check=True)
packet=base/'native-itinerary-toolbar-compatibility'
(packet/'restoration-map-final-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'restoration-map-final-reconciliation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'core':report['core'],'currentNativeTests':sum(item['passedTests'] for item in report['nativeCurrent']),'manualFullGraphComparisons':10,'strictFormatSwiftFiles':report['strictFormatSwiftFileCount']}))
