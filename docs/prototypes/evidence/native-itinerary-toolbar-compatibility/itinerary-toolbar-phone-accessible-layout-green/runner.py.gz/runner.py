from pathlib import Path
import gzip, hashlib, io, json, os, shutil, subprocess, sys, tarfile, time, signal
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
selected = sys.argv[2]
packet = repository / 'docs/prototypes/evidence/native-itinerary-toolbar-compatibility' / phase
packet.mkdir(parents=True, exist_ok=False)
root = Path('/private/tmp/PlannerBrowserNativeSource')
root.mkdir(exist_ok=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
overlays = sorted({path for path in changed + new if (path.endswith('.swift') and path.startswith(('Packages/', 'Planner/', 'PlannerMCPTests/', 'PlannerNavigationUITests/', 'PlannerFixtureUITests/', 'PlannerFixtures/'))) or path.startswith(('Configuration/', 'Planner.xcodeproj/', 'docs/fixtures/'))})
archive = subprocess.check_output(['git', 'archive', base, 'Configuration', 'Packages', 'Planner.xcodeproj', 'Planner', 'PlannerMCPTests', 'PlannerFixtures', 'PlannerFixtureUITests', 'PlannerNavigationUITests', 'PlannerShareMobile', 'PlannerShareMac', 'docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for member in source.getmembers():
        if not member.isfile(): continue
        destination = root / member.name
        content = source.extractfile(member).read()
        if member.name in overlays:
            content = (repository / member.name).read_bytes()
        if destination.is_file() and destination.read_bytes() == content: continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
for path in overlays:
    (root / path).parent.mkdir(parents=True, exist_ok=True)
    if (root / path).is_file() and (root / path).read_bytes() == (repository / path).read_bytes(): continue
    shutil.copy2(repository / path, root / path)
inputs = sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet / 'source-sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root': str(root), 'base':base, 'overlays':overlays}, indent=2) + '\n')
for path in overlays:
    (packet / (Path(path).name + '.gz')).write_bytes(gzip.compress((root / path).read_bytes(), mtime=0))
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
bundle = '/private/tmp/PlannerItemWindow-' + phase + '.xcresult'
command = ['xcodebuild', 'test', '-project', 'Planner.xcodeproj', '-scheme', 'PlannerNavigation', '-destination', 'platform=iOS Simulator,id=2A49C66C-C8A4-435F-B98A-9A90706780DE', '-derivedDataPath', '/private/tmp/PlannerBrowserMobileDerivedData', '-clonedSourcePackagesDirPath', '/private/tmp/PlannerCalendarMonthSourcePackages', '-disableAutomaticPackageResolution', '-parallel-testing-enabled', 'NO', '-jobs', '1', *['-only-testing:PlannerNavigationUITests/' + name for name in selected.split(',')], '-resultBundlePath', bundle, 'CODE_SIGNING_ALLOWED=NO', 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerItemWindow-' + phase + '.log')
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try: code = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGINT)
        try: code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode':code, 'bundle':bundle}, indent=2) + '\n')
assert all(hashlib.sha256((root / path).read_bytes()).hexdigest() == digest for path, digest in hashes.items())
assert all((repository/path).is_file() and hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())


for kind in ['summary','tests']:
    result = subprocess.run(['xcrun','xcresulttool','get','test-results',kind,'--path',bundle],capture_output=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
    if result.returncode == 0:
        (packet / ('test-summary.json' if kind=='summary' else 'test-results-tests.json.gz')).write_bytes(result.stdout if kind=='summary' else gzip.compress(result.stdout,mtime=0))
product_root = Path('/private/tmp/PlannerBrowserMobileDerivedData/Build/Products')
products = {str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in product_root.rglob('*') if path.is_file() and path.name in ['Planner','Planner.debug.dylib','PlannerNavigationUITests','PlannerNavigationUITests-Runner']}
(packet/'product-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
print(phase, 'exit', code)
for line in log.read_text().splitlines():
    if line.startswith(('Test Case ', '** TEST', 'error:')) or ('Test ' in line and ('passed' in line or 'failed' in line)) or ': error:' in line or 'recorded an issue' in line:
        print(line[:1500])
raise SystemExit(code)
