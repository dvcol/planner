from pathlib import Path
import gzip,json,os,subprocess,sys
phase,selected,platform=sys.argv[1:4]
assert platform in ['phone','tablet']
packet=Path('/Users/dinh-van.colomban/Workspace/private/planner/docs/prototypes/evidence/native-itinerary-toolbar-compatibility')/phase
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
device='2A49C66C-C8A4-435F-B98A-9A90706780DE' if platform=='phone' else 'FBD72DAB-1D40-4E64-912D-7F9763E00446'
observations=[]
def observe(attribute):
 command=['xcrun','simctl','ui',device,attribute]
 result=subprocess.run(command,capture_output=True,env=environment)
 observations.append({'command':command,'exitCode':result.returncode,'output':result.stdout.decode().strip(),'error':result.stderr.decode().strip()})
 result.check_returncode()
 return result.stdout.decode().strip()
def set_value(attribute,value):
 subprocess.run(['xcrun','simctl','ui',device,attribute,value],check=True,capture_output=True,env=environment)
original={attribute:observe(attribute) for attribute in ['appearance','increase_contrast','content_size']}
requested={'appearance':'dark','increase_contrast':'enabled','content_size':'accessibility-extra-extra-extra-large'}
changed=[]
result=None
try:
 for attribute,value in requested.items():
  if original[attribute]!=value:
   set_value(attribute,value)
   changed.append(attribute)
  assert observe(attribute)==value
 runtime='/private/tmp/PlannerItineraryToolbarProduction'+('PhoneRuntime' if platform=='phone' else 'TabletRuntime')+'.py'
 result=subprocess.run(['python3',runtime,phase,selected],env=environment)
finally:
 for attribute in reversed(changed):set_value(attribute,original[attribute])
 restored={attribute:observe(attribute) for attribute in original}
 assert restored==original
 if packet.exists():
  (packet/'appearance-observation.json').write_text(json.dumps({'observations':observations,'requested':requested,'original':original,'restored':restored,'restoredToOriginal':True},indent=2)+'\n')
  (packet/'appearance-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
raise SystemExit(result.returncode if result else 1)
