from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
packet = workspace / 'docs/prototypes/evidence/native-membership-consolidation'
mac = packet / 'schema19-migrations-mac-final'
phone = packet / 'schema19-migrations-phone-pinned-cache'
mac_inputs = json.loads((mac / 'source-sha256.json').read_text())
phone_inputs = json.loads((phone / 'source-sha256.json').read_text())
phone_core = {name: digest for name, digest in phone_inputs.items() if name.startswith('Packages/PlannerCore/')}
assert phone_core == mac_inputs
for phase in [mac, phone]:
    manifest = json.loads((phase / 'source-sha256.json').read_text())
    staged = Path(json.loads((phase / 'source-root.json').read_text())['root'])
    assert all(hashlib.sha256((workspace / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
    assert all(hashlib.sha256((staged / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
    products = json.loads((phase / 'product-sha256.json').read_text())
    assert products and all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
summary = json.loads((phone / 'test-summary.json').read_text())
assert summary['passedTests'] == summary['totalTestCount'] == 18 and summary['failedTests'] == summary['skippedTests'] == 0
assert json.loads((phone / 'exit.json').read_text())['exitCode'] == 0
phone_log = gzip.decompress((phone / 'test.log.gz').read_bytes()).decode()
assert phone_log.count('vnode unlinked while in use') == 0
assert '** TEST SUCCEEDED **' in phone_log
mac_result = json.loads((mac / 'execution.json').read_text())
for case in mac_result['cases']:
    assert ('✔ Test ' + case['name'].split('/')[-1] + ' passed after') in phone_log, case['name']
paths = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.swift'], text=True).splitlines()
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.swift'], text=True).splitlines()
command = ['xcrun', 'swift', 'format', 'lint', '--strict', *paths]
lint = subprocess.run(command, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), capture_output=True, text=True)
(packet / 'schema19-swift-format.log.gz').write_bytes(gzip.compress((lint.stdout + lint.stderr).encode(), mtime=0))
assert lint.returncode == 0, lint.stdout + lint.stderr
report = json.loads((packet / 'schema19-foundation-validation.json').read_text())
report.update(phoneQualificationPending=False, phoneFunctions=18, phoneSkipped=0, phoneFailed=0, phoneSqliteUnlinkWarnings=0, coreInputsMatchAcrossPlatforms=True, phoneInputCount=len(phone_inputs), macProductCount=len(json.loads((mac / 'product-sha256.json').read_text())), phoneProductCount=len(json.loads((phone / 'product-sha256.json').read_text())), affectedSwiftFormatCommand=command, affectedSwiftFormatExitCode=0)
(packet / 'schema19-foundation-validation.json').write_text(json.dumps(report, indent=2) + '\n')
(packet / 'schema19-foundation-reconciliation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(phone / 'dependency-checkouts.json').write_bytes(Path('/private/tmp/PlannerMembershipDependencyCheckouts.json').read_bytes())
(phone / 'boundary-validation.json').write_text(json.dumps({'inputCount': len(phone_inputs), 'productCount': report['phoneProductCount'], 'workspaceDifferences': [], 'stagedDifferences': [], 'productDifferences': [], 'passedTests':18, 'failedTests':0, 'skippedTests':0}, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['coreInputCount', 'phoneInputCount', 'macFunctions', 'phoneFunctions', 'coreInputsMatchAcrossPlatforms', 'affectedSwiftFormatExitCode', 'consolidationQualified']}))
