from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'partial-removal-canonical-mac'
phone=root/'partial-removal-canonical-phone'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==196 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==196 and sum(signatures[0].values())==572
mac_inputs=json.loads((mac/'source-sha256.json').read_text())
phone_inputs=json.loads((phone/'source-sha256.json').read_text())
assert len(mac_inputs)==806 and all(phone_inputs.get(path)==digest for path,digest in mac_inputs.items())
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in phone_inputs.items())
previous=json.loads((root/'strict-membership-commands-canonical-mac/source-sha256.json').read_text())
fixtures=[path for path in mac_inputs if '/Fixtures/' in path]
models=[path for path in mac_inputs if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(fixtures)==512 and len(models)==19
assert all(previous[path]==mac_inputs[path] for path in fixtures+models)
phases=['partial-removal-generation-first','partial-removal-roundtrip-first','partial-removal-context-scope-first','partial-removal-canonical-mac','partial-removal-canonical-phone']
removed=[]
for phase in phases:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text())
 assert disposition['success']
 removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
files=sorted(path for path in files if path.endswith('.swift'))
assert len(files)==6
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':196,'invocationsPerPlatform':572,'suitesPerPlatform':79,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixtures),'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'removedClosedDisposableStores':len(removed),'externalMacUIPhysicalCloudOrSystemInvocationQualified':False,'remainingMembershipCommandsQualified':False}
(root/'partial-removal-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'partial-removal-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
