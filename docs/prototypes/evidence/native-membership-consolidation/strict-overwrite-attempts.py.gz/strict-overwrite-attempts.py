from pathlib import Path
import gzip,json,re
root=Path('docs/prototypes/evidence/native-membership-consolidation')
attempts=[]
for packet in sorted(root.glob('strict-overwrite-*')):
 if not packet.is_dir():continue
 entry={'phase':packet.name}
 execution=packet/'execution.json';exit_file=packet/'exit.json'
 if execution.exists():
  report=json.loads(execution.read_text())
  if 'cases' in report:
   entry.update({key:value for key,value in report.items() if key!='cases'})
   entry['functions']=len(report['cases'])
   entry['failedFunctions']=sum(bool(case['failures']) for case in report['cases'])
   entry['issues']=sum(len(case['failures']) for case in report['cases'])
  else:entry['stages']=report
 elif exit_file.exists():entry['mobileExecution']=json.loads(exit_file.read_text())
 else:raise AssertionError(packet)
 if packet.name=='strict-overwrite-resolved-bindings-first':entry['note']='The edit preflight failed before changing source. This repeated the previous failing candidate unchanged.'
 if packet.name=='strict-overwrite-owned-regression':entry['note']='Compiler cache sandbox access failed before tests; the approved local retry is recorded separately.'
 if packet.name=='strict-overwrite-evidence-red':entry['note']='Initial test source did not compile. The separate evidence-runtime-red phase establishes the behavioral failure.'
 attempts.append(entry)
assert len(attempts)==18,len(attempts)
(root/'strict-overwrite-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
(root/'strict-overwrite-attempts.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Retained completed phases',len(attempts))
