from pathlib import Path
import base64,copy,hashlib,json,struct,uuid
root=Path('Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation')
original=json.loads((root/'operation-fingerprint-literals.json').read_text())
def encode(value):
 kind, content=value
 if kind=='string':
  data=content.encode(); return b'\x10'+struct.pack('>Q',len(data))+data
 if kind=='identity': return b'\x14'+uuid.UUID(content).bytes
 if kind=='record':
  result=b'\x18'+struct.pack('>Q',len(content))
  for name in sorted(content):
   data=name.encode();result+=struct.pack('>Q',len(data))+data+encode(content[name])
  return result
 if kind=='identitySet':return b'\x17'+struct.pack('>Q',len(content))+b''.join(sorted(encode(element) for element in content))
 raise ValueError(kind)
old=original['cases'][0]
assert old['name']=='legacy-remove-v1'
assert base64.b64decode(old['payloadBase64'])==b'PlannerOperationPayload'+b'\x00\x00\x00\x00\x01'+encode(old['canonicalValue'])
value=copy.deepcopy(old['canonicalValue'])
command=value[1]['command'][1]
command['type']=['string','moveMembership']
command['destinationListId']=['identity','00000000-0000-4000-8000-000000000202']
command['placement']=['record',{'kind':['string','last']}]
value[1]['resolvedBindings'][1].append(['record',{'kind':['string','list'],'id':['identity','00000000-0000-4000-8000-000000000202'],'lifetimeId':['identity','00000000-0000-4000-8000-000000000822']}])
payload=b'PlannerOperationPayload'+b'\x00\x00\x00\x00\x01'+encode(value)
result={'identity':original['identity'],'name':'legacy-new-destination-move-v1','version':1,'canonicalValue':value,'payloadBase64':base64.b64encode(payload).decode(),'payloadDigest':'sha256-payload-v1:'+hashlib.sha256(payload).hexdigest()}
(root/'legacy-move-fingerprint-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['payloadDigest'])
