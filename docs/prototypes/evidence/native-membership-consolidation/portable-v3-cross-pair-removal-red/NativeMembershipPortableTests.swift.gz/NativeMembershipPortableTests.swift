import Foundation
import PlannerCore
import Testing

struct NativeMembershipPortableTests {
  @Test func informedReaddDecodesItsRetainedRemovalHistoryWithoutOpeningStorage() throws {
    let directory = try makePlannerStoreFixtureDirectory()
    let planner = Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .shareExtension, storageMode: .localOnly))
    let result = planner.decodeImport(try informedMembershipPortableFixtureData())
    guard case .decoded(let decoded) = result else {
      Issue.record("Decode the independent informed re-add and retained strict removal: \(result)")
      return
    }
    #expect(decoded.backup.formatVersion == 3)
    #expect(decoded.backup.membershipProvenance.count == 2)
    #expect(
      decoded.backup.membershipRemovals.map(\.deletionId.uuidString) == [
        "00000000-0000-4000-8000-000000000891"
      ])
    let informed = try #require(
      decoded.backup.membershipProvenance.first {
        $0.membershipId.uuidString == "00000000-0000-4000-8000-000000000405"
      })
    #expect(
      informed.observedRemovalIds.map(\.uuidString) == [
        "00000000-0000-4000-8000-000000000891"
      ])
    #expect(informed.list.id.uuidString == "00000000-0000-4000-8000-000000000201")
    #expect(informed.item.lifetimeId.uuidString == "00000000-0000-4000-8000-000000000811")
    let membership = try #require(decoded.backup.memberships.first)
    #expect(decoded.backup.sources.count == 2 && decoded.backup.memberships.count == 1)
    #expect(membership.id.uuidString == "00000000-0000-4000-8000-000000000405")
    #expect(membership.lifetimeId.uuidString == "00000000-0000-4000-8000-000000000845")
    #expect(!membership.localDone && membership.rank == 1024)
    #expect(decoded.backup.items.first?.globalDone == false)
    #expect(decoded.backup.deletionMarkers.count == 1)
    #expect(decoded.externalBindings.isEmpty && decoded.originPaths.isEmpty)
    #expect(!FileManager.default.fileExists(atPath: directory.path))
  }

  @Test func removalObservationsCannotBorrowAnotherItemListPairsAuthority() throws {
    var graph = try #require(
      JSONSerialization.jsonObject(with: informedMembershipPortableFixtureData()) as? [String: Any])
    var sources = try #require(graph["sources"] as? [[String: Any]])
    var otherItem = sources[0]
    otherItem["id"] = "00000000-0000-4000-8000-000000000102"
    otherItem["lifetimeId"] = "00000000-0000-4000-8000-000000000812"
    sources.append(otherItem)
    graph["sources"] = sources
    var provenance = try #require(graph["membershipProvenance"] as? [[String: Any]])
    provenance[0]["item"] = [
      "kind": "item", "id": "00000000-0000-4000-8000-000000000102",
      "lifetimeId": "00000000-0000-4000-8000-000000000812",
    ]
    graph["membershipProvenance"] = provenance
    let directory = try makePlannerStoreFixtureDirectory()
    let planner = Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .shareExtension, storageMode: .localOnly))
    let result = planner.decodeImport(try JSONSerialization.data(withJSONObject: graph))
    guard case .invalid(let failure) = result else {
      Issue.record("A removal for another Item cannot authorize this membership: \(result)")
      return
    }
    #expect(failure.code == "invalidInput")
    #expect(failure.propertyPath == "/membershipProvenance/1/observedRemovalIds/0")
    #expect(!FileManager.default.fileExists(atPath: directory.path))
  }
}

private func informedMembershipPortableFixtureData() throws -> Data {
  #if SWIFT_PACKAGE
    let bundle = Bundle.module
  #else
    let bundle = Bundle(for: NativeMembershipPortableFixtureBundle.self)
  #endif
  let fixture = try #require(
    bundle.url(
      forResource: "informed-readd-v3", withExtension: "json",
      subdirectory: "Fixtures/MembershipConsolidation"))
  return try Data(contentsOf: fixture)
}

private final class NativeMembershipPortableFixtureBundle: NSObject {}
