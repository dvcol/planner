import Foundation
import PlannerCore
import Testing

struct NativeMaintenanceRecoveryTests {
  @Test func acknowledgedMaintenanceEnvelopeIsInspectableWithoutOpeningPlannerStorage() async throws
  {
    let fixture = try MaintenanceRecoveryFixture.create()
    let originalFiles = try fixture.files()
    let listed = await fixture.planner.inspectRecovery(
      request: .namespace(namespaceId: fixture.namespaceIdentifier))
    guard case .listed(let view) = listed else {
      Issue.record("Inspect the independently frozen maintenance checkpoint: \(listed)")
      return
    }
    #expect(view.availability == .available)
    #expect(view.acknowledgedSnapshot?.storageSchemaVersion == 19)
    #expect(view.acknowledgedSnapshot?.portableFormatVersion == 3)
    #expect(view.acknowledgedSnapshot?.checkpointGeneration == 7)
    #expect(view.preparedProposals.isEmpty)
    let selected = await fixture.planner.inspectRecovery(
      request: .acknowledgedSnapshot(
        namespaceId: fixture.namespaceIdentifier, checkpointGeneration: 7))
    guard case .selected(let selection) = selected else {
      Issue.record("Select the exact acknowledged portable bytes: \(selected)")
      return
    }
    #expect(selection.evidence == .acknowledgedSnapshot)
    #expect(selection.checkpointGeneration == 7)
    #expect(selection.proposalId == nil && selection.originalOperationId == nil)
    #expect(selection.portableData == (try maintenanceFixtureData("informed-readd-v3")))
    #expect(selection.decodedBackup.backup.membershipRemovals.count == 1)
    #expect(try fixture.files() == originalFiles)
    #expect(!FileManager.default.fileExists(atPath: fixture.configuration.storeURL.path))
    #expect(!FileManager.default.fileExists(atPath: fixture.configuration.controlURL.path))
  }
}

private struct MaintenanceRecoveryFixture {
  let planner: Planner
  let configuration: PlannerStorageConfiguration
  let namespaceIdentifier: UUID
  let namespaceDirectory: URL

  static func create() throws -> Self {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .shareExtension, storageMode: .localOnly)
    let namespaceIdentifier = try #require(UUID(uuidString: "00000000-0000-4000-8000-000000000920"))
    let namespaceDirectory = configuration.recoveryDirectoryURL.appendingPathComponent(
      namespaceIdentifier.uuidString)
    try FileManager.default.createDirectory(
      at: namespaceDirectory, withIntermediateDirectories: true)
    let identity: [String: Any] = [
      "schemaVersion": 19, "datasetId": "00000000-0000-4000-8000-000000000910",
      "namespaceId": namespaceIdentifier.uuidString,
      "epochId": "00000000-0000-4000-8000-000000000930",
      "ownershipBinding": "local:membership-fixture",
    ]
    try JSONSerialization.data(withJSONObject: identity).write(
      to: namespaceDirectory.appendingPathComponent("identity.json"), options: .atomic)
    try maintenanceFixtureData("maintenance-recovery-v2").write(
      to: namespaceDirectory.appendingPathComponent("checkpoint-7.json"), options: .atomic)
    return .init(
      planner: Planner(configuration: configuration), configuration: configuration,
      namespaceIdentifier: namespaceIdentifier, namespaceDirectory: namespaceDirectory)
  }

  func files() throws -> [String: Data] {
    let files = try FileManager.default.contentsOfDirectory(
      at: namespaceDirectory, includingPropertiesForKeys: nil)
    return try Dictionary(
      uniqueKeysWithValues: files.map { ($0.lastPathComponent, try Data(contentsOf: $0)) })
  }
}

private func maintenanceFixtureData(_ name: String) throws -> Data {
  #if SWIFT_PACKAGE
    let bundle = Bundle.module
  #else
    let bundle = Bundle(for: NativeMaintenanceRecoveryFixtureBundle.self)
  #endif
  let file = try #require(
    bundle.url(
      forResource: name, withExtension: "json", subdirectory: "Fixtures/MembershipConsolidation"))
  return try Data(contentsOf: file)
}

private final class NativeMaintenanceRecoveryFixtureBundle: NSObject {}
