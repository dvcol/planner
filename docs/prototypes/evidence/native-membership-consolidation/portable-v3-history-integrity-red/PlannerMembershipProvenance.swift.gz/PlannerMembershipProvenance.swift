import Foundation

public struct PlannerPortableMembershipProvenance: Sendable, Equatable, Codable {
  public let membershipId: UUID
  public let membershipLifetimeId: UUID
  public let list: PlannerBoundSource
  public let item: PlannerBoundSource
  public let observedRemovalIds: [UUID]

  var membership: PlannerPortableBoundIdentity {
    .init(kind: .membership, id: membershipId, lifetimeId: membershipLifetimeId)
  }

  var pair: PlannerMembershipPair { .init(list: list, item: item) }
}

public struct PlannerPortableMembershipRemoval: Sendable, Equatable, Codable {
  public let deletionId: UUID
}

struct PlannerMembershipPair: Hashable {
  let list: PlannerBoundSource
  let item: PlannerBoundSource
}

extension PlannerImportGraph {
  func validateMembershipProvenance() throws {
    try unique(
      backup.membershipProvenance.map(\.membership), "/membershipProvenance", "membershipId")
    try unique(backup.membershipRemovals.map(\.deletionId), "/membershipRemovals", "deletionId")
    let provenance = Dictionary(
      uniqueKeysWithValues: backup.membershipProvenance.map { ($0.membership, $0) })
    let markers = Dictionary(
      uniqueKeysWithValues: backup.deletionMarkers.map { ($0.deletionId, $0) })
    var removalPairs: [UUID: PlannerMembershipPair] = [:]
    for (index, removal) in backup.membershipRemovals.enumerated() {
      guard let target = markers[removal.deletionId]?.target.importIdentity,
        target.kind == .membership, let binding = provenance[target]
      else {
        throw failure(
          "A strict membership removal needs its retained marker and pair binding.",
          "/membershipRemovals/\(index)/deletionId")
      }
      removalPairs[removal.deletionId] = binding.pair
    }
    for (index, binding) in backup.membershipProvenance.enumerated() {
      var observed: Set<UUID> = []
      for (observedIndex, identifier) in binding.observedRemovalIds.enumerated() {
        guard observed.insert(identifier).inserted, removalPairs[identifier] == binding.pair else {
          throw failure(
            "An observation must name a distinct strict removal for this exact Item/List pair.",
            "/membershipProvenance/\(index)/observedRemovalIds/\(observedIndex)")
        }
      }
      guard
        let member = backup.memberships.first(where: {
          $0.id == binding.membershipId && $0.lifetimeId == binding.membershipLifetimeId
        })
      else { continue }
      let actualList = PlannerBoundSource(
        kind: .list, id: member.list.id, lifetimeId: member.listLifetimeId)
      let actualItem = PlannerBoundSource(
        kind: .item, id: member.item.id, lifetimeId: member.itemLifetimeId)
      guard binding.list == actualList else {
        throw failure(
          "Membership provenance must retain its actual List binding.",
          "/membershipProvenance/\(index)/list")
      }
      guard binding.item == actualItem else {
        throw failure(
          "Membership provenance must retain its actual Item binding.",
          "/membershipProvenance/\(index)/item")
      }
    }
  }
}
