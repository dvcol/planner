from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import subprocess

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
root=workspace/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'canonical-membership-maintenance-lifetime-final-mac'
phone=root/'canonical-membership-maintenance-lifetime-final-phone'
mac_manifest=json.loads((mac/'source-sha256.json').read_text())
phone_manifest=json.loads((phone/'source-sha256.json').read_text())
assert mac_manifest=={name:digest for name,digest in phone_manifest.items() if name.startswith('Packages/PlannerCore/')}
for packet in [mac,phone]:
    manifest=json.loads((packet/'source-sha256.json').read_text())
    staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
    for base in [workspace,staged]:
        assert all((base/name).is_file() and hashlib.sha256((base/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
    products=json.loads((packet/'product-sha256.json').read_text())
    assert products and all(Path(name).is_file() and hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())

def signatures(packet):
    log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
    assert all(marker not in log for marker in ['vnode unlinked while in use','invalidated open fd','database integrity compromised'])
    results={}
    for line in log.splitlines():
        matched=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
        if matched and not matched[1].startswith('run with '):
            assert matched[1] not in results,matched[1]
            results[matched[1]]=int(matched[2] or 1)
    assert len(results)==184,len(results)
    return results
mac_signatures=signatures(mac)
assert mac_signatures==signatures(phone)
mac_execution=json.loads((mac/'execution.json').read_text())
assert mac_execution['exitCode']==0 and not mac_execution['runnerTimedOut']
assert len(mac_execution['cases'])==184 and all(not case['failures'] and not case['skipped'] for case in mac_execution['cases'])
summary=json.loads((phone/'test-summary.json').read_text())
assert summary['passedTests']==summary['totalTestCount']==184 and summary['failedTests']==summary['skippedTests']==0
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
frozen_schemas={}
for version in range(1,19):
    name='Packages/PlannerCore/Sources/PlannerCore/'+('PlannerStore.swift' if version==1 else f'PlannerSchemaV{version}.swift')
    original=subprocess.check_output(['git','show','7131bca3cc809a581e2cb8c3084bbbecaec251f3:'+name])
    current=(workspace/name).read_bytes()
    if version==1:
        original=original.split(b'\nextension PlannerSchemaV18.Item')[0]
        current=current.split(b'\nextension PlannerSchemaV18.Item')[0]
    assert original==current,name
    frozen_schemas[str(version)]=hashlib.sha256(current).hexdigest()
assert not subprocess.check_output(['git','diff','--name-only','--','Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures'],text=True).strip()
fixture=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation'
for name,evidence in json.loads((fixture/'provenance.json').read_text())['files'].items():
    assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==evidence['sha256']
paths=subprocess.check_output(['git','diff','--name-only','--','*.swift'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.swift'],text=True).splitlines()
command=['xcrun','swift','format','lint','--strict',*paths]
lint=subprocess.run(command,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
(root/'canonical-membership-maintenance-swift-format.log.gz').write_bytes(gzip.compress((lint.stdout+lint.stderr).encode(),mtime=0))
assert lint.returncode==0,lint.stdout+lint.stderr
report={'macFunctions':184,'phoneFunctions':184,'suitesPerPlatform':78,'executedInvocationsPerPlatform':sum(mac_signatures.values()),'testSignaturesAndArgumentCountsMatch':True,'coreInputs':len(mac_manifest),'phoneInputs':len(phone_manifest),'coreInputsMatchAcrossPlatforms':True,'workspaceAndStagedDifferences':[],'productDifferences':[],'productsPerPlatform':{packet.name:len(json.loads((packet/'product-sha256.json').read_text())) for packet in [mac,phone]},'failedFunctions':0,'skippedFunctions':0,'sqliteLifetimeDiagnostics':0,'frozenSchemaDeclarations':frozen_schemas,'oldFixturesAndFrozenWireLiteralsUnchanged':True,'affectedSwiftFormatExitCode':lint.returncode,'affectedSwiftFormatCommand':command,'maintenanceEnvelopeReadsAndCarryForwardQualified':True,'baselineConsolidationQualified':True,'strictMembershipRemovalObservationsQualified':False,'automaticMembershipMaintenanceQualified':True,'preparedMaintenanceInspectionQualified':False,'nativeMaintenanceRetryJourneyQualified':False,'exactNewFingerprintVectorExecutionQualified':False}
(root/'canonical-membership-maintenance-checkpoint-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'canonical-membership-maintenance-checkpoint-reconciliation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(phone/'boundary-validation.json').write_text(json.dumps({'inputCount':len(phone_manifest),'productCount':len(json.loads((phone/'product-sha256.json').read_text())),'coreInputsMatchMac':True,'passedTests':184,'failedTests':0,'skippedTests':0,'testSignaturesAndArgumentCountsMatch':True,'workspaceDifferences':[],'stagedDifferences':[],'productDifferences':[]},indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key not in ['frozenSchemaDeclarations','affectedSwiftFormatCommand']}))
