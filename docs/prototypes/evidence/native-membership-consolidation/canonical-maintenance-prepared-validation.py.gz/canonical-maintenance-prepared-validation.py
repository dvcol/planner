from pathlib import Path
import gzip, hashlib, json, os, re, subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'canonical-maintenance-prepared-core-mac'
phone=root/'canonical-maintenance-prepared-core-phone'
def signatures(packet):
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript
 assert '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 return found
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==190 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
mac_signatures=signatures(mac)
assert mac_signatures==signatures(phone)
assert len(mac_signatures)==190 and sum(mac_signatures.values())==565
mac_inputs=json.loads((mac/'source-sha256.json').read_text())
phone_inputs=json.loads((phone/'source-sha256.json').read_text())
assert len(mac_inputs)==805
assert all(phone_inputs.get(name)==digest for name,digest in mac_inputs.items())
assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in phone_inputs.items())
assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in mac_inputs.items())
for packet,expected_count in [(mac,2),(phone,2)]:
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==expected_count
 assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
adapter=root/'canonical-maintenance-prepared-adapter-mac'
adapter_execution=json.loads((adapter/'execution.json').read_text())
assert len(adapter_execution)==3
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in adapter_execution.values())
summary=json.loads((adapter/'test-summary.json').read_text())
assert summary['passedTests']==4 and summary['failedTests']==0 and summary['skippedTests']==0
adapter_inputs=json.loads((adapter/'source-sha256.json').read_text())
differences=[name for name,digest in adapter_inputs.items() if hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
assert differences==['PlannerFixtureUITests/PreparedMaintenanceRecoveryJourneyTests.swift']
for phase,expected_count in [('canonical-maintenance-prepared-ui-ipad-navigation',1),('canonical-maintenance-prepared-ui-phone-final',3)]:
 packet=root/phase
 assert json.loads((packet/'exit.json').read_text())['exitCode']==0
 summary=json.loads((packet/'test-summary.json').read_text())
 assert summary['totalTestCount']==expected_count and summary['passedTests']==expected_count and summary['failedTests']==0 and summary['skippedTests']==0
 inputs=json.loads((packet/'source-sha256.json').read_text())
 assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
mobile_app=root/'canonical-maintenance-prepared-phone-app'
mobile_execution=json.loads((mobile_app/'execution.json').read_text())
assert mobile_execution['exitCode']==0 and not mobile_execution['timedOut'] and mobile_execution['products']==6
for manifest in ['source-sha256.json','product-sha256.json']:
 values=json.loads((mobile_app/manifest).read_text())
 assert all(hashlib.sha256((repository/name if manifest=='source-sha256.json' else Path(name)).read_bytes()).hexdigest()==digest for name,digest in values.items())
removed=[]
for phase in ['canonical-maintenance-prepared-list-wired','canonical-maintenance-prepared-extra-field-green','canonical-maintenance-prepared-graph-field-green','canonical-maintenance-prepared-selection-green','canonical-maintenance-prepared-admission','canonical-maintenance-prepared-core-mac','canonical-maintenance-prepared-core-phone','canonical-maintenance-prepared-adapter-mac']:
 for file in (root/phase).glob('*fixture-disposition.json'):
  disposition=json.loads(file.read_text());assert disposition['success'];removed+=disposition['removedDirectories']
assert len(removed)==len(set(removed))==1222
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=sorted(name for name in files if name.endswith('.swift'))
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'coreFunctionsPerPlatform':190,'coreInvocationsPerPlatform':565,'suitesPerPlatform':78,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'coreProductsPerPlatform':2,'macAdapterFunctions':4,'macAppShareAndFixtureBuildsPassed':True,'mobileAppAndShareBuildPassed':True,'mobileAppAndShareProducts':6,'closedDisposableStoresRemoved':len(removed),'nativeRecoveryPhoneAndDarkIPadPassed':True,'strictSwiftFormatFiles':len(files),'macAdapterTestOnlyInputDrift':differences,'productionClientInputDrift':[],'savedCommandOrMaintenanceExecutionInferredFromPreparation':False,'signedPhysicalCloudOrSystemInvocationQualified':False}
(root/'canonical-maintenance-prepared-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'canonical-maintenance-prepared-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
