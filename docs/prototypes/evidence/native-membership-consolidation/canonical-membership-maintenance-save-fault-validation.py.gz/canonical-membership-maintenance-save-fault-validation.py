from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path('docs/prototypes/evidence/native-membership-consolidation')
name='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift'
original=subprocess.check_output(['git','show','fb117155:'+name],text=True)
current=Path(name).read_text()
assert current.count('#if os(macOS)')==2
common=current[:current.index('#if os(macOS)\n  extension NativeMembershipConsolidationTests')]
common=common.replace('\n#if os(macOS)\n  import Darwin\n#endif\n','\n',1)
common=common.replace('@testable import PlannerCore\n\n\n','@testable import PlannerCore\n\n',1)
assert common.rstrip()==original.rstrip()
changed=subprocess.check_output(['git','diff','--name-only','--','Packages/PlannerCore','Planner','PlannerFixtures','PlannerMCPTests'],text=True).splitlines()
assert changed==[name]
packet=root/'canonical-membership-maintenance-save-fault-final'
execution=json.loads((packet/'execution.json').read_text())
assert len(execution['cases'])==12 and execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert all(not case['failures'] and not case['skipped'] for case in execution['cases'])
source=json.loads((packet/'source-sha256.json').read_text())
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in source.items())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
assert all(hashlib.sha256((staged/path).read_bytes()).hexdigest()==digest for path,digest in source.items())
products=json.loads((packet/'product-sha256.json').read_text())
assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
command=['xcrun','swift-format','lint','--strict',name]
formatting=subprocess.run(command,capture_output=True,text=True)
assert formatting.returncode==0,formatting.stderr
signatures={}
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
for line in log.splitlines():
 match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
 if match and not match[1].startswith('run with '):signatures[match[1]]=int(match[2] or 1)
assert len(signatures)==12
reports=list(root.glob('canonical-membership-maintenance-save-fault-*/child-fixture-disposition.json'))+list(root.glob('canonical-membership-maintenance-save-fault-*/fixture-disposition.json'))
removed=[]
for report in reports:
 value=json.loads(report.read_text());assert value['success'];removed+=value['removedDirectories']
assert len(removed)==len(set(removed))
report={'macFunctions':12,'suites':4,'invocations':sum(signatures.values()),'failedFunctions':0,'skippedFunctions':0,'sqliteLifetimeDiagnostics':0,'coreInputs':len(source),'actualTestProducts':len(products),'workspaceDifferences':[],'stagedDifferences':[],'productDifferences':[],'productionCodeChanged':False,'existingCommonTestBodyUnchanged':True,'newTestMacOnly':True,'strictFormatExitCode':formatting.returncode,'removedOwnedFixtures':len(removed),'physicalAndProcessInterruptionQualified':False}
(root/'canonical-membership-maintenance-save-fault-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'canonical-membership-maintenance-save-fault-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
