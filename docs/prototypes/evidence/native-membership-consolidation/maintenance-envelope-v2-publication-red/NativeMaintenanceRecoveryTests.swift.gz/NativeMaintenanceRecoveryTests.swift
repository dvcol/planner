import Foundation
import PlannerCore
import Testing

struct NativeMaintenanceRecoveryTests {
  @Test func ordinaryWritesPreserveAcknowledgedMaintenanceAndOriginalCommandCheckpoints()
    async throws
  {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .decoded(let decoded) = planner.decodeImport(
        try maintenanceFixtureData("informed-readd-v3")),
      case .reviewed(let review) = await planner.prepareReview(
        session: session, command: .applyImport(backup: decoded, mode: .overwrite))
    else { throw CancellationError() }
    let original = PlannerOperation(
      operationId: UUID(), session: session, command: review.command,
      reviewToken: review.reviewToken)
    guard
      case .applied(let imported, .complete(let originalCheckpoint)) =
        await planner.execute(original).outcome,
      case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces),
      let namespace = namespaces.first
    else { throw CancellationError() }
    let namespaceDirectory = configuration.recoveryDirectoryURL.appendingPathComponent(
      namespace.namespaceId.uuidString)
    let originalFile = namespaceDirectory.appendingPathComponent(
      "checkpoint-\(originalCheckpoint).json")
    var acknowledged = try #require(
      JSONSerialization.jsonObject(with: Data(contentsOf: originalFile)) as? [String: Any])
    let identity = try #require(
      JSONSerialization.jsonObject(with: Data(contentsOf: configuration.controlURL))
        as? [String: Any])
    let literal = try #require(
      JSONSerialization.jsonObject(with: maintenanceFixtureData("maintenance-recovery-v2"))
        as? [String: Any])
    var maintenance = try #require((literal["maintenanceReceipts"] as? [[String: Any]])?.first)
    for key in ["namespaceId", "datasetId", "epochId", "ownershipBinding"] {
      maintenance[key] = try #require(identity[key])
    }
    maintenance["checkpointGeneration"] = String(originalCheckpoint)
    acknowledged["formatVersion"] = 2
    acknowledged["maintenanceReceipts"] = [maintenance]
    let acknowledgedBytes = try JSONSerialization.data(withJSONObject: acknowledged)
    try acknowledgedBytes.write(to: originalFile, options: .atomic)
    let operationIdentifier = UUID()
    let response = await planner.execute(
      .init(
        operationId: operationIdentifier, session: session,
        command: .createTag(content: .init(name: "Cloudy"))))
    guard case .applied(_, .complete(let nextCheckpoint)) = response.outcome,
      case .exported(let currentData) = await planner.exportData(session: session),
      case .selected(let selected) = await planner.inspectRecovery(
        request: .acknowledgedSnapshot(
          namespaceId: namespace.namespaceId, checkpointGeneration: nextCheckpoint))
    else {
      Issue.record("A normal command must publish alongside acknowledged maintenance: \(response)")
      return
    }
    let published = try #require(
      JSONSerialization.jsonObject(
        with: Data(
          contentsOf: namespaceDirectory.appendingPathComponent("checkpoint-\(nextCheckpoint).json")
        ))
        as? [String: Any])
    #expect(published["formatVersion"] as? Int == 2)
    let retained = try #require((published["maintenanceReceipts"] as? [[String: Any]])?.first)
    #expect(NSDictionary(dictionary: maintenance).isEqual(to: retained))
    let receipts = try #require(published["receipts"] as? [[String: Any]])
    #expect(
      Set(receipts.compactMap { $0["operationId"] as? String })
        == [original.operationId.uuidString, operationIdentifier.uuidString])
    #expect(
      receipts.first { $0["operationId"] as? String == original.operationId.uuidString }?[
        "checkpointGeneration"] as? String == String(originalCheckpoint))
    #expect(
      receipts.first { $0["operationId"] as? String == operationIdentifier.uuidString }?[
        "checkpointGeneration"] as? String == String(nextCheckpoint))
    #expect(nextCheckpoint == originalCheckpoint + 1)
    #expect(selected.portableData == currentData)
    #expect(try Data(contentsOf: originalFile) == acknowledgedBytes)
    let maintenanceIdentifier = try #require(
      UUID(uuidString: "00000000-0000-4000-8000-000000000940"))
    guard
      case .noReliableEvidence = await planner.operationStatus(
        session: session, operationId: maintenanceIdentifier),
      case .applied(let replayed, .complete(let replayCheckpoint)) =
        await planner.execute(original).outcome
    else {
      Issue.record("Maintenance must not become a command receipt or change original replay.")
      return
    }
    #expect(replayed == imported && replayCheckpoint == originalCheckpoint)
    let reopened = Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .exported(let reopenedData) = await reopened.exportData(session: reopenedSession)
    else { throw CancellationError() }
    #expect(reopenedData == currentData)
  }

  @Test func acknowledgedMaintenanceEnvelopeIsInspectableWithoutOpeningPlannerStorage() async throws
  {
    let fixture = try MaintenanceRecoveryFixture.create()
    let originalFiles = try fixture.files()
    let listed = await fixture.planner.inspectRecovery(
      request: .namespace(namespaceId: fixture.namespaceIdentifier))
    guard case .listed(let view) = listed else {
      Issue.record("Inspect the independently frozen maintenance checkpoint: \(listed)")
      return
    }
    #expect(view.availability == .available)
    #expect(view.acknowledgedSnapshot?.storageSchemaVersion == 19)
    #expect(view.acknowledgedSnapshot?.portableFormatVersion == 3)
    #expect(view.acknowledgedSnapshot?.checkpointGeneration == 7)
    #expect(view.preparedProposals.isEmpty)
    let selected = await fixture.planner.inspectRecovery(
      request: .acknowledgedSnapshot(
        namespaceId: fixture.namespaceIdentifier, checkpointGeneration: 7))
    guard case .selected(let selection) = selected else {
      Issue.record("Select the exact acknowledged portable bytes: \(selected)")
      return
    }
    #expect(selection.evidence == .acknowledgedSnapshot)
    #expect(selection.checkpointGeneration == 7)
    #expect(selection.proposalId == nil && selection.originalOperationId == nil)
    #expect(selection.portableData == (try maintenanceFixtureData("informed-readd-v3")))
    #expect(selection.decodedBackup.backup.membershipRemovals.count == 1)
    #expect(try fixture.files() == originalFiles)
    #expect(!FileManager.default.fileExists(atPath: fixture.configuration.storeURL.path))
    #expect(!FileManager.default.fileExists(atPath: fixture.configuration.controlURL.path))
  }
}

private struct MaintenanceRecoveryFixture {
  let planner: Planner
  let configuration: PlannerStorageConfiguration
  let namespaceIdentifier: UUID
  let namespaceDirectory: URL

  static func create() throws -> Self {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .shareExtension, storageMode: .localOnly)
    let namespaceIdentifier = try #require(UUID(uuidString: "00000000-0000-4000-8000-000000000920"))
    let namespaceDirectory = configuration.recoveryDirectoryURL.appendingPathComponent(
      namespaceIdentifier.uuidString)
    try FileManager.default.createDirectory(
      at: namespaceDirectory, withIntermediateDirectories: true)
    let identity: [String: Any] = [
      "schemaVersion": 19, "datasetId": "00000000-0000-4000-8000-000000000910",
      "namespaceId": namespaceIdentifier.uuidString,
      "epochId": "00000000-0000-4000-8000-000000000930",
      "ownershipBinding": "local:membership-fixture",
    ]
    try JSONSerialization.data(withJSONObject: identity).write(
      to: namespaceDirectory.appendingPathComponent("identity.json"), options: .atomic)
    try maintenanceFixtureData("maintenance-recovery-v2").write(
      to: namespaceDirectory.appendingPathComponent("checkpoint-7.json"), options: .atomic)
    return .init(
      planner: Planner(configuration: configuration), configuration: configuration,
      namespaceIdentifier: namespaceIdentifier, namespaceDirectory: namespaceDirectory)
  }

  func files() throws -> [String: Data] {
    let files = try FileManager.default.contentsOfDirectory(
      at: namespaceDirectory, includingPropertiesForKeys: nil)
    return try Dictionary(
      uniqueKeysWithValues: files.map { ($0.lastPathComponent, try Data(contentsOf: $0)) })
  }
}

private func maintenanceFixtureData(_ name: String) throws -> Data {
  #if SWIFT_PACKAGE
    let bundle = Bundle.module
  #else
    let bundle = Bundle(for: NativeMaintenanceRecoveryFixtureBundle.self)
  #endif
  let file = try #require(
    bundle.url(
      forResource: name, withExtension: "json", subdirectory: "Fixtures/MembershipConsolidation"))
  return try Data(contentsOf: file)
}

private final class NativeMaintenanceRecoveryFixtureBundle: NSObject {}
