from pathlib import Path
import gzip,hashlib,io,json,os,shutil,signal,subprocess,sys,tarfile,time
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/native-membership-consolidation'/phase
packet.mkdir(parents=True,exist_ok=False)
root=Path('/private/tmp/PlannerStrictMembershipAdapterMacSource')
root.mkdir(exist_ok=True)
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
overlays=[]
archive=subprocess.check_output(['git','archive',base,'Configuration','Packages','Planner.xcodeproj','Planner','PlannerMCPTests','PlannerFixtures','PlannerFixtureUITests','PlannerNavigationUITests','PlannerShareMobile','PlannerShareMac','docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
 for member in source.getmembers():
  if not member.isfile():continue
  destination=root/member.name
  destination.parent.mkdir(parents=True,exist_ok=True)
  content=(repository/member.name).read_bytes() if member.name in overlays else source.extractfile(member).read()
  if not destination.is_file() or destination.read_bytes()!=content:destination.write_bytes(content)
for path in overlays:
 destination=root/path
 destination.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(repository/path,destination)
inputs={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path)}
(packet/'source-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(root),'base':base,'overlays':overlays},indent=2)+'\n')
for path in overlays:(packet/(Path(path).name+'.gz')).write_bytes(gzip.compress((root/path).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
selected=['BulkCompletionRoutingTests']
common=['-project','Planner.xcodeproj','-scheme','Planner','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/PlannerMapNativeDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerItinerarySelectionSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1',*['-only-testing:PlannerMCPTests/'+name for name in selected],'CODE_SIGNING_ALLOWED=YES','CODE_SIGN_IDENTITY=-','CODE_SIGN_STYLE=Manual','DEVELOPMENT_TEAM=','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
report={}
for mode,timeout in [('build-for-testing',600),('test-without-building',120)]:
 bundle='/private/tmp/PlannerMembershipAdapter-'+phase+'-'+mode+'.xcresult'
 arguments=common
 if mode=='fixture-build':
  arguments=[value for value in common if not value.startswith('-only-testing:')]
  arguments[arguments.index('Planner')]='PlannerFixtures'
 command=['xcodebuild','build' if mode=='fixture-build' else mode,*arguments,'-resultBundlePath',bundle]
 (packet/(mode+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 log=Path('/private/tmp/PlannerMembershipAdapter-'+phase+'-'+mode+'.log')
 started=time.monotonic()
 with log.open('wb') as output:
  process=subprocess.Popen(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  timed_out=False
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True
   os.killpg(process.pid,signal.SIGINT)
   try:code=process.wait(timeout=20)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL)
    code=process.wait()
 content=log.read_text()
 (packet/(mode+'.log.gz')).write_bytes(gzip.compress(log.read_bytes(),mtime=0))
 report[mode]={'exitCode':code,'timedOut':timed_out,'seconds':round(time.monotonic()-started,3),'bundle':bundle,'sqliteUnlinkWarnings':content.count('vnode unlinked while in use')}
 assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
 assert {name for name,digest in inputs.items() if hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest} == {
  'Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift',
  'Packages/PlannerCore/Sources/PlannerCore/PlannerBulkCompletion.swift',
  'Packages/PlannerCore/Sources/PlannerCore/PlannerMembershipConsolidation.swift',
  'Packages/PlannerCore/Sources/PlannerCore/PlannerNativeImportStorage.swift',
  'Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift'
 }
 products={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in Path('/private/tmp/PlannerMapNativeDerivedData/Build/Products/Debug').rglob('*') if path.is_file() and path.name in ['Planner','Planner.debug.dylib','PlannerMCPTests','PlannerShareMac','PlannerShareMac.debug.dylib']}
 (packet/(mode+'-product-sha256.json')).write_text(json.dumps(products,indent=2)+'\n')
 if mode=='test-without-building':
  for kind in ['summary','tests']:
   results=subprocess.run(['xcrun','xcresulttool','get','test-results',kind,'--path',bundle],capture_output=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
   if results.returncode==0:(packet/('test-summary.json' if kind=='summary' else 'test-results-tests.json.gz')).write_bytes(results.stdout if kind=='summary' else gzip.compress(results.stdout,mtime=0))
 (packet/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
 print(mode,report[mode],flush=True)
 for line in content.splitlines():
  if 'error:' in line or 'recorded an issue' in line or line.startswith(('** TEST','** BUILD')):print(line[:1500],flush=True)
 if code:break
raise SystemExit(code)
