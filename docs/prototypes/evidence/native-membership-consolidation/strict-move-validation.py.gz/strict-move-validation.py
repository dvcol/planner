from pathlib import Path
import base64,gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'strict-move-canonical-mac';phone=root/'strict-move-canonical-phone';adapter=root/'strict-move-adapter-mac'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==198 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==198 and sum(signatures[0].values())==575
mac_inputs=json.loads((mac/'source-sha256.json').read_text());phone_inputs=json.loads((phone/'source-sha256.json').read_text());adapter_inputs=json.loads((adapter/'source-sha256.json').read_text())
assert len(mac_inputs)==807
assert all(phone_inputs.get(path)==digest and adapter_inputs.get(path)==digest for path,digest in mac_inputs.items())
for inputs in [phone_inputs,adapter_inputs]:assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
previous=json.loads((root/'partial-removal-canonical-mac/source-sha256.json').read_text())
old_fixtures=[path for path in previous if '/Fixtures/' in path]
assert len(old_fixtures)==512 and all(previous[path]==mac_inputs[path] for path in old_fixtures)
models=[path for path in mac_inputs if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(models)==19 and all(previous[path]==mac_inputs[path] for path in models)
literal=json.loads((repository/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation/legacy-move-fingerprint-v1.json').read_text())
assert literal['payloadDigest']=='sha256-payload-v1:'+hashlib.sha256(base64.b64decode(literal['payloadBase64'])).hexdigest()
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in json.loads((adapter/'execution.json').read_text()).values())
summary=json.loads((adapter/'test-summary.json').read_text());assert summary['passedTests']==6 and summary['failedTests']==0 and summary['skippedTests']==0
products=json.loads((adapter/'test-without-building-product-sha256.json').read_text())
assert products and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert any('/Planner.app/' in path for path in products)
assert any('/PlannerShareMac.appex/' in path for path in products)
assert any('/PlannerFixtures.app/' in path for path in products)
removed=[]
for phase in ['strict-move-command-first','strict-move-legacy-replay-first','strict-move-canonical-mac','strict-move-canonical-phone']:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text());assert disposition['success'];removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=sorted(path for path in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if path.endswith('.swift'))
assert len(files)==3
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':198,'invocationsPerPlatform':575,'suitesPerPlatform':79,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(old_fixtures),'newIndependentLegacyLiteral':literal['payloadDigest'],'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'realMacHTTPStatusFunctions':6,'macAppShareFixtureBuildsPassed':True,'removedClosedDisposableStores':len(removed),'nativeUIOrPhysicalCloudOrSystemInvocationQualified':False,'remainingMembershipCommandsQualified':False}
(root/'strict-move-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'strict-move-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
