from pathlib import Path
import gzip
import importlib.util
import json
import os
import subprocess
import sys
sys.dont_write_bytecode = True
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
root=workspace/'docs/prototypes/evidence/native-membership-consolidation'
specification=importlib.util.spec_from_file_location('fixture_verifier',workspace/'scripts/verify-intent-fixtures.py')
verifier=importlib.util.module_from_spec(specification)
specification.loader.exec_module(verifier)
phases=['portable-v3-informed-readd-decoder-first-green','portable-v3-cross-pair-removal-green','portable-v3-history-integrity-first-green','portable-v3-native-roundtrip-first-green','portable-v3-native-ordinary-writes','portable-v3-import-migration-final-mac']
report={'removedFixtures':0,'nominalBytes':0,'phases':[],'scope':'Only marked fixtures from completed passing Core runs; frozen fixtures, original evidence, failed fixtures and user datasets retained.'}
for phase in phases:
    packet=root/phase
    execution=json.loads((packet/'execution.json').read_text())
    assert execution['exitCode']==0 and not execution['runnerTimedOut']
    assert execution['frozenInputsUnchanged'] and execution['workspaceInputsUnchanged']
    content=gzip.decompress((packet/'test.log.gz').read_bytes())
    records=verifier.read_fixtures(content.decode())
    verifier.require_closed_hosts(records)
    verifier.require_closed_databases(records)
    files=[file for directory in records for file in directory.rglob('*')]
    assert all(not file.is_symlink() for file in files)
    assert all(directory.stat().st_uid==os.getuid() for directory in records)
    size=sum(file.stat().st_size for file in files if file.is_file())
    log=Path('/private/tmp/PlannerPortableMembershipCleanup-'+phase+'.log')
    log.write_bytes(content)
    result=subprocess.run([sys.executable,str(workspace/'scripts/verify-intent-fixtures.py'),str(log),'--report',str(packet/'fixture-disposition.json')],capture_output=True,text=True)
    disposition=json.loads((packet/'fixture-disposition.json').read_text())
    assert result.returncode==0 and disposition['success'],result.stdout+result.stderr
    assert len(disposition['removedDirectories'])==len(records)
    report['phases'].append({'phase':phase,'fixtureCount':len(records),'nominalBytes':size})
    report['removedFixtures']+=len(records)
    report['nominalBytes']+=size
    (root/'portable-v3-passing-fixture-cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'portable-v3-passing-fixture-cleanup.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'removedFixtures':report['removedFixtures'],'nominalBytes':report['nominalBytes'],'phases':len(report['phases'])}))
