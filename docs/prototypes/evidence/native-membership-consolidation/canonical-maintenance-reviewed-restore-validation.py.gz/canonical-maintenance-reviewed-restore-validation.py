from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
name='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMaintenanceRecoveryTests.swift'
original=subprocess.check_output(['git','show','03ab0b6c:'+name],text=True)
current=Path(name).read_text()
start=current.index('  @Test func reviewedMaintenanceCopyRestoresItsGraphWithoutAcknowledgingThePreparation()')
end=current.index('  @Test func selectedMaintenanceCopyPreservesItsGraphWithoutClaimingExecution()',start)
assert current[:start]+current[end:]==original
assert subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerFixtures','PlannerFixtureUITests','PlannerMCPTests'],text=True).splitlines()==[name]
mac=root/'canonical-maintenance-reviewed-restore-mac';phone=root/'canonical-maintenance-reviewed-restore-phone'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==23 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==23 and sum(signatures[0].values())==78
mac_inputs=json.loads((mac/'source-sha256.json').read_text());phone_inputs=json.loads((phone/'source-sha256.json').read_text())
assert len(mac_inputs)==805 and all(phone_inputs.get(path)==digest for path,digest in mac_inputs.items())
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in phone_inputs.items())
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',name],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
removed=[]
for phase in ['canonical-maintenance-reviewed-restore-mac-first','canonical-maintenance-reviewed-restore-mac','canonical-maintenance-reviewed-restore-phone']:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text());assert disposition['success'];removed+=disposition['removedDirectories']
assert len(removed)==len(set(removed))
report={'functionsPerPlatform':23,'suitesPerPlatform':3,'invocationsPerPlatform':78,'matchedCoreInputs':805,'actualTestProductsPerPlatform':2,'productionUnchanged':True,'existingTestBodiesUnchanged':True,'strictFormatExitCode':0,'removedClosedDisposableStores':len(removed),'originalMaintenanceAcknowledgedByRestore':False,'nativeUIPhysicalCloudAndSystemInvocationQualifiedByThisTest':False}
(root/'canonical-maintenance-reviewed-restore-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'canonical-maintenance-reviewed-restore-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
