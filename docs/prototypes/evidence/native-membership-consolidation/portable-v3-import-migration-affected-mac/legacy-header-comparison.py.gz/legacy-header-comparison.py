from pathlib import Path
import base64
import gzip
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
packet=workspace/'docs/prototypes/evidence/native-membership-consolidation/portable-v3-import-migration-affected-mac'
specification=importlib.util.spec_from_file_location('fixture_verifier',workspace/'scripts/verify-intent-fixtures.py')
verifier=importlib.util.module_from_spec(specification)
specification.loader.exec_module(verifier)
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
records=verifier.read_fixtures(log)
verifier.require_closed_hosts(records)
verifier.require_closed_databases(records)
fixtures=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/PortableImport'
def graph(value):
    result={}
    for key,element in value.items():
        if isinstance(element,list):
            result[key]=sorted([json.dumps(record,sort_keys=True,separators=(',',':')) for record in element])
        else:
            result[key]=element
    return result

def current_header(value):
    value=dict(value)
    value['formatVersion']=3
    value['membershipProvenance']=[]
    value['membershipRemovals']=[]
    return value
results=[]
for directory in records:
    files=list((directory/'dataset/recovery').glob('*/checkpoint-*.json'))
    if not files: continue
    envelopes=sorted([json.loads(path.read_text()) for path in files],key=lambda value:int(value['checkpointGeneration']))
    final=envelopes[-1]
    if not any(receipt['operationId']=='00000000-0000-4000-8000-000000000998' for receipt in final['receipts']): continue
    first_graph=json.loads(base64.b64decode(envelopes[0]['portablePayloadBase64']))
    last_graph=json.loads(base64.b64decode(final['portablePayloadBase64']))
    for suffix in ['','-deep']:
        initial=json.loads((fixtures/('fresh-local-restoration-current'+suffix+'-v2.json')).read_text())
        if graph(first_graph)!=graph(current_header(initial)): continue
        item=next(source for source in last_graph['sources'] if source['id']=='00000000-0000-4000-8000-000000000101')
        expected_text=(fixtures/('fresh-local-restoration-expected'+suffix+'-v2.json')).read_text()
        expected=json.loads(expected_text.replace('$restored-lifetime',item['lifetimeId']))
        assert graph(last_graph)==graph(current_header(expected)),directory
        results.append({'fixture':str(directory),'legacyFixtureKind':'deep' if suffix else 'single','firstCheckpoint':envelopes[0]['checkpointGeneration'],'finalCheckpoint':final['checkpointGeneration'],'initialAndFinalCompleteGraphsMatchWithOnlyV3HeaderAndEmptyGroups':True})
assert len(results)==4,len(results)
(packet/'legacy-header-comparison.json').write_text(json.dumps({'cases':results,'changedExpectedFields':['formatVersion','membershipProvenance','membershipRemovals'],'freshLifetimeOnlyCapturedPerExistingFixtureContract':True},indent=2)+'\n')
(packet/'legacy-header-comparison.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Verified all',len(results),'failing restoration cases: complete initial/final graphs match after only the v3 header and two empty arrays.')
