from pathlib import Path
import gzip,json,re,subprocess,sys
root=Path.cwd()/'docs/prototypes/evidence/native-membership-consolidation'
phase=sys.argv[1]
packet=root/phase
execution=json.loads((packet/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['functions'] if 'functions' in execution else execution['exitCode']==0
assert execution['sqliteUnlinkWarnings']==0
log=Path('/private/tmp/PlannerImportLifetime-'+phase+'.log')
assert gzip.decompress((packet/'test.log.gz').read_bytes())==log.read_bytes()
paths=re.findall(r'^MAINTENANCE_SAVE_FAULT_CHILD_LOG (.+)$',log.read_text(),re.MULTILINE)
assert len(paths)==1
child=Path(paths[0])
transcript=child.read_text()
assert 'Test run with 1 test' in transcript and 'passed' in transcript and '✘' not in transcript
assert 'vnode unlinked while in use' not in transcript
(packet/'child.log.gz').write_bytes(gzip.compress(child.read_bytes(),mtime=0))
report={'function':'failedMaintenanceSaveKeepsItsPreparationUnverifiedAndRetriesFresh','sourceLog':str(child),'parentExitCode':execution['exitCode'],'childTranscriptComplete':True,'fault':'RLIMIT_FSIZE soft limit zero at the real ModelContext.willSave boundary in an isolated child, restored before outcome reads.','productionTestHook':False,'qualificationScope':'Mac native-save failure, preparation-only rejection, fresh maintenance and waiting-command retry.'}
(packet/'child-runtime-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
result=subprocess.run(['python3','scripts/verify-intent-fixtures.py',str(child),'--report',str(packet/'child-fixture-disposition.json')],capture_output=True,text=True)
assert result.returncode==0,result.stdout+result.stderr
(packet/'child-runtime-evidence.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(phase,result.stdout.strip())
