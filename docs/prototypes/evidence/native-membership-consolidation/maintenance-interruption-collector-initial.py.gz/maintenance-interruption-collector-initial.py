from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/native-membership-consolidation'/phase
execution=json.loads((packet/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert execution['cases'] and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
log=Path('/private/tmp/PlannerImportLifetime-'+phase+'.log')
assert gzip.decompress((packet/'test.log.gz').read_bytes())==log.read_bytes()
paths=re.findall(r'^MAINTENANCE_INTERRUPTION_CHILD_LOG (.+)$',log.read_text(),re.MULTILINE)
assert len(paths)==1
child=Path(paths[0]).resolve(strict=True)
assert child.name=='child.log' and child.parent.name=='dataset'
assert child.parent.parent.parent.name=='PlannerStoreFixtures'
assert (child.parent.parent/'.planner-store-fixture.json').is_file()
transcript=child.read_text()
assert 'interruptedPreparedMaintenanceStaysUnverifiedAndFreshBootstrapIncludesLaterInput' in transcript
assert 'PLANNER_STORE_FIXTURE ' in transcript and '✘' not in transcript and 'vnode unlinked while in use' not in transcript
captures={}
for name in ['input.json','will-save.json','termination.json']:
 source=child.parent/name
 if not source.exists():
  assert name=='termination.json' and phase=='maintenance-interruption-runtime-first'
  continue
 (packet/('interruption-'+name)).write_bytes(source.read_bytes())
 captures[name]=hashlib.sha256(source.read_bytes()).hexdigest()
proof=json.loads((packet/'interruption-will-save.json').read_text())
assert proof=={'preparationCount':1}
if 'termination.json' in captures:
 status=json.loads((packet/'interruption-termination.json').read_text())
 assert status['finishedWithinDeadline'] and status['terminationReason']=='uncaughtSignal' and status['terminationStatus']==9
 marker=re.search(r'^PLANNER_STORE_FIXTURE (.+)$',transcript,re.MULTILINE)
 assert marker and json.loads(marker[1])['hostProcessIdentifier']==status['childProcessIdentifier']
(packet/'interruption-child.log.gz').write_bytes(gzip.compress(child.read_bytes(),mtime=0))
captures['child.log']=hashlib.sha256(child.read_bytes()).hexdigest()
combined=log.read_text()+'\n'+transcript
combined_path=Path('/private/tmp/PlannerMaintenanceInterruption-'+phase+'-combined.log')
combined_path.write_text(combined)
(packet/'interruption-combined.log.gz').write_bytes(gzip.compress(combined.encode(),mtime=0))
report={'sourceChildLog':str(child),'capturedHashes':captures,'parentFunctions':len(execution['cases']),'qualification':'Mac isolated SIGKILL after durable preparation and before native save; unverified-copy inspection, fresh reconciliation after later native input, old retry rejection and waiting-command exact replay.','productionTestHook':False,'powerLossOrPhysicalDeviceQualified':False}
(packet/'interruption-runtime-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
result=subprocess.run(['python3','scripts/verify-intent-fixtures.py',str(combined_path),'--report',str(packet/'fixture-disposition.json')],capture_output=True,text=True)
assert result.returncode==0,result.stdout+result.stderr
(packet/'interruption-runtime-evidence.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(phase,result.stdout.strip())
