import CryptoKit
import Foundation
import SwiftData
import Testing

@testable import PlannerCore

struct NativeMembershipConsolidationTests {
  @Test func ordinaryReaddDoesNotInheritAClosedCanonicalGroupsCompletion() async throws {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let itemResult, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(content: .init(title: "Hotel")))
      ).outcome,
      let item = itemResult.generated.first,
      case .applied(let listResult, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: .createList(content: .init(name: "Tokyo"))
        )
      ).outcome,
      let list = listResult.generated.first
    else { throw CancellationError() }
    try await insertIndependentMemberships(
      storeURL: configuration.storeURL, itemIdentifier: item.id, listIdentifier: list.id)
    guard
      case .snapshot(let completed) = await planner.query(
        .init(
          session: session,
          request: .items(.init(scope: .list(list.id), completion: .done, archive: .all)))),
      case .appearance(_, .listMembership(_, let canonicalIdentifier))? = completed.rows.first,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .removeMembership(listId: list.id, membershipId: canonicalIdentifier))
      ).outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .addMembership(itemId: item.id, listId: list.id, placement: .last))
      ).outcome
    else { throw CancellationError() }
    try await insertIndependentMemberships(
      storeURL: configuration.storeURL, itemIdentifier: item.id, listIdentifier: list.id,
      contributions: [
        (
          "00000000-0000-4000-8000-000000000403", "00000000-0000-4000-8000-000000000843", 3072,
          false
        )
      ])
    guard
      case .snapshot(let todo) = await planner.query(
        .init(
          session: session,
          request: .items(.init(scope: .list(list.id), completion: .todo, archive: .all)))),
      case .snapshot(let done) = await planner.query(
        .init(
          session: session,
          request: .items(.init(scope: .list(list.id), completion: .done, archive: .all)))),
      case .exported(let data) = await planner.exportData(session: session)
    else { throw CancellationError() }
    #expect(todo.matchingCount == 1)
    #expect(done.matchingCount == 0)
    let graph = try #require(JSONSerialization.jsonObject(with: data) as? [String: Any])
    let members = try #require(graph["memberships"] as? [[String: Any]])
    #expect(members.count == 1 && members.first?["localDone"] as? Bool == false)
    let aliases = try #require(graph["contextAliases"] as? [[String: Any]])
    let originalIdentifiers = [
      "00000000-0000-4000-8000-000000000401", "00000000-0000-4000-8000-000000000402",
    ]
    let oldHistory = aliases.filter { value in
      guard let context = value["context"] as? [String: Any],
        let identifier = context["membershipId"] as? String
      else { return false }
      return originalIdentifiers.contains(identifier)
    }
    #expect(oldHistory.count == 2)
    #expect(
      oldHistory.allSatisfy {
        ($0["canonicalContext"] as? [String: Any])?["membershipId"] as? String
          == "00000000-0000-4000-8000-000000000401"
      })
    #expect((graph["completionChanges"] as? [Any])?.isEmpty == true)
  }

  @Test func committedMaintenanceBlocksNewCommandsUntilItsOwnRecoveryRetryCompletes() async throws {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let createdItem, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(content: .init(title: "Hotel")))
      ).outcome,
      let item = createdItem.generated.first,
      case .applied(let createdList, .complete(let initialCheckpoint)) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: .createList(content: .init(name: "Tokyo"))
        )
      ).outcome,
      let list = createdList.generated.first,
      case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces),
      let namespace = namespaces.first
    else { throw CancellationError() }
    let namespaceDirectory = configuration.recoveryDirectoryURL.appendingPathComponent(
      namespace.namespaceId.uuidString)
    let originalFiles = try maintenanceNamespaceFiles(namespaceDirectory)
    try await insertIndependentMemberships(
      storeURL: configuration.storeURL, itemIdentifier: item.id, listIdentifier: list.id)
    let obstruction = NativeSaveRecoveryObstruction(configuration: configuration)
    let observer = NotificationCenter.default.addObserver(
      forName: ModelContext.didSave, object: nil, queue: nil
    ) {
      notification in obstruction.observe(notification)
    }
    defer {
      NotificationCenter.default.removeObserver(observer)
      try? obstruction.restore()
      try? FileManager.default.setAttributes(
        [.posixPermissions: 0o700], ofItemAtPath: namespaceDirectory.path)
    }
    let waitingOperationIdentifier = UUID()
    let response = await planner.execute(
      .init(
        operationId: waitingOperationIdentifier, session: session,
        command: .createTag(content: .init(name: "Must wait"))))
    guard case .rejected = response.outcome else {
      Issue.record(
        "The waiting command must remain unapplied after maintenance recovery fails: \(response)")
      return
    }
    #expect(obstruction.didObstruct && obstruction.failure == nil)
    guard
      case .snapshot(let readable) = await planner.query(
        .init(
          session: session,
          request: .items(.init(scope: .list(list.id), completion: .done, archive: .all)))),
      case .exported(let committedData) = await planner.exportData(session: session)
    else { throw CancellationError() }
    #expect(readable.matchingCount == 1)
    try obstruction.restore()
    let preparationFiles = try FileManager.default.contentsOfDirectory(
      at: namespaceDirectory, includingPropertiesForKeys: nil
    )
    .filter { $0.lastPathComponent.hasPrefix("maintenance-") }
    #expect(preparationFiles.count == 1)
    let preparationFile = try #require(preparationFiles.first)
    let preparation = try #require(
      JSONSerialization.jsonObject(with: Data(contentsOf: preparationFile)) as? [String: Any])
    let maintenanceIdentifier = try #require(
      (preparation["maintenanceId"] as? String).flatMap(UUID.init(uuidString:)))
    guard
      case .noReliableEvidence = await planner.operationStatus(
        session: session, operationId: waitingOperationIdentifier),
      case .noReliableEvidence = await planner.operationStatus(
        session: session, operationId: maintenanceIdentifier),
      case .listed(let pendingView) = await planner.inspectRecovery(
        request: .namespace(namespaceId: namespace.namespaceId))
    else { throw CancellationError() }
    #expect(pendingView.acknowledgedSnapshot?.checkpointGeneration == initialCheckpoint)
    let status = await planner.read(session: session, request: .status)
    guard case .status(let pendingStatus) = status,
      case .known(
        let pendingCheckpoint, let incompleteOperations, let incompleteMaintenance,
        let mutationBlocked) =
        pendingStatus.recovery
    else {
      Issue.record(
        "Verified committed maintenance must have a known, blocked recovery status: \(status)")
      return
    }
    #expect(
      pendingCheckpoint == initialCheckpoint && incompleteOperations.isEmpty && mutationBlocked)
    #expect(incompleteMaintenance == [maintenanceIdentifier])
    let blocked = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .createTag(content: .init(name: "Still waiting"))))
    guard case .rejected(let blockedReason) = blocked.outcome else {
      Issue.record("Pending maintenance must block a new ordinary command: \(blocked)")
      return
    }
    #expect(blockedReason.code == "mutationBlocked")
    let beforeRetry = try maintenanceNamespaceFiles(namespaceDirectory)
    for (name, bytes) in originalFiles { #expect(beforeRetry[name] == bytes) }
    try FileManager.default.setAttributes(
      [.posixPermissions: 0o500], ofItemAtPath: namespaceDirectory.path)
    let continued = await planner.retryMaintenanceRecovery(
      session: session, maintenanceId: maintenanceIdentifier)
    guard case .incomplete(let reason) = continued else {
      Issue.record(
        "A verified native commit must remain incomplete when publication still fails: \(continued)"
      )
      return
    }
    #expect(!reason.message.isEmpty)
    #expect(try maintenanceNamespaceFiles(namespaceDirectory) == beforeRetry)
    try FileManager.default.setAttributes(
      [.posixPermissions: 0o700], ofItemAtPath: namespaceDirectory.path)
    guard
      case .complete(let checkpoint) = await planner.retryMaintenanceRecovery(
        session: session, maintenanceId: maintenanceIdentifier),
      case .exported(let recoveredData) = await planner.exportData(session: session)
    else { throw CancellationError() }
    #expect(checkpoint == initialCheckpoint + 1)
    #expect(recoveredData == committedData)
    let acknowledgedFiles = try maintenanceNamespaceFiles(namespaceDirectory)
    guard
      case .complete(let repeatedCheckpoint) = await planner.retryMaintenanceRecovery(
        session: session, maintenanceId: maintenanceIdentifier)
    else { throw CancellationError() }
    #expect(repeatedCheckpoint == checkpoint)
    #expect(try maintenanceNamespaceFiles(namespaceDirectory) == acknowledgedFiles)
    let saved = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .createTag(content: .init(name: "After recovery"))))
    guard case .applied(_, .complete(let nextCheckpoint)) = saved.outcome,
      case .exported(let finalData) = await planner.exportData(session: session)
    else { throw CancellationError() }
    #expect(nextCheckpoint == checkpoint + 1)
    let finalGraph = try #require(JSONSerialization.jsonObject(with: finalData) as? [String: Any])
    let finalSources = try #require(finalGraph["sources"] as? [[String: Any]])
    let tags = finalSources.filter { $0["kind"] as? String == "tag" }
    #expect(tags.count == 1)
    #expect((tags.first?["content"] as? [String: Any])?["name"] as? String == "After recovery")
  }

  @Test func independentNativeMembershipsReadAsOneDoneContextWithoutCompletingTheirItem()
    async throws
  {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    let itemOperationIdentifier = UUID()
    let listOperationIdentifier = UUID()
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let createdItem, .complete(let itemCheckpoint)) = await planner.execute(
        .init(
          operationId: itemOperationIdentifier, session: session,
          command: .createItem(content: .init(title: "Hotel")))
      ).outcome,
      let item = createdItem.generated.first,
      case .applied(let createdList, .complete(let listCheckpoint)) = await planner.execute(
        .init(
          operationId: listOperationIdentifier, session: session,
          command: .createList(content: .init(name: "Tokyo")))
      ).outcome,
      let list = createdList.generated.first,
      case .exported(let originalData) = await planner.exportData(session: session)
    else { throw CancellationError() }

    try await insertIndependentMemberships(
      storeURL: configuration.storeURL, itemIdentifier: item.id, listIdentifier: list.id)

    let reopened = Planner(configuration: configuration)
    let bootstrap = await reopened.bootstrap()
    guard case .ready(let reopenedSession) = bootstrap else {
      Issue.record("Native relationship delivery must retain a readable dataset: \(bootstrap)")
      return
    }
    let result = await reopened.query(
      .init(
        session: reopenedSession,
        request: .items(.init(scope: .list(list.id), completion: .done, archive: .all))))
    guard case .snapshot(let snapshot) = result else {
      Issue.record("Independent Todo/Done memberships must resolve to one Done context: \(result)")
      return
    }
    #expect(snapshot.matchingCount == 1)
    #expect(
      snapshot.rows == [
        .appearance(
          source: item,
          appearance: .listMembership(
            listId: list.id,
            membershipId: UUID(uuidString: "00000000-0000-4000-8000-000000000401")!))
      ])
    guard
      case .source(.item(let read)) = await reopened.read(
        session: reopenedSession, request: .source(item))
    else { throw CancellationError() }
    #expect(read.state.globalDone == false)
    guard case .exported(let data) = await reopened.exportData(session: reopenedSession),
      case .listedNamespaces(let namespaces) = await reopened.inspectRecovery(request: .namespaces),
      let namespace = namespaces.first,
      let checkpoint = namespace.acknowledgedSnapshot?.checkpointGeneration,
      case .selected(let recovery) = await reopened.inspectRecovery(
        request: .acknowledgedSnapshot(
          namespaceId: namespace.namespaceId, checkpointGeneration: checkpoint))
    else { throw CancellationError() }
    #expect(checkpoint == listCheckpoint + 1)
    let actual = try #require(JSONSerialization.jsonObject(with: data) as? [String: Any])
    var expected = try #require(JSONSerialization.jsonObject(with: originalData) as? [String: Any])
    let sources = try #require(expected["sources"] as? [[String: Any]])
    let originalItem = try #require(sources.first { $0["id"] as? String == item.id.uuidString })
    let originalList = try #require(sources.first { $0["id"] as? String == list.id.uuidString })
    let itemBinding: [String: Any] = [
      "kind": "item", "id": item.id.uuidString,
      "lifetimeId": try #require(originalItem["lifetimeId"]),
    ]
    let listBinding: [String: Any] = [
      "kind": "list", "id": list.id.uuidString,
      "lifetimeId": try #require(originalList["lifetimeId"]),
    ]
    let canonical: [String: Any] = [
      "kind": "listMembership", "membershipId": "00000000-0000-4000-8000-000000000401",
      "membershipLifetimeId": "00000000-0000-4000-8000-000000000841",
    ]
    expected["memberships"] = [
      [
        "id": "00000000-0000-4000-8000-000000000401",
        "lifetimeId": "00000000-0000-4000-8000-000000000841",
        "list": listBinding, "item": itemBinding, "rank": "1024", "localDone": true,
      ]
    ]
    let seeds = try initialCompletionSeedFixtures()
    expected["contextAliases"] = try seeds.map { seed -> [String: Any] in
      [
        "aliasId": try #require(seed["aliasId"]), "context": try #require(seed["context"]),
        "canonicalContext": canonical, "initialDone": try #require(seed["initialDone"]),
        "currentChangeId": NSNull(),
      ]
    }.sorted { ($0["aliasId"] as? String ?? "") < ($1["aliasId"] as? String ?? "") }
    expected["membershipProvenance"] = [
      [
        "membershipId": "00000000-0000-4000-8000-000000000401",
        "membershipLifetimeId": "00000000-0000-4000-8000-000000000841",
        "list": listBinding, "item": itemBinding, "observedRemovalIds": [],
      ],
      [
        "membershipId": "00000000-0000-4000-8000-000000000402",
        "membershipLifetimeId": "00000000-0000-4000-8000-000000000842",
        "list": listBinding, "item": itemBinding, "observedRemovalIds": [],
      ],
    ]
    #expect(NSDictionary(dictionary: expected).isEqual(to: actual))
    let recoveredGraph = try #require(
      JSONSerialization.jsonObject(with: recovery.portableData) as? [String: Any])
    #expect(NSDictionary(dictionary: expected).isEqual(to: recoveredGraph))
    let namespaceDirectory = configuration.recoveryDirectoryURL.appendingPathComponent(
      namespace.namespaceId.uuidString)
    let envelope = try #require(
      JSONSerialization.jsonObject(
        with: Data(
          contentsOf: namespaceDirectory.appendingPathComponent("checkpoint-\(checkpoint).json")))
        as? [String: Any])
    #expect(envelope["formatVersion"] as? Int == 2)
    let maintenanceReceipts = try #require(envelope["maintenanceReceipts"] as? [[String: Any]])
    #expect(maintenanceReceipts.count == 1)
    let maintenance = try #require(maintenanceReceipts.first)
    let maintenanceIdentifier = try #require(
      (maintenance["maintenanceId"] as? String).flatMap(UUID.init(uuidString:)))
    #expect(
      maintenanceIdentifier != itemOperationIdentifier
        && maintenanceIdentifier != listOperationIdentifier)
    #expect(maintenance["checkpointGeneration"] as? String == String(checkpoint))
    let commandReceipts = try #require(envelope["receipts"] as? [[String: Any]])
    #expect(
      Set(commandReceipts.compactMap { $0["operationId"] as? String }) == [
        itemOperationIdentifier.uuidString, listOperationIdentifier.uuidString,
      ])
    let preparationData = try Data(
      contentsOf: namespaceDirectory.appendingPathComponent(
        "maintenance-\(maintenanceIdentifier.uuidString).json"))
    let preparation = try #require(
      JSONSerialization.jsonObject(with: preparationData) as? [String: Any])
    #expect(
      Set(preparation.keys) == [
        "format", "formatVersion", "maintenanceId", "namespaceId", "datasetId", "epochId",
        "ownershipBinding", "kind", "ruleVersion", "proposedBackup", "evidence",
      ])
    #expect(preparation["format"] as? String == "planner-maintenance-preparation")
    #expect(preparation["evidence"] as? String == "preparedUnverified")
    let preparedGraph = try #require(preparation["proposedBackup"] as? [String: Any])
    #expect(NSDictionary(dictionary: expected).isEqual(to: preparedGraph))
    let digest =
      "sha256:" + SHA256.hash(data: preparationData).map { String(format: "%02x", $0) }.joined()
    #expect(maintenance["preparationDigest"] as? String == digest)
    let beforeNoOp = try maintenanceNamespaceFiles(namespaceDirectory)
    guard
      case .noReliableEvidence = await reopened.operationStatus(
        session: reopenedSession, operationId: maintenanceIdentifier),
      case .complete(let maintenanceCheckpoint) = await reopened.retryMaintenanceRecovery(
        session: reopenedSession, maintenanceId: maintenanceIdentifier),
      case .applied(let replayedItem, .complete(let replayedItemCheckpoint)) =
        await reopened.execute(
          .init(
            operationId: itemOperationIdentifier, session: reopenedSession,
            command: .createItem(content: .init(title: "Hotel")))
        ).outcome,
      case .applied(let replayedList, .complete(let replayedListCheckpoint)) =
        await reopened.execute(
          .init(
            operationId: listOperationIdentifier, session: reopenedSession,
            command: .createList(content: .init(name: "Tokyo")))
        ).outcome
    else { throw CancellationError() }
    #expect(maintenanceCheckpoint == checkpoint)
    #expect(replayedItem == createdItem && replayedItemCheckpoint == itemCheckpoint)
    #expect(replayedList == createdList && replayedListCheckpoint == listCheckpoint)
    let another = Planner(configuration: configuration)
    guard case .ready(let anotherSession) = await another.bootstrap(),
      case .exported(let reopenedData) = await another.exportData(session: anotherSession)
    else { throw CancellationError() }
    #expect(reopenedData == data)
    #expect(try maintenanceNamespaceFiles(namespaceDirectory) == beforeNoOp)
  }

  /// Model access constructs the actual persisted input; all behavioral observations use Planner.
  @MainActor private func insertIndependentMemberships(
    storeURL: URL, itemIdentifier: UUID, listIdentifier: UUID,
    contributions: [(identifier: String, lifetime: String, rank: Int64, done: Bool)] = [
      ("00000000-0000-4000-8000-000000000401", "00000000-0000-4000-8000-000000000841", 1024, false),
      ("00000000-0000-4000-8000-000000000402", "00000000-0000-4000-8000-000000000842", 2048, true),
    ]
  ) throws {
    let schema = Schema(versionedSchema: PlannerSchemaV19.self)
    let container = try ModelContainer(
      for: schema, migrationPlan: PlannerMigrationPlan.self,
      configurations: [ModelConfiguration(schema: schema, url: storeURL, cloudKitDatabase: .none)])
    let context = ModelContext(container)
    context.autosaveEnabled = false
    let item = try #require(
      context.fetch(FetchDescriptor<PlannerSchemaV18.Item>()).first { $0.id == itemIdentifier })
    let list = try #require(
      context.fetch(FetchDescriptor<PlannerSchemaV18.List>()).first { $0.id == listIdentifier })
    let itemLifetime = try #require(item.lifetimeId)
    let listLifetime = try #require(list.lifetimeId)
    for (identifier, lifetime, rank, done) in contributions {
      context.insert(
        PlannerSchemaV18.Membership(
          snapshot: .init(
            id: try #require(UUID(uuidString: identifier)),
            lifetimeId: try #require(UUID(uuidString: lifetime)),
            list: .init(kind: "list", id: listIdentifier, lifetimeId: listLifetime),
            item: .init(kind: "item", id: itemIdentifier, lifetimeId: itemLifetime),
            rank: Int64(rank), localDone: done), list: list, item: item))
    }
    try context.save()
  }
}

private func maintenanceNamespaceFiles(_ directory: URL) throws -> [String: Data] {
  try Dictionary(
    uniqueKeysWithValues: FileManager.default.contentsOfDirectory(
      at: directory, includingPropertiesForKeys: nil
    ).map {
      ($0.lastPathComponent, try Data(contentsOf: $0))
    })
}

private func initialCompletionSeedFixtures() throws -> [[String: Any]] {
  #if SWIFT_PACKAGE
    let bundle = Bundle.module
  #else
    let bundle = Bundle(for: InitialCompletionSeedFixtureBundle.self)
  #endif
  let file = try #require(
    bundle.url(
      forResource: "initial-completion-seeds-v1", withExtension: "json",
      subdirectory: "Fixtures/MembershipConsolidation"))
  let root = try #require(
    JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: Any])
  return try #require(root["cases"] as? [[String: Any]])
}

private final class InitialCompletionSeedFixtureBundle: NSObject {}
