from pathlib import Path
import ast,base64,gzip,hashlib,json,struct,uuid

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
legacy=ast.parse(Path('/private/tmp/PlannerFreezeMembershipWireFixtures.py').read_text())
functions=[node for node in legacy.body if isinstance(node,ast.FunctionDef) and node.name in ['unsigned','tagged','identifier']]
assert len(functions)==3
exec(compile(ast.Module(body=functions,type_ignores=[]),'<independent tagged encoder>','exec'))
cases=[]
for membership,lifetime,done in [(401,841,False),(402,842,True)]:
 context={'kind':'listMembership','membershipId':identifier(membership),'membershipLifetimeId':identifier(lifetime)}
 canonical=('record',{'context':('record',{'kind':('string','listMembership'),'membershipId':('identity',identifier(membership)),'membershipLifetimeId':('identity',identifier(lifetime))}),'initialDone':('boolean',done)})
 value=tagged(*canonical)
 digest=bytearray(hashlib.sha256(b'PlannerInitialCompletionAlias-v1'+value).digest())
 digest[6]=(digest[6]&0x0f)|0x80
 digest[8]=(digest[8]&0x3f)|0x80
 cases.append({'aliasId':str(uuid.UUID(bytes=bytes(digest[:16]))).upper(),'context':context,'initialDone':done,'canonicalValueBase64':base64.b64encode(value).decode()})
path=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation/initial-completion-seeds-v1.json'
assert not path.exists()
path.write_text(json.dumps({'domain':'PlannerInitialCompletionAlias-v1','cases':cases},indent=2)+'\n')
packet=workspace/'docs/prototypes/evidence/native-membership-consolidation/initial-completion-seed-freeze'
packet.mkdir(exist_ok=False)
(packet/'producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(packet/'provenance.json').write_text(json.dumps({'fixture':str(path.relative_to(workspace)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'producer':'Independent Python tagged-value encoder; Planner production not executed'},indent=2)+'\n')
print(json.dumps({'frozenSeedIdentities':[case['aliasId'] for case in cases]}))
