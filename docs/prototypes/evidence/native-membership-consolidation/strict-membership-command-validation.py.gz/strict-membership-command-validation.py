from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'strict-membership-commands-canonical-mac';phone=root/'strict-membership-commands-canonical-phone'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==195 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==195 and sum(signatures[0].values())==570
mac_inputs=json.loads((mac/'source-sha256.json').read_text());phone_inputs=json.loads((phone/'source-sha256.json').read_text())
assert len(mac_inputs)==806 and all(phone_inputs.get(path)==digest for path,digest in mac_inputs.items())
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in phone_inputs.items())
previous=json.loads((root/'canonical-maintenance-prepared-core-mac/source-sha256.json').read_text())
fixture_paths=[path for path in mac_inputs if '/Fixtures/' in path]
assert fixture_paths and all(previous.get(path)==mac_inputs[path] for path in fixture_paths)
model_paths=[]
for path in mac_inputs:
 if '/Sources/PlannerCore/' not in path or not path.endswith('.swift'):continue
 source=(repository/path).read_text()
 if '@Model' not in source:continue
 model_paths.append(path)
 if path.endswith('/PlannerStore.swift'):
  original=subprocess.check_output(['git','show','70b2bed0:'+path],text=True)
  marker='extension PlannerSchemaV18.Item {'
  assert source[:source.index(marker)]==original[:original.index(marker)]
 else:assert previous[path]==mac_inputs[path]
adapter=root/'strict-membership-commands-adapter-mac'
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in json.loads((adapter/'execution.json').read_text()).values())
summary=json.loads((adapter/'test-summary.json').read_text());assert summary['passedTests']==6 and summary['failedTests']==0 and summary['skippedTests']==0
for phase in ['strict-membership-native-undo-navigation-phone','strict-membership-native-undo-ipad-dark']:
 packet=root/phase
 assert json.loads((packet/'exit.json').read_text())['exitCode']==0
 summary=json.loads((packet/'test-summary.json').read_text())
 assert summary['totalTestCount']==1 and summary['passedTests']==1 and summary['failedTests']==0 and summary['skippedTests']==0
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in json.loads((packet/'source-sha256.json').read_text()).items())
 screenshots=json.loads((packet/'screenshot-sha256.json').read_text());assert len(screenshots)==2
 assert all(hashlib.sha256((packet/'screenshots'/value['file']).read_bytes()).hexdigest()==value['sha256'] for value in screenshots)
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in json.loads((adapter/'source-sha256.json').read_text()).items())
mobile_products=json.loads((root/'strict-membership-native-undo-ipad-dark/mobile-app-share-products.json').read_text())
assert len(mobile_products)==6 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in mobile_products.items())
removed=[]
phases=['strict-membership-remove-command-first','strict-membership-remove-undo-first','strict-membership-remove-evidence-wired','strict-membership-add-evidence-first','strict-membership-unaware-add-first','strict-membership-sole-unaware-add-first','strict-membership-commands-canonical-mac','strict-membership-commands-canonical-phone']
for phase in phases:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text());assert disposition['success'];removed+=disposition['removedDirectories']
assert len(removed)==len(set(removed))==1194
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=sorted(path for path in files if path.endswith('.swift'))
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':195,'invocationsPerPlatform':570,'suitesPerPlatform':79,'matchedCoreInputs':806,'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixture_paths),'preservedModelSourceFiles':len(model_paths),'versionOneModelAndReceiptClassBodiesUnchanged':True,'macHTTPStatusFunctions':6,'macAppShareFixtureBuildsPassed':True,'nativeUndoJourneys':2,'inspectedOriginalScreenshots':4,'mobileAppShareProducts':6,'strictFormatFiles':len(files),'removedClosedDisposableStores':len(removed),'mcpExtraFixtureDeletionAttempted':False,'partiallyInformedGenerationsAndOtherCommandsQualified':False,'actualMacUIPhysicalCloudOrSystemInvocationQualified':False}
(root/'strict-membership-command-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'strict-membership-command-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
