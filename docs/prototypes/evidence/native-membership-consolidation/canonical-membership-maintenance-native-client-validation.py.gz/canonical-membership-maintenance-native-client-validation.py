from pathlib import Path
import gzip,hashlib,json
repository=Path.cwd()
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
core=json.loads((root/'canonical-membership-maintenance-lifetime-final-mac/source-sha256.json').read_text())
mac=root/'canonical-membership-maintenance-adapter-final-mac'
phone=root/'canonical-membership-maintenance-final-phone-app'
fixture=root/'canonical-membership-maintenance-final-phone-fixture'
execution=json.loads((mac/'execution.json').read_text())
assert set(execution)=={'build-for-testing','fixture-build','test-without-building'}
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in execution.values())
summary=json.loads((mac/'test-summary.json').read_text())
assert summary['passedTests']==summary['totalTestCount']==4 and summary['failedTests']==summary['skippedTests']==0
manifests=[]
products={}
for packet in [mac,phone,fixture]:
 manifest=json.loads((packet/'source-sha256.json').read_text())
 source_root=Path(json.loads((packet/'source-root.json').read_text())['root'])
 assert {name:digest for name,digest in manifest.items() if name.startswith('Packages/PlannerCore/')}==core
 assert all(hashlib.sha256((source_root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
 assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
 manifests.append(manifest)
 if packet==mac: product_file='test-without-building-product-sha256.json'
 else:
  product_file='product-sha256.json'
  result=json.loads((packet/'execution.json').read_text())
  assert result['exitCode']==0 and not result['timedOut'] and result['frozenInputsUnchanged'] and result['workspaceInputsUnchanged']
 binaries=json.loads((packet/product_file).read_text())
 assert binaries and all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in binaries.items())
 products[packet.name]=len(binaries)
assert manifests[0]==manifests[1]==manifests[2]
assert len(manifests[0])==1142
for packet,filename in [(mac,'fixture-build.log.gz'),(fixture,'build.log.gz')]:
 assert 'PlannerChangeObservationFixtureView.swift' in gzip.decompress((packet/filename).read_bytes()).decode()
assert 'SavedPlannerStore.swift' in gzip.decompress((phone/'build.log.gz').read_bytes()).decode()
report={'nativeAdapterFunctionsPassed':4,'failedFunctions':0,'skippedFunctions':0,'sqliteLifetimeDiagnostics':0,'projectInputsPerNativeClient':1142,'sharedCoreInputs':len(core),'nativeClientInputsMatch':True,'workspaceDifferences':[],'stagedDifferences':[],'actualProductDifferences':[],'recordedProducts':products,'macAppShareAndFixtureCompiled':True,'iPhoneAppShareAndFixtureCompiled':True,'changedObservationFixtureCompiledBothPlatforms':True,'confirmedStaleSchemaTestCorrected':True,'productionMCPReadSchemaUnchangedFromBase':True,'actualSystemShortcutsInvocationQualified':False,'positiveNativeMaintenanceRetryUIJourneyQualified':False}
(root/'canonical-membership-maintenance-native-client-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'canonical-membership-maintenance-native-client-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
