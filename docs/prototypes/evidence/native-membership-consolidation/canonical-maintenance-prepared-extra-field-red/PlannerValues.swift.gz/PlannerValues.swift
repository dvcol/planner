import Foundation

public struct PlannerStorageConfiguration: Sendable {
  public enum ProcessRole: Sendable { case mainApplication, shareExtension }
  public enum StorageMode: Sendable { case localOnly }

  public let storeURL: URL
  public let controlURL: URL
  public let recoveryDirectoryURL: URL
  public let processRole: ProcessRole
  public let storageMode: StorageMode

  public init(
    storeURL: URL, controlURL: URL, recoveryDirectoryURL: URL,
    processRole: ProcessRole, storageMode: StorageMode
  ) {
    self.storeURL = storeURL
    self.controlURL = controlURL
    self.recoveryDirectoryURL = recoveryDirectoryURL
    self.processRole = processRole
    self.storageMode = storageMode
  }
}

public struct PlannerDatasetSession: Sendable, Equatable {
  public let datasetId: UUID
  public let sessionId: UUID
  /// Opaque ownership identity for account-scoped device preferences; never an account selector.
  public let ownershipBinding: String
  let epochId: UUID
}

public struct PlannerFailure: Error, Sendable, Equatable {
  public let code: String
  public let propertyPath: String?
  public let message: String
  public let details: PlannerFailureDetails?

  init(
    _ code: String, _ message: String, propertyPath: String? = nil,
    details: PlannerFailureDetails? = nil
  ) {
    self.code = code
    self.propertyPath = propertyPath
    self.message = message
    self.details = details
  }
}

public enum PlannerItemFieldValue: Sendable, Equatable {
  case string(String)
  case optionalString(String?)
  case optionalLocation(PlannerOwnedLocation?)
  case optionalEstimate(PlannerEstimate?)
  case links([PlannerOwnedLinkRead])
  case identitySet(Set<UUID>)
}

public enum PlannerFailureDetails: Sendable, Equatable {
  case staleReview
  case staleSnapshot(requestedGeneration: UUID, currentGeneration: UUID?)
  case staleEdit(
    conflictingFields: [PlannerItemField], currentValues: [PlannerItemField: PlannerItemFieldValue],
    currentFieldHashes: [PlannerItemField: PlannerFieldHash]
  )
  case staleItineraryEdit(
    conflictingFields: [PlannerItineraryField],
    currentValues: [PlannerItineraryField: PlannerItineraryFieldValue],
    currentFieldHashes: [PlannerItineraryField: PlannerFieldHash])
  case staleScheduleEdit(currentForm: PlannerScheduleForm, currentFormHash: PlannerFieldHash)
  case staleListEdit(
    conflictingFields: [PlannerListField], currentValues: [PlannerListField: PlannerListFieldValue],
    currentFieldHashes: [PlannerListField: PlannerFieldHash])
  case staleCategoryEdit(
    conflictingFields: [PlannerCategoryField],
    currentValues: [PlannerCategoryField: PlannerCategoryFieldValue],
    currentFieldHashes: [PlannerCategoryField: PlannerFieldHash])
  case staleTagEdit(
    conflictingFields: [PlannerTagField],
    currentValues: [PlannerTagField: PlannerTagFieldValue],
    currentFieldHashes: [PlannerTagField: PlannerFieldHash])
}

public enum PlannerBootstrapResult: Sendable {
  case ready(PlannerDatasetSession)
  case mainAppSetupRequired
  case mainAppMigrationRequired
  case unavailable(PlannerFailure)
}

public enum PlannerEntityKind: String, Sendable, Codable {
  case item, list, itinerary, category, tag, schedule
}

public struct PlannerEntityReference: Sendable, Codable, Hashable {
  public let kind: PlannerEntityKind
  public let id: UUID

  public init(kind: PlannerEntityKind, id: UUID) {
    self.kind = kind
    self.id = id
  }
}

public struct PlannerCoordinate: Sendable, Codable, Equatable {
  public let latitude: Double
  public let longitude: Double

  public init(latitude: Double, longitude: Double) {
    self.latitude = latitude
    self.longitude = longitude
  }
}

public struct PlannerOwnedLocation: Sendable, Codable, Equatable {
  public let displayName: String?
  public let formattedAddress: String?
  public let coordinate: PlannerCoordinate?

  public init(displayName: String?, formattedAddress: String?, coordinate: PlannerCoordinate?) {
    self.displayName = displayName
    self.formattedAddress = formattedAddress
    self.coordinate = coordinate
  }

  private enum CodingKeys: String, CodingKey { case displayName, formattedAddress, coordinate }

  public func encode(to encoder: any Encoder) throws {
    var fields = encoder.container(keyedBy: CodingKeys.self)
    try fields.encode(displayName, forKey: .displayName)
    try fields.encode(formattedAddress, forKey: .formattedAddress)
    try fields.encode(coordinate, forKey: .coordinate)
  }
}

public enum PlannerEstimateUnit: String, Sendable, Codable {
  case minute, hour, day, week, month, year
}

public struct PlannerEstimate: Sendable, Codable, Equatable {
  public let minutes: Int64
  public let displayUnit: PlannerEstimateUnit

  public init(minutes: Int64, displayUnit: PlannerEstimateUnit) {
    self.minutes = minutes
    self.displayUnit = displayUnit
  }
}

public struct PlannerLinkInput: Sendable, Equatable {
  public let linkId: UUID?
  public let originalUrl: String
  public let label: String?

  public init(linkId: UUID? = nil, originalUrl: String, label: String? = nil) {
    self.linkId = linkId
    self.originalUrl = originalUrl
    self.label = label
  }
}

public struct PlannerItemContentInput: Sendable, Equatable {
  public let title: String
  public let subtitle: String?
  public let notes: String?
  public let location: PlannerOwnedLocation?
  public let estimate: PlannerEstimate?
  public let links: [PlannerLinkInput]
  public let categoryIds: Set<UUID>
  public let tagIds: Set<UUID>

  public init(
    title: String, subtitle: String? = nil, notes: String? = nil,
    location: PlannerOwnedLocation? = nil, estimate: PlannerEstimate? = nil,
    links: [PlannerLinkInput] = [], categoryIds: Set<UUID> = [], tagIds: Set<UUID> = []
  ) {
    self.title = title
    self.subtitle = subtitle
    self.notes = notes
    self.location = location
    self.estimate = estimate
    self.links = links
    self.categoryIds = categoryIds
    self.tagIds = tagIds
  }
}

public enum PlannerCommand: Sendable {
  case applyCapture(
    draftId: UUID, draftGeneration: UUID, choice: PlannerCaptureChoice, listIds: Set<UUID>)
  case applyImport(
    backup: PlannerDecodedBackup, mode: PlannerImportMode = .skip, restoreDeletedData: Bool = false)
  case restoreRecovery(selection: PlannerRecoverySelection, mode: PlannerImportMode = .skip)
  case deleteSource(source: PlannerEntityReference)
  case createItem(content: PlannerItemContentInput, listId: UUID? = nil)
  case createList(content: PlannerListContentInput)
  case createItinerary(content: PlannerItineraryContentInput)
  case addItineraryEntry(
    itineraryId: UUID, source: PlannerEntityReference, placement: PlannerPlacement)
  case removeItineraryEntry(itineraryId: UUID, entryId: UUID)
  case reorderItineraryEntry(itineraryId: UUID, entryId: UUID, placement: PlannerPlacement)
  case editItinerary(
    sourceId: UUID, changes: PlannerItineraryChanges,
    expectedFieldHashes: [PlannerItineraryField: PlannerFieldHash])
  case createCategory(content: PlannerCategoryContentInput)
  case createTag(content: PlannerTagContentInput)
  case editCategory(
    sourceId: UUID, changes: PlannerCategoryChanges,
    expectedFieldHashes: [PlannerCategoryField: PlannerFieldHash])
  case editTag(
    sourceId: UUID, changes: PlannerTagChanges,
    expectedFieldHashes: [PlannerTagField: PlannerFieldHash])
  case addMembership(itemId: UUID, listId: UUID, placement: PlannerPlacement)
  case removeMembership(listId: UUID, membershipId: UUID)
  case restoreAssociation(snapshot: PlannerAssociationUndoSnapshot)
  case moveMembership(
    listId: UUID, membershipId: UUID, destinationListId: UUID, placement: PlannerPlacement)
  case reorderMembership(listId: UUID, membershipId: UUID, placement: PlannerPlacement)
  case editList(
    sourceId: UUID, changes: PlannerListChanges,
    expectedFieldHashes: [PlannerListField: PlannerFieldHash])
  case createSchedule(source: PlannerEntityReference, form: PlannerScheduleForm)
  case editSchedule(
    scheduleId: UUID, changes: PlannerScheduleChanges,
    expectedFieldHashes: [PlannerScheduleField: PlannerFieldHash])
  case changeScheduleZone(
    scheduleId: UUID, planningTimeZone: String,
    expectedFieldHashes: [PlannerScheduleField: PlannerFieldHash])
  case removeSchedule(scheduleId: UUID)
  case setCompletion(scope: PlannerCompletionScope, done: Bool)
  case setBulkCompletion(scope: PlannerBulkScope, done: Bool)
  case setArchive(source: PlannerEntityReference, archived: Bool)
  case editItem(
    sourceId: UUID, changes: PlannerItemChanges,
    expectedFieldHashes: [PlannerItemField: PlannerFieldHash])
}

public enum PlannerCompletionScope: Sendable {
  case globalItem(itemId: UUID)
  case appearance(PlannerAppearance)
}

public enum PlannerFieldChange<Value: Sendable>: Sendable {
  case unchanged
  case set(Value)
  case clear
}

public struct PlannerItemChanges: Sendable {
  public let title: PlannerFieldChange<String>
  public let subtitle: PlannerFieldChange<String>
  public let notes: PlannerFieldChange<String>
  public let location: PlannerFieldChange<PlannerOwnedLocation>
  public let estimate: PlannerFieldChange<PlannerEstimate>
  public let links: PlannerFieldChange<[PlannerLinkInput]>
  public let categoryIds: PlannerFieldChange<Set<UUID>>
  public let tagIds: PlannerFieldChange<Set<UUID>>

  public init(
    title: PlannerFieldChange<String> = .unchanged,
    subtitle: PlannerFieldChange<String> = .unchanged,
    notes: PlannerFieldChange<String> = .unchanged,
    location: PlannerFieldChange<PlannerOwnedLocation> = .unchanged,
    estimate: PlannerFieldChange<PlannerEstimate> = .unchanged,
    links: PlannerFieldChange<[PlannerLinkInput]> = .unchanged,
    categoryIds: PlannerFieldChange<Set<UUID>> = .unchanged,
    tagIds: PlannerFieldChange<Set<UUID>> = .unchanged
  ) {
    self.title = title
    self.subtitle = subtitle
    self.notes = notes
    self.location = location
    self.estimate = estimate
    self.links = links
    self.categoryIds = categoryIds
    self.tagIds = tagIds
  }
}

public struct PlannerReviewToken: Sendable {
  let reviewId: UUID

  public var opaqueValue: String { reviewId.uuidString }

  public init?(opaqueValue: String) {
    guard let reviewId = UUID(uuidString: opaqueValue) else { return nil }
    self.reviewId = reviewId
  }

  init(reviewId: UUID) { self.reviewId = reviewId }
}

public struct PlannerOperation: Sendable {
  public let operationId: UUID
  public let session: PlannerDatasetSession
  public let command: PlannerCommand
  public let reviewToken: PlannerReviewToken?

  public init(
    operationId: UUID, session: PlannerDatasetSession, command: PlannerCommand,
    reviewToken: PlannerReviewToken? = nil
  ) {
    self.operationId = operationId
    self.session = session
    self.command = command
    self.reviewToken = reviewToken
  }
}

public enum PlannerRecoveryResult: Sendable {
  case complete(checkpointGeneration: Int64)
  case incomplete(PlannerFailure)
}

public struct PlannerOperationResult: Sendable {
  public enum Outcome: Sendable {
    case rejected(PlannerFailure)
    case applied(result: PlannerAppliedResult, recovery: PlannerRecoveryResult)
    case unverified(PlannerProposalSummary)
  }

  public let operationId: UUID
  public let outcome: Outcome
  public let associationUndoSnapshot: PlannerAssociationUndoSnapshot?

  init(
    operationId: UUID, outcome: Outcome,
    associationUndoSnapshot: PlannerAssociationUndoSnapshot? = nil
  ) {
    self.operationId = operationId
    self.outcome = outcome
    self.associationUndoSnapshot = associationUndoSnapshot
  }
}

public enum PlannerOperationStatus: Sendable {
  case knownUnapplied(PlannerFailure)
  case preparedUnverified(PlannerProposalSummary)
  case appliedRecoveryIncomplete(result: PlannerAppliedResult, reason: PlannerFailure)
  case appliedRecoveryComplete(result: PlannerAppliedResult, checkpointGeneration: Int64)
  case noReliableEvidence
  case unavailable(PlannerFailure)
}

public enum PlannerItemField: String, Sendable, CaseIterable {
  case title, subtitle, notes, location, estimate, links, categoryIds, tagIds
}

public struct PlannerFieldHash: Sendable, Equatable {
  public let value: String

  public init(value: String) {
    self.value = value
  }
}

public struct PlannerItemContent: Sendable {
  public let title: String
  public let subtitle: String?
  public let notes: String?
  public let location: PlannerOwnedLocation?
  public let estimate: PlannerEstimate?
  public let links: [PlannerOwnedLinkRead]
  public let categoryIds: Set<UUID>
  public let tagIds: Set<UUID>
}

public struct PlannerOwnedLinkRead: Sendable, Equatable {
  public let linkId: UUID
  public let originalUrl: String
  public let label: String?
  public let kind: PlannerLinkKind
  public let providerReference: PlannerProviderReference?
}

public enum PlannerLinkKind: String, Sendable, Codable {
  case appleMaps, googleMaps, tabelog, website, booking, generic
}

public struct PlannerProviderReference: Sendable, Codable, Equatable {
  public enum Kind: String, Sendable, Codable { case applePlaceId }
  public let kind: Kind
  public let value: String
}

public enum PlannerReferenceRead: Sendable, Hashable {
  case expandedCompletion(itineraryId: UUID, listEntryId: UUID, membershipId: UUID)
  case itineraryEntry(id: UUID, itinerary: PlannerEntityReference, source: PlannerEntityReference)
  case membership(id: UUID, list: PlannerEntityReference, item: PlannerEntityReference)
  case ownedLink(id: UUID, owner: PlannerEntityReference)
  case schedule(id: UUID, source: PlannerEntityReference)
  case labelAssociation(id: UUID, owner: PlannerEntityReference, label: PlannerEntityReference)
}

public enum PlannerSourceRead: Sendable {
  case itinerary(PlannerItinerarySourceRead)
  case list(PlannerListSourceRead)
  case item(PlannerItemSourceRead)
  case schedule(PlannerScheduleSourceRead)
  case category(PlannerCategorySourceRead)
  case tag(PlannerTagSourceRead)
}

public struct PlannerLabelRead: Sendable, Equatable {
  public let reference: PlannerEntityReference
  public let name: String
  public let color: PlannerColor?
  public let iconName: String?
}

public struct PlannerItemSourceRead: Sendable {
  public let source: PlannerEntityReference
  public let sourceLifetimeId: UUID
  public let content: PlannerItemContent
  public let createdAt: Date
  public let updatedAt: Date
  public let fieldHashes: [PlannerItemField: PlannerFieldHash]
  public let state: PlannerSourceState
  public let labels: [PlannerLabelRead]
  public let references: [PlannerReferenceRead]
}

public struct PlannerSourceState: Sendable {
  public let globalDone: Bool?
  public let archived: Bool?
}

public enum PlannerReadRequest: Sendable {
  case status
  case source(PlannerEntityReference)
  case appearance(PlannerAppearance)
  case rows(generation: UUID, offset: Int64, limit: Int64)
  case mapRows(generation: UUID, offset: Int64, limit: Int64)
  case calendarRows(generation: UUID, offset: Int64, limit: Int64)
}

public enum PlannerReadResult: Sendable {
  case status(PlannerNativeStatusRead)
  case source(PlannerSourceRead)
  case appearance(PlannerAppearanceRead)
  case rows(PlannerRowWindow)
  case mapRows(PlannerMapRowWindow)
  case calendarRows(PlannerCalendarRowWindow)
  case failed(PlannerFailure)
}

public struct PlannerQuery: Sendable {
  public let session: PlannerDatasetSession
  public let request: PlannerQueryRequest

  public init(session: PlannerDatasetSession, request: PlannerQueryRequest) {
    self.session = session
    self.request = request
  }
}

public enum PlannerQueryRequest: Sendable {
  case items(PlannerItemQuery)
  case catalog(PlannerCatalogQuery)
  case calendar(PlannerCalendarQuery)
}

public struct PlannerCatalogQuery: Sendable {
  public struct Sort: Sendable {
    public enum Mode: String, Sendable { case title, created, lastUpdated, fullEstimate }
    public enum Direction: String, Sendable { case ascending, descending }
    public let mode: Mode
    public let direction: Direction

    public init(mode: Mode = .title, direction: Direction = .ascending) {
      self.mode = mode
      self.direction = direction
    }
  }
  public let sourceKind: PlannerEntityKind
  public let text: String
  public let archive: PlannerItemQuery.Archive
  public let sort: Sort?

  public init(
    sourceKind: PlannerEntityKind, text: String = "", archive: PlannerItemQuery.Archive = .active,
    sort: Sort? = nil
  ) {
    self.sourceKind = sourceKind
    self.text = text
    self.archive = archive
    self.sort = sort
  }
}

public struct PlannerItemQuery: Sendable {
  public enum Scope: Sendable {
    case global, inbox
    case list(UUID)
    case itinerary(UUID)
  }
  public enum Completion: Sendable { case todo, done, all }
  public enum Archive: Sendable { case active, archived, all }
  public enum Scheduling: String, Sendable { case scheduled, unscheduled, all }
  public struct IdentityGroup: Sendable {
    public enum Match: String, Sendable { case any, all }
    public let ids: Set<UUID>
    public let match: Match

    public init(ids: Set<UUID>, match: Match = .any) {
      self.ids = ids
      self.match = match
    }

    func matches(_ selectedIdentifiers: Set<UUID>) -> Bool {
      guard !ids.isEmpty else { return true }
      switch match {
      case .any: return !ids.isDisjoint(with: selectedIdentifiers)
      case .all: return ids.isSubset(of: selectedIdentifiers)
      }
    }
  }
  public struct Duration: Sendable {
    public let minimumMinutes: Int64?
    public let maximumMinutes: Int64?
    public let includeUnknown: Bool

    public init(
      minimumMinutes: Int64? = nil, maximumMinutes: Int64? = nil, includeUnknown: Bool = false
    ) {
      self.minimumMinutes = minimumMinutes
      self.maximumMinutes = maximumMinutes
      self.includeUnknown = includeUnknown
    }
  }
  public struct Sort: Sendable {
    public enum Mode: String, Sendable { case title, created, lastUpdated, duration, manual }
    public enum Direction: String, Sendable { case ascending, descending }
    public let mode: Mode
    public let direction: Direction

    public init(mode: Mode = .title, direction: Direction = .ascending) {
      self.mode = mode
      self.direction = direction
    }
  }
  public let scope: Scope
  public let text: String
  public let completion: Completion
  public let archive: Archive
  public let categories: IdentityGroup?
  public let tags: IdentityGroup?
  public let lists: IdentityGroup?
  public let duration: Duration?
  public let hasAddress: Bool
  public let hasLinks: Bool
  public let scheduled: Scheduling
  public let sort: Sort
  public let rowPresentation: PlannerRowPresentationContext?

  public init(
    scope: Scope = .global, text: String = "", completion: Completion = .todo,
    archive: Archive = .active, categories: IdentityGroup? = nil, tags: IdentityGroup? = nil,
    lists: IdentityGroup? = nil,
    duration: Duration? = nil,
    hasAddress: Bool = false, hasLinks: Bool = false, scheduled: Scheduling = .all,
    sort: Sort = Sort(), rowPresentation: PlannerRowPresentationContext? = nil
  ) {
    self.scope = scope
    self.text = text
    self.completion = completion
    self.archive = archive
    self.categories = categories
    self.tags = tags
    self.lists = lists
    self.duration = duration
    self.hasAddress = hasAddress
    self.hasLinks = hasLinks
    self.scheduled = scheduled
    self.sort = sort
    self.rowPresentation = rowPresentation
  }
}

public enum PlannerRowIdentity: Sendable, Equatable {
  case source(PlannerEntityReference)
  case appearance(source: PlannerEntityReference, appearance: PlannerAppearance)
}

public struct PlannerQuerySnapshot: Sendable {
  public let session: PlannerDatasetSession
  public let generation: UUID
  public let rows: [PlannerRowIdentity]
  public let matchingCount: Int64
  public let rowPresentation: PlannerRowPresentationContext?
  public let progress: [PlannerContainerProgress]
  public let unresolvedReferences: [PlannerReferenceRead]
}

public enum PlannerQueryResult: Sendable {
  case snapshot(PlannerQuerySnapshot)
  case failed(PlannerFailure)
}

public enum PlannerRecoveryRequest: Sendable {
  case namespaces
  case namespace(namespaceId: UUID)
  case acknowledgedSnapshot(namespaceId: UUID, checkpointGeneration: Int64)
  case proposal(namespaceId: UUID, proposalId: UUID)
}

public struct PlannerSnapshotSummary: Sendable {
  public let storageSchemaVersion: Int64
  public let portableFormatVersion: Int
  public let checkpointGeneration: Int64
  public let integrity: String
}

public struct PlannerProposalSummary: Sendable {
  public let proposalId: UUID
  public let originalOperationId: UUID
  public let evidence: String
  public let requiresFreshReview: Bool
}

public struct PlannerPreparedMaintenanceSummary: Sendable {
  public let maintenanceId: UUID
  public let evidence: String
  public let requiresFreshReview: Bool
}

public struct PlannerRecoveryView: Sendable {
  public enum Availability: Sendable { case available, unavailable, ownershipUnverified }
  public let namespaceId: UUID
  public let datasetId: UUID
  public let ownershipDescription: String?
  public let acknowledgedSnapshot: PlannerSnapshotSummary?
  public let preparedProposals: [PlannerProposalSummary]
  public let preparedMaintenance: [PlannerPreparedMaintenanceSummary]
  public let availability: Availability
}

public struct PlannerRecoverySelection: Sendable {
  public enum Evidence: Sendable { case acknowledgedSnapshot, preparedUnverified }
  public let selectionId: UUID
  public let namespaceId: UUID
  public let datasetId: UUID
  public let ownershipBinding: String
  public let evidence: Evidence
  public let checkpointGeneration: Int64?
  public let proposalId: UUID?
  public let originalOperationId: UUID?
  public let portableData: Data
  public let decodedBackup: PlannerDecodedBackup
}

public enum PlannerRecoveryInspection: Sendable {
  case listedNamespaces([PlannerRecoveryView])
  case listed(PlannerRecoveryView)
  case selected(PlannerRecoverySelection)
  case failed(PlannerFailure)
}

public struct PlannerDecodedBackup: Sendable {
  public let backup: PlannerPortableBackup
  public let externalBindings: [PlannerBoundSource]
  public let originPaths: [PlannerBindingPath]

  init(
    backup: PlannerPortableBackup, externalBindings: [PlannerBoundSource] = [],
    originPaths: [PlannerBindingPath] = []
  ) {
    self.backup = backup
    self.externalBindings = externalBindings
    self.originPaths = originPaths
  }
}

public struct PlannerPortableBackup: Sendable {
  public let formatVersion: Int
  public let labelAssociations: [PlannerPortableLabelAssociation]
  public var items: [PlannerPortableItem] {
    sources.compactMap {
      if case .item(let item) = $0 { return item }
      return nil
    }
  }

  public var lists: [PlannerPortableList] {
    sources.compactMap {
      if case .list(let list) = $0 { return list }
      return nil
    }
  }

  public let sources: [PlannerPortableSource]
  public let memberships: [PlannerPortableMembership]
  public let itineraryEntries: [PlannerPortableItineraryEntry]
  public let expandedCompletions: [PlannerPortableExpandedCompletion]
  public let schedules: [PlannerPortableSchedule]
  public let deletionMarkers: [PlannerPortableDeletionMarker]
  public let ownedLinks: [PlannerPortableOwnedLink]
  public let contextAliases: [PlannerPortableContextAlias]
  public let completionChanges: [PlannerPortableCompletionChange]
  public let restorationFamilies: [PlannerPortableRestorationFamily]
  public let membershipProvenance: [PlannerPortableMembershipProvenance]
  public let membershipRemovals: [PlannerPortableMembershipRemoval]

  init(
    sources: [PlannerPortableSource], labelAssociations: [PlannerPortableLabelAssociation],
    memberships: [PlannerPortableMembership],
    itineraryEntries: [PlannerPortableItineraryEntry],
    expandedCompletions: [PlannerPortableExpandedCompletion],
    schedules: [PlannerPortableSchedule] = [],
    deletionMarkers: [PlannerPortableDeletionMarker],
    ownedLinks: [PlannerPortableOwnedLink] = [],
    contextAliases: [PlannerPortableContextAlias] = [],
    completionChanges: [PlannerPortableCompletionChange] = [],
    restorationFamilies: [PlannerPortableRestorationFamily] = [],
    formatVersion: Int = 2,
    membershipProvenance: [PlannerPortableMembershipProvenance] = [],
    membershipRemovals: [PlannerPortableMembershipRemoval] = []
  ) {
    self.formatVersion = formatVersion
    self.sources = sources
    self.labelAssociations = labelAssociations
    self.memberships = memberships
    self.itineraryEntries = itineraryEntries
    self.expandedCompletions = expandedCompletions
    self.schedules = schedules
    self.deletionMarkers = deletionMarkers
    self.ownedLinks = ownedLinks
    self.contextAliases = contextAliases
    self.completionChanges = completionChanges
    self.restorationFamilies = restorationFamilies
    self.membershipProvenance = membershipProvenance
    self.membershipRemovals = membershipRemovals
  }
}

public struct PlannerPortableItem: Sendable {
  public let kind: PlannerEntityKind
  public let id: UUID
  public let lifetimeId: UUID
  public let createdAt: Date
  public let updatedAt: Date
  public let content: PlannerItemContent
  public let globalDone: Bool
  public let archived: Bool
  public let contentOrigins: [String: String]
}
