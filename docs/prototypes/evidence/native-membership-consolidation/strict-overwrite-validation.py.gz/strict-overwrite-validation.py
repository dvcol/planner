from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'strict-overwrite-resolved-final-mac';phone=root/'strict-overwrite-resolved-final-phone';adapter=root/'strict-overwrite-final-adapter-mac'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert len(execution['cases'])==238 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==238 and sum(signatures[0].values())==676,(len(signatures[0]),sum(signatures[0].values()))
mac_inputs=json.loads((mac/'source-sha256.json').read_text());phone_inputs=json.loads((phone/'source-sha256.json').read_text());adapter_inputs=json.loads((adapter/'source-sha256.json').read_text())
assert len(mac_inputs)==808 and all(phone_inputs.get(path)==digest and adapter_inputs.get(path)==digest for path,digest in mac_inputs.items())
for inputs in [mac_inputs,phone_inputs,adapter_inputs]:assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
previous=json.loads((root/'strict-capture-final-mac/source-sha256.json').read_text())
fixtures=[path for path in previous if '/Fixtures/' in path]
assert len(fixtures)==513 and all(previous[path]==mac_inputs[path] for path in fixtures)
models=[path for path in mac_inputs if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(models)==19 and all(previous[path]==mac_inputs[path] for path in models)
for name in ['NativeImportCompetingValuesTests.swift','NativeImportCompetingValueKindsTests.swift']:
 path='Packages/PlannerCore/Tests/PlannerCoreStoreTests/'+name
 assert previous[path]==mac_inputs[path]
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in json.loads((adapter/'execution.json').read_text()).values())
summary=json.loads((adapter/'test-summary.json').read_text());assert summary['passedTests']==6 and summary['failedTests']==0 and summary['skippedTests']==0
products=json.loads((adapter/'test-without-building-product-sha256.json').read_text())
assert products and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
for suffix in ['/Planner.app/','/PlannerShareMac.appex/','/PlannerFixtures.app/']:assert any(suffix in path for path in products)
removed=[]
for phase in ['strict-overwrite-removal-first','strict-overwrite-foreign-closure-first','strict-overwrite-owned-regression-local','strict-overwrite-evidence-first','strict-overwrite-compatibility-first','strict-overwrite-resolved-bindings-fixed','strict-overwrite-resolved-final-mac','strict-overwrite-resolved-final-phone']:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text());assert disposition['success'];removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=sorted(path for path in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if path.endswith('.swift'))
assert len(files)==7
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
literal=json.loads((repository/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation/strict-overwrite-fingerprint-v3.json').read_text())
import base64
payload=base64.b64decode(literal['payloadBase64'])
assert literal['payloadDigest']=='sha256-payload-v3:'+hashlib.sha256(payload).hexdigest()
assert literal['payloadDigest']=='sha256-payload-v3:96b81ccd106cdb596ff00fbb5c40d1939281eae8a4dd9e800d3e41cade9f16a7'
(root/'strict-overwrite-literal-producer.py.gz').write_bytes(gzip.compress(Path('/private/tmp/PlannerProduceStrictOverwriteLiteral.py').read_bytes(),mtime=0))
report={'functionsPerPlatform':238,'invocationsPerPlatform':676,'suitesPerPlatform':83,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixtures),'newIndependentFingerprintFixtureInputs':1,'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'realMacHTTPFunctions':6,'macAppShareFixtureBuildsPassed':True,'competingValueTestExpectationsUnchanged':True,'removedClosedDisposableStores':len(removed),'newFingerprint':literal['payloadDigest'],'legacyRestorationFingerprint':'sha256-payload-v2:287439f4fb9ec1a01410bbb65122c0bd4047170e7740dcd8047d420930244b5b','preparationOnlyInputRemainsUnverified':True,'actualProcessInterruptionQualified':False,'nativeUIPhysicalCloudOrSystemInvocationQualified':False,'allMembershipCommandsQualified':False}
(root/'strict-overwrite-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'strict-overwrite-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
