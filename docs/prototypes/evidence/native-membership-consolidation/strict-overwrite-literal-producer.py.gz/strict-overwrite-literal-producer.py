from pathlib import Path
import base64,copy,hashlib,json,struct,uuid
root=Path('Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation')
legacy=json.loads((root/'operation-fingerprint-literals.json').read_text())
def encode(value):
 kind,content=value
 if kind=='string':
  data=content.encode(); return b'\x10'+struct.pack('>Q',len(data))+data
 if kind=='boolean':return b'\x11'+bytes([int(content)])
 if kind=='integer':return b'\x12'+struct.pack('>q',content)
 if kind=='date':return b'\x19'+struct.pack('>d',content)
 if kind=='identity':return b'\x14'+uuid.UUID(content).bytes
 if kind=='optional':return b'\x15'+bytes([content is not None])+(encode(content) if content is not None else b'')
 if kind in ['ordered','identitySet']:
  values=[encode(element) for element in content]
  if kind=='identitySet':values.sort()
  return bytes([0x16 if kind=='ordered' else 0x17])+struct.pack('>Q',len(values))+b''.join(values)
 if kind=='record':
  result=b'\x18'+struct.pack('>Q',len(content))
  for name in sorted(content):
   data=name.encode();result+=struct.pack('>Q',len(data))+data+encode(content[name])
  return result
 raise ValueError(kind)
for case in legacy['cases']:
 assert base64.b64decode(case['payloadBase64'])==b'PlannerOperationPayload'+b'\x00'+struct.pack('>I',case['version'])+encode(case['canonicalValue']),case['name']
def record(value):return ['record',value]
def binding(value):return record({key:[('string' if key=='kind' else 'identity'),value[key]] for key in ['kind','id','lifetimeId']})
def evidence(value):return record({'membership':binding({'kind':'membership','id':value['membershipId'],'lifetimeId':value['membershipLifetimeId']}),'list':binding(value['list']),'item':binding(value['item']),'observedRemovalIds':['identitySet',[['identity',item] for item in value['observedRemovalIds']]]})
original=json.loads((root/'informed-readd-v3.json').read_text())
incoming=copy.deepcopy(original)
incoming['memberships']=[]
incoming['membershipProvenance']=incoming['membershipProvenance'][:1]
backup=copy.deepcopy(legacy['cases'][1]['canonicalValue'][1]['reviewedCurrentData'][1])
backup['formatVersion']=['integer',3]
sources=[]
for source in incoming['sources']:
 fields={'createdAt':['date',source['createdAt']],'updatedAt':['date',source['updatedAt']],'contentOrigins':record({key:['string',value] for key,value in source['contentOrigins'].items()}),'archived':['boolean',False]}
 if source['kind']=='item':
  fields.update({'title':['string','Hotel'],'notes':['optional',['string','A shared stop']],'subtitle':['optional',None],'location':['optional',None],'estimate':['optional',record({'minutes':['integer',30],'displayUnit':['string','minute']})],'globalDone':['boolean',False]})
 else:
  fields.update({'name':['string','Tokyo'],'notes':['optional',None],'color':['optional',None],'iconName':['optional',None],'manualEstimate':['optional',None],'globalDone':['optional',None]})
 sources.append(record({'identity':binding(source),'fields':record(fields)}))
backup['sources']=['ordered',sources]
backup['deletionMarkers']=['ordered',[record({'deletionId':['identity',marker['deletionId']],'operationId':['identity',marker['operationId']],'target':binding(marker['target']),'closedFamilyId':['optional',None]}) for marker in incoming['deletionMarkers']]]
backup['membershipProvenance']=['ordered',[record({'membershipId':['identity',value['membershipId']],'membershipLifetimeId':['identity',value['membershipLifetimeId']],'list':binding(value['list']),'item':binding(value['item']),'observedRemovalIds':['identitySet',[]]}) for value in incoming['membershipProvenance']]]
backup['membershipRemovals']=['ordered',[record({'deletionId':['identity',value['deletionId']]}) for value in incoming['membershipRemovals']]]
bindings=[binding(source) for source in incoming['sources']]+[binding({'kind':'membership','id':value['membershipId'],'lifetimeId':value['membershipLifetimeId']}) for value in original['membershipProvenance']]
value=record({'command':record({'type':['string','applyImport'],'backup':record(backup),'mode':['string','overwrite']}),'datasetId':['identity',legacy['identity']['datasetId']],'ownershipBinding':['string',legacy['identity']['ownershipBinding']],'resolvedBindings':['identitySet',bindings],'reviewedCurrentData':copy.deepcopy(legacy['cases'][1]['canonicalValue'][1]['reviewedCurrentData']),'resolvedMembershipEvidence':['ordered',[evidence(value) for value in original['membershipProvenance']]]})
payload=b'PlannerOperationPayload'+b'\x00'+struct.pack('>I',3)+encode(value)
result={'identity':legacy['identity'],'name':'strict-overwrite-membership-removal-v3','version':3,'incoming':incoming,'expectedMembershipEvidence':original['membershipProvenance'],'expectedBindings':[{'kind':source['kind'],'id':source['id'],'lifetimeId':source['lifetimeId']} for source in incoming['sources']]+[{'kind':'membership','id':value['membershipId'],'lifetimeId':value['membershipLifetimeId']} for value in original['membershipProvenance']],'canonicalValue':value,'payloadBase64':base64.b64encode(payload).decode(),'payloadDigest':'sha256-payload-v3:'+hashlib.sha256(payload).hexdigest()}
path=root/'strict-overwrite-fingerprint-v3.json'
assert not path.exists()
path.write_text(json.dumps(result,indent=2)+'\n')
print(result['payloadDigest'])
