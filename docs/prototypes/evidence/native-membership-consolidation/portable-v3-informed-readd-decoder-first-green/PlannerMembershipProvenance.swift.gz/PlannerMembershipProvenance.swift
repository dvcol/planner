import Foundation

public struct PlannerPortableMembershipProvenance: Sendable, Equatable, Codable {
  public let membershipId: UUID
  public let membershipLifetimeId: UUID
  public let list: PlannerBoundSource
  public let item: PlannerBoundSource
  public let observedRemovalIds: [UUID]
}

public struct PlannerPortableMembershipRemoval: Sendable, Equatable, Codable {
  public let deletionId: UUID
}
