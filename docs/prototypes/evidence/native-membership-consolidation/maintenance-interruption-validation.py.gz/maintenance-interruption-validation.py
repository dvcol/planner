from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();root=repository/'docs/prototypes/evidence/native-membership-consolidation'
packet=root/'maintenance-interruption-cohort-mac'
execution=json.loads((packet/'execution.json').read_text())
assert execution['exitCode']==0 and execution['sqliteUnlinkWarnings']==0 and len(execution['cases'])==22
assert all(not value['failures'] and not value['skipped'] for value in execution['cases'])
inputs=json.loads((packet/'source-sha256.json').read_text())
previous=json.loads((root/'strict-move-canonical-mac/source-sha256.json').read_text())
assert len(inputs)==len(previous)==807
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
production=[path for path in inputs if '/Sources/' in path]
assert all(inputs[path]==previous[path] for path in production)
assert [path for path in inputs if inputs[path]!=previous[path]]==['Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift']
products=json.loads((packet/'product-sha256.json').read_text());assert len(products)==2
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
found={}
for line in transcript.splitlines():
 match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
 if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
assert len(found)==22
removed=[]
for path in [root/'maintenance-interruption-runtime-first/fixture-disposition.json',packet/'fixture-disposition.json',packet/'child-fixture-disposition.json']:
 value=json.loads(path.read_text());assert value['success'];removed+=value['removedDirectories']
assert len(removed)==len(set(removed))
file='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift'
result=subprocess.run(['xcrun','swift-format','lint','--strict',file],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert result.returncode==0,result.stdout+result.stderr
subprocess.run(['git','diff','--check'],check=True)
report={'macFunctions':22,'macInvocations':sum(found.values()),'macSuites':4,'verifiedProducts':2,'matchedProductionInputs':len(production),'testOnlySourceFileChanged':file,'sourceInputs':len(inputs),'removedClosedDisposableStores':len(removed),'actualChildTermination':json.loads((packet/'interruption-termination.json').read_text()),'productionChanged':False,'physicalPowerLossOrCloudInterruptionQualified':False}
(root/'maintenance-interruption-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'maintenance-interruption-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
