from pathlib import Path
import gzip,json,os,re,subprocess,tempfile
repository=Path.cwd()
packet=repository/'docs/prototypes/evidence/native-membership-consolidation/canonical-membership-maintenance-undo-save-faults-mac'
outer=Path('/private/tmp/PlannerImportLifetime-canonical-membership-maintenance-undo-save-faults-mac.log')
report=json.loads((packet/'execution.json').read_text())
assert report['exitCode']==0 and not report['runnerTimedOut']
expected={case['name'].removesuffix('()') for case in report['cases']}
assert len(expected)==4
outer_stat=outer.stat()
found=[]
for directory in Path(tempfile.gettempdir()).glob('PlannerUndoWriteFailure-*'):
 path=directory/'child.log'
 if not path.is_file() or not outer_stat.st_birthtime <= path.stat().st_mtime <= outer_stat.st_mtime: continue
 transcript=path.read_text()
 selected=[name for name in expected if 'Test '+name+'()' in transcript]
 if not selected: continue
 assert len(selected)==1 and 'Test run with 1 test' in transcript and '✘' not in transcript
 assert 'vnode unlinked while in use' not in transcript
 name=selected[0]
 assert name not in [entry['function'] for entry in found]
 (packet/(name+'.child.log.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
 result=subprocess.run(['python3','scripts/verify-intent-fixtures.py',str(path),'--report',str(packet/(name+'.fixture-disposition.json'))],capture_output=True,text=True)
 assert result.returncode==0,result.stdout+result.stderr
 found.append({'function':name,'sourceLog':str(path),'fixtureCleanup':json.loads(result.stdout),'sourceLogModifiedAt':path.stat().st_mtime})
assert {entry['function'] for entry in found}==expected
(packet/'child-runtime-evidence.json').write_text(json.dumps({'outerLogBirthTime':outer_stat.st_birthtime,'outerLogModificationTime':outer_stat.st_mtime,'children':found},indent=2)+'\n')
(packet/'child-runtime-evidence.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Collected and verified',len(found),'actual child runtimes')
