from pathlib import Path
import copy
import gzip
import hashlib
import json

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
fixtures=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation'
graph=json.loads((fixtures/'retired-membership-alias-v3.json').read_text())
legacy=json.loads((fixtures.parent/'PortableImport/portable-backup-v1.json').read_text())
itinerary=next(s for s in legacy['sources'] if s['kind']=='itinerary')
itinerary['content']['manualEstimate']=None
graph['sources'].append(itinerary)
itinerary_binding={'kind':'itinerary','id':itinerary['id'],'lifetimeId':itinerary['lifetimeId']}
list_binding=graph['membershipProvenance'][0]['list']
item_binding=graph['membershipProvenance'][0]['item']
for entry_suffix,entry_lifetime,rank,done,first_alias,second_alias in [(451,851,'1024',False,861,862),(452,852,'2048',True,871,872)]:
 entry_id=f'00000000-0000-4000-8000-{entry_suffix:012d}'
 entry_lifetime_id=f'00000000-0000-4000-8000-{entry_lifetime:012d}'
 graph['itineraryEntries'].append({'id':entry_id,'lifetimeId':entry_lifetime_id,'itinerary':itinerary_binding,'source':list_binding,'rank':rank,'localDone':None})
 canonical={'kind':'expandedListItem','listEntryId':entry_id,'listEntryLifetimeId':entry_lifetime_id,'membershipId':'00000000-0000-4000-8000-000000000401','membershipLifetimeId':'00000000-0000-4000-8000-000000000841'}
 expanded=copy.deepcopy(canonical)
 expanded.pop('kind')
 graph['expandedCompletions'].append({'context':expanded,'localDone':done})
 retired=copy.deepcopy(canonical)
 retired['membershipId']='00000000-0000-4000-8000-000000000402'
 retired['membershipLifetimeId']='00000000-0000-4000-8000-000000000842'
 graph['contextAliases'].extend([
  {'aliasId':f'00000000-0000-4000-8000-{first_alias:012d}','context':canonical,'canonicalContext':canonical,'initialDone':False,'currentChangeId':None},
  {'aliasId':f'00000000-0000-4000-8000-{second_alias:012d}','context':retired,'canonicalContext':canonical,'initialDone':done,'currentChangeId':None}])
graph['itineraryEntries'].append({'id':'00000000-0000-4000-8000-000000000453','lifetimeId':'00000000-0000-4000-8000-000000000853','itinerary':itinerary_binding,'source':item_binding,'rank':'3072','localDone':False})
output=fixtures/'retired-expanded-membership-alias-v3.json'
assert not output.exists()
content=(json.dumps(graph,indent=2)+'\n').encode()
output.write_bytes(content)
evidence=workspace/'docs/prototypes/evidence/native-membership-consolidation/retired-expanded-alias-fixture-freeze'
evidence.mkdir(exist_ok=False)
(evidence/'producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(evidence/'provenance.json').write_text(json.dumps({'producer':'Independent Python literal graph, no Planner encoder or resolver','fixture':str(output.relative_to(workspace)),'sha256':hashlib.sha256(content).hexdigest(),'expected':'Standalone Done, first List branch Todo, repeated second List branch Done, direct Item stop Todo. Retired M402 contributions remain scoped to each entry lifetime.'},indent=2)+'\n')
print(json.dumps({'fixture':output.name,'sha256':hashlib.sha256(content).hexdigest()}))
