from pathlib import Path
import base64
import gzip
import hashlib
import json
import struct
import uuid

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
fixture = workspace / 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation'
assert not fixture.exists()
fixture.mkdir()

def identifier(suffix):
    return '00000000-0000-4000-8000-' + str(suffix).zfill(12)

def source(kind, suffix, lifetime):
    return {'kind': kind, 'id': identifier(suffix), 'lifetimeId': identifier(lifetime)}

item = source('item', 101, 811)
plan = source('list', 201, 821)
provenance = [
    {'membershipId': identifier(401), 'membershipLifetimeId': identifier(841), 'list': plan, 'item': item, 'observedRemovalIds': []},
    {'membershipId': identifier(405), 'membershipLifetimeId': identifier(845), 'list': plan, 'item': item, 'observedRemovalIds': [identifier(891)]},
]
portable = {
    'format': 'planner-data', 'formatVersion': 3,
    'sources': [
        dict(item, createdAt=10.25, updatedAt=20.125, content={'title': 'Hotel', 'subtitle': None, 'notes': 'A shared stop', 'location': None, 'estimate': {'minutes': '30', 'displayUnit': 'minute'}}, globalDone=False, archived=False, contentOrigins={'title': 'independent', 'notes': 'independent'}),
        dict(plan, createdAt=10.25, updatedAt=20.125, content={'name': 'Tokyo', 'notes': None, 'color': None, 'iconName': None, 'manualEstimate': None}, globalDone=None, archived=False, contentOrigins={'name': 'independent'}),
    ],
    'memberships': [{'id': identifier(405), 'lifetimeId': identifier(845), 'list': plan, 'item': item, 'rank': '1024', 'localDone': False}],
    'itineraryEntries': [], 'expandedCompletions': [], 'labelAssociations': [], 'ownedLinks': [], 'schedules': [],
    'deletionMarkers': [{'deletionId': identifier(891), 'operationId': identifier(991), 'target': {'kind': 'membership', 'id': identifier(401), 'lifetimeId': identifier(841)}, 'closedFamilyId': None}],
    'contextAliases': [], 'completionChanges': [], 'restorationFamilies': [],
    'membershipProvenance': provenance, 'membershipRemovals': [{'deletionId': identifier(891)}],
}

def write(name, value):
    content = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    (fixture / name).write_bytes(content)
    return content

portable_bytes = write('informed-readd-v3.json', portable)
identity = {'namespaceId': identifier(920), 'datasetId': identifier(910), 'epochId': identifier(930), 'ownershipBinding': 'local:membership-fixture'}
preparation = {'format': 'planner-maintenance-preparation', 'formatVersion': 1, 'maintenanceId': identifier(940), **identity, 'kind': 'membershipConsolidation', 'ruleVersion': 1, 'proposedBackup': portable, 'evidence': 'preparedUnverified'}
prepared_bytes = write('maintenance-preparation-v1.json', preparation)
maintenance = {'maintenanceId': identifier(940), **identity, 'kind': 'membershipConsolidation', 'ruleVersion': 1, 'preparationDigest': 'sha256:' + hashlib.sha256(prepared_bytes).hexdigest()}
recovery = {'format': 'planner-recovery', 'formatVersion': 2, 'namespaceId': identity['namespaceId'], 'datasetId': identity['datasetId'], 'ownershipBinding': identity['ownershipBinding'], 'storageSchemaVersion': '19', 'checkpointGeneration': '7', 'portablePayloadBase64': base64.b64encode(portable_bytes).decode(), 'dataDigest': 'sha256:' + hashlib.sha256(portable_bytes).hexdigest(), 'receipts': [], 'preparedProposals': [], 'maintenanceReceipts': [dict(maintenance, commitState='applied', checkpointGeneration='7')]}
write('maintenance-recovery-v2.json', recovery)

# This independent Python encoder follows the approved tagged-value byte protocol.
def unsigned(value):
    return struct.pack('>Q', value)

def tagged(kind, value):
    if kind == 'string':
        encoded = value.encode(); return b'\x10' + unsigned(len(encoded)) + encoded
    if kind == 'boolean':
        return bytes([0x11, int(value)])
    if kind == 'integer':
        return b'\x12' + struct.pack('>q', value)
    if kind == 'identity':
        return b'\x14' + uuid.UUID(value).bytes
    if kind in ['ordered', 'identitySet']:
        encoded = [tagged(*element) for element in value]
        if kind == 'identitySet':
            encoded.sort()
        return bytes([0x16 if kind == 'ordered' else 0x17]) + unsigned(len(encoded)) + b''.join(encoded)
    assert kind == 'record'
    encoded = b'\x18' + unsigned(len(value))
    for name in sorted(value):
        key = name.encode(); encoded += unsigned(len(key)) + key + tagged(*value[name])
    return encoded

def canonical_binding(binding):
    return ('record', {key: ('string' if key == 'kind' else 'identity', value) for key, value in binding.items()})

membership = source('membership', 405, 845)
command = ('record', {'type': ('string', 'removeMembership'), 'listId': ('identity', plan['id']), 'membershipId': ('identity', membership['id'])})
legacy_remove = {'command': command, 'datasetId': ('identity', identity['datasetId']), 'ownershipBinding': ('string', identity['ownershipBinding']), 'resolvedBindings': ('identitySet', [canonical_binding(binding) for binding in [item, plan, membership]])}
resolved = ('record', {'membership': canonical_binding(membership), 'list': canonical_binding(plan), 'item': canonical_binding(item), 'observedRemovalIds': ('identitySet', [('identity', identifier(891))])})
current_remove = dict(legacy_remove, resolvedMembershipEvidence=('ordered', [resolved]))
legacy_graph = ('record', {'format': ('string', 'planner-data'), 'formatVersion': ('integer', 2), **{key: ('ordered', []) for key in ['sources', 'memberships', 'itineraryEntries', 'expandedCompletions', 'labelAssociations', 'ownedLinks', 'schedules', 'deletionMarkers', 'contextAliases', 'completionChanges', 'restorationFamilies']}})
legacy_restore = {'command': ('record', {'type': ('string', 'applyImport'), 'backup': legacy_graph, 'mode': ('string', 'overwrite'), 'restoreDeletedData': ('boolean', True)}), 'datasetId': ('identity', identity['datasetId']), 'ownershipBinding': ('string', identity['ownershipBinding']), 'resolvedBindings': ('identitySet', []), 'reviewedCurrentData': legacy_graph}
fingerprints = []
for name, version, value in [('legacy-remove-v1', 1, legacy_remove), ('legacy-restoration-v2', 2, legacy_restore), ('observed-remove-v3', 3, current_remove)]:
    content = b'PlannerOperationPayload\x00' + struct.pack('>I', version) + tagged('record', value)
    fingerprints.append({'name': name, 'version': version, 'canonicalValue': ('record', value), 'payloadBase64': base64.b64encode(content).decode(), 'payloadDigest': f'sha256-payload-v{version}:' + hashlib.sha256(content).hexdigest()})
write('operation-fingerprint-literals.json', {'identity': identity, 'cases': fingerprints})
files = {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(fixture.iterdir())}
write('provenance.json', {'contract': 'docs/native-membership-consolidation-contract-review.md', 'frozenBeforeImplementationTests': True, 'producer': 'Independent literal graph and Python tagged-value encoder; no Planner production code executed', 'case': 'M401/841 removed under D891; M405/845 explicitly observes D891 and remains Todo', 'files': files})
packet = workspace / 'docs/prototypes/evidence/native-membership-consolidation/wire-fixture-freeze'
packet.mkdir()
(packet / 'producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(packet / 'files.json').write_bytes((fixture / 'provenance.json').read_bytes())
print(json.dumps({'fixtureFiles': len(files) + 1, 'fingerprints': {value['name']: value['payloadDigest'] for value in fingerprints}}))
