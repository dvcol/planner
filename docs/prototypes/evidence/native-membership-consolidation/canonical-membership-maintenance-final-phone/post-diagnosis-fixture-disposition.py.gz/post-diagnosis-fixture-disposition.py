from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode=True

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
root=workspace/'docs/prototypes/evidence/native-membership-consolidation'
packet=root/'canonical-membership-maintenance-final-phone'
qualified=root/'canonical-membership-maintenance-checkpoint-reconciliation.json'
qualification=json.loads(qualified.read_text())
assert qualification['automaticMembershipMaintenanceQualified']
assert qualification['sqliteLifetimeDiagnostics']==qualification['failedFunctions']==qualification['skippedFunctions']==0
log=Path('/private/tmp/PlannerItemWindow-canonical-membership-maintenance-final-phone.log').read_bytes()
assert gzip.decompress((packet/'test.log.gz').read_bytes())==log
content=log.decode()
assert content.count('vnode unlinked while in use')==102 and '✘' not in content
assert '** TEST SUCCEEDED **' in content
baseline=json.loads((root/'canonical-membership-legacy-lifetime-base-phone/boundary-validation.json').read_text())
assert baseline['sqliteLifetimeWarnings']==102 and baseline['baseInputsMatchArchive'] and baseline['stagedInputsMatchArchive']
module_path=workspace/'scripts/verify-intent-fixtures.py'
specification=importlib.util.spec_from_file_location('owned_fixture_verifier',module_path)
verifier=importlib.util.module_from_spec(specification)
specification.loader.exec_module(verifier)
records=verifier.read_fixtures(content)
diagnosis=json.loads((packet/'sqlite-lifetime-diagnosis.json').read_text())
warning_roots=[Path(name) for name in diagnosis['unownedRoots']]
assert all(not warning.is_relative_to(owned) and not owned.is_relative_to(warning) for warning in warning_roots for owned in records)
hosts=verifier.require_closed_hosts(records)
verifier.require_closed_databases(records)
report={'success':False,'originalRunQualificationComplete':False,'originalSqliteLifetimeWarnings':102,'reason':'The diagnosed warnings name separate unmarked roots. Remove only marked, unaffected fixture roots after exact-base reproduction, corrected qualification, host exit and closed-file checks.','sourceLogSha256':hashlib.sha256(log).hexdigest(),'qualifiedFinalReportSha256':hashlib.sha256(qualified.read_bytes()).hexdigest(),'ownershipVerifierSha256':hashlib.sha256(module_path.read_bytes()).hexdigest(),'hostProcessIdentifiers':hosts,'removedDirectories':[]}
report_path=packet/'post-diagnosis-fixture-disposition.json'
assert not report_path.exists()
for directory in records:
 report['activeDirectory']=str(directory)
 report_path.write_text(json.dumps(report,indent=2)+'\n')
 shutil.rmtree(directory)
 report['removedDirectories'].append(str(directory))
 report.pop('activeDirectory')
 report_path.write_text(json.dumps(report,indent=2)+'\n')
report['success']=True
report_path.write_text(json.dumps(report,indent=2)+'\n')
(packet/'post-diagnosis-fixture-disposition.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'success':True,'removedUnaffectedOwnedFixtures':len(records),'originalWarningRunRemainsUnqualified':True}))
