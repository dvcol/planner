import Foundation
import SwiftData

enum PlannerSchemaV1: VersionedSchema {
  static let versionIdentifier = Schema.Version(1, 0, 0)
  static var models: [any PersistentModel.Type] { [Item.self, Receipt.self] }

  @Model final class Item {
    var id: UUID? = nil
    var lifetimeId: UUID? = nil
    var title: String = ""
    var subtitle: String? = nil
    var notes: String? = nil
    var locationData: Data? = nil
    var estimateData: Data? = nil
    var createdAt: Date? = nil
    var updatedAt: Date? = nil
    var globalDone: Bool = false
    var archived: Bool = false

    init(input: PlannerItemContentInput) throws {
      id = UUID()
      lifetimeId = UUID()
      title = input.title
      subtitle = input.subtitle
      notes = input.notes
      locationData = try input.location.map { try JSONEncoder().encode($0) }
      estimateData = try input.estimate.map { try JSONEncoder().encode($0) }
      let now = Date()
      createdAt = now
      updatedAt = now
    }

    func value() throws -> ItemSnapshot {
      guard let id, let lifetimeId, let createdAt, let updatedAt else {
        throw PlannerFailure("readUnavailable", "The Item has unresolved identity or timestamps.")
      }
      let input = PlannerItemContentInput(
        title: title, subtitle: subtitle, notes: notes,
        location: try locationData.map {
          try JSONDecoder().decode(PlannerOwnedLocation.self, from: $0)
        },
        estimate: try estimateData.map { try JSONDecoder().decode(PlannerEstimate.self, from: $0) }
      )
      try input.validate()
      return ItemSnapshot(
        id: id, lifetimeId: lifetimeId, createdAt: createdAt, updatedAt: updatedAt,
        input: input, globalDone: globalDone, archived: archived
      )
    }
  }

  @Model final class Receipt {
    var operationId: UUID? = nil
    var payloadDigest: String = ""
    var resultData: Data? = nil
    var datasetId: UUID? = nil
    var ownershipBinding: String = ""

    init(
      operation: PlannerOperation, digest: String, result: PlannerAppliedResult,
      bindings: [PlannerBoundIdentity] = []
    ) throws {
      operationId = operation.operationId
      payloadDigest = digest
      resultData = try JSONEncoder().encode(
        PlannerStoredOperationEvidence(result: result, bindings: bindings))
      datasetId = operation.session.datasetId
      ownershipBinding = operation.session.ownershipBinding
    }

    func evidence() throws -> PlannerStoredOperationEvidence {
      guard let resultData else {
        throw PlannerFailure("readUnavailable", "Operation result evidence is missing.")
      }
      if let value = try? JSONDecoder().decode(
        PlannerStoredOperationEvidence.self, from: resultData)
      {
        return value
      }
      // The original creation-only prototype stored AppliedResult directly with no resolved bindings.
      return PlannerStoredOperationEvidence(
        result: try JSONDecoder().decode(PlannerAppliedResult.self, from: resultData), bindings: []
      )
    }
  }
}

extension PlannerSchemaV18.Item {
  func rowRead(
    identity: PlannerRowIdentity, localDone: Bool?, hasLinks: Bool,
    previewLink: PlannerOwnedLinkRead?, labels: [PlannerLabelRead],
    scheduleSummary: PlannerRowScheduleSummary
  ) throws -> PlannerRowRead {
    guard id != nil, let lifetimeId else {
      throw PlannerFailure("readUnavailable", "The row Item has unresolved identity.")
    }
    let content = PlannerItemContentInput(
      title: title, subtitle: subtitle,
      location: try locationData.map {
        try JSONDecoder().decode(PlannerOwnedLocation.self, from: $0)
      },
      estimate: try estimateData.map { try JSONDecoder().decode(PlannerEstimate.self, from: $0) })
    try content.validate()
    return PlannerRowRead(
      identity: identity, sourceLifetimeId: lifetimeId,
      title: content.title, subtitle: content.subtitle, estimate: content.estimate,
      manualEstimate: nil, containerEstimates: nil,
      globalDone: globalDone, localDone: localDone,
      effectiveDone: globalDone || localDone == true, archived: archived,
      hasLocation: content.location != nil, hasLinks: hasLinks,
      ownedLocation: content.location, previewLink: previewLink,
      labels: labels, scheduleSummary: scheduleSummary)
  }
}

struct PlannerBoundIdentity: Codable {
  let kind: String
  let id: UUID
  let lifetimeId: UUID

  var canonicalValue: PlannerCanonicalValue {
    .record(["kind": .string(kind), "id": .identity(id), "lifetimeId": .identity(lifetimeId)])
  }
}

struct PlannerStoredOperationEvidence: Codable {
  let result: PlannerAppliedResult
  let bindings: [PlannerBoundIdentity]
}

enum PlannerMigrationPlan: SchemaMigrationPlan {
  static var schemas: [any VersionedSchema.Type] {
    [
      PlannerSchemaV1.self, PlannerSchemaV2.self, PlannerSchemaV3.self, PlannerSchemaV4.self,
      PlannerSchemaV5.self, PlannerSchemaV6.self, PlannerSchemaV7.self, PlannerSchemaV8.self,
      PlannerSchemaV9.self, PlannerSchemaV10.self, PlannerSchemaV11.self, PlannerSchemaV12.self,
      PlannerSchemaV13.self, PlannerSchemaV14.self, PlannerSchemaV15.self, PlannerSchemaV16.self,
      PlannerSchemaV17.self, PlannerSchemaV18.self, PlannerSchemaV19.self,
    ]
  }
  static var stages: [MigrationStage] {
    [
      .lightweight(fromVersion: PlannerSchemaV1.self, toVersion: PlannerSchemaV2.self),
      .lightweight(fromVersion: PlannerSchemaV2.self, toVersion: PlannerSchemaV3.self),
      .lightweight(fromVersion: PlannerSchemaV3.self, toVersion: PlannerSchemaV4.self),
      .lightweight(fromVersion: PlannerSchemaV4.self, toVersion: PlannerSchemaV5.self),
      .lightweight(fromVersion: PlannerSchemaV5.self, toVersion: PlannerSchemaV6.self),
      .lightweight(fromVersion: PlannerSchemaV6.self, toVersion: PlannerSchemaV7.self),
      .lightweight(fromVersion: PlannerSchemaV7.self, toVersion: PlannerSchemaV8.self),
      .lightweight(fromVersion: PlannerSchemaV8.self, toVersion: PlannerSchemaV9.self),
      .lightweight(fromVersion: PlannerSchemaV9.self, toVersion: PlannerSchemaV10.self),
      .lightweight(fromVersion: PlannerSchemaV10.self, toVersion: PlannerSchemaV11.self),
      .lightweight(fromVersion: PlannerSchemaV11.self, toVersion: PlannerSchemaV12.self),
      .lightweight(fromVersion: PlannerSchemaV12.self, toVersion: PlannerSchemaV13.self),
      .lightweight(fromVersion: PlannerSchemaV13.self, toVersion: PlannerSchemaV14.self),
      .lightweight(fromVersion: PlannerSchemaV14.self, toVersion: PlannerSchemaV15.self),
      .lightweight(fromVersion: PlannerSchemaV15.self, toVersion: PlannerSchemaV16.self),
      .lightweight(fromVersion: PlannerSchemaV16.self, toVersion: PlannerSchemaV17.self),
      .lightweight(fromVersion: PlannerSchemaV17.self, toVersion: PlannerSchemaV18.self),
      .lightweight(fromVersion: PlannerSchemaV18.self, toVersion: PlannerSchemaV19.self),
    ]
  }
}

struct ItemSnapshot {
  let id: UUID
  let lifetimeId: UUID
  let createdAt: Date
  let updatedAt: Date
  let input: PlannerItemContentInput
  let globalDone: Bool
  let archived: Bool
  var links: [OwnedLinkSnapshot] = []
  var schedules: [ScheduleSnapshot] = []
  var labelAssociations: [LabelAssociationSnapshot] = []
  var labels: [PlannerLabelRead] = []

  var contentOrigins: [String: String]? = nil

  var reference: PlannerEntityReference { PlannerEntityReference(kind: .item, id: id) }

  func read(
    datasetId: UUID, memberships: [MembershipSnapshot], entries: [ItineraryEntrySnapshot] = []
  ) -> PlannerItemSourceRead {
    PlannerItemSourceRead(
      source: reference, sourceLifetimeId: lifetimeId,
      content: input.readContent(links: links.map(\.read)), createdAt: createdAt,
      updatedAt: updatedAt,
      fieldHashes: input.fieldHashes(
        datasetId: datasetId, itemId: id, lifetimeId: lifetimeId, links: links.map(\.read),
        labelAssociations: labelAssociations),
      state: PlannerSourceState(globalDone: globalDone, archived: archived), labels: labels,
      references: labelAssociations.sorted { $0.id.uuidString < $1.id.uuidString }.map(\.reference)
        + links.map { .ownedLink(id: $0.id, owner: reference) }
        + schedules.sorted { $0.id.uuidString < $1.id.uuidString }.map {
          .schedule(id: $0.id, source: reference)
        }
        + memberships.filter { $0.item.id == id }.sorted { $0.id.uuidString < $1.id.uuidString }
        .map(\.reference)
        + entries.filter {
          $0.source.kind == "item" && $0.source.id == id && $0.source.lifetimeId == lifetimeId
        }.sorted { $0.id.uuidString < $1.id.uuidString }.map(\.reference)
    )
  }
}

struct PlannerStoreIdentity: Codable {
  let schemaVersion: Int
  let datasetId: UUID
  let epochId: UUID
  let namespaceId: UUID
  let ownershipBinding: String
}

func plannerWriteDurably(_ data: Data, to destination: URL) throws {
  let directory = destination.deletingLastPathComponent()
  try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
  let temporaryURL = directory.appendingPathComponent(".\(UUID().uuidString).pending")
  defer { try? FileManager.default.removeItem(at: temporaryURL) }
  try data.write(to: temporaryURL, options: .withoutOverwriting)
  let handle = try FileHandle(forWritingTo: temporaryURL)
  do {
    try handle.synchronize()
    try handle.close()
  } catch {
    try? handle.close()
    throw error
  }
  if FileManager.default.fileExists(atPath: destination.path) {
    _ = try FileManager.default.replaceItemAt(destination, withItemAt: temporaryURL)
  } else {
    try FileManager.default.moveItem(at: temporaryURL, to: destination)
  }
}
