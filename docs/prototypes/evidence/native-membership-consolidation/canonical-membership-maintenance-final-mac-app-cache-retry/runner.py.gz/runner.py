from pathlib import Path
import gzip, hashlib, io, json, os, shutil, subprocess, sys, tarfile, time, signal
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
selected = sys.argv[2]
packet = repository / 'docs/prototypes/evidence/native-membership-consolidation' / phase
packet.mkdir(parents=True, exist_ok=False)
root = Path('/private/tmp/PlannerBrowserMacSource')
root.mkdir(exist_ok=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
overlays = sorted({path for path in changed + new if (path.endswith('.swift') and path.startswith(('Packages/', 'Planner/', 'PlannerMCPTests/', 'PlannerNavigationUITests/', 'PlannerFixtureUITests/', 'PlannerFixtures/'))) or path.startswith(('Configuration/', 'Planner.xcodeproj/', 'docs/fixtures/', 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/'))})
archive = subprocess.check_output(['git', 'archive', base, 'Configuration', 'Packages', 'Planner.xcodeproj', 'Planner', 'PlannerMCPTests', 'PlannerFixtures', 'PlannerFixtureUITests', 'PlannerNavigationUITests', 'PlannerShareMobile', 'PlannerShareMac', 'docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for member in source.getmembers():
        if not member.isfile(): continue
        destination = root / member.name
        content = source.extractfile(member).read()
        if member.name in overlays:
            content = (repository / member.name).read_bytes()
        if destination.is_file() and destination.read_bytes() == content: continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
for path in overlays:
    (root / path).parent.mkdir(parents=True, exist_ok=True)
    if (root / path).is_file() and (root / path).read_bytes() == (repository / path).read_bytes(): continue
    shutil.copy2(repository / path, root / path)
inputs = sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet / 'source-sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root': str(root), 'base':base, 'overlays':overlays}, indent=2) + '\n')
for path in overlays:
    (packet / (Path(path).name + '.gz')).write_bytes(gzip.compress((root / path).read_bytes(), mtime=0))
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
command = ['xcodebuild','build','-project','Planner.xcodeproj','-scheme','Planner','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/PlannerMapNativeDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerItinerarySelectionSourcePackages','-disableAutomaticPackageResolution','-jobs','1','CODE_SIGNING_ALLOWED=YES','CODE_SIGN_IDENTITY=-','CODE_SIGN_STYLE=Manual','DEVELOPMENT_TEAM=','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerMembership-'+phase+'.log')
started=time.monotonic()
with log.open('wb') as output:
    process=subprocess.Popen(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    timed_out=False
    try: code=process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGINT)
        try: code=process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            code=process.wait()
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
assert all(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
assert all((repository/path).is_file() and hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
products={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in Path('/private/tmp/PlannerMapNativeDerivedData/Build/Products/Debug').rglob('*') if path.is_file() and path.name in ['Planner','Planner.debug.dylib','PlannerShareMac','PlannerShareMac.debug.dylib']}
(packet/'product-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
report={'exitCode':code,'timedOut':timed_out,'seconds':round(time.monotonic()-started,3),'frozenInputsUnchanged':True,'workspaceInputsUnchanged':True,'products':len(products),'nativeInteractionQualified':False}
(packet/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
for line in log.read_text().splitlines():
    if 'error:' in line or line.startswith('** BUILD'):print(line[:1500])
raise SystemExit(code)
