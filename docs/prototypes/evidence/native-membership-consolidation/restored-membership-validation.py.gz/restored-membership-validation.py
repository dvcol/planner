from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd();assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'restored-membership-lifecycle-final-mac';phone=root/'restored-membership-lifecycle-final-phone';adapter=root/'restored-membership-final-adapter-mac'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert execution['frozenInputsUnchanged'] and execution['workspaceInputsUnchanged']
assert len(execution['cases'])==246 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
selected=set(Path('/private/tmp/PlannerRestoredMembershipCohort.txt').read_text().strip().split(','));assert len(selected)==88
assert {case['className'].split('.')[-1] for case in execution['cases']}==selected
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==246 and sum(signatures[0].values())==688
mac_inputs=json.loads((mac/'source-sha256.json').read_text());phone_inputs=json.loads((phone/'source-sha256.json').read_text());adapter_inputs=json.loads((adapter/'source-sha256.json').read_text())
fixture_suites=['ExpandedCompletionRecoveryTests','ItineraryEntryClosureRecoveryTests','RecoverySourceIdentityTests','RecoverySourceIdentityRejectionTests','SourceDeletionIntegrityTests']
fixture_paths={'Packages/PlannerCore/Tests/PlannerCoreStoreTests/'+name+'.swift' for name in fixture_suites}
assert len(mac_inputs)==808 and all(phone_inputs.get(path)==digest for path,digest in mac_inputs.items())
assert {path for path,digest in mac_inputs.items() if adapter_inputs.get(path)!=digest}==fixture_paths
for inputs in [mac_inputs,phone_inputs]:assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in adapter_inputs.items() if path not in fixture_paths)
previous=json.loads((root/'strict-overwrite-resolved-final-mac/source-sha256.json').read_text())
fixtures=[path for path in previous if '/Fixtures/' in path]
assert len(fixtures)==514 and all(previous[path]==mac_inputs[path] for path in fixtures)
models=[path for path in mac_inputs if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(models)==19 and all(previous[path]==mac_inputs[path] for path in models)
test_path='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift'
base_source=subprocess.check_output(['git','show','c6165cc6:'+test_path],text=True)
current_source=(repository/test_path).read_text()
head='struct NativeMembershipConsolidationTests {\n'
original_first='  @Test(arguments: [false, true])\n  func reviewedOverwriteRemovalDefeatsAnUnseenAddWithoutDeletingItsItem'
helper_first='  @MainActor private func insertIndependentExpandedCompletion('
helper_end='  /// Model access constructs the actual persisted input; all behavioral observations use Planner.'
reconstructed=current_source[:current_source.index(head)+len(head)]+current_source[current_source.index(original_first):current_source.index(helper_first)]+current_source[current_source.index(helper_end):]
assert reconstructed==base_source
early_cleanup='''    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }'''
for path,digest in previous.items():
 if '/Tests/' not in path or not path.endswith('.swift') or path==test_path:continue
 if path in fixture_paths:
  old_source=subprocess.check_output(['git','show','c6165cc6:'+path],text=True)
  assert old_source.count(early_cleanup)==1
  assert (repository/path).read_text()==old_source.replace(early_cleanup,'    let directory = try makePlannerStoreFixtureDirectory()')
 else:assert mac_inputs[path]==digest
comparison=root/'restored-membership-lifecycle-base-phone'
assert json.loads((comparison/'exit.json').read_text())['exitCode']==0
comparison_log=gzip.decompress((comparison/'test.log.gz').read_bytes()).decode()
assert 'Test run with 5 tests in 5 suites passed' in comparison_log
assert comparison_log.count('vnode unlinked while in use')==12
comparison_inputs=json.loads((comparison/'source-sha256.json').read_text())
initial_phone_inputs=json.loads((root/'restored-membership-final-phone/source-sha256.json').read_text())
comparison_paths=set(json.loads((comparison/'source-root.json').read_text())['productionFilesFromBase'])
assert len(comparison_paths)==3
for path,digest in comparison_inputs.items():
 if path in comparison_paths:assert digest==previous[path]
 else:assert digest==initial_phone_inputs[path]
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in json.loads((adapter/'execution.json').read_text()).values())
summary=json.loads((adapter/'test-summary.json').read_text());assert summary['passedTests']==6 and summary['failedTests']==0 and summary['skippedTests']==0
adapter_build=gzip.decompress((adapter/'build-for-testing.log.gz').read_bytes()).decode()
assert "in target 'PlannerCoreStoreTests'" not in adapter_build
assert all(name+'.swift' not in adapter_build for name in fixture_suites)
products=json.loads((adapter/'test-without-building-product-sha256.json').read_text())
assert products and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
for suffix in ['/Planner.app/','/PlannerShareMac.appex/','/PlannerFixtures.app/']:assert any(suffix in path for path in products)
removed=[]
for phase in ['restored-membership-old-delivery-first','restored-membership-snapshot-validation-first','restored-membership-expanded-delivery-runtime-red','restored-membership-explicit-expanded-closure-red','restored-membership-context-regressions','restored-membership-unproven-lifetimes-first','restored-membership-final-mac','restored-membership-lifecycle-final-mac','restored-membership-lifecycle-final-phone']:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text());assert disposition['success'];removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=sorted(path for path in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if path.endswith('.swift'));assert len(files)==9
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':246,'invocationsPerPlatform':688,'suitesPerPlatform':88,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixtures),'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'realMacHTTPFunctions':6,'macAppShareFixtureBuildsPassed':True,'existingConsolidationTestsByteUnchanged':True,'fiveRecoveryBodiesChangedOnlyFixtureLifetime':True,'phoneTeardownDiagnosticsReproducedOnBase':12,'allCurrentProductionAppMCPInputsMatchAdapter':True,'unusedAdapterCoreTestFactoryDifferences':5,'originalIDUndoWithStrictClosureQualified':True,'twoRestoredBranchesKeepIndependentStates':True,'unprovenCompetingLifetimesRemainUnavailableWithoutMaintenanceWrites':True,'legacyClosedMembershipImportAndChecksummedRecoveryRejectionQualified':True,'removedClosedDisposableStores':len(removed),'expandedOnlyDeliveryQualified':False,'standaloneExpandedClosureDeliveryQualified':False,'sourceDeletionOrOrphanEndpointReconciliationQualified':False,'nativeUIPhysicalCloudOrSystemInvocationQualified':False,'allLifetimeReconciliationQualified':False}
(root/'restored-membership-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'restored-membership-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(root/'restored-membership-cohort.json').write_text(json.dumps(sorted(selected),indent=2)+'\n')
print(json.dumps(report))
