from pathlib import Path
import gzip, hashlib, json, os, re, subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
mac=root/'eligible-alias-final-mac'
phone=root/'eligible-alias-final-phone'
adapter=root/'eligible-alias-final-adapter-mac'
execution=json.loads((mac/'execution.json').read_text())
assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
assert execution['frozenInputsUnchanged'] and execution['workspaceInputsUnchanged']
assert len(execution['cases'])==249 and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
selected=set(Path('/private/tmp/PlannerRestoredMembershipCohort.txt').read_text().strip().split(','))
assert len(selected)==88 and {case['className'].split('.')[-1] for case in execution['cases']}==selected
assert json.loads((phone/'exit.json').read_text())['exitCode']==0
summary=json.loads((phone/'test-summary.json').read_text())
assert summary['failedTests']==0 and summary['skippedTests']==0
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=json.loads((packet/'product-sha256.json').read_text())
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==249 and sum(signatures[0].values())==703
mac_inputs=json.loads((mac/'source-sha256.json').read_text())
phone_inputs=json.loads((phone/'source-sha256.json').read_text())
adapter_inputs=json.loads((adapter/'source-sha256.json').read_text())
assert len(mac_inputs)==808 and len(phone_inputs)==1147
assert all(phone_inputs.get(path)==digest and adapter_inputs.get(path)==digest for path,digest in mac_inputs.items())
for inputs in [mac_inputs,phone_inputs,adapter_inputs]:
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
previous=json.loads((root/'expanded-only-final-mac/source-sha256.json').read_text())
fixtures=[path for path in previous if '/Fixtures/' in path]
assert len(fixtures)==514 and all(previous[path]==mac_inputs[path] for path in fixtures)
models=[path for path in mac_inputs if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(models)==19 and all(previous[path]==mac_inputs[path] for path in models)
test_path='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipAliasTests.swift'
base_source=subprocess.check_output(['git','show','f882531f:'+test_path],text=True)
current_source=(repository/test_path).read_text()
head='struct NativeMembershipAliasTests {\n'
original_first='  enum InvalidAlias: CaseIterable {'
reconstructed=current_source[:current_source.index(head)+len(head)]+current_source[current_source.index(original_first):]
assert reconstructed==base_source
changed=[path for path,digest in mac_inputs.items() if previous[path]!=digest]
assert set(changed)=={test_path,'Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift'}
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in json.loads((adapter/'execution.json').read_text()).values())
summary=json.loads((adapter/'test-summary.json').read_text())
assert summary['passedTests']==6 and summary['failedTests']==0 and summary['skippedTests']==0
products=json.loads((adapter/'test-without-building-product-sha256.json').read_text())
assert products and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
for suffix in ['/Planner.app/','/PlannerShareMac.appex/','/PlannerFixtures.app/']:assert any(suffix in path for path in products)
removed=[]
for phase in ['eligible-alias-first','eligible-alias-organization-first','eligible-alias-final-mac','eligible-alias-final-phone']:
 disposition=json.loads((root/phase/'fixture-disposition.json').read_text())
 assert disposition['success']
 removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=sorted(path for path in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if path.endswith('.swift'))
assert len(files)==2
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':249,'invocationsPerPlatform':703,'suitesPerPlatform':88,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixtures),'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'realMacHTTPFunctions':6,'macAppShareFixtureBuildsPassed':True,'existingAliasTestsByteUnchanged':True,'onlyTwoCoreInputsChanged':True,'allCurrentProductionAppMCPInputsMatchAdapter':True,'eligibleAliasReadsAndIndependentCompletionQualified':True,'aliasRemoveMoveReorderAndPlacementQualified':True,'originalAssociationUndoQualified':True,'closedAliasCannotTargetOrdinaryReadd':True,'wrongListReadAndActionsLeaveExportAndEvidenceUnchanged':True,'exactStoredReplayAfterReaddQualified':True,'removedClosedDisposableStores':len(removed),'laterLowerCanonicalArrivalQualified':False,'aliasSpecificHTTPJourneyQualified':False,'preparedOnlyAliasReplayAfterRootChangeQualified':False,'nativeUIPhysicalCloudOrSystemInvocationQualified':False,'allLifetimeReconciliationQualified':False}
(root/'eligible-alias-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'eligible-alias-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(root/'eligible-alias-cohort.json').write_text(json.dumps(sorted(selected),indent=2)+'\n')
attempts=[]
phase_notes={
 'eligible-alias-runtime-red':'The public real-store read tracer failed in all three exact appearance contexts.',
 'eligible-alias-first':'The same tracer passed alias reads, independent completion, replay and rejection after remove/re-add.',
 'eligible-alias-organization-red':'All seven organization cases failed, including canonical actions, placement anchors and self-anchor error semantics.',
 'eligible-alias-organization-first':'Both new tracers passed ten invocations; final runs add wrong-List rejection and unchanged-export checks.',
 'eligible-alias-final-mac':'Final matched Mac cohort, current inputs and actual products verified.',
 'eligible-alias-final-phone':'Final matched iPhone Simulator cohort, current inputs and actual products verified.',
 'eligible-alias-final-adapter-mac':'Current-source Mac app/Share/fixture compilation and six existing HTTP regression functions passed.'
}
for phase,note in phase_notes.items():
 packet=root/phase
 record={'phase':phase,'note':note,'sourceManifest':'source-sha256.json','rawLogsRetained':True}
 for name in ['execution.json','exit.json','test-summary.json']:
  if (packet/name).exists():record[name]=json.loads((packet/name).read_text())
 attempts.append(record)
assert len(attempts)==7
(root/'eligible-alias-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
print(json.dumps(report))
