from pathlib import Path
import gzip,json,re
root=Path('docs/prototypes/evidence/native-membership-consolidation')
entries=[]
for packet in sorted(root.glob('restored-membership-*')):
 if not packet.is_dir():continue
 entry={'phase':packet.name}
 execution=packet/'execution.json';exit_file=packet/'exit.json'
 if execution.exists():
  report=json.loads(execution.read_text())
  if 'cases' in report:
   entry.update({key:value for key,value in report.items() if key!='cases'})
   entry['functions']=len(report['cases']);entry['failedFunctions']=sum(bool(case['failures']) for case in report['cases'])
   entry['issues']=sum(len(case['failures']) for case in report['cases'])
  else:entry['stages']=report
 elif exit_file.exists():
  entry['mobileExecution']=json.loads(exit_file.read_text())
  transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
  entry['sqliteUnlinkWarnings']=transcript.count('vnode unlinked while in use')
 else:raise AssertionError(packet)
 if packet.name in ['restored-membership-old-delivery-red','restored-membership-expanded-delivery-red']:
  entry['note']='Test-source compilation failed before execution. The separate runtime phases retain actual behavior.'
 if packet.name=='restored-membership-expanded-delivery-runtime-red':
  entry['note']='This additional repeated-branch qualification passed without another production change; the historical phase name is retained.'
 if packet.name=='restored-membership-explicit-expanded-closure-red':
  entry['note']='Both old expanded records arrive with their old membership and this scenario passes. The historical name does not qualify an independent expanded-completion deletion-marker case.'
 if packet.name=='restored-membership-final-phone':
  entry['note']='All assertions pass, but twelve teardown diagnostics remain. No extra cleanup is applied to this warning-bearing log.'
 if packet.name=='restored-membership-lifecycle-base-phone':
  entry['note']='Five unchanged recovery suites pass against c6165cc6 production and reproduce all twelve teardown diagnostics.'
 entries.append(entry)
assert len(entries)==15,len(entries)
(root/'restored-membership-attempts.json').write_text(json.dumps(entries,indent=2)+'\n')
(root/'restored-membership-attempts.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Retained completed phases',len(entries))
