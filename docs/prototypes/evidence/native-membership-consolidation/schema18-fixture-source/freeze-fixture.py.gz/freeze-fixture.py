from pathlib import Path
import base64
import gzip
import hashlib
import json
import shutil
import sqlite3
import subprocess

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
source_record = json.loads(Path('/private/tmp/PlannerSchema18FixtureSource.json').read_text())
source = Path(source_record['dataset'])
fixture = workspace / 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/SchemaV18'
assert not fixture.exists()
process = subprocess.run(['ps', '-p', str(source_record['record']['hostProcessIdentifier']), '-o', 'pid=,comm='], capture_output=True, text=True)
assert process.returncode == 1 and not process.stdout
handles = subprocess.run(['lsof', '-Fn', '--', *map(str, sorted((source / 'store').glob('Planner.sqlite*')))], capture_output=True, text=True)
assert handles.returncode == 1 and not handles.stdout
connection = sqlite3.connect((source / 'store/Planner.sqlite').as_uri() + '?mode=ro', uri=True)
import plistlib
metadata = plistlib.loads(connection.execute('SELECT Z_PLIST FROM Z_METADATA').fetchone()[0])
connection.close()
assert metadata['NSStoreModelVersionIdentifiers'] == ['18.0.0']
def inventory(root):
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(root.rglob('*')) if path.is_file()}
source_hashes = inventory(source)
shutil.copytree(source, fixture)
assert inventory(fixture) == source_hashes
identity = json.loads((fixture / 'control/writer').read_text())
assert identity['schemaVersion'] == 18
checkpoint = json.loads((fixture / 'recovery' / identity['namespaceId'] / 'checkpoint-7.json').read_text())
payload = base64.b64decode(checkpoint['portablePayloadBase64'], validate=True)
assert checkpoint['dataDigest'] == 'sha256:' + hashlib.sha256(payload).hexdigest()
(fixture / 'expected-portable.json').write_bytes(payload)
portable = json.loads(payload)
manifest = json.loads((fixture / 'manifest.json').read_text())
creation_receipt = next(receipt for receipt in checkpoint['receipts'] if receipt['operationId'] == manifest['creationOperationId'])
assert creation_receipt['checkpointGeneration'] == '1'
manifest.update(storageSchemaVersion='18', generatorCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), creationCheckpointGeneration='1', baselineCheckpointGeneration='7', itemLifetimeId=next(value['lifetimeId'] for value in portable['sources'] if value['id'] == manifest['itemId']))
(fixture / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
producer = {'sourceCommit': manifest['generatorCommit'], 'storageSchemaVersion': 18, 'producer': 'Existing genuineV15MigrationPreservesGraphBudgetsRecoveryAndCreationReplay test, unchanged production schema 18, exited native test host', 'executionPacket': 'docs/prototypes/evidence/native-membership-consolidation/schema18-fixture-source', 'sourceHostExited': True, 'noOpenSqliteHandles': True, 'modelVersionIdentifiers': metadata['NSStoreModelVersionIdentifiers'], 'originalFilesSha256': source_hashes, 'filesSha256': inventory(fixture)}
(fixture / 'producer.json').write_text(json.dumps(producer, indent=2) + '\n')
assert inventory(source) == source_hashes
packet = workspace / 'docs/prototypes/evidence/native-membership-consolidation/schema18-fixture-source'
(packet / 'freeze-fixture.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(packet / 'frozen-fixture.json').write_text(json.dumps(producer, indent=2) + '\n')
print(json.dumps({'fixture': str(fixture), 'files': len(inventory(fixture)), 'modelVersionIdentifiers': metadata['NSStoreModelVersionIdentifiers'], 'originalReceiptGeneration': creation_receipt['checkpointGeneration'], 'bytes': sum(path.stat().st_size for path in fixture.rglob('*') if path.is_file())}))
