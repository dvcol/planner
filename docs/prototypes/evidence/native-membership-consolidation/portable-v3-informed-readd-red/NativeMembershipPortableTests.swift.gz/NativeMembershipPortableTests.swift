import Foundation
import PlannerCore
import Testing

struct NativeMembershipPortableTests {
  @Test func informedReaddDecodesItsRetainedRemovalHistoryWithoutOpeningStorage() throws {
    #if SWIFT_PACKAGE
      let bundle = Bundle.module
    #else
      let bundle = Bundle(for: NativeMembershipPortableFixtureBundle.self)
    #endif
    let fixture = try #require(
      bundle.url(
        forResource: "informed-readd-v3", withExtension: "json",
        subdirectory: "Fixtures/MembershipConsolidation"))
    let directory = try makePlannerStoreFixtureDirectory()
    let planner = Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .shareExtension, storageMode: .localOnly))
    let result = planner.decodeImport(try Data(contentsOf: fixture))
    guard case .decoded(let decoded) = result else {
      Issue.record("Decode the independent informed re-add and retained strict removal: \(result)")
      return
    }
    let membership = try #require(decoded.backup.memberships.first)
    #expect(decoded.backup.sources.count == 2 && decoded.backup.memberships.count == 1)
    #expect(membership.id.uuidString == "00000000-0000-4000-8000-000000000405")
    #expect(membership.lifetimeId.uuidString == "00000000-0000-4000-8000-000000000845")
    #expect(!membership.localDone && membership.rank == 1024)
    #expect(decoded.backup.items.first?.globalDone == false)
    #expect(decoded.backup.deletionMarkers.count == 1)
    #expect(decoded.externalBindings.isEmpty && decoded.originPaths.isEmpty)
    #expect(!FileManager.default.fileExists(atPath: directory.path))
  }
}

private final class NativeMembershipPortableFixtureBundle: NSObject {}
