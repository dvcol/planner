from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/native-membership-consolidation'
def read_json(path): return json.loads(path.read_text())
def passed_core(phase,functions):
 packet=root/phase
 execution=read_json(packet/'execution.json')
 assert execution['exitCode']==0 and not execution['runnerTimedOut'] and execution['sqliteUnlinkWarnings']==0
 assert execution['frozenInputsUnchanged'] and execution['workspaceInputsUnchanged']
 assert len(execution['cases'])==functions and all(not case['failures'] and not case['skipped'] for case in execution['cases'])
 return packet,execution
mac,execution=passed_core('initial-completion-validated-mac',255)
isolated,_=passed_core('initial-completion-native-save-final',1)
phone=root/'initial-completion-validated-phone'
adapter=root/'initial-completion-validated-adapter-mac'
assert read_json(phone/'exit.json')['exitCode']==0
phone_summary=read_json(phone/'test-summary.json')
assert phone_summary['failedTests']==0 and phone_summary['skippedTests']==0
selected=set(Path('/private/tmp/PlannerInitialCompletionCohort.txt').read_text().strip().split(','))
assert len(selected)==90 and {case['className'].split('.')[-1] for case in execution['cases']}==selected
signatures=[]
for packet in [mac,phone]:
 transcript=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
 assert 'vnode unlinked while in use' not in transcript and '✘' not in transcript
 found={}
 for line in transcript.splitlines():
  match=re.match(r'^✔ Test (.+?)(?: with (\d+) test cases?)? passed after',line.strip().lstrip('\u200b'))
  if match and not match[1].startswith('run with '):found[match[1]]=int(match[2] or 1)
 signatures.append(found)
 products=read_json(packet/'product-sha256.json')
 assert len(products)==2 and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
assert signatures[0]==signatures[1] and len(signatures[0])==255 and sum(signatures[0].values())==722
mac_inputs=read_json(mac/'source-sha256.json')
phone_inputs=read_json(phone/'source-sha256.json')
adapter_inputs=read_json(adapter/'source-sha256.json')
assert len(mac_inputs)==808 and len(phone_inputs)==1147
assert all(phone_inputs.get(path)==digest and adapter_inputs.get(path)==digest for path,digest in mac_inputs.items())
for inputs in [mac_inputs,phone_inputs,adapter_inputs]:
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
assert read_json(isolated/'source-sha256.json')==mac_inputs
assert read_json(isolated/'product-sha256.json')==read_json(mac/'product-sha256.json')
capture=read_json(isolated/'child-capture.json')
child=gzip.decompress((isolated/'child.log.gz').read_bytes())
assert hashlib.sha256(child).hexdigest()==capture['childLogSha256']
assert capture['forwardedOwnedFixtures']==3 and child.count(b'PLANNER_STORE_FIXTURE ')==3
assert b'vnode unlinked while in use' not in child and '✘'.encode() not in child
previous=read_json(root/'eligible-alias-final-mac/source-sha256.json')
fixtures=[path for path in previous if '/Fixtures/' in path]
models=[path for path in previous if path.startswith('Packages/PlannerCore/Sources/PlannerCore/') and '@Model' in (repository/path).read_text(errors='replace')]
assert len(fixtures)==514 and all(previous[path]==mac_inputs[path] for path in fixtures)
assert len(models)==19 and all(previous[path]==mac_inputs[path] for path in models)
expected_changes={
 'Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift',
 'Packages/PlannerCore/Sources/PlannerCore/PlannerMembershipConsolidation.swift',
 'Packages/PlannerCore/Sources/PlannerCore/PlannerNativeImportStorage.swift',
 'Packages/PlannerCore/Sources/PlannerCore/PlannerBulkCompletion.swift',
 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift',
 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeImportConflictReviewTests.swift',
 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeImportOmittedOwnerReviewTests.swift'
}
assert {path for path,digest in mac_inputs.items() if previous[path]!=digest}==expected_changes
def base_source(path):return subprocess.check_output(['git','show','2d78e438:'+path],text=True)
test_path='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeMembershipConsolidationTests.swift'
current=(repository/test_path).read_text()
head='struct NativeMembershipConsolidationTests {\n'
original_first='  @Test(arguments: ["missingMembershipHistory", "differentList"])'
assert current[:current.index(head)+len(head)]+current[current.index(original_first):]==base_source(test_path)
consolidation_path='Packages/PlannerCore/Sources/PlannerCore/PlannerMembershipConsolidation.swift'
old=base_source(consolidation_path)
old=old[old.index('  private static func initialAliasIdentifier('):old.index('  private static func unresolved(')]
new=(repository/consolidation_path).read_text()
new=new[new.index('func plannerInitialCompletionAliasIdentifier('):new.index('extension PlannerDataSnapshot {')]
assert old[old.index('{')+1:old.rindex('}')].split()==new[new.index('{')+1:new.rindex('}')].split()
def assertions(source):
 values=[];position=0
 while True:
  start=source.find('#expect(',position)
  if start<0:return values
  index=start+len('#expect(');depth=1;quoted=False;escaped=False
  while depth:
   character=source[index]
   if quoted:
    if escaped:escaped=False
    elif character=='\\':escaped=True
    elif character=='"':quoted=False
   elif character=='"':quoted=True
   elif character=='(':depth+=1
   elif character==')':depth-=1
   index+=1
  values.append(' '.join(source[start:index].split()));position=index
omitted='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeImportOmittedOwnerReviewTests.swift'
assert assertions((repository/omitted).read_text())==assertions(base_source(omitted))
conflict='Packages/PlannerCore/Tests/PlannerCoreStoreTests/NativeImportConflictReviewTests.swift'
expected_assertions=assertions(base_source(conflict))
old_assert='#expect(listConflict.before?.changedFieldNames == ["memberships"])'
new_assert='#expect( listConflict.before?.changedFieldNames == [ "completionChanges", "contextAliases", "memberships", ])'
assert expected_assertions.count(old_assert)==1
expected_assertions[expected_assertions.index(old_assert)]=new_assert
assert assertions((repository/conflict).read_text())==expected_assertions
http_path='PlannerMCPTests/BulkCompletionRoutingTests.swift'
old_cleanup='    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)\n    defer { try? FileManager.default.removeItem(at: directory) }'
old_http=base_source(http_path)
assert old_http.count(old_cleanup)==1
assert (repository/http_path).read_text()==old_http.replace(old_cleanup,'    let directory = try await makePlannerIntentStorage().directory')
assert all(value['exitCode']==0 and not value['timedOut'] and value['sqliteUnlinkWarnings']==0 for value in read_json(adapter/'execution.json').values())
summary=read_json(adapter/'test-summary.json')
assert summary['passedTests']==7 and summary['failedTests']==0 and summary['skippedTests']==0
products=read_json(adapter/'test-without-building-product-sha256.json')
assert products and all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
for suffix in ['/Planner.app/','/PlannerShareMac.appex/','/PlannerFixtures.app/']:assert any(suffix in path for path in products)
baseline=root/'initial-completion-base-bulk-http'
assert read_json(baseline/'test-summary.json')['passedTests']==1
assert read_json(baseline/'execution.json')['test-without-building']['sqliteUnlinkWarnings']==3
assert read_json(baseline/'source-sha256.json')==read_json(root/'eligible-alias-final-adapter-mac/source-sha256.json')
removed=[]
cleanup_phases=['smaller-canonical-first','initial-completion-history-fixed','initial-completion-bulk-first','initial-completion-native-save-failure','initial-completion-native-save-final','initial-completion-import-fixture-fix','initial-completion-validated-mac','initial-completion-validated-phone','initial-completion-validated-adapter-mac']
for phase in cleanup_phases:
 disposition=read_json(root/phase/'fixture-disposition.json');assert disposition['success'];removed.extend(disposition['removedDirectories'])
assert len(removed)==len(set(removed))
files=sorted(path for path in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if path.endswith('.swift'))
assert len(files)==8
formatting=subprocess.run(['xcrun','swift-format','lint','--strict',*files],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True,text=True)
assert formatting.returncode==0,formatting.stdout+formatting.stderr
subprocess.run(['git','diff','--check'],check=True,capture_output=True)
report={'functionsPerPlatform':255,'invocationsPerPlatform':722,'suitesPerPlatform':90,'matchedCoreInputs':len(mac_inputs),'fullPhoneInputs':len(phone_inputs),'actualCoreTestProductsPerPlatform':2,'unchangedFrozenFixtureInputs':len(fixtures),'unchangedModelSourceFiles':len(models),'strictFormatFiles':len(files),'realMacHTTPFunctions':7,'macAppShareFixtureBuildsPassed':True,'preexistingConsolidationTestsByteUnchanged':True,'allOmittedOwnerAssertionsUnchanged':True,'conflictCountsAndScopeAssertionsPreservedWithExactHistoryFieldExpectation':True,'bulkHTTPBodyChangedOnlyFixtureLifetime':True,'bulkHTTPTeardownDiagnosticsReproducedOnBase':3,'allCurrentProductionAppMCPInputsMatchAdapter':True,'initialAliasHashBodyUnchanged':True,'newActualCompletionTransitionsHaveCausalHistoryBeforeDuplicates':True,'listExpandedDirectAndReviewedBulkQualified':True,'largerToSmallerCanonicalRootPreservesExactScopesAndHistory':True,'realPreparationFailureRollbackAndRetryQualified':True,'realNativeSaveFailureRollbackAndRetryQualified':True,'isolatedMacNativeSaveFunctions':1,'isolatedMacNativeSaveScopes':3,'removedClosedDisposableStores':len(removed),'firstNoChangeAssertionQualified':False,'divergentNativeAndHistoryFlagReconciliationQualified':False,'preparedOnlyReplayAfterRootChangeQualified':False,'aliasSpecificHTTPJourneyQualified':False,'nativeUIPhysicalCloudOrSystemInvocationQualified':False,'allLifetimeReconciliationQualified':False}
(root/'initial-completion-validation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'initial-completion-validation.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(root/'initial-completion-cohort.json').write_text(json.dumps(sorted(selected),indent=2)+'\n')
phase_notes={
 'smaller-canonical-first':'Additional qualification passed on unchanged production; a smaller root retains actual rank, immutable alias contributions and explicit history.',
 'initial-completion-history-red':'Four standalone/expanded actual-transition cases failed because no initial aliases or explicit changes were recorded.',
 'initial-completion-history-first':'A preflight script rejected a function-name mismatch before writing production; this attempted pass still used old production and retained the same failure.',
 'initial-completion-history-fixed':'Corrected implementation passed the four direct List/expanded cases and smaller-root regression.',
 'initial-completion-bulk-red':'The expanded twelve-case tracer passed List/expanded actions and exposed missing history in direct and reviewed bulk actions.',
 'initial-completion-bulk-first':'All twelve history cases, smaller-root qualification and existing bulk regressions passed.',
 'initial-completion-native-save-failure':'Isolated actual native willSave failures rolled back all targets and metadata and allowed retry across three scopes; child log retained.',
 'initial-completion-final-mac':'Broader run exposed two fixture assumptions about replacement and omitted-owner history; failures retained.',
 'initial-completion-final-phone':'Same two fixture assumptions failed on iPhone; the failed Xcode run also reported a simctl debug-collection lookup error.',
 'initial-completion-final-adapter-mac':'Seven checks passed but three SQLite unlink diagnostics made teardown unqualified.',
 'initial-completion-base-bulk-http':'Unchanged committed production/test comparison reproduced all three bulk HTTP unlink diagnostics.',
 'initial-completion-import-fixture-fix':'Valid complete incoming history restores exact conflict/omission assertions, including metadata fields.',
 'initial-completion-validated-mac':'Final matched current-source Mac cohort passed with actual test products verified.',
 'initial-completion-validated-phone':'Final matched current-source iPhone Simulator cohort passed with actual test products verified.',
 'initial-completion-validated-adapter-mac':'Current-source app/Share/fixture compilation and seven actual HTTP checks passed without unlink diagnostics.',
 'initial-completion-native-save-final':'Isolated native fault repeated against final matching products and inputs; actual child log and three scopes retained.'
}
attempts=[]
for phase,note in phase_notes.items():
 packet=root/phase
 item={'phase':phase,'note':note,'sourceManifest':'source-sha256.json','rawLogsRetained':True}
 for name in ['execution.json','exit.json','test-summary.json']:
  if (packet/name).exists():item[name]=read_json(packet/name)
 attempts.append(item)
assert len(attempts)==16
(root/'initial-completion-attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
print(json.dumps(report))
