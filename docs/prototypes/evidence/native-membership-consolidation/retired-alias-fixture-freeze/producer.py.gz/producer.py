from pathlib import Path
import copy
import gzip
import hashlib
import json

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
fixtures=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/MembershipConsolidation'
graph=json.loads((fixtures/'informed-readd-v3.json').read_text())
member=graph['memberships'][0]
member['id']='00000000-0000-4000-8000-000000000401'
member['lifetimeId']='00000000-0000-4000-8000-000000000841'
member['localDone']=True
graph['deletionMarkers']=[]
graph['membershipRemovals']=[]
first=graph['membershipProvenance'][0]
second=copy.deepcopy(first)
second['membershipId']='00000000-0000-4000-8000-000000000402'
second['membershipLifetimeId']='00000000-0000-4000-8000-000000000842'
graph['membershipProvenance']=[first,second]
canonical={'kind':'listMembership','membershipId':member['id'],'membershipLifetimeId':member['lifetimeId']}
graph['contextAliases']=[
 {'aliasId':'00000000-0000-4000-8000-000000000851','context':canonical,'canonicalContext':canonical,'initialDone':False,'currentChangeId':None},
 {'aliasId':'00000000-0000-4000-8000-000000000852','context':{'kind':'listMembership','membershipId':second['membershipId'],'membershipLifetimeId':second['membershipLifetimeId']},'canonicalContext':canonical,'initialDone':True,'currentChangeId':None},
]
output=fixtures/'retired-membership-alias-v3.json'
assert not output.exists()
content=(json.dumps(graph,indent=2)+'\n').encode()
output.write_bytes(content)
evidence=workspace/'docs/prototypes/evidence/native-membership-consolidation/retired-alias-fixture-freeze'
evidence.mkdir(exist_ok=False)
(evidence/'producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(evidence/'provenance.json').write_text(json.dumps({'producer':'Independent Python literal graph, no Planner encoder or resolver','fixture':str(output.relative_to(workspace)),'sha256':hashlib.sha256(content).hexdigest(),'expected':'M401/841 remains live at rank1024 and local Done. Retired M402/842 contributes initial Done through alias852, without a Remove or strict barrier.'},indent=2)+'\n')
print(json.dumps({'fixture':output.name,'sha256':hashlib.sha256(content).hexdigest()}))
