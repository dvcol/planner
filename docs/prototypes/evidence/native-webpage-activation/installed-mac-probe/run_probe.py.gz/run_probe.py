from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import json
import subprocess
import threading

scratch_path = Path(__file__).parent
fixture_target = "mailto:planner-fixture@example.invalid"

class FixtureHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        case_name = self.path.strip("/")
        action_scripts = {
            "element-click": "fixtureLink.click();",
            "dispatch-mouse-click": "fixtureLink.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, button: 0, buttons: 1}));",
            "location-assign": "location.assign(fixtureLink.href);",
            "blank-element-click": "fixtureLink.target = '_blank'; fixtureLink.click();",
        }
        if case_name not in action_scripts:
            self.send_error(404)
            return
        document = """<!doctype html><meta charset="utf-8"><title>Activation facts</title>
<a id="fixture-link" href="mailto:planner-fixture@example.invalid">Harmless fixture</a>
<script>
window.probeRecords = [];
const fixtureLink = document.getElementById('fixture-link');
function activationRecord(label, event) {
    const record = {
        label,
        active: navigator.userActivation.isActive,
        hasBeenActive: navigator.userActivation.hasBeenActive
    };
    if (event) {
        record.trusted = event.isTrusted;
        record.button = event.button;
        record.buttons = event.buttons;
        record.detail = event.detail;
    }
    window.probeRecords.push(record);
}
fixtureLink.addEventListener('click', event => activationRecord('click-event', event));
window.addEventListener('load', () => {
    activationRecord('load');
    setTimeout(() => {
        activationRecord('before-action');
        ACTION_SCRIPT
        activationRecord('after-action');
    }, 250);
});
</script>""".replace("ACTION_SCRIPT", action_scripts[case_name])
        (scratch_path / f"{case_name}.html").write_text(document)
        response_bytes = document.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(response_bytes)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(response_bytes)

    def log_message(self, format_string, *arguments):
        with (scratch_path / "http.log").open("a") as log_file:
            log_file.write(format_string % arguments + "\n")

server = HTTPServer(("127.0.0.1", 0), FixtureHandler)
threading.Thread(target=server.serve_forever, daemon=True).start()
base_url = f"http://127.0.0.1:{server.server_port}"
command = [str(scratch_path / "ActivationProbe"), base_url]
(scratch_path / "run-command.json").write_text(json.dumps(command))
try:
    result = subprocess.run(command, capture_output=True, text=True, timeout=30)
    (scratch_path / "probe-output.jsonl").write_text(result.stdout)
    (scratch_path / "probe-stderr.log").write_text(result.stderr)
    print(result.stdout, end="")
    print("native_exit_code", result.returncode)
except subprocess.TimeoutExpired as error:
    (scratch_path / "probe-timeout.log").write_text(str(error))
    print("native_timeout_after_30_seconds")
finally:
    server.shutdown()
