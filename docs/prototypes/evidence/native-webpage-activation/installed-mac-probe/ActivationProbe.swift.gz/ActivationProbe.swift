import AppKit
import Foundation
import WebKit

@MainActor
func emit(_ record: [String: Any]) {
    let data = try! JSONSerialization.data(withJSONObject: record, options: [.sortedKeys])
    print(String(data: data, encoding: .utf8)!)
}

@MainActor
func frameRecord(_ frame: WebPage.FrameInfo) -> [String: Any] {
    [
        "isMainFrame": frame.isMainFrame,
        "url": frame.request.url?.absoluteString ?? "nil",
        "originScheme": frame.securityOrigin.protocol,
        "originHost": frame.securityOrigin.host,
        "originPort": frame.securityOrigin.port,
    ]
}

@MainActor
final class ProbeNavigation: WebPage.NavigationDeciding {
    let caseName: String

    init(caseName: String) {
        self.caseName = caseName
    }

    func decidePolicy(for action: WebPage.NavigationAction, preferences: inout WebPage.NavigationPreferences) async -> WKNavigationActionPolicy {
        let scheme = action.request.url?.scheme
        let allow = scheme == "http" || scheme == "https"
        emit([
            "event": "action",
            "case": caseName,
            "navigationType": action.navigationType.rawValue,
            "buttonNumber": action.buttonNumber,
            "requestURL": action.request.url?.absoluteString ?? "nil",
            "requestMethod": action.request.httpMethod ?? "nil",
            "requestHeaders": action.request.allHTTPHeaderFields ?? [:],
            "requestMainDocumentURL": action.request.mainDocumentURL?.absoluteString ?? "nil",
            "requestBodyCount": action.request.httpBody?.count ?? 0,
            "source": frameRecord(action.source),
            "target": action.target.map(frameRecord) ?? ["absent": true],
            "shouldPerformDownload": action.shouldPerformDownload,
            "isContentRuleListRedirect": action.isContentRuleListRedirect,
            "policy": allow ? "allow" : "cancel",
        ])
        return allow ? .allow : .cancel
    }
}

@main
struct ActivationProbe {
    @MainActor
    static func main() async {
        setbuf(stdout, nil)
        _ = NSApplication.shared
        let baseURL = URL(string: CommandLine.arguments[1])!
        for caseName in ["element-click", "dispatch-mouse-click", "location-assign", "blank-element-click"] {
            let page = WebPage(navigationDecider: ProbeNavigation(caseName: caseName))
            let requestURL = baseURL.appendingPathComponent(caseName)
            do {
                for try await event in page.load(requestURL) {
                    emit(["event": "load", "case": caseName, "value": String(describing: event)])
                    if event == .finished {
                        break
                    }
                }
                try await Task.sleep(for: .seconds(1.5))
                let result = try await page.callJavaScript("return JSON.stringify(window.probeRecords)")
                emit(["event": "script-records", "case": caseName, "value": result as? String ?? "nil"])
            } catch {
                emit(["event": "error", "case": caseName, "value": String(reflecting: error)])
            }
            page.stopLoading()
        }
        emit(["event": "complete"])
        exit(0)
    }
}
