from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
root=repository/'docs/prototypes/evidence/native-import-competing-values'
packet=root/phase
exit_result=json.loads((packet/'exit.json').read_text())
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
checks={}
for name,base in [('workspace',repository),('staged',staged)]:
 differences=[path for path,digest in manifest.items() if not (base/path).is_file() or hashlib.sha256((base/path).read_bytes()).hexdigest()!=digest]
 checks[name+'Differences']=differences
 assert not differences,differences
products=json.loads((packet/'product-sha256.json').read_text())
checks['productDifferences']=[path for path,digest in products.items() if not Path(path).is_file() or hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['inputCount']=len(manifest);checks['productCount']=len(products);checks['exitCode']=exit_result['exitCode']
summary=json.loads((packet/'test-summary.json').read_text())
checks.update({key:summary.get(key) for key in ['passedTests','failedTests','skippedTests']})
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
output=Path('/private/tmp/PlannerApprovedAdminAttachments-'+phase)
command=['xcrun','xcresulttool','export','attachments','--path',exit_result['bundle'],'--output-path',str(output)]
subprocess.run(command,check=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True)
selected=[]
for test in json.loads((output/'manifest.json').read_text()):
 for attachment in test['attachments']:
  source=output/attachment['exportedFileName'];name=attachment['suggestedHumanReadableName']
  if not name.startswith('Competing values'):continue
  if source.suffix=='.png':
   shutil.copy2(source,packet/source.name);retained=source.name
  elif source.suffix=='.txt':
   retained=source.name+'.gz';(packet/retained).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
  else:continue
  selected.append(dict(attachment,testIdentifier=test['testIdentifier'],retainedFileName=retained,originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(packet/'selected-attachments.json').write_text(json.dumps({'command':command,'attachments':selected,'videoPublished':False},indent=2)+'\n')

def typed(value):
 if value is None:return ('null',)
 if isinstance(value,bool):return ('bool',value)
 if isinstance(value,(int,float)):return ('number',*value.as_integer_ratio())
 if isinstance(value,str):return ('string',value)
 if isinstance(value,list):return ('array',tuple(typed(entry) for entry in value))
 assert isinstance(value,dict)
 return ('object',tuple(sorted((key,typed(entry)) for key,entry in value.items())))
def graph(value):
 return {key:sorted((typed(entry) for entry in entries),key=repr) if isinstance(entries,list) else typed(entries) for key,entries in value.items()}
def current_format(value):
 value=json.loads(json.dumps(value));assert value['formatVersion']==1;value['formatVersion']=2
 for entry in value['sources']:
  if entry['kind'] in ['list','itinerary']:entry['content']['manualEstimate']=None
 return value
current=current_format(json.loads((repository/'docs/fixtures/native-current-restoration-family.json').read_text()))
incoming=current_format(json.loads((repository/'docs/fixtures/native-competing-values-overwrite.json').read_text()))
item_identifier='00000000-0000-4000-8000-000000000101'
retained_lifetime='00000000-0000-4000-8000-000000000814'
def retained_binding(value):
 if isinstance(value,list):return [retained_binding(entry) for entry in value]
 if not isinstance(value,dict):return value
 result={key:retained_binding(entry) for key,entry in value.items()}
 if value.get('kind')=='item' and value.get('id')==item_identifier:result['lifetimeId']=retained_lifetime
 return result
projected=retained_binding(incoming)
expected=json.loads(json.dumps(current))
museum=next(entry for entry in projected['sources'] if entry['kind']=='item')
expected['sources']=[museum if entry['kind']=='item' and entry['id']==item_identifier else entry for entry in current['sources']]
expected['sources'] += [entry for entry in projected['sources'] if entry['id']!=item_identifier]
for table in ['memberships','itineraryEntries','expandedCompletions','contextAliases','completionChanges']:
 expected[table]+=projected[table]
for table,owner_field in [('ownedLinks','owner'),('labelAssociations','owner'),('schedules','source')]:
 represented=[entry for entry in projected[table] if entry[owner_field]['kind']=='item' and entry[owner_field]['id']==item_identifier]
 retained=[entry for entry in current[table] if entry[owner_field]['kind']=='item' and entry[owner_field]['id']==item_identifier]
 assert graph({'rows':represented})==graph({'rows':retained})
 expected[table]+=[entry for entry in projected[table] if entry not in represented]
filenames=[entry for entry in selected if entry['suggestedHumanReadableName'].startswith('Competing values delivered backup filename')]
if filenames:
 assert len(filenames)==1
 filename=gzip.decompress((packet/filenames[0]['retainedFileName']).read_bytes()).decode().strip()
 assert Path(filename).name==filename and filename.endswith('.json')
 provenance=json.loads((root/'native-inputs'/(platform+'-provenance.json')).read_text())
 provider=Path(provenance['inputs'][0]['destination']).parent
 delivered=provider/filename
 assert delivered.is_file() and delivered.stat().st_mtime>=summary['startTime']-2
 data=delivered.read_bytes();actual=json.loads(data)
 assert graph(actual)==graph(expected),(phase,'The complete graph differs from the reviewed expected values and references.')
 (packet/'delivered-backup.json.gz').write_bytes(gzip.compress(data,mtime=0))
 result={'filename':filename,'delivered':str(delivered),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'completeGraphMatches':True,'duplicatesRetainedInComparison':True,'nestedSequencesComparedExactly':True}
else:result={'notProduced':True}
(packet/'delivered-file-validation.json').write_text(json.dumps({'result':result,'nativeTestPassed':summary['failedTests']==0 and summary['passedTests']>0,'scope':'Current B/F, all omitted owners/history and complete retained Museum data; incoming values and exact new Tour/Itinerary/Tag references, without D/G.'},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'checks':checks,'captures':len([entry for entry in selected if entry['retainedFileName'].endswith('.png')]),'delivered':result}))
