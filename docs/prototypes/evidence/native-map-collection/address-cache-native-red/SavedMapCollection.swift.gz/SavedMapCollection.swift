import Foundation
import Observation
import PlannerCore
import PlannerPreviews

enum SavedMapCollectionState: Equatable {
  case idle, loading, ready
  case failed(String)
}

struct SavedMapLocationGroup {
  let coordinate: PlannerCoordinate
  var rows: [PlannerMapRowRead]
}

@MainActor @Observable
final class SavedMapCollection {
  private struct CoordinateKey: Hashable {
    let latitude: Double
    let longitude: Double
  }

  @ObservationIgnored private let addressPreviews: PlannerAddressPreviews
  @ObservationIgnored private let mapsPreviews: PlannerMapsPreviews
  private(set) var state = SavedMapCollectionState.idle
  private(set) var matchingCount: Int64 = 0
  private(set) var rows: [PlannerMapRowRead] = []
  private(set) var collection: PlannerMapCollection?
  private(set) var listBranches: [PlannerMapListBranch] = []
  private(set) var groups: [SavedMapLocationGroup] = []
  private(set) var locatedCount = 0
  private(set) var unresolvedCount = 0
  private(set) var noInputCount = 0
  @ObservationIgnored private var requestIdentifier = UUID()

  init(addressPreviews: PlannerAddressPreviews, mapsPreviews: PlannerMapsPreviews) {
    self.addressPreviews = addressPreviews
    self.mapsPreviews = mapsPreviews
  }

  func reload(
    planner: PlannerCore.Planner, session: PlannerDatasetSession, query: PlannerItemQuery,
    identity: SavedItemWindowIdentity
  ) async {
    guard !Task.isCancelled else { return }
    let identifier = UUID()
    requestIdentifier = identifier
    clearPublication()
    state = .loading
    let result = await planner.query(.init(session: session, request: .items(query)))
    guard !Task.isCancelled, requestIdentifier == identifier else { return }
    guard case .snapshot(let snapshot) = result else {
      if case .failed(let reason) = result { state = .failed(reason.message) }
      return
    }
    guard snapshot.matchingCount == Int64(snapshot.rows.count) else {
      state = .failed("Planner could not resolve the complete Map collection.")
      return
    }
    var loadedRows: [PlannerMapRowRead] = []
    var firstWindow: PlannerMapRowWindow?
    repeat {
      let offset = loadedRows.count
      let end = min(offset + 64, snapshot.rows.count)
      let read = await planner.read(
        session: session,
        request: .mapRows(generation: snapshot.generation, offset: Int64(offset), limit: 64))
      guard !Task.isCancelled, requestIdentifier == identifier else { return }
      guard case .mapRows(let window) = read else {
        if case .failed(let reason) = read {
          state = .failed(reason.message)
        } else {
          state = .failed("Planner could not read its Map locations.")
        }
        return
      }
      guard window.generation == snapshot.generation, window.offset == Int64(offset),
        window.matchingCount == snapshot.matchingCount,
        window.rows.map(\.identity) == Array(snapshot.rows[offset..<end])
      else {
        state = .failed("Planner could not read its complete Map page.")
        return
      }
      if let firstWindow {
        guard window.collection == firstWindow.collection,
          window.listBranches == firstWindow.listBranches
        else {
          state = .failed("Planner's Map context changed while loading.")
          return
        }
      } else {
        firstWindow = window
      }
      loadedRows.append(contentsOf: window.rows)
    } while loadedRows.count < snapshot.rows.count
    rows = loadedRows
    matchingCount = snapshot.matchingCount
    collection = firstWindow?.collection
    listBranches = firstWindow?.listBranches ?? []
    publishOwnedLocations()
    state = .ready
  }

  func cancel() {
    requestIdentifier = UUID()
    clearPublication()
    state = .idle
  }

  private func clearPublication() {
    matchingCount = 0
    rows = []
    collection = nil
    listBranches = []
    groups = []
    locatedCount = 0
    unresolvedCount = 0
    noInputCount = 0
  }

  private func publishOwnedLocations() {
    var groupIndices: [CoordinateKey: Int] = [:]
    var locationGroups: [SavedMapLocationGroup] = []
    for row in rows {
      guard let coordinate = row.ownedLocation?.coordinate else {
        let address = row.ownedLocation?.formattedAddress ?? ""
        if address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && row.mapsLinks.isEmpty
        {
          noInputCount += 1
        } else {
          unresolvedCount += 1
        }
        continue
      }
      locatedCount += 1
      let key = CoordinateKey(latitude: coordinate.latitude, longitude: coordinate.longitude)
      if let index = groupIndices[key] {
        locationGroups[index].rows.append(row)
      } else {
        groupIndices[key] = locationGroups.count
        locationGroups.append(.init(coordinate: coordinate, rows: [row]))
      }
    }
    groups = locationGroups
  }
}
