import Foundation
import PlannerCore
import PlannerPreviews
import XCTest

@testable import Planner

@MainActor
final class SavedMapCollectionTests: XCTestCase {
  func testAddressResolutionReusesDetailsCacheAndKeepsRepeatedAppearanceChoices() async throws {
    let (planner, session) = try await makePlanner()
    let cached = try await createItem(
      title: "Cached museum",
      location: .init(displayName: nil, formattedAddress: "Cached address", coordinate: nil),
      planner: planner, session: session)
    let fresh = try await createItem(
      title: "Fresh museum",
      location: .init(displayName: nil, formattedAddress: "Fresh address", coordinate: nil),
      planner: planner, session: session)
    let owned = try await createItem(
      title: "Owned museum",
      location: .init(
        displayName: nil, formattedAddress: "Never look up this address",
        coordinate: .init(latitude: 33, longitude: 137)), planner: planner, session: session)
    let itinerary = try await apply(
      .createItinerary(content: .init(title: "Museum route")), planner: planner, session: session)
    var entries: [UUID] = []
    for source in [cached, fresh, cached, fresh, owned] {
      let result = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .addItineraryEntry(
            itineraryId: itinerary.id, source: source, placement: .last)))
      guard case .applied(let applied, .complete) = result.outcome,
        case .itineraryEntry(let identifier, _, _)? = applied.generatedReferences.first
      else { throw CancellationError() }
      entries.append(identifier)
    }
    guard
      case .source(.item(let cachedSource)) = await planner.read(
        session: session, request: .source(cached))
    else { throw CancellationError() }
    let addressProvider = RecordingMapAddressProvider()
    addressProvider.candidatesByAddress = [
      "Cached address": [
        .init(id: "cached", name: "Cached place", address: nil, latitude: 35, longitude: 139)
      ],
      "Fresh address": [
        .init(id: "fresh", name: "Fresh place", address: nil, latitude: 36, longitude: 140)
      ],
    ]
    let addressPreviews = PlannerAddressPreviews(provider: addressProvider)
    await addressPreviews.loadAddress(
      .init(
        source: .init(
          namespace: "address-route", sourceId: cached.id,
          sourceLifetimeId: cachedSource.sourceLifetimeId), address: "Cached address"))
    let mapsProvider = RecordingMapLinkProvider()
    let collection = SavedMapCollection(
      addressPreviews: addressPreviews, mapsPreviews: .init(provider: mapsProvider))
    guard case .exported(let before) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    await collection.reload(
      planner: planner, session: session,
      query: .init(
        scope: .itinerary(itinerary.id), completion: .all, archive: .all,
        sort: .init(mode: .manual)),
      identity: .init(namespace: "address-route", savedRevision: UUID()))
    try await waitUntil { collection.locatedCount == 5 }
    XCTAssertEqual(collection.state, .ready)
    XCTAssertEqual(collection.collection?.source, itinerary)
    XCTAssertEqual(collection.collection?.title, "Museum route")
    XCTAssertEqual(collection.matchingCount, 5)
    XCTAssertEqual(collection.unresolvedCount, 0)
    XCTAssertEqual(collection.noInputCount, 0)
    XCTAssertEqual(addressProvider.requests, ["Cached address", "Fresh address"])
    XCTAssertTrue(mapsProvider.requests.isEmpty)
    XCTAssertEqual(
      collection.groups.map(\.coordinate),
      [
        .init(latitude: 35, longitude: 139), .init(latitude: 36, longitude: 140),
        .init(latitude: 33, longitude: 137),
      ])
    guard collection.groups.count == 3 else {
      XCTFail("Both address previews and the owned coordinate must be located.")
      return
    }
    XCTAssertEqual(
      collection.groups[0].rows.map(\.identity),
      [0, 2].map {
        .appearance(
          source: cached,
          appearance: .directItineraryItem(itineraryId: itinerary.id, entryId: entries[$0]))
      })
    XCTAssertEqual(
      collection.groups[1].rows.map(\.identity),
      [1, 3].map {
        .appearance(
          source: fresh,
          appearance: .directItineraryItem(itineraryId: itinerary.id, entryId: entries[$0]))
      })
    guard case .exported(let after) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    XCTAssertEqual(after, before)
  }

  func testCompleteCollectionKeepsOffscreenOwnedPinsAndExactGroupedChoices() async throws {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerMapCollectionFixtures", directoryHint: .isDirectory)
      .appending(path: UUID().uuidString, directoryHint: .isDirectory)
    print("Planner Map-collection fixture directory: \(directory.path)")
    let planner = PlannerCore.Planner(
      configuration: .init(
        storeURL: directory.appending(path: "store/Planner.sqlite"),
        controlURL: directory.appending(path: "control/writer"),
        recoveryDirectoryURL: directory.appending(path: "recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else {
      throw CancellationError()
    }
    let coordinates: [Int: PlannerCoordinate] = [
      0: .init(latitude: 35, longitude: 139),
      63: .init(latitude: 35, longitude: 139),
      64: .init(latitude: 36, longitude: 140),
      129: .init(latitude: 37, longitude: 141),
    ]
    var expectedSources: [PlannerEntityReference] = []
    for index in 0..<130 {
      let location: PlannerOwnedLocation? = coordinates[index].map { coordinate in
        .init(displayName: "Owned place \(index)", formattedAddress: nil, coordinate: coordinate)
      }
      let result = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(
            content: .init(title: String(format: "Map Activity %03d", index), location: location))))
      guard case .applied(let applied, .complete) = result.outcome else {
        XCTFail("The real fixture Item must save completely: \(result.outcome)")
        return
      }
      expectedSources.append(try XCTUnwrap(applied.generated.first))
    }
    guard case .exported(let before) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    let addressProvider = RecordingMapAddressProvider()
    let mapsProvider = RecordingMapLinkProvider()
    let collection = SavedMapCollection(
      addressPreviews: .init(provider: addressProvider), mapsPreviews: .init(provider: mapsProvider)
    )
    await collection.reload(
      planner: planner, session: session,
      query: .init(scope: .global, completion: .all, archive: .all),
      identity: .init(namespace: "owned-map-pins", savedRevision: UUID()))
    XCTAssertEqual(collection.state, .ready)
    XCTAssertEqual(collection.matchingCount, 130)
    XCTAssertEqual(collection.rows.map(\.identity), expectedSources.map { .source($0) })
    XCTAssertNil(collection.collection)
    XCTAssertTrue(collection.listBranches.isEmpty)
    XCTAssertEqual(collection.locatedCount, 4)
    XCTAssertEqual(collection.noInputCount, 126)
    XCTAssertEqual(collection.unresolvedCount, 0)
    XCTAssertEqual(
      collection.groups.map(\.coordinate),
      [
        .init(latitude: 35, longitude: 139), .init(latitude: 36, longitude: 140),
        .init(latitude: 37, longitude: 141),
      ])
    guard collection.rows.count == 130, collection.groups.count == 3 else {
      XCTFail("The complete Map must retain all rows and the three literal coordinate groups.")
      return
    }
    XCTAssertEqual(
      collection.groups[0].rows.map(\.identity),
      [.source(expectedSources[0]), .source(expectedSources[63])])
    XCTAssertEqual(collection.groups[1].rows.map(\.identity), [.source(expectedSources[64])])
    XCTAssertEqual(collection.groups[2].rows.map(\.identity), [.source(expectedSources[129])])
    for position in [0, 63, 64, 129] {
      XCTAssertEqual(collection.rows[position].ownedLocation?.coordinate, coordinates[position])
      XCTAssertEqual(collection.rows[position].title, String(format: "Map Activity %03d", position))
    }
    XCTAssertTrue(addressProvider.requests.isEmpty)
    XCTAssertTrue(mapsProvider.requests.isEmpty)
    guard case .exported(let after) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    XCTAssertEqual(after, before)
  }

  private func makePlanner() async throws -> (PlannerCore.Planner, PlannerDatasetSession) {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerMapCollectionFixtures", directoryHint: .isDirectory)
      .appending(path: UUID().uuidString, directoryHint: .isDirectory)
    print("Planner Map-collection fixture directory: \(directory.path)")
    let planner = PlannerCore.Planner(
      configuration: .init(
        storeURL: directory.appending(path: "store/Planner.sqlite"),
        controlURL: directory.appending(path: "control/writer"),
        recoveryDirectoryURL: directory.appending(path: "recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    return (planner, session)
  }

  private func createItem(
    title: String, location: PlannerOwnedLocation, planner: PlannerCore.Planner,
    session: PlannerDatasetSession
  ) async throws -> PlannerEntityReference {
    try await apply(
      .createItem(content: .init(title: title, location: location)), planner: planner,
      session: session)
  }

  private func apply(
    _ command: PlannerCommand, planner: PlannerCore.Planner, session: PlannerDatasetSession
  ) async throws -> PlannerEntityReference {
    let result = await planner.execute(
      .init(operationId: UUID(), session: session, command: command))
    guard case .applied(let applied, .complete) = result.outcome else {
      XCTFail("Fixture command must save completely: \(result.outcome)")
      throw CancellationError()
    }
    return try XCTUnwrap(applied.generated.first)
  }

  private func waitUntil(_ predicate: @MainActor () -> Bool) async throws {
    let deadline = ContinuousClock.now.advanced(by: .seconds(3))
    while !predicate(), ContinuousClock.now < deadline {
      try await Task.sleep(for: .milliseconds(10))
    }
    XCTAssertTrue(predicate(), "The production collection must publish the expected result.")
  }
}

@MainActor
private final class RecordingMapAddressProvider: PlannerAddressPreviewProvider {
  private(set) var requests: [String] = []
  var candidatesByAddress: [String: [PlannerAddressCandidate]] = [:]

  func addressPreview(for address: String) async throws -> [PlannerAddressCandidate] {
    requests.append(address)
    return candidatesByAddress[address] ?? []
  }
}

@MainActor
private final class RecordingMapLinkProvider: PlannerMapsPreviewProvider {
  private(set) var requests: [String] = []

  func mapsPreview(for originalURL: String) async -> PlannerCapturePreviewCandidate? {
    requests.append(originalURL)
    return nil
  }
}
