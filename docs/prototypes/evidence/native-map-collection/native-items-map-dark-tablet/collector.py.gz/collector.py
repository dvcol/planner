from pathlib import Path
import gzip,hashlib,json,os,struct,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/native-map-collection'/phase
summary=json.loads((packet/'test-summary.json').read_text())
assert summary['result']=='Passed' and summary['failedTests']==0 and summary['skippedTests']==0
execution=json.loads((packet/'exit.json').read_text());assert execution['exitCode']==0
export=Path('/private/tmp/PlannerMapUIAttachments-'+phase)
result=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',execution['bundle'],'--output-path',str(export)],capture_output=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
result.check_returncode()
(packet/'attachment-export.log.gz').write_bytes(gzip.compress(result.stdout+result.stderr,mtime=0))
manifest=json.loads((export/'manifest.json').read_text())
(packet/'original-attachment-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
captures=[]
for case in manifest:
 for attachment in case['attachments']:
  name=attachment['suggestedHumanReadableName']
  if not name.startswith('Native Items Map retains its pin and Locations control'):continue
  data=(export/attachment['exportedFileName']).read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'
  (packet/'items-map.png').write_bytes(data)
  captures.append({'file':'items-map.png','original':name,'exportedFile':attachment['exportedFileName'],'sha256':hashlib.sha256(data).hexdigest(),'dimensions':list(struct.unpack('>II',data[16:24]))})
assert len(captures)==1
(packet/'capture-manifest.json').write_text(json.dumps(captures,indent=2)+'\n')
sources=json.loads((packet/'source-sha256.json').read_text())
root=Path(json.loads((packet/'source-root.json').read_text())['root'])
assert all(hashlib.sha256((base/path).read_bytes()).hexdigest()==digest for base in [repository,root] for path,digest in sources.items())
products=json.loads((packet/'product-sha256.json').read_text());assert products
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
unlink=[line for line in log.splitlines() if 'unlinked' in line.lower() and 'sqlite' in line.lower()];assert not unlink
qualification={'sourceInputCount':len(sources),'sourceDifferences':[],'actualProductCount':len(products),'productDifferences':[],'passedFunctions':summary['passedTests'],'failedFunctions':0,'skippedFunctions':0,'sqliteUnlinkDiagnostics':unlink,'originalCaptureCount':1,'meaning':'Actual native creation, collection Map pin, exact saved-link detail and unlocated Locations selection on the represented Simulator. Not List/Itinerary Map integration, counted-marker choice, full visual/accessibility, Mac UI or physical acceptance.'}
(packet/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(qualification))
