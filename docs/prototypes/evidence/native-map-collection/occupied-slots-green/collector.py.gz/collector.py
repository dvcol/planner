from pathlib import Path
import gzip,hashlib,json,re,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/native-map-collection'/phase
summary=json.loads((packet/'test-summary.json').read_text())
assert summary['result']=='Passed' and summary['failedTests']==0 and summary['skippedTests']==0
assert json.loads((packet/'exit.json').read_text())['exitCode']==0
sources=json.loads((packet/'source-sha256.json').read_text())
root=Path(json.loads((packet/'source-root.json').read_text())['root'])
for base in [repository,root]:
 assert all((base/path).is_file() and hashlib.sha256((base/path).read_bytes()).hexdigest()==digest for path,digest in sources.items())
products=json.loads((packet/'product-sha256.json').read_text())
assert products and all(Path(path).is_file() and hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
unlink=[line for line in log.splitlines() if 'unlinked' in line.lower() and 'sqlite' in line.lower()]
assert not unlink
fixtures=re.findall(r'Planner Map-collection fixture directory: (.+)',log)
result={'sourceInputCount':len(sources),'actualProductCount':len(products),'sourceDifferences':[],'productDifferences':[],'passedFunctions':summary['passedTests'],'failedFunctions':0,'skippedFunctions':0,'sqliteUnlinkDiagnostics':unlink,'fixtureDirectories':fixtures,'meaning':'Actual app-hosted production-interface execution using real Planner storage and existing provider boundaries. Not native Map UI, physical performance, signed CloudKit or system Shortcuts qualification.'}
if phase=='owned-pins-green':
 red=packet.parent/'owned-pins-red'
 assert (red/'SavedMapCollectionTests.swift.gz').read_bytes()==(packet/'SavedMapCollectionTests.swift.gz').read_bytes()
 assert json.loads((red/'test-summary.json').read_text())['failedTests']==1
 result['unchangedRedGreenTestSha256']=hashlib.sha256(gzip.decompress((packet/'SavedMapCollectionTests.swift.gz').read_bytes())).hexdigest()
(packet/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(result))
