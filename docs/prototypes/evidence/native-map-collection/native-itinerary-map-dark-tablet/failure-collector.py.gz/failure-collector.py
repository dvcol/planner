from pathlib import Path
import json,hashlib,gzip,struct,os,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
packet=repository/'docs/prototypes/evidence/native-map-collection/native-itinerary-map-dark-tablet'
export=Path('/private/tmp/PlannerItineraryMapTabletFailureAttachments')
summary=json.loads((packet/'test-summary.json').read_text());assert summary['passedTests']==4 and summary['failedTests']==2 and summary['skippedTests']==0
assert json.loads((packet/'exit.json').read_text())['exitCode']==65
sources=json.loads((packet/'source-sha256.json').read_text());frozen=Path(json.loads((packet/'source-root.json').read_text())['root'])
assert all(hashlib.sha256((base/path).read_bytes()).hexdigest()==digest for base in [repository,frozen] for path,digest in sources.items())
products=json.loads((packet/'product-sha256.json').read_text());assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
manifest=json.loads((export/'manifest.json').read_text());(packet/'original-attachment-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
names={'Native Items Map retains its pin and Locations control':'items-map.png','Counted native Map marker keeps exact Item choices':'coincident-items-map.png','List Map opens its exact completed membership':'list-map-membership.png'}
captures=[]
for case in manifest:
 for attachment in case['attachments']:
  name=attachment['suggestedHumanReadableName'];filename=attachment['exportedFileName']
  for prefix,destination in names.items():
   if not name.startswith(prefix):continue
   data=(export/filename).read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n';(packet/destination).write_bytes(data)
   captures.append({'file':destination,'original':name,'exportedFile':filename,'sha256':hashlib.sha256(data).hexdigest(),'dimensions':list(struct.unpack('>II',data[16:24]))})
  if 'hierarchy' in name:
   identifier=case['testIdentifier'].split('/')[0]+'-'+Path(filename).stem+'.txt.gz'
   (packet/identifier).write_bytes(gzip.compress((export/filename).read_bytes(),mtime=0))
assert len(captures)==3
(packet/'capture-manifest.json').write_text(json.dumps(captures,indent=2)+'\n')
assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal']
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode();unlink=[line for line in log.splitlines() if 'sqlite' in line.lower() and 'unlinked' in line.lower()];assert not unlink
(packet/'toolbar-diagnosis.json').write_text(json.dumps({'sourceInputCount':len(sources),'sourceDifferences':[],'actualProductCount':len(products),'productDifferences':[],'passedFunctions':4,'failedFunctions':2,'skippedFunctions':0,'sqliteUnlinkDiagnostics':unlink,'cohortResult':'Failed','meaning':'Itinerary reader, coincident sources, Items pin/Locations and List-local Map cases pass. Ordinary itinerary and repeated-stop setup fail at Add Entry, which is absent from the narrow primary toolbar. Both actual hierarchies show View, Filters, disabled Edit and native More. Correct View priority using the native secondary placement. No passing cohort or itinerary-Map credit.'},indent=2)+'\n')
(packet/'failure-collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Preserved failed cohort, four independent passes, two toolbar failures and three original Map captures')
