import Foundation
import PlannerCore
import PlannerPreviews
import XCTest

@testable import Planner

@MainActor
final class SavedMapCollectionTests: XCTestCase {
  func testCompleteCollectionKeepsOffscreenOwnedPinsAndExactGroupedChoices() async throws {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerMapCollectionFixtures", directoryHint: .isDirectory)
      .appending(path: UUID().uuidString, directoryHint: .isDirectory)
    print("Planner Map-collection fixture directory: \(directory.path)")
    let planner = PlannerCore.Planner(
      configuration: .init(
        storeURL: directory.appending(path: "store/Planner.sqlite"),
        controlURL: directory.appending(path: "control/writer"),
        recoveryDirectoryURL: directory.appending(path: "recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else {
      throw CancellationError()
    }
    let coordinates: [Int: PlannerCoordinate] = [
      0: .init(latitude: 35, longitude: 139),
      63: .init(latitude: 35, longitude: 139),
      64: .init(latitude: 36, longitude: 140),
      129: .init(latitude: 37, longitude: 141),
    ]
    var expectedSources: [PlannerEntityReference] = []
    for index in 0..<130 {
      let location: PlannerOwnedLocation? = coordinates[index].map { coordinate in
        .init(displayName: "Owned place \(index)", formattedAddress: nil, coordinate: coordinate)
      }
      let result = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(
            content: .init(title: String(format: "Map Activity %03d", index), location: location))))
      guard case .applied(let applied, .complete) = result.outcome else {
        XCTFail("The real fixture Item must save completely: \(result.outcome)")
        return
      }
      expectedSources.append(try XCTUnwrap(applied.generated.first))
    }
    guard case .exported(let before) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    let addressProvider = RecordingMapAddressProvider()
    let mapsProvider = RecordingMapLinkProvider()
    let collection = SavedMapCollection(
      addressPreviews: .init(provider: addressProvider), mapsPreviews: .init(provider: mapsProvider)
    )
    await collection.reload(
      planner: planner, session: session,
      query: .init(scope: .global, completion: .all, archive: .all),
      identity: .init(namespace: "owned-map-pins", savedRevision: UUID()))
    XCTAssertEqual(collection.state, .ready)
    XCTAssertEqual(collection.matchingCount, 130)
    XCTAssertEqual(collection.rows.map(\.identity), expectedSources.map { .source($0) })
    XCTAssertNil(collection.collection)
    XCTAssertTrue(collection.listBranches.isEmpty)
    XCTAssertEqual(collection.locatedCount, 4)
    XCTAssertEqual(collection.noInputCount, 126)
    XCTAssertEqual(collection.unresolvedCount, 0)
    XCTAssertEqual(
      collection.groups.map(\.coordinate),
      [
        .init(latitude: 35, longitude: 139), .init(latitude: 36, longitude: 140),
        .init(latitude: 37, longitude: 141),
      ])
    guard collection.rows.count == 130, collection.groups.count == 3 else {
      XCTFail("The complete Map must retain all rows and the three literal coordinate groups.")
      return
    }
    XCTAssertEqual(
      collection.groups[0].rows.map(\.identity),
      [.source(expectedSources[0]), .source(expectedSources[63])])
    XCTAssertEqual(collection.groups[1].rows.map(\.identity), [.source(expectedSources[64])])
    XCTAssertEqual(collection.groups[2].rows.map(\.identity), [.source(expectedSources[129])])
    for position in [0, 63, 64, 129] {
      XCTAssertEqual(collection.rows[position].ownedLocation?.coordinate, coordinates[position])
      XCTAssertEqual(collection.rows[position].title, String(format: "Map Activity %03d", position))
    }
    XCTAssertTrue(addressProvider.requests.isEmpty)
    XCTAssertTrue(mapsProvider.requests.isEmpty)
    guard case .exported(let after) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    XCTAssertEqual(after, before)
  }
}

@MainActor
private final class RecordingMapAddressProvider: PlannerAddressPreviewProvider {
  private(set) var requests: [String] = []

  func addressPreview(for address: String) async throws -> [PlannerAddressCandidate] {
    requests.append(address)
    return []
  }
}

@MainActor
private final class RecordingMapLinkProvider: PlannerMapsPreviewProvider {
  private(set) var requests: [String] = []

  func mapsPreview(for originalURL: String) async -> PlannerCapturePreviewCandidate? {
    requests.append(originalURL)
    return nil
  }
}
