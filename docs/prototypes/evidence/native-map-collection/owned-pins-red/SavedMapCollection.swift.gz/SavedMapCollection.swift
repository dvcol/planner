import Foundation
import Observation
import PlannerCore
import PlannerPreviews

enum SavedMapCollectionState: Equatable {
  case idle, loading, ready
  case failed(String)
}

struct SavedMapLocationGroup {
  let coordinate: PlannerCoordinate
  let rows: [PlannerMapRowRead]
}

@MainActor @Observable
final class SavedMapCollection {
  @ObservationIgnored private let addressPreviews: PlannerAddressPreviews
  @ObservationIgnored private let mapsPreviews: PlannerMapsPreviews
  private(set) var state = SavedMapCollectionState.idle
  private(set) var matchingCount: Int64 = 0
  private(set) var rows: [PlannerMapRowRead] = []
  private(set) var collection: PlannerMapCollection?
  private(set) var listBranches: [PlannerMapListBranch] = []
  private(set) var groups: [SavedMapLocationGroup] = []
  private(set) var locatedCount = 0
  private(set) var unresolvedCount = 0
  private(set) var noInputCount = 0

  init(addressPreviews: PlannerAddressPreviews, mapsPreviews: PlannerMapsPreviews) {
    self.addressPreviews = addressPreviews
    self.mapsPreviews = mapsPreviews
  }

  func reload(
    planner: PlannerCore.Planner, session: PlannerDatasetSession, query: PlannerItemQuery,
    identity: SavedItemWindowIdentity
  ) async {}

  func cancel() {}
}
