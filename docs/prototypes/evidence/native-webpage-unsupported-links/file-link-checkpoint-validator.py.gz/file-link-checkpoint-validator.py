import gzip
import hashlib
import json
from pathlib import Path

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = repository / 'docs/prototypes/evidence/native-webpage-unsupported-links'
phases = {'file-link-phone': 1, 'file-link-phone-regression': 1, 'file-link-dark-tablet': 2}
reference = json.loads((root / 'file-link-phone/source-sha256.json').read_text())
results = []
captures = []
file_outcomes = []
for phase, expected_count in phases.items():
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0
    assert validation['passedTests'] == expected_count
    assert validation['failedTests'] == validation['skippedTests'] == 0
    assert not any(validation[name] for name in ['workspaceDifferences', 'stagedDifferences', 'productDifferences'])
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    assert 'unlinked while open' not in log and 'vnode unlinked' not in log
    results.append({'phase': phase, 'passedFunctions': expected_count, 'sqliteUnlinkDiagnostics': 0})
    for attachment in json.loads((packet / 'selected-attachments.json').read_text())['attachments']:
        path = packet / attachment['retainedFileName']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == attachment['originalSha256']
        if path.suffix == '.png':
            captures.append({'path': str(path.relative_to(root)), 'sha256': attachment['originalSha256'], 'visuallyInspected': True})
        elif path.suffix == '.json':
            outcome = json.loads(path.read_text())
            assert outcome == {'target': 'file:///planner-fixture-unavailable.txt', 'plannerNoticePresented': False, 'guideStillReadable': True}
            file_outcomes.append({'phase': phase, 'originalAttachment': attachment['retainedFileName'], **outcome})
assert len(captures) == 4 and len(file_outcomes) == 2
compiler = root / 'file-link-mac-compiler'
assert json.loads((compiler / 'source-sha256.json').read_text()) == reference
compiler_result = json.loads((compiler / 'boundary-validation.json').read_text())
assert compiler_result['exitCode'] == 0 and not compiler_result['runtimeCredit']
products = json.loads((compiler / 'product-sha256.json').read_text())
assert len(products) == 9
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in reference.items())
appearance = json.loads((root / 'file-link-dark-tablet/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert [value['output'] for value in appearance['observations'] if value['command'][-1] == 'appearance'] == ['dark', 'dark', 'dark']
report = {'nativeInputs': len(reference), 'nativeExecutions': results, 'totalPassedFunctions': 4, 'macBuild': compiler_result, 'macProductCount': len(products), 'fileLinkOutcomes': file_outcomes, 'originalCaptures': captures, 'productionChanges': False, 'appearanceRestored': True, 'actualMacRuntimeCredit': False, 'physicalDeviceCredit': False, 'scope': 'An activated nonexistent file URL leaves the guide readable and its bookmark unchanged; custom-scheme regressions remain distinct. No claim about every file, executable script, provider or native WebKit navigation.'}
(root / 'file-link-checkpoint-reconciliation.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'file-link-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'nativeInputs': len(reference), 'passedFunctions': 4, 'macProducts': len(products), 'inspectedOriginals': len(captures), 'observedFileNotices': [value['plannerNoticePresented'] for value in file_outcomes]}))
