import gzip
import hashlib
import json
import subprocess
from pathlib import Path

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
subprocess.run(['git', 'diff', '--quiet', '--', 'Packages', 'Planner', 'PlannerShareMobile', 'PlannerShareMac', 'PlannerFixtures', 'Configuration', 'Planner.xcodeproj'], check=True)
root = repository / 'docs/prototypes/evidence/native-webpage-unsupported-links'
phases = {'executable-data-link-phone': 1, 'executable-data-link-phone-regression': 1, 'executable-data-link-dark-tablet': 2}
reference = json.loads((root / 'executable-data-link-phone/source-sha256.json').read_text())
inspections = json.loads(Path('/private/tmp/PlannerExecutableDataLinkInspectedOriginals.json').read_text())
results = []
captures = []
outcomes = []
expected_target = 'data:text/html,%3Ch1%3EInline%20executable%20fixture%3C%2Fh1%3E%3Cscript%3Edocument.title%3D%27Executed%20inline%20fixture%27%3C%2Fscript%3E'
for phase, expected_count in phases.items():
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0
    assert validation['passedTests'] == expected_count
    assert validation['failedTests'] == validation['skippedTests'] == 0
    assert not any(validation[name] for name in ['workspaceDifferences', 'stagedDifferences', 'productDifferences'])
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    assert 'unlinked while open' not in log and 'vnode unlinked' not in log
    results.append({'phase': phase, 'passedFunctions': expected_count, 'sqliteUnlinkDiagnostics': 0})
    for attachment in json.loads((packet / 'selected-attachments.json').read_text())['attachments']:
        path = packet / attachment['retainedFileName']
        contents = path.read_bytes()
        if path.name.endswith('.txt.gz'):
            contents = gzip.decompress(contents)
        assert hashlib.sha256(contents).hexdigest() == attachment['originalSha256']
        if path.suffix == '.png':
            relative = str(path.relative_to(root))
            assert inspections[relative] == attachment['originalSha256']
            captures.append({'path': relative, 'sha256': attachment['originalSha256'], 'visuallyInspected': True})
        elif path.suffix == '.json':
            outcome = json.loads(contents)
            assert set(outcome) == {'target', 'plannerNoticePresented', 'guideStillReadable', 'inlineDocumentVisible'}
            assert outcome['target'] == expected_target
            assert type(outcome['plannerNoticePresented']) is bool
            assert outcome['guideStillReadable'] is True and outcome['inlineDocumentVisible'] is False
            outcomes.append({'phase': phase, 'originalAttachment': attachment['retainedFileName'], **outcome})
assert len(captures) == 4 and len(outcomes) == 2
assert set(inspections) == {capture['path'] for capture in captures}
compiler = root / 'executable-data-link-mac-compiler'
assert json.loads((compiler / 'source-sha256.json').read_text()) == reference
compiler_result = json.loads((compiler / 'boundary-validation.json').read_text())
assert compiler_result['exitCode'] == 0 and not compiler_result['runtimeCredit']
products = json.loads((compiler / 'product-sha256.json').read_text())
assert len(products) == 9
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in reference.items())
appearance = json.loads((root / 'executable-data-link-dark-tablet/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert [value['output'] for value in appearance['observations'] if value['command'][-1] == 'appearance'] == ['dark', 'dark', 'dark']
report = {'nativeInputs': len(reference), 'nativeExecutions': results, 'totalPassedFunctions': 4, 'macBuild': compiler_result, 'macProductCount': len(products), 'executableDataLinkOutcomes': outcomes, 'originalCaptures': captures, 'productionChanges': False, 'appearanceRestored': True, 'actualMacRuntimeCredit': False, 'physicalDeviceCredit': False, 'scope': 'The activated data HTML/script URL cannot replace the saved guide; exact unsupported notices, onward HTTP navigation and original bookmarks survive. Other executable URL forms, arbitrary webpages, actual Mac and physical behavior remain unqualified.'}
(root / 'executable-data-link-checkpoint-reconciliation.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'executable-data-link-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'nativeInputs': len(reference), 'passedFunctions': 4, 'macProducts': len(products), 'inspectedOriginals': len(captures), 'observedPlannerNotices': [value['plannerNoticePresented'] for value in outcomes]}))
