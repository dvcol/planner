from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-webpage-calendar-return'
phases={
 'calendar-return-phone-stable-reader-final':(3,9),
 'calendar-itinerary-return-dark-tablet-stable-reader':(1,4),
 'calendar-return-dark-tablet-regressions-final':(2,5),
 'calendar-return-phone-healthy-final':(1,1),
 'calendar-return-dark-tablet-healthy-final':(1,1),
}
reference=None
results=[]
for phase,(expected_functions,expected_captures) in phases.items():
 packet=root/phase
 inputs=json.loads((packet/'source-sha256.json').read_text())
 if reference is None:reference=inputs
 assert inputs==reference,phase
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items()),phase
 boundary=json.loads((packet/'boundary-validation.json').read_text())
 assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences'],phase
 summary=json.loads((packet/'test-summary.json').read_text())
 assert summary['result']=='Passed' and summary['passedTests']==expected_functions and summary['totalTestCount']==expected_functions and summary['failedTests']==summary['skippedTests']==0,phase
 captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
 assert len(captures)==expected_captures,phase
 inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
 assert set(inspected).issubset({capture['file'] for capture in captures}),phase
 for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256'],phase
 if 'dark-tablet' in phase:assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal'],phase
 results.append({'phase':phase,'passedFunctions':expected_functions,'retainedOriginalCaptures':expected_captures,'inspectedOriginalCaptures':len(inspected),'sourceInputs':len(inputs),'retainedProducts':boundary['retainedProductCount']})
mac=root/'calendar-return-mac-compiler-final'
assert json.loads((mac/'source-sha256.json').read_text())==reference
boundary=json.loads((mac/'boundary-validation.json').read_text())
assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences'] and boundary['retainedProductCount']==9
changed_production=subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerShareMobile','PlannerShareMac'],text=True).splitlines()
assert changed_production==['Planner/Scenes/SavedPlannerView.swift'],changed_production
record={
 'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'sourceInputs':len(reference),'nativeExecutions':results,
 'totalPassedNativeExecutions':sum(result['passedFunctions'] for result in results),
 'totalRetainedOriginalCaptures':sum(result['retainedOriginalCaptures'] for result in results),
 'totalInspectedOriginalCaptures':sum(result['inspectedOriginalCaptures'] for result in results),
 'macCompiler':{'phase':mac.name,'retainedProducts':boundary['retainedProductCount'],'runtimeCredit':False},
 'changedProduction':changed_production,
 'changedNativeTests':subprocess.check_output(['git','diff','--name-only','--','PlannerFixtureUITests','PlannerNavigationUITests'],text=True).splitlines(),
 'limits':['These journeys qualify deleted Calendar Item/Itinerary origins, their surviving source containers and the represented existing healthy Calendar/Items returns. Other removal/replacement lifetimes remain separate.','Actual Mac UI/resizing, interactive reader closure, broad accessibility, physical devices and whole-app polish remain open.','Earlier driver/navigation failures and preliminary passes remain separate source epochs and are excluded from final totals.'],
 'meaning':'All final source inputs match. Each source/product boundary was validated before reuse. Original captures reconcile; only the explicitly listed subset receives visual-inspection credit.'
}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'reconcile-checkpoint.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(record,indent=2))
