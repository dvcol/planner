from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
roots=[workspace/'docs/prototypes/evidence/native-webpage-restored-context',workspace/'docs/prototypes/evidence/native-itinerary-toolbar-compatibility',workspace/'docs/prototypes/evidence/native-import-fresh-local-values']
records=[]
for root in roots:
    for packet in sorted(root.iterdir()):
        if not packet.is_dir() or not (packet/'selected-attachments.json').is_file():continue
        directory=Path('/private/tmp/PlannerApprovedAdminAttachments-'+packet.name)
        if not directory.exists():continue
        assert directory.parent==Path('/private/tmp') and directory==directory.resolve(strict=True) and not directory.is_symlink()
        assert (packet/'boundary-validation.json').is_file()
        original=Path(json.loads((packet/'exit.json').read_text())['bundle'])
        assert original.is_dir() and not original.is_symlink()
        selected=json.loads((packet/'selected-attachments.json').read_text())['attachments']
        for item in selected:
            exported=directory/item['exportedFileName'];retained=packet/item['retainedFileName']
            content=exported.read_bytes()
            assert hashlib.sha256(content).hexdigest()==item['originalSha256']
            assert (gzip.decompress(retained.read_bytes()) if retained.suffix=='.gz' else retained.read_bytes())==content
        files=list(directory.rglob('*'))
        assert all(not path.is_symlink() and path.stat().st_uid==os.getuid() for path in [directory,*files])
        handles=subprocess.run(['/usr/sbin/lsof','-t','+D',str(directory)],capture_output=True,text=True)
        assert handles.returncode==1 and not handles.stdout.strip() and not handles.stderr.strip()
        records.append({'directory':str(directory),'originalResult':str(original),'packet':str(packet.relative_to(workspace)),'selectedAttachmentsVerified':len(selected),'nominalBytes':sum(path.stat().st_size for path in files if path.is_file()),'exportManifestSha256':hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest()})
report={'scope':'Completed duplicate xcresult attachment exports only; original results, retained captures, products, sources and all datasets preserved.','candidates':records,'removedDirectories':[],'nominalBytes':0}
report_path=roots[0]/'completed-map-checkpoint-export-cleanup.json'
report_path.write_text(json.dumps(report,indent=2)+'\n')
for record in records:
    directory=Path(record['directory'])
    assert hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest()==record['exportManifestSha256']
    shutil.rmtree(directory)
    report['removedDirectories'].append(str(directory));report['nominalBytes']+=record['nominalBytes']
    report_path.write_text(json.dumps(report,indent=2)+'\n')
(roots[0]/'completed-map-checkpoint-export-cleanup.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'removedDirectories':len(report['removedDirectories']),'nominalBytes':report['nominalBytes'],'retainedOriginalResults':len(records),'verifiedRetainedAttachments':sum(record['selectedAttachmentsVerified'] for record in records)}))
