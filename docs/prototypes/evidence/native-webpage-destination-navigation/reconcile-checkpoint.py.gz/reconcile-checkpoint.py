from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-webpage-destination-navigation'
reference=None
executions=[]
for phase in ['destination-navigation-phone-final','destination-navigation-dark-tablet-final']:
 packet=root/phase
 inputs=json.loads((packet/'source-sha256.json').read_text())
 if reference is None:reference=inputs
 assert inputs==reference
 assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
 boundary=json.loads((packet/'boundary-validation.json').read_text())
 assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
 summary=json.loads((packet/'test-summary.json').read_text())
 assert summary['result']=='Passed' and summary['passedTests']==summary['totalTestCount']==2 and summary['failedTests']==summary['skippedTests']==0
 captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
 inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
 assert len(captures)==len(inspected)==5 and set(inspected)=={capture['file'] for capture in captures}
 for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256']
 if 'dark-tablet' in phase:assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal']
 executions.append({'phase':phase,'passedFunctions':2,'retainedOriginalCaptures':5,'inspectedOriginalCaptures':5,'retainedProducts':boundary['retainedProductCount']})
mac=root/'destination-navigation-mac-compiler-final'
assert json.loads((mac/'source-sha256.json').read_text())==reference
boundary=json.loads((mac/'boundary-validation.json').read_text())
assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences'] and boundary['retainedProductCount']==9
assert not subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerShareMobile','PlannerShareMac'],text=True).strip()
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(reference),'nativeExecutions':executions,'totalPassedNativeExecutions':4,'totalRetainedOriginalCaptures':10,'totalInspectedOriginalCaptures':10,'productionChanged':False,'macCompiler':{'phase':mac.name,'retainedProducts':9,'runtimeCredit':False},'limits':['These executions qualify the represented Items/Lists/Calendar transitions from an active reader and ordinary Calendar Return on phone/dark iPad, not every owner/appearance or gesture.','Actual Mac UI/resizing, physical devices, broad accessibility, other lifecycles and whole-app polish remain open.','The initial complete phone pass predates final test formatting and is excluded from these matched-source totals.'],'meaning':'Every final source input matches; source/product boundaries were validated before reuse and original capture bytes reconcile. Shipping production remains unchanged.'}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'reconcile-checkpoint.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(record,indent=2))
