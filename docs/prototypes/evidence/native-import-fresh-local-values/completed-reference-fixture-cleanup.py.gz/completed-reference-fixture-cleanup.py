from pathlib import Path
import gzip, hashlib, importlib.util, json, os, subprocess, sys
sys.dont_write_bytecode = True
workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
root = workspace / 'docs/prototypes/evidence/native-import-fresh-local-values'
specification = importlib.util.spec_from_file_location('fixture_verifier', workspace / 'scripts/verify-intent-fixtures.py')
verifier = importlib.util.module_from_spec(specification)
specification.loader.exec_module(verifier)
phases = ['fresh-local-values-references-affected-mac', 'fresh-local-values-references-affected-phone', 'fresh-local-values-owned-affected-mac', 'fresh-local-values-owned-affected-tablet', 'fresh-local-values-contexts-affected-mac', 'fresh-local-values-contexts-affected-tablet']
report = {'scope': 'Completed passing owned Core fixtures only; original runtime logs, results, sources, products, failed fixtures and user datasets retained.', 'phases': [], 'removedFixtures': 0, 'nominalBytes': 0}
report_path = root / 'completed-reference-fixture-cleanup.json'
if report_path.exists(): report = json.loads(report_path.read_text())
for phase in phases:
    if any(entry['phase'] == phase for entry in report['phases']): continue
    packet = root / phase
    assert (packet / 'boundary-validation.json').is_file()
    assert json.loads((packet / 'execution.json').read_text())['exitCode'] == 0
    content = gzip.decompress((packet / 'test.log.gz').read_bytes())
    records = verifier.read_fixtures(content.decode())
    files = [path for directory in records for path in directory.rglob('*')]
    assert all(not path.is_symlink() for path in files)
    assert all(directory.stat().st_uid == os.getuid() for directory in records)
    nominal_bytes = sum(path.stat().st_size for path in files if path.is_file())
    verifier.require_closed_hosts(records)
    verifier.require_closed_databases(records)
    temporary_log = Path('/private/tmp/PlannerFreshRestorationCleanup-' + phase + '.log')
    temporary_log.write_bytes(content)
    result = subprocess.run([sys.executable, str(workspace / 'scripts/verify-intent-fixtures.py'), str(temporary_log), '--report', str(packet / 'fixture-cleanup.json')], capture_output=True, text=True)
    disposition = json.loads((packet / 'fixture-cleanup.json').read_text())
    assert result.returncode == 0 and disposition['success'] and len(disposition['removedDirectories']) == len(records), result.stdout + result.stderr
    assert temporary_log.read_bytes() == content
    report['phases'].append({'phase': phase, 'fixtureCount': len(records), 'nominalBytes': nominal_bytes, 'sourceLogSha256': hashlib.sha256(content).hexdigest()})
    report['removedFixtures'] += len(records)
    report['nominalBytes'] += nominal_bytes
    (root / 'completed-reference-fixture-cleanup.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'completed-reference-fixture-cleanup.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps(report))
