import Foundation
import SwiftData
import Testing

@testable import PlannerCore

struct NativeMembershipConsolidationTests {
  @Test func independentNativeMembershipsReadAsOneDoneContextWithoutCompletingTheirItem()
    async throws
  {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let createdItem, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(content: .init(title: "Hotel")))
      ).outcome,
      let item = createdItem.generated.first,
      case .applied(let createdList, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createList(content: .init(name: "Tokyo")))
      ).outcome,
      let list = createdList.generated.first
    else { throw CancellationError() }

    try await insertIndependentMemberships(
      storeURL: configuration.storeURL, itemIdentifier: item.id, listIdentifier: list.id)

    let reopened = Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap() else {
      Issue.record("Native relationship delivery must retain a readable dataset.")
      return
    }
    let result = await reopened.query(
      .init(
        session: reopenedSession,
        request: .items(.init(scope: .list(list.id), completion: .done, archive: .all))))
    guard case .snapshot(let snapshot) = result else {
      Issue.record("Independent Todo/Done memberships must resolve to one Done context: \(result)")
      return
    }
    #expect(snapshot.matchingCount == 1)
    #expect(
      snapshot.rows == [
        .appearance(
          source: item,
          appearance: .listMembership(
            listId: list.id,
            membershipId: UUID(uuidString: "00000000-0000-4000-8000-000000000401")!))
      ])
    guard
      case .source(.item(let read)) = await reopened.read(
        session: reopenedSession, request: .source(item))
    else { throw CancellationError() }
    #expect(read.state.globalDone == false)
  }

  /// Model access constructs the actual persisted input; all behavioral observations use Planner.
  @MainActor private func insertIndependentMemberships(
    storeURL: URL, itemIdentifier: UUID, listIdentifier: UUID
  ) throws {
    let schema = Schema(versionedSchema: PlannerSchemaV18.self)
    let container = try ModelContainer(
      for: schema, migrationPlan: PlannerMigrationPlan.self,
      configurations: [ModelConfiguration(schema: schema, url: storeURL, cloudKitDatabase: .none)])
    let context = ModelContext(container)
    context.autosaveEnabled = false
    let item = try #require(
      context.fetch(FetchDescriptor<PlannerSchemaV18.Item>()).first { $0.id == itemIdentifier })
    let list = try #require(
      context.fetch(FetchDescriptor<PlannerSchemaV18.List>()).first { $0.id == listIdentifier })
    let itemLifetime = try #require(item.lifetimeId)
    let listLifetime = try #require(list.lifetimeId)
    for (identifier, lifetime, rank, done) in [
      ("00000000-0000-4000-8000-000000000401", "00000000-0000-4000-8000-000000000841", 1024, false),
      ("00000000-0000-4000-8000-000000000402", "00000000-0000-4000-8000-000000000842", 2048, true),
    ] {
      context.insert(
        PlannerSchemaV18.Membership(
          snapshot: .init(
            id: try #require(UUID(uuidString: identifier)),
            lifetimeId: try #require(UUID(uuidString: lifetime)),
            list: .init(kind: "list", id: listIdentifier, lifetimeId: listLifetime),
            item: .init(kind: "item", id: itemIdentifier, lifetimeId: itemLifetime),
            rank: Int64(rank), localDone: done), list: list, item: item))
    }
    try context.save()
  }
}
