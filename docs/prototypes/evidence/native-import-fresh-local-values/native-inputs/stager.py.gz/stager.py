from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
platform=sys.argv[1]
device={'phone':'2A49C66C-C8A4-435F-B98A-9A90706780DE','tablet':'FBD72DAB-1D40-4E64-912D-7F9763E00446'}[platform]
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
command=['xcrun','simctl','get_app_container',device,'com.apple.DocumentsApp','groups']
groups=dict(line.split('\t',1) for line in subprocess.check_output(command,text=True,env=environment).splitlines())
container=Path(groups['group.com.apple.FileProvider.LocalStorage'])/'File Provider Storage'
assert container.is_dir() and not container.is_symlink()
inputs=[]
for source_name,destination_name in [('fresh-local-restoration-current-v2.json','Planner fresh local deleted owner.json'),('fresh-local-restoration-incoming-v2.json','Planner fresh local incoming values.json')]:
    source=workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/PortableImport'/source_name
    destination=container/destination_name
    data=source.read_bytes()
    assert not destination.is_symlink()
    assert not destination.exists() or destination.read_bytes()==data
    destination.write_bytes(data)
    assert destination.read_bytes()==data
    inputs.append({'source':str(source.relative_to(workspace)),'destination':str(destination),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
packet=workspace/'docs/prototypes/evidence/native-import-fresh-local-values/native-inputs'
packet.mkdir(parents=True,exist_ok=True)
(packet/(platform+'-provenance.json')).write_text(json.dumps({'device':device,'containerCommand':command,'inputs':inputs},indent=2)+'\n')
(packet/'stager.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Staged',len(inputs),'literal import files for',platform)
