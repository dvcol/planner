from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
root=repository/'docs/prototypes/evidence/native-import-fresh-local-values'
packet=root/phase
exit_result=json.loads((packet/'exit.json').read_text())
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
checks={}
for name,base in [('workspace',repository),('staged',staged)]:
 differences=[path for path,digest in manifest.items() if not (base/path).is_file() or hashlib.sha256((base/path).read_bytes()).hexdigest()!=digest]
 checks[name+'Differences']=differences
 assert not differences,differences
products=json.loads((packet/'product-sha256.json').read_text())
checks['productDifferences']=[path for path,digest in products.items() if not Path(path).is_file() or hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['inputCount']=len(manifest);checks['productCount']=len(products);checks['exitCode']=exit_result['exitCode']
summary=json.loads((packet/'test-summary.json').read_text())
checks.update({key:summary.get(key) for key in ['passedTests','failedTests','skippedTests']})
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
output=Path('/private/tmp/PlannerApprovedAdminAttachments-'+phase)
command=['xcrun','xcresulttool','export','attachments','--path',exit_result['bundle'],'--output-path',str(output)]
subprocess.run(command,check=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True)
selected=[]
for test in json.loads((output/'manifest.json').read_text()):
 for attachment in test['attachments']:
  source=output/attachment['exportedFileName'];name=attachment['suggestedHumanReadableName']
  if not name.startswith('Fresh local import'):continue
  if source.suffix=='.png':
   shutil.copy2(source,packet/source.name);retained=source.name
  elif source.suffix=='.txt':
   retained=source.name+'.gz';(packet/retained).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
  else:continue
  selected.append(dict(attachment,testIdentifier=test['testIdentifier'],retainedFileName=retained,originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(packet/'selected-attachments.json').write_text(json.dumps({'command':command,'attachments':selected,'videoPublished':False},indent=2)+'\n')

def typed(value):
 if value is None:return ('null',)
 if isinstance(value,bool):return ('bool',value)
 if isinstance(value,(int,float)):return ('number',*value.as_integer_ratio())
 if isinstance(value,str):return ('string',value)
 if isinstance(value,list):return ('array',tuple(typed(element) for element in value))
 assert isinstance(value,dict)
 return ('object',tuple(sorted((key,typed(element)) for key,element in value.items())))
def graph(value):
 return {key:sorted((typed(element) for element in elements),key=repr) if isinstance(elements,list) else typed(elements) for key,elements in value.items()}
fixture_root=repository/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/PortableImport'
current=json.loads((fixture_root/'fresh-local-restoration-current-v2.json').read_text())
incoming=json.loads((fixture_root/'fresh-local-restoration-incoming-v2.json').read_text())
expected_skip=json.loads(json.dumps(current))
expected_skip['sources'].append(next(value for value in incoming['sources'] if value['kind']=='tag'))
results={}
provenance=json.loads((root/'native-inputs'/(platform+'-provenance.json')).read_text())
provider=Path(provenance['inputs'][0]['destination']).parent
expected_restored=None
for mode in ['Skip','Denied','Restored','Repeated','Relaunched']:
 attachments=[entry for entry in selected if entry['suggestedHumanReadableName'].startswith('Fresh local import '+mode+' delivered backup filename')]
 if not attachments:
  results[mode]={'notProduced':True};continue
 assert len(attachments)==1
 filename=gzip.decompress((packet/attachments[0]['retainedFileName']).read_bytes()).decode().strip()
 assert Path(filename).name==filename and filename.endswith('.json')
 delivered=provider/filename
 assert delivered.is_file() and delivered.stat().st_mtime>=summary['startTime']-2
 data=delivered.read_bytes();actual=json.loads(data)
 if mode in ['Skip','Denied']:
  expected=expected_skip
 else:
  if expected_restored is None:
   museum=next(value for value in actual['sources'] if value['kind']=='item' and value['id']=='00000000-0000-4000-8000-000000000101')
   lifetime=museum['lifetimeId']
   assert lifetime not in ['00000000-0000-4000-8000-000000000811','00000000-0000-4000-8000-000000000813']
   family=next(value for value in actual['restorationFamilies'] if value['familyId']=='BF4CA8D3-7AFB-8BF5-A2C3-7F67C76178EC')
   assert len(family['candidates'])==1
   candidate=family['candidates'][0]
   assert candidate['lifetimeId']==lifetime
   import uuid
   uuid.UUID(candidate['operationId']);uuid.UUID(lifetime)
   assert candidate['operationId'] not in ['00000000-0000-4000-8000-000000000992','00000000-0000-4000-8000-000000000996']
   expected_text=(fixture_root/'fresh-local-restoration-expected-v2.json').read_text()
   expected_restored=json.loads(expected_text.replace('$restored-lifetime',lifetime).replace('00000000-0000-4000-8000-000000000998',candidate['operationId']))
   (packet/'new-native-identities.json').write_text(json.dumps({'lifetimeId':lifetime,'operationId':candidate['operationId'],'fixedFamilyId':family['familyId']},indent=2)+'\n')
  expected=expected_restored
 assert graph(actual)==graph(expected),(phase,mode)
 retained=mode.lower()+'-delivered.json.gz';(packet/retained).write_bytes(gzip.compress(data,mtime=0))
 results[mode]={'filename':filename,'delivered':str(delivered),'retained':retained,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'completeGraphMatches':True,'tableOrderingOnlyNormalized':True}
passed=summary['failedTests']==0 and summary['passedTests']>0
if passed:assert all(not result.get('notProduced') for result in results.values()),results
(packet/'delivered-file-validation.json').write_text(json.dumps({'results':results,'nativeTestPassed':passed,'scope':'Complete literal graphs; only fresh local lifetime and issuing operation are captured; Skip and denied preserve closure; restored, repeated and relaunched exports remain identical'},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'checks':checks,'captures':len([entry for entry in selected if entry['retainedFileName'].endswith('.png')]),'delivered':results}))
