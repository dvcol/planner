from pathlib import Path
import gzip,hashlib,json,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/native-import-fresh-local-values'/sys.argv[1]
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
checks={}
for label,base in [('workspace',repository),('staged',staged)]:
 checks[label+'Differences']=[name for name,digest in manifest.items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=digest]
 assert not checks[label+'Differences']
products=json.loads((packet/'product-sha256.json').read_text())
assert products
checks['productDifferences']=[name for name,digest in products.items() if not Path(name).is_file() or hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['inputCount']=len(manifest);checks['productCount']=len(products)
execution=json.loads((packet/'execution.json').read_text())
assert execution['cases'] and not execution['runnerTimedOut']
checks.update({key:execution[key] for key in ['exitCode','sqliteUnlinkWarnings']})
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
(packet/'validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(checks))
