from pathlib import Path
import gzip, hashlib, json
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
root=workspace/'docs/prototypes/evidence/native-import-fresh-local-values'
packet=root/'fresh-local-values-owned-affected-tablet'
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
mac_manifest=json.loads((root/'fresh-local-values-owned-affected-mac/source-sha256.json').read_text())
checks={'inputCount':len(manifest),'matchingCoreInputCount':len(mac_manifest)}
for label,base in [('workspace',workspace),('staged',staged)]:
    differences=[name for name,digest in manifest.items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=digest]
    assert not differences,differences
    checks[label+'Differences']=differences
assert all(manifest[name]==digest for name,digest in mac_manifest.items())
products=json.loads((packet/'product-sha256.json').read_text())
assert len(products)==2
checks['productCount']=len(products)
checks['productDifferences']=[name for name,digest in products.items() if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['bundleFixtureSha256']={}
for fixture in (workspace/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/PortableImport').glob('fresh-local-restoration-*-v2.json'):
    bundled=Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/PlannerCoreStoreTests.xctest/Fixtures/PortableImport')/fixture.name
    assert bundled.read_bytes()==fixture.read_bytes()
    checks['bundleFixtureSha256'][str(bundled)]=hashlib.sha256(bundled.read_bytes()).hexdigest()
assert len(checks['bundleFixtureSha256'])==5
execution=json.loads((packet/'execution.json').read_text())
assert not execution['runnerTimedOut'] and execution['summary']['passedTests']==83 and execution['summary']['failedTests']==0
checks['exitCode']=execution['exitCode']
for label,phase in [('mac','fresh-local-values-owned-affected-mac'),('tablet','fresh-local-values-owned-affected-tablet')]:
    content=gzip.decompress((root/phase/'test.log.gz').read_bytes()).decode()
    checks[label+'FixtureCount']=content.count('PLANNER_STORE_FIXTURE ')
    checks[label+'SqliteUnlinkWarnings']=content.count('vnode unlinked while in use')
assert checks['macFixtureCount']==checks['tabletFixtureCount']==346
assert checks['macSqliteUnlinkWarnings']==checks['tabletSqliteUnlinkWarnings']==0
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
(packet/'validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(checks))
