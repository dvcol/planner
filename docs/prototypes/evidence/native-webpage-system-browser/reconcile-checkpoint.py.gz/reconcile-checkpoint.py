from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-webpage-system-browser'
reference=None
executions=[]
for phase,expected_functions,expected_captures in [('system-browser-phone-direct-failure-capture',1,3),('system-browser-phone-retry-final',2,2),('system-browser-dark-tablet-final',3,5)]:
    packet=root/phase
    inputs=json.loads((packet/'source-sha256.json').read_text())
    if reference is None:reference=inputs
    assert inputs==reference
    assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
    boundary=json.loads((packet/'boundary-validation.json').read_text())
    assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
    summary=json.loads((packet/'test-summary.json').read_text())
    assert summary['result']=='Passed' and summary['passedTests']==summary['totalTestCount']==expected_functions and summary['failedTests']==summary['skippedTests']==0
    captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
    inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
    assert len(captures)==len(inspected)==expected_captures and set(inspected)=={capture['file'] for capture in captures}
    for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256']
    if expected_captures in [3,5]:
        attachment=json.loads((packet/'request-attachment-manifest.json').read_text())
        assert hashlib.sha256((packet/attachment['file']).read_bytes()).hexdigest()==attachment['sha256']
        observation=json.loads((packet/attachment['file']).read_text())
        assert observation['browserBecameForeground'] and observation['browserState']==4
        assert observation['requestedExternalTarget'].endswith('/garden') and observation['originalBookmark'].endswith('/guide')
        assert observation['requestLine']=='GET /garden HTTP/1.1'
        assert any(' Safari/' in agent and agent not in observation['plannerUserAgents'] for agent in observation['externalUserAgents'])
    if 'dark-tablet' in phase:assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal']
    executions.append({'phase':phase,'passedFunctions':expected_functions,'retainedOriginalCaptures':expected_captures,'inspectedOriginalCaptures':expected_captures,'retainedProducts':boundary['retainedProductCount']})
mac=root/'system-browser-mac-compiler-final'
assert json.loads((mac/'source-sha256.json').read_text())==reference
boundary=json.loads((mac/'boundary-validation.json').read_text())
assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences'] and boundary['retainedProductCount']==9
assert not subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerShareMobile','PlannerShareMac'],text=True).strip()
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(reference),'nativeExecutions':executions,'totalPassedNativeExecutions':6,'distinctNativeFunctions':3,'totalRetainedOriginalCaptures':10,'totalInspectedOriginalCaptures':10,'productionChanged':False,'actualSystemHandoffExecutions':2,'macCompiler':{'phase':mac.name,'retainedProducts':9,'runtimeCredit':False},'limits':['The represented explicit failure fallback opens the exact linked Garden target in Safari and preserves the original Museum bookmark on phone/dark iPad.','Foreground and exact attributed HTTP requests establish handoff; screenshots do not establish completed Safari page rendering.','Other content/owner fallbacks, actual Mail/Phone/Maps activation, Mac runtime, physical devices, broad accessibility and whole-app polish remain open.','The initial screenshot-helper failure and pre-test sandbox failure are excluded from passing totals.'],'meaning':'All final source inputs match; source/product boundaries were validated before reuse, and original captures and request attachments reconcile. Shipping production remains unchanged.'}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'reconcile-checkpoint.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'passedNativeExecutions':6,'distinctFunctions':3,'originalCaptures':10,'sourceInputs':len(reference),'macCompilerProducts':9,'productionChanged':False}))
