import gzip,hashlib,io,json,os,subprocess,tarfile,time
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
source=Path('/private/tmp/PlannerPreviewIOSSource')
source.mkdir(exist_ok=False)
packet=workspace/'docs/prototypes/evidence/previews/ios-sdk/build'
packet.mkdir(parents=True,exist_ok=False)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip()
archive=subprocess.check_output(['git','archive',base,'Packages/PlannerCore','Packages/PlannerPreviews','scripts/preview-fixture-server.py'],cwd=workspace)
paths=[]
with tarfile.open(fileobj=io.BytesIO(archive)) as contents:
 for member in contents.getmembers():
  if not member.isfile():continue
  paths.append(member.name)
  destination=source/member.name
  destination.parent.mkdir(parents=True,exist_ok=True)
  destination.write_bytes(contents.extractfile(member).read())
manifest={path:hashlib.sha256((source/path).read_bytes()).hexdigest() for path in paths}
(packet/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(source),'base':base,'overlays':[],'scope':'Committed preview package, its Core dependency and existing fixture server; no production or test edits.'},indent=2)+'\n')
command=['xcodebuild','build-for-testing','-scheme','PlannerPreviews','-destination','generic/platform=iOS Simulator','-derivedDataPath','/private/tmp/PlannerPreviewIOSDerivedData','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1','-only-testing:PlannerPreviewsTests','CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
log=Path('/private/tmp/PlannerPreviewIOSBuild.log')
started=time.monotonic()
with log.open('wb') as output:
 process=subprocess.Popen(command,cwd=source/'Packages/PlannerPreviews',env=environment,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try:exit_code=process.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timed_out=True;process.terminate()
  try:exit_code=process.wait(timeout=20)
  except subprocess.TimeoutExpired:process.kill();exit_code=process.wait()
unchanged=all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
(packet/'exit.json').write_text(json.dumps({'exitCode':exit_code,'runnerTimedOut':timed_out,'elapsedSeconds':round(time.monotonic()-started,3),'frozenInputsUnchanged':unchanged,'runtimeCredit':False},indent=2)+'\n')
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Build exit',exit_code,'source unchanged',unchanged)
print(log.read_text(errors='replace')[-1800:])
