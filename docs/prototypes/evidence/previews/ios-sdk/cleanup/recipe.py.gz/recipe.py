import gzip,hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
base=workspace/'docs/prototypes/evidence/previews/ios-sdk'
audit=base/'cleanup'
audit.mkdir(exist_ok=False)
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
subprocess.run(['git','diff','--exit-code','HEAD','--',str(base)],cwd=workspace,check=True,capture_output=True)
manifest=json.loads((base/'build/source-sha256.json').read_text())
source=Path('/private/tmp/PlannerPreviewIOSSource')
assert all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
assert all(hashlib.sha256((workspace/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
for platform in ['phone','tablet']:
 packet=base/f'{platform}-runtime'
 products=json.loads((packet/'product-sha256.json').read_text())
 assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
 raw=Path(f'/private/tmp/PlannerPreviewSDK-{platform}.xcresult')
 result=subprocess.run(['xcrun','xcresulttool','get','test-results','summary','--path',str(raw)],env=environment,check=True,capture_output=True)
 assert json.loads(result.stdout)==json.loads((packet/'test-summary.json').read_text())
 assert raw.with_suffix('.log').read_bytes()==gzip.decompress((packet/'test.log.gz').read_bytes())
assert Path('/private/tmp/PlannerPreviewIOSBuild.log').read_bytes()==gzip.decompress((base/'build/build.log.gz').read_bytes())
assert json.loads((base/'server/exit.json').read_text())['exitCode']==143
paths=[Path('/private/tmp/PlannerPreviewIOSDerivedData'),Path('/private/tmp/PlannerPreviewSDK-phone.xcresult'),Path('/private/tmp/PlannerPreviewSDK-tablet.xcresult')]
source_check=subprocess.run(['lsof','-nP','+D',str(source),'-Fpfn'],capture_output=True)
retained=[]
if source_check.returncode==1 and not source_check.stdout and not source_check.stderr:paths.append(source)
else:retained.append({'path':str(source),'reason':'Open handles or an inconclusive open-file check; source copy retained.'})
records=[]
for path in paths:
 assert path.parent==Path('/private/tmp') and path.is_dir() and not path.is_symlink()
 check=subprocess.run(['lsof','-nP','+D',str(path),'-Fpfn'],capture_output=True)
 assert check.returncode==1 and not check.stdout and not check.stderr,(path,check.stdout[:100],check.stderr[:100])
 files=[candidate for candidate in path.rglob('*') if stat.S_ISREG(candidate.lstat().st_mode)]
 records.append({'path':str(path),'regularFileCount':len(files),'nominalFileBytes':sum(candidate.stat().st_size for candidate in files),'openFileCheckExitCode':check.returncode})
for path,record in zip(paths,records):
 shutil.rmtree(path)
 record['removed']=not path.exists()
 assert record['removed']
report={'evidenceCommit':'6595eceae21541f961bd63dd97cab35af31c6445','verifiedInputs':len(manifest),'verifiedRawSummaries':2,'verifiedOriginalLogs':3,'ownedServerStopped':True,'removed':records,'retained':retained,'nominalFileBytes':sum(record['nominalFileBytes'] for record in records),'metric':'Regular-file logical bytes, not an equal APFS free-space promise.','preserved':'Committed original logs/results/recipes, raw text logs, current app/UI products and source, native Maps archives, unrelated package caches, Simulator state and Planner datasets.'}
(audit/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
(audit/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'removedDirectories':len(records),'nominalFileBytes':report['nominalFileBytes'],'nominalGiB':round(report['nominalFileBytes']/1024**3,2),'retained':retained}))
