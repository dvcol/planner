import copy,hashlib,json
from pathlib import Path
root=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==root
original=json.loads((root/'docs/fixtures/portable-backup-v1.json').read_text())
def identifier(suffix):return f'00000000-0000-4000-8000-{suffix:012d}'
def binding(kind,source,lifetime):return {'kind':kind,'id':identifier(source),'lifetimeId':identifier(lifetime)}
def rebind(value):
 if isinstance(value,list):return [rebind(element) for element in value]
 if not isinstance(value,dict):return value
 result={key:rebind(element) for key,element in value.items()}
 if value.get('kind')=='item' and value.get('id')==identifier(101) and value.get('lifetimeId')==identifier(811):result['lifetimeId']=identifier(814)
 return result
current=rebind(original)
current['sources'][0]['content']['title']='Current museum'
current['sources'][0]['content']['notes']='Current restored notes'
predecessor=binding('item',101,811)
current['deletionMarkers']=[{'deletionId':identifier(892),'operationId':identifier(992),'target':{'kind':'source','source':predecessor},'closedFamilyId':None}]
current['restorationFamilies']=[{'familyId':identifier(890),'predecessor':predecessor,'candidates':[{'lifetimeId':identifier(814),'operationId':identifier(994)}]}]
empty={key:copy.deepcopy(value) if key in ['format','formatVersion'] else [] for key,value in original.items()}
old=copy.deepcopy(empty)
old['sources']=[copy.deepcopy(original['sources'][0])]
for group,owner_field in [('labelAssociations','owner'),('ownedLinks','owner'),('schedules','source')]:
 old[group]=[copy.deepcopy(value) for value in original[group] if value[owner_field]['kind']=='item' and value[owner_field]['id']==identifier(101)]
unknown=copy.deepcopy(empty)
item=copy.deepcopy(original['sources'][0]);item['lifetimeId']=identifier(813);item['content']['title']='Other museum'
food=copy.deepcopy(next(value for value in original['sources'] if value['kind']=='list'));food['id']=identifier(277);food['lifetimeId']=identifier(827);food['content']['name']='Unavailable Tour'
weekend=copy.deepcopy(next(value for value in original['sources'] if value['kind']=='itinerary'));weekend['id']=identifier(377);weekend['lifetimeId']=identifier(837);weekend['content']['title']='Unavailable Weekend'
tag=copy.deepcopy(next(value for value in original['sources'] if value['kind']=='tag'));tag['id']=identifier(602);tag['lifetimeId']=identifier(862);tag['content']['name']='Independent Rainy day'
unknown['sources']=[item,food,weekend,tag]
unknown['deletionMarkers']=copy.deepcopy(current['deletionMarkers'])
unknown['restorationFamilies']=[{'familyId':identifier(893),'predecessor':predecessor,'candidates':[{'lifetimeId':identifier(813),'operationId':identifier(996)}]}]
unknown['memberships']=[{'id':identifier(477),'lifetimeId':identifier(477),'list':binding('list',277,827),'item':binding('item',101,813),'rank':'1024','localDone':True}]
context={'kind':'listMembership','membershipId':identifier(477),'membershipLifetimeId':identifier(477)}
unknown['contextAliases']=[{'aliasId':identifier(477),'context':context,'canonicalContext':context,'initialDone':False,'currentChangeId':identifier(891)}]
unknown['completionChanges']=[{'id':identifier(891),'aliasId':identifier(477),'context':context,'done':True,'observedChangeIds':[]}]
unknown['itineraryEntries']=[{'id':identifier(478),'lifetimeId':identifier(478),'itinerary':binding('itinerary',377,837),'source':binding('list',277,827),'rank':'1024','localDone':None}]
link=copy.deepcopy(original['ownedLinks'][0]);link['id']=identifier(779);link['lifetimeId']=identifier(879);link['owner']=binding('itinerary',377,837)
unknown['ownedLinks']=[link]
schedule=copy.deepcopy(original['schedules'][0]);schedule['id']=identifier(703);schedule['lifetimeId']=identifier(873);schedule['source']=binding('itinerary',377,837)
unknown['schedules']=[schedule]
unknown['labelAssociations']=[{'id':identifier(677),'lifetimeId':identifier(677),'owner':binding('itinerary',377,837),'label':binding('tag',602,862)}]
files={'native-current-restoration-family.json':current,'native-unknown-restoration-candidate.json':unknown,'native-closed-predecessor-values.json':old}
for filename,value in files.items():
 destination=root/'docs/fixtures'/filename
 assert not destination.exists()
 destination.write_text(json.dumps(value,indent=2)+'\n')
 print(filename,hashlib.sha256(destination.read_bytes()).hexdigest())
