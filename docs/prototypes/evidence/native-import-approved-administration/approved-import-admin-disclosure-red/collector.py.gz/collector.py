from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
root=repository/'docs/prototypes/evidence/native-import-approved-administration'
packet=root/phase
exit_result=json.loads((packet/'exit.json').read_text())
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
checks={}
for name,base in [('workspace',repository),('staged',staged)]:
 differences=[path for path,digest in manifest.items() if not (base/path).is_file() or hashlib.sha256((base/path).read_bytes()).hexdigest()!=digest]
 checks[name+'Differences']=differences
 assert not differences,differences
products=json.loads((packet/'product-sha256.json').read_text())
checks['productDifferences']=[path for path,digest in products.items() if not Path(path).is_file() or hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['inputCount']=len(manifest);checks['productCount']=len(products);checks['exitCode']=exit_result['exitCode']
summary=json.loads((packet/'test-summary.json').read_text())
checks.update({key:summary.get(key) for key in ['passedTests','failedTests','skippedTests']})
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
output=Path('/private/tmp/PlannerApprovedAdminAttachments-'+phase)
command=['xcrun','xcresulttool','export','attachments','--path',exit_result['bundle'],'--output-path',str(output)]
subprocess.run(command,check=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True)
selected=[]
for test in json.loads((output/'manifest.json').read_text()):
 for attachment in test['attachments']:
  source=output/attachment['exportedFileName'];name=attachment['suggestedHumanReadableName']
  if not name.startswith('Approved import'):continue
  if source.suffix=='.png':
   shutil.copy2(source,packet/source.name);retained=source.name
  elif source.suffix=='.txt':
   retained=source.name+'.gz';(packet/retained).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
  else:continue
  selected.append(dict(attachment,testIdentifier=test['testIdentifier'],retainedFileName=retained,originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(packet/'selected-attachments.json').write_text(json.dumps({'command':command,'attachments':selected,'videoPublished':False},indent=2)+'\n')

def typed(value):
 if value is None:return ('null',)
 if isinstance(value,bool):return ('bool',value)
 if isinstance(value,(int,float)):return ('number',*value.as_integer_ratio())
 if isinstance(value,str):return ('string',value)
 if isinstance(value,list):return ('array',tuple(typed(element) for element in value))
 assert isinstance(value,dict)
 return ('object',tuple(sorted((key,typed(element)) for key,element in value.items())))
def graph(value):
 return {key:sorted((typed(element) for element in elements),key=repr) if isinstance(elements,list) else typed(elements) for key,elements in value.items()}
def current_format(value):
 value=json.loads(json.dumps(value));assert value['formatVersion']==1;value['formatVersion']=2
 for source in value['sources']:
  if source['kind'] in ['list','itinerary']:source['content']['manualEstimate']=None
 return value
current=json.loads((repository/'docs/fixtures/native-current-restoration-family.json').read_text())
unknown=json.loads((repository/'docs/fixtures/native-unknown-restoration-candidate.json').read_text())
old=json.loads((repository/'docs/fixtures/native-closed-predecessor-values.json').read_text())
expected=current_format(current)
expected['sources'].append(next(value for value in unknown['sources'] if value['id'].endswith('000602')))
results={}
provenance=json.loads((root/'inputs'/(platform+'-provenance.json')).read_text())
provider=Path(provenance['inputs'][0]['destination']).parent
for mode in ['Skip','Overwrite']:
 if mode=='Overwrite':
  original=old['sources'][0].copy();original['lifetimeId']='00000000-0000-4000-8000-000000000814'
  expected['sources']=[original if value['id']==original['id'] else value for value in expected['sources']]
 attachments=[entry for entry in selected if entry['suggestedHumanReadableName'].startswith('Approved import '+mode+' delivered backup filename')]
 if not attachments:
  results[mode]={'notProduced':True};continue
 assert len(attachments)==1
 filename=gzip.decompress((packet/attachments[0]['retainedFileName']).read_bytes()).decode().strip()
 assert Path(filename).name==filename and filename.endswith('.json')
 delivered=provider/filename
 assert delivered.is_file() and delivered.stat().st_mtime>=summary['startTime']-2
 data=delivered.read_bytes();actual=json.loads(data)
 assert graph(actual)==graph(expected),(phase,mode)
 retained=mode.lower()+'-delivered.json.gz';(packet/retained).write_bytes(gzip.compress(data,mtime=0))
 results[mode]={'filename':filename,'delivered':str(delivered),'retained':retained,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'completeGraphMatches':True,'tableOrderingOnlyNormalized':True}
(packet/'delivered-file-validation.json').write_text(json.dumps({'results':results,'nativeTestPassed':summary['failedTests']==0 and summary['passedTests']>0,'scope':'Complete current family and omitted graph; independent Skip addition; predecessor values under live B; version migration only'},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'checks':checks,'captures':len([entry for entry in selected if entry['retainedFileName'].endswith('.png')]),'delivered':results}))
