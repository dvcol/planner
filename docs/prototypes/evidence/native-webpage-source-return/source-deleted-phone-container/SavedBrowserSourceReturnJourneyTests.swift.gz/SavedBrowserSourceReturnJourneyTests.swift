import XCTest

@MainActor
final class SavedBrowserSourceReturnJourneyTests: XCTestCase {
  func testDeletedSourceKeepsItsGuideOpenAndReturnsToItsSurvivingCollection() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = [
      "--change-stream-fixture", "--fixture-dataset", UUID().uuidString,
      "--fixture-website-url", destination.absoluteString,
    ]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    let source = application.savedPlannerItemRows("Hotel").firstMatch
    XCTAssertTrue(source.waitForExistence(timeout: 20))
    source.activateForPlannerJourney()
    let link = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.")
    ).firstMatch
    for _ in 0..<3 {
      if link.exists && link.isHittable { break }
      application.swipeUp()
    }
    XCTAssertTrue(link.waitForExistence(timeout: 10))
    link.activateForPlannerJourney()
    let page = application.webViews.firstMatch
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].waitForExistence(timeout: 10))
    application.plannerElement("fixture.writer.menu").activateForPlannerJourney()
    application.plannerElement("fixture.writer.deleteHotel").activateForPlannerJourney()
    XCTAssertEqual(
      XCTWaiter.wait(
        for: [
          XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "label == %@", "Deleted Hotel from another writer"),
            object: application.staticTexts["fixture.writer.status"])
        ], timeout: 10), .completed)
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].exists)
    XCTAssertFalse(application.alerts.firstMatch.exists)
    let reading = XCTAttachment(screenshot: application.screenshot())
    reading.name = "Deleted source leaves the original guide open"
    reading.lifetime = .keepAlways
    add(reading)
    application.plannerElement("saved.browser.return").activateForPlannerJourney()
    let explanation = application.alerts.firstMatch
    XCTAssertTrue(explanation.waitForExistence(timeout: 10))
    XCTAssertTrue(
      explanation.staticTexts["The original item is no longer available. Returned to Items."].exists
    )
    explanation.buttons["OK"].activateForPlannerJourney()
    XCTAssertTrue(page.waitForNonExistence(timeout: 10))
    XCTAssertTrue(application.staticTexts["No matching items"].waitForExistence(timeout: 10))
    XCTAssertTrue(
      application.descendants(matching: .any).matching(identifier: "saved.items.catalog")
        .firstMatch.exists)
    let returned = XCTAttachment(screenshot: application.screenshot())
    returned.name = "Deleted browser source returns to the surviving Items collection"
    returned.lifetime = .keepAlways
    add(returned)
  }
}
