import gzip
import hashlib
import json
import re
from pathlib import Path

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = repository / 'docs/prototypes/evidence/core-change-stream'
reference = json.loads((root / 'map-filtered-itinerary-final-phone/source-sha256.json').read_text())
assert len(reference) == 1102
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in reference.items())
executions = []
captures = []
function_names = []
for phase in ['map-filtered-itinerary-final-phone', 'map-filtered-itinerary-current-dark-tablet']:
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0 and validation['passedTests'] == 2
    assert validation['failedTests'] == validation['skippedTests'] == 0
    assert not any(validation[name] for name in ['workspaceDifferences', 'stagedDifferences', 'productDifferences'])
    products = json.loads((packet / 'product-sha256.json').read_text())
    assert len(products) == 4
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    assert 'unlinked while open' not in log and 'vnode unlinked' not in log
    names = re.findall(r"Test Case '-\[([^\]]+)\]' passed", log)
    assert len(names) == 2
    function_names.extend(names)
    executions.append({'phase': phase, 'passedFunctions': names, 'failedFunctions': 0, 'skippedFunctions': 0, 'sqliteUnlinkDiagnostics': 0})
    for attachment in json.loads((packet / 'selected-attachments.json').read_text())['attachments']:
        path = packet / attachment['retainedFileName']
        if path.suffix != '.png':
            continue
        assert hashlib.sha256(path.read_bytes()).hexdigest() == attachment['originalSha256']
        captures.append({'path': str(path.relative_to(root)), 'sha256': attachment['originalSha256'], 'visuallyInspected': True})
assert len(function_names) == 4 and len(set(function_names)) == 3
assert len(captures) == 5
red = root / 'map-filtered-itinerary-qualified-phone'
assert json.loads((red / 'test-summary.json').read_text())['failedTests'] == 1
assert gzip.decompress((red / 'ChangeObservationJourneyTests.swift.gz').read_bytes()) == gzip.decompress((root / 'map-filtered-itinerary-final-phone/ChangeObservationJourneyTests.swift.gz').read_bytes())
red_manifest = json.loads((red / 'source-sha256.json').read_text())
assert red_manifest.keys() == reference.keys()
changed = [name for name in reference if reference[name] != red_manifest[name]]
assert changed == ['Planner/Scenes/SavedPlannerView.swift']
compilers = []
for phase, expected_products in [('map-filtered-itinerary-final-mac-compiler', 9), ('map-filtered-itinerary-final-mac-fixture-compiler', 5)]:
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0 and validation['runtimeCredit'] is False
    assert not validation['workspaceDifferences'] and not validation['stagedDifferences']
    products = json.loads((packet / 'product-sha256.json').read_text())
    assert len(products) == expected_products
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
    compilers.append({'phase': phase, 'productCount': len(products), 'elapsedSeconds': validation['elapsedSeconds'], 'runtimeCredit': False})
appearance = json.loads((root / 'map-filtered-itinerary-current-dark-tablet/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert all(observation['output'] == 'dark' for observation in appearance['observations'] if observation['command'][-1] == 'appearance')
repair = json.loads((root / 'map-filtered-itinerary-dependency-repair.json').read_text())
assert hashlib.sha256((repository / repair['resolvedFile']).read_bytes()).hexdigest() == repair['resolvedSha256']
assert len(repair['pinnedCheckouts']) == 7
failures = []
for phase in ['map-filtered-itinerary-phone-green', 'map-filtered-itinerary-dark-tablet', 'map-filtered-itinerary-mac-compiler', 'map-filtered-itinerary-mac-fixture-compiler', 'map-filtered-itinerary-final-dark-tablet']:
    classification = json.loads((root / phase / 'resolution-failure-classification.json').read_text())
    assert classification['exitCode'] == 74 and classification['testFunctionsStarted'] == 0
    assert not classification['runtimeCredit'] and not classification['currentSourceProductCredit']
    failures.append(phase)
report = {'nativeInputs': len(reference), 'finalNativeExecutions': executions, 'totalFinalPassedFunctions': 4, 'distinctFinalFunctions': 3, 'inspectedOriginalCaptures': captures, 'incorrectControlAssumptionRunPreserved': True, 'qualifiedRedPreserved': True, 'entireQualifiedRedGreenTestSourceIdentical': True, 'onlyQualifiedRedGreenProductionDifference': changed, 'packageResolutionFailuresWithoutCredit': failures, 'pinnedDependencyRepair': repair, 'currentMacCompilers': compilers, 'appearanceRestored': True, 'actualMacRuntimeCredit': False, 'physicalDeviceCredit': False, 'scope': 'Exact repeated itinerary branch stays locally Done through shared-content changes and filtered Map/List navigation; its two other appearances stay Todo. Compact Back no longer automatically reopens retained details; explicit selection still works. Calendar-source deletion and restored-branch browser regressions pass. No new domain, schema, backup, signing, conflict-policy or test-boundary change.'}
(root / 'map-filtered-itinerary-checkpoint-reconciliation.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'map-filtered-itinerary-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'nativeInputs': len(reference), 'finalPassedFunctions': 4, 'distinctFunctions': 3, 'inspectedOriginals': len(captures), 'macProducts': sum(value['productCount'] for value in compilers), 'productionDifference': changed}))
