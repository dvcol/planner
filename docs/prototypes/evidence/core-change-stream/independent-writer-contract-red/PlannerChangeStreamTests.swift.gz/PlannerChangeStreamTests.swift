import Foundation
import PlannerCore
import Testing

struct PlannerChangeStreamTests {
  @Test func anIndependentLocalWriterInvalidatesCanonicalReadsAfterSubscription() async throws {
    let directory = try makePlannerStoreFixtureDirectory()
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let reader = Planner(configuration: configuration)
    let writer = Planner(configuration: configuration)
    guard case .ready(let readerSession) = await reader.bootstrap(),
      case .ready(let writerSession) = await writer.bootstrap()
    else { throw CancellationError() }
    let changes = await reader.changes(session: readerSession)
    guard
      case .snapshot(let initial) = await reader.query(
        .init(session: readerSession, request: .items(.init())))
    else { throw CancellationError() }
    #expect(initial.rows.isEmpty)
    guard
      case .applied(let saved, .complete) = await writer.execute(
        .init(
          operationId: UUID(), session: writerSession,
          command: .createItem(content: .init(title: "From another writer", notes: "Live notes")))
      ).outcome,
      let source = saved.generated.first
    else { throw CancellationError() }
    try await withThrowingTaskGroup(of: Void.self) { group in
      group.addTask {
        for try await change in changes {
          if case .dataChanged = change.payload { return }
        }
        throw ChangeStreamTestFailure.endedWithoutInvalidation
      }
      group.addTask {
        try await Task.sleep(for: .seconds(5))
        throw ChangeStreamTestFailure.noInvalidationBeforeTestDeadline
      }
      defer { group.cancelAll() }
      try await group.next()
    }
    guard
      case .snapshot(let refreshed) = await reader.query(
        .init(session: readerSession, request: .items(.init()))),
      case .source(.item(let item)) = await reader.read(
        session: readerSession, request: .source(source))
    else { throw CancellationError() }
    #expect(refreshed.rows == [.source(source)])
    #expect(item.source == source)
    #expect(item.content.title == "From another writer")
    #expect(item.content.notes == "Live notes")
  }
}

private enum ChangeStreamTestFailure: Error {
  case endedWithoutInvalidation
  case noInvalidationBeforeTestDeadline
}
