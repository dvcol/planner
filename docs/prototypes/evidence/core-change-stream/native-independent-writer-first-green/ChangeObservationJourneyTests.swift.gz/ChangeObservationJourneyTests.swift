import XCTest

@MainActor
final class ChangeObservationJourneyTests: XCTestCase {
  func testAnIndependentWriterRefreshesTheSelectedItemWithoutNavigation() {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = [
      "--change-stream-fixture", "--fixture-dataset", UUID().uuidString,
    ]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    let original = application.savedPlannerItemRows("Hotel").firstMatch
    XCTAssertTrue(original.waitForExistence(timeout: 20))
    let sourceIdentifier = original.identifier
    original.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Original notes"].waitForExistence(timeout: 10))
    application.plannerElement("fixture.writer.menu").activateForPlannerJourney()
    application.plannerElement("fixture.writer.update").activateForPlannerJourney()
    let status = application.staticTexts["fixture.writer.status"]
    XCTAssertEqual(
      XCTWaiter.wait(
        for: [
          XCTNSPredicateExpectation(
            predicate: NSPredicate(format: "label == %@", "Saved another-writer change"),
            object: status)
        ], timeout: 10), .completed)
    XCTAssertTrue(application.staticTexts["Other writer notes"].waitForExistence(timeout: 15))
    XCTAssertFalse(application.staticTexts["Original notes"].exists)
    let attachment = XCTAttachment(screenshot: application.screenshot())
    attachment.name = "Independent writer refreshes the selected Item"
    attachment.lifetime = .keepAlways
    add(attachment)
    application.openPlannerSection("Lists")
    application.openPlannerSection("Items")
    let updated = application.savedPlannerItemRows("Hotel updated").firstMatch
    XCTAssertTrue(updated.waitForExistence(timeout: 10))
    XCTAssertEqual(updated.identifier, sourceIdentifier)
  }
}
