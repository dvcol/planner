from pathlib import Path
import gzip,hashlib,json,os,signal,subprocess,time
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
reference=repository/'docs/prototypes/evidence/core-change-stream/map-filtered-catalog-phone-green'
manifest=json.loads((reference/'source-sha256.json').read_text())
root=Path('/private/tmp/PlannerApprovedAdminMacSource')
packet=repository/'docs/prototypes/evidence/core-change-stream/map-filtered-catalog-mac-compiler'
packet.mkdir(parents=True,exist_ok=False)
for name,digest in manifest.items():
 data=(repository/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
 destination=root/name;destination.parent.mkdir(parents=True,exist_ok=True)
 if not destination.is_file() or destination.read_bytes()!=data:destination.write_bytes(data)
(packet/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(root),'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'copiedFromExactNativeEpoch':str(reference.relative_to(repository))},indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
command=['xcodebuild','build-for-testing','-project','Planner.xcodeproj','-scheme','PlannerNavigation','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/PlannerMapNativeDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1','CODE_SIGNING_ALLOWED=YES','CODE_SIGN_IDENTITY=-','CODE_SIGN_STYLE=Manual','DEVELOPMENT_TEAM=','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerFilteredCatalogMapMacBuild.log');started=time.monotonic()
with log.open('wb') as output:
 process=subprocess.Popen(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=900)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGINT)
  try:code=process.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
checks={'exitCode':code,'runtimeCredit':False,'elapsedSeconds':round(time.monotonic()-started,3),'inputCount':len(manifest)}
for label,base in [('workspace',repository),('staged',root)]:
 checks[label+'Differences']=[name for name,digest in manifest.items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=digest]
 assert not checks[label+'Differences']
products={}
for candidate in Path('/private/tmp/PlannerMapNativeDerivedData/Build/Products').rglob('*'):
 if candidate.is_file() and (candidate.name in ['Planner','Planner.debug.dylib','PlannerNavigationUITests-Runner','PlannerNavigationUITests','PlannerShareMac','PlannerShareMac.debug.dylib'] or (candidate.name.startswith('PlannerNavigation_') and candidate.name.endswith('.xctestrun'))):products[str(candidate)]=hashlib.sha256(candidate.read_bytes()).hexdigest()
(packet/'product-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks|{'products':len(products)}))
for line in log.read_text(errors='replace').splitlines():
 if line.startswith(('** BUILD','** TEST','error:')) or '.swift:' in line and ': error:' in line:print(line[:1000])
raise SystemExit(code)
