from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
root=repository/'docs/prototypes/evidence/core-change-stream'
packet=root/phase
exit_result=json.loads((packet/'exit.json').read_text())
manifest=json.loads((packet/'source-sha256.json').read_text())
staged=Path(json.loads((packet/'source-root.json').read_text())['root'])
checks={}
for name,base in [('workspace',repository),('staged',staged)]:
 differences=[path for path,digest in manifest.items() if not (base/path).is_file() or hashlib.sha256((base/path).read_bytes()).hexdigest()!=digest]
 checks[name+'Differences']=differences
 assert not differences,differences
products=json.loads((packet/'product-sha256.json').read_text())
checks['productDifferences']=[path for path,digest in products.items() if not Path(path).is_file() or hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
assert not checks['productDifferences']
checks['inputCount']=len(manifest);checks['productCount']=len(products);checks['exitCode']=exit_result['exitCode']
summary=json.loads((packet/'test-summary.json').read_text())
checks.update({key:summary.get(key) for key in ['passedTests','failedTests','skippedTests']})
(packet/'boundary-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
output=Path('/private/tmp/PlannerApprovedAdminAttachments-'+phase)
command=['xcrun','xcresulttool','export','attachments','--path',exit_result['bundle'],'--output-path',str(output)]
subprocess.run(command,check=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),capture_output=True)
selected=[]
for test in json.loads((output/'manifest.json').read_text()):
 for attachment in test['attachments']:
  source=output/attachment['exportedFileName'];name=attachment['suggestedHumanReadableName']
  if not any(value in name for value in ['Filtered Map retains', 'Filtered Map removes', 'Native Map rotation', 'Native Map heading', 'Collection destination opens', 'Old reader returns', 'Fresh restored Item', 'Restored public List', 'Restored repeated List', 'Restored direct itinerary', 'Restored List', 'Native accessible Map summary', 'Filtered itinerary', 'Itinerary title', 'Itinerary native', 'Itinerary toolbar', 'title beside', 'navigation frames', 'catalog actions', 'catalog toolbar', 'Collection Map', 'Independent writer', 'List title', 'List native', 'List toolbar', 'Filtered List', 'Filtered Manual', 'Hidden membership', 'Saved List', 'Native Items Map', 'List Map', 'Counted itinerary', 'Native collection Maps', 'Unresolved collection Map', 'Counted native Map']):continue
  if source.suffix=='.png':
   shutil.copy2(source,packet/source.name);retained=source.name
  elif source.suffix=='.txt':
   retained=source.name+'.gz';(packet/retained).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
  else:continue
  selected.append(dict(attachment,testIdentifier=test['testIdentifier'],retainedFileName=retained,originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(packet/'selected-attachments.json').write_text(json.dumps({'command':command,'attachments':selected,'videoPublished':False},indent=2)+'\n')

(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'checks':checks,'captures':[entry['retainedFileName'] for entry in selected if entry['retainedFileName'].endswith('.png')]}))
