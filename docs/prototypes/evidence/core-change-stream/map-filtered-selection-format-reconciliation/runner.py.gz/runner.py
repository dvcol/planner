import difflib
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/core-change-stream'
reference=json.loads((root/'map-filtered-selection-final-phone/source-sha256.json').read_text())
assert reference==json.loads((root/'map-filtered-selection-final-dark-tablet/source-sha256.json').read_text())
assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in reference.items())
relative='Planner/Scenes/SavedMapCollectionView.swift'
source=repository/relative
before=source.read_bytes()
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
canonical_before=subprocess.check_output(['xcrun','swift','format','format',str(source)],env=environment)
subprocess.run(['xcrun','swift','format','format','--in-place',str(source)],env=environment,check=True)
after=source.read_bytes()
assert after==canonical_before
assert b''.join(before.split())==b''.join(after.split())
current={name:hashlib.sha256((repository/name).read_bytes()).hexdigest() for name in reference}
assert [name for name in current if current[name]!=reference[name]]==[relative]
packet=root/'map-filtered-selection-format-reconciliation'
packet.mkdir(exist_ok=False)
(packet/'source-sha256.json').write_text(json.dumps(current,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(repository),'runtimeReference':'map-filtered-selection-final-phone','note':'Current compiler inputs after one formatting newline; original runtime manifests remain unchanged.'},indent=2)+'\n')
(packet/'SavedMapCollectionView.swift.gz').write_bytes(gzip.compress(after,mtime=0))
(packet/'format.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='executed-runtime-source',tofile='formatted-workspace-source')))
(packet/'format-validation.json').write_text(json.dumps({'file':relative,'runtimeInputSha256':hashlib.sha256(before).hexdigest(),'formattedInputSha256':hashlib.sha256(after).hexdigest(),'formattedRuntimeSourceEqualsCurrent':True,'nonWhitespaceBytesUnchanged':True,'otherInputsUnchanged':len(current)-1,'runtimeManifestsEdited':False},indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Formatting-only newline reconciled; original runtime manifests retained.')
