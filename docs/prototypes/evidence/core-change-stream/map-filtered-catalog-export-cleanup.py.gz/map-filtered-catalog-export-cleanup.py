from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess

workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
scope={
    'core-change-stream':['map-filtered-catalog-phone','map-filtered-catalog-phone-green','map-filtered-catalog-dark-tablet','map-filtered-catalog-phone-regressions'],
}
records=[]
for namespace,phases in scope.items():
    for phase in phases:
        packet=workspace/'docs/prototypes/evidence'/namespace/phase
        directory=Path('/private/tmp/PlannerApprovedAdminAttachments-'+phase)
        assert directory.is_dir() and directory==directory.resolve(strict=True) and not directory.is_symlink()
        assert (packet/'boundary-validation.json').is_file()
        original=Path(json.loads((packet/'exit.json').read_text())['bundle'])
        assert original.is_dir() and not original.is_symlink()
        selected=json.loads((packet/'selected-attachments.json').read_text())['attachments']
        for attachment in selected:
            exported=directory/attachment['exportedFileName']
            retained=packet/attachment['retainedFileName']
            content=exported.read_bytes()
            assert hashlib.sha256(content).hexdigest()==attachment['originalSha256']
            assert (gzip.decompress(retained.read_bytes()) if retained.suffix=='.gz' else retained.read_bytes())==content
        files=list(directory.rglob('*'))
        assert all(not path.is_symlink() and path.stat().st_uid==os.getuid() for path in [directory,*files])
        handles=subprocess.run(['/usr/sbin/lsof','-t','+D',str(directory)],capture_output=True,text=True)
        assert handles.returncode==1 and not handles.stdout.strip() and not handles.stderr.strip()
        manifest=(directory/'manifest.json').read_bytes()
        (packet/'exported-attachment-manifest.json.gz').write_bytes(gzip.compress(manifest,mtime=0))
        records.append({'directory':str(directory),'originalResult':str(original),'packet':str(packet.relative_to(workspace)),'selectedAttachmentsVerified':len(selected),'nominalBytes':sum(path.stat().st_size for path in files if path.is_file()),'exportManifestSha256':hashlib.sha256(manifest).hexdigest()})
root=workspace/'docs/prototypes/evidence/core-change-stream'
report={'scope':'Only four explicitly enumerated duplicate attachment-export directories. All original xcresults, retained attachments, sources/products, complete exported manifests and datasets remain. Nominal bytes do not promise an equal APFS free-space change.','candidates':records,'removedDirectories':[],'nominalBytes':0}
output=root/'map-filtered-catalog-export-cleanup.json'
output.write_text(json.dumps(report,indent=2)+'\n')
for record in records:
    directory=Path(record['directory'])
    assert hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest()==record['exportManifestSha256']
    shutil.rmtree(directory)
    report['removedDirectories'].append(str(directory))
    report['nominalBytes']+=record['nominalBytes']
    output.write_text(json.dumps(report,indent=2)+'\n')
(root/'map-filtered-catalog-export-cleanup.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'removedDirectories':len(report['removedDirectories']),'nominalBytes':report['nominalBytes'],'retainedOriginalResults':len(records),'verifiedRetainedAttachments':sum(record['selectedAttachmentsVerified'] for record in records)}))
