import gzip
import hashlib
import json
from pathlib import Path

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = repository / 'docs/prototypes/evidence/core-change-stream'
reference = json.loads((root / 'map-filtered-catalog-phone-green/source-sha256.json').read_text())
assert len(reference) == 1102
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in reference.items())
executions = []
captures = []
for phase, expected_count in [('map-filtered-catalog-phone-green', 1), ('map-filtered-catalog-dark-tablet', 1), ('map-filtered-catalog-phone-regressions', 2)]:
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0 and validation['passedTests'] == expected_count
    assert validation['failedTests'] == validation['skippedTests'] == 0
    assert not any(validation[name] for name in ['workspaceDifferences', 'stagedDifferences', 'productDifferences'])
    products = json.loads((packet / 'product-sha256.json').read_text())
    assert len(products) == 4
    current_products_checked = phase != 'map-filtered-catalog-phone-green'
    if current_products_checked:
        assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    assert 'unlinked while open' not in log and 'vnode unlinked' not in log
    executions.append({'phase': phase, 'passedFunctions': expected_count, 'failedFunctions': 0, 'skippedFunctions': 0, 'sqliteUnlinkDiagnostics': 0, 'productsValidatedBeforeReuse': True, 'productsRecheckedAtFinalCheckpoint': current_products_checked})
    for attachment in json.loads((packet / 'selected-attachments.json').read_text())['attachments']:
        path = packet / attachment['retainedFileName']
        assert path.suffix == '.png'
        assert hashlib.sha256(path.read_bytes()).hexdigest() == attachment['originalSha256']
        captures.append({'path': str(path.relative_to(root)), 'sha256': attachment['originalSha256'], 'visuallyInspected': True})
assert len(captures) == 10
red = root / 'map-filtered-catalog-phone'
assert json.loads((red / 'test-summary.json').read_text())['failedTests'] == 1
assert gzip.decompress((red / 'ChangeObservationJourneyTests.swift.gz').read_bytes()) == gzip.decompress((root / 'map-filtered-catalog-phone-green/ChangeObservationJourneyTests.swift.gz').read_bytes())
red_manifest = json.loads((red / 'source-sha256.json').read_text())
assert red_manifest.keys() == reference.keys()
changed = [name for name in reference if reference[name] != red_manifest[name]]
assert changed == ['Planner/Scenes/SavedPlannerView.swift']
provenance = json.loads((red / 'failure-frame-provenance.json').read_text())
assert provenance['inboxLoopReached'] is False
compilers = []
for phase, expected_products in [('map-filtered-catalog-mac-compiler', 9), ('map-filtered-catalog-mac-fixture-compiler', 5)]:
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0 and validation['runtimeCredit'] is False
    assert not validation['workspaceDifferences'] and not validation['stagedDifferences']
    products = json.loads((packet / 'product-sha256.json').read_text())
    assert len(products) == expected_products
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
    compilers.append({'phase': phase, 'productCount': len(products), 'elapsedSeconds': validation['elapsedSeconds'], 'runtimeCredit': False})
appearance = json.loads((root / 'map-filtered-catalog-dark-tablet/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert all(observation['output'] == 'dark' for observation in appearance['observations'] if observation['command'][-1] == 'appearance')
readiness = json.loads((root / 'map-filtered-catalog-mac-runtime-readiness.json').read_text())
assert not readiness['newUiTestAttempt'] and not readiness['signingChanged']
report = {'nativeInputs': len(reference), 'finalNativeExecutions': executions, 'totalFinalPassedFunctions': 4, 'distinctFinalFunctions': 3, 'catalogScopesOnEachDevice': ['Items', 'Inbox'], 'inspectedOriginalCaptures': captures, 'initialRedPreserved': True, 'redInboxLoopReached': False, 'entireRedGreenTestSourceIdentical': True, 'onlyRedGreenProductionDifference': changed, 'currentMacCompilers': compilers, 'appearanceRestored': True, 'actualMacRuntimeCredit': False, 'physicalDeviceCredit': False, 'scope': 'Retained source selection in Items/Inbox Map stays valid after independent content edits; compact Back and representation changes do not automatically push details. Explicit selection of that same source still opens current details. Standalone List and Items/Inbox editor cancellation regressions pass. No Core/MCP, schema, backup, signing, conflict-policy or new test-boundary changes.'}
(root / 'map-filtered-catalog-checkpoint-reconciliation.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'map-filtered-catalog-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'nativeInputs': len(reference), 'finalPassedFunctions': 4, 'distinctFunctions': 3, 'inspectedOriginals': len(captures), 'macProducts': sum(value['productCount'] for value in compilers), 'redGreenProductionDifference': changed}))
