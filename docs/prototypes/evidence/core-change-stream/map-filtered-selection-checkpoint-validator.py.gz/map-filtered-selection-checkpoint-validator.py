import gzip
import hashlib
import json
from pathlib import Path

repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/core-change-stream'
reference=json.loads((root/'map-filtered-selection-final-phone/source-sha256.json').read_text())
executions=[]
captures=[]
for phase in ['map-filtered-selection-final-phone','map-filtered-selection-final-dark-tablet']:
    packet=root/phase
    assert json.loads((packet/'source-sha256.json').read_text())==reference
    validation=json.loads((packet/'boundary-validation.json').read_text())
    assert validation['exitCode']==0 and validation['passedTests']==2
    assert validation['failedTests']==validation['skippedTests']==0
    assert not any(validation[name] for name in ['workspaceDifferences','stagedDifferences','productDifferences'])
    products=json.loads((packet/'product-sha256.json').read_text())
    assert len(products)==4
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
    log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
    assert 'unlinked while open' not in log and 'vnode unlinked' not in log
    executions.append({'phase':phase,'passedFunctions':2,'failedFunctions':0,'skippedFunctions':0,'sqliteUnlinkDiagnostics':0})
    for attachment in json.loads((packet/'selected-attachments.json').read_text())['attachments']:
        path=packet/attachment['retainedFileName']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==attachment['originalSha256']
        if path.suffix=='.png':
            captures.append({'path':str(path.relative_to(root)),'sha256':attachment['originalSha256'],'visuallyInspected':True})
assert len(captures)==7
old=root/'map-filtered-selection-phone'
green=root/'map-filtered-selection-phone-green'
assert json.loads((old/'test-summary.json').read_text())['failedTests']==1
assert json.loads((green/'test-summary.json').read_text())['passedTests']==1
old_test=gzip.decompress((old/'ChangeObservationJourneyTests.swift.gz').read_bytes())
assert old_test==gzip.decompress((green/'ChangeObservationJourneyTests.swift.gz').read_bytes())
final_test=gzip.decompress((root/'map-filtered-selection-final-phone/ChangeObservationJourneyTests.swift.gz').read_bytes())
refocus=b'search.buttons["Clear text"].activateForPlannerJourney()\n    search.activateForPlannerJourney()\n'
assert final_test.count(refocus)==1
assert final_test.replace(refocus,b'search.buttons["Clear text"].activateForPlannerJourney()\n')==old_test
failed_tablet=json.loads((root/'map-filtered-selection-dark-tablet/test-summary.json').read_text())
assert failed_tablet['failedTests']==1 and failed_tablet['passedTests']==1
bridge=root/'map-filtered-selection-format-reconciliation'
current=json.loads((bridge/'source-sha256.json').read_text())
assert current.keys()==reference.keys()
changed=[name for name in current if current[name]!=reference[name]]
assert changed==['Planner/Scenes/SavedMapCollectionView.swift']
assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in current.items())
format_result=json.loads((bridge/'format-validation.json').read_text())
assert format_result['formattedRuntimeSourceEqualsCurrent'] and format_result['nonWhitespaceBytesUnchanged']
assert not format_result['runtimeManifestsEdited']
compilers=[]
for phase,expected_products in [('map-filtered-selection-final-mac-compiler',9),('map-filtered-selection-final-mac-fixture-compiler',5)]:
    packet=root/phase
    assert json.loads((packet/'source-sha256.json').read_text())==current
    result=json.loads((packet/'boundary-validation.json').read_text())
    assert result['exitCode']==0 and not result['runtimeCredit']
    assert not result['workspaceDifferences'] and not result['stagedDifferences']
    products=json.loads((packet/'product-sha256.json').read_text())
    assert len(products)==expected_products
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
    compilers.append({'phase':phase,'productCount':len(products),'elapsedSeconds':result['elapsedSeconds'],'runtimeCredit':False})
appearance=json.loads((root/'map-filtered-selection-final-dark-tablet/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert all(value['output']=='dark' for value in appearance['observations'] if value['command'][-1]=='appearance')
report={'nativeInputs':len(current),'finalNativeExecutions':executions,'totalFinalPassedFunctions':4,'distinctFinalFunctions':3,'inspectedOriginalCaptures':captures,'initialRedPreserved':True,'unchangedFirstRedGreenJourney':True,'laterTestChange':'Reactivate the actual search field after Clear, using the established native UI interaction. No invariant or observation removed.','failedTabletInvocationPreserved':True,'formattingOnlyRuntimeToCurrentDifference':changed,'formatValidation':format_result,'currentMacCompilers':compilers,'appearanceRestored':True,'actualMacRuntimeCredit':False,'physicalDeviceCredit':False,'scope':'Exact selected standalone List appearance survives a filtered Map refresh. Compact Back does not become an automatic push when its row returns. Native empty-state contrast is inspected in light/dark. Error-view styling has compiler coverage only; broader lifecycles and final whole-app polish stay open.'}
(root/'map-filtered-selection-checkpoint-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'map-filtered-selection-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'nativeInputs':len(current),'finalPassedFunctions':4,'inspectedOriginals':len(captures),'macProducts':sum(value['productCount'] for value in compilers),'formattingOnlyDifference':changed}))
