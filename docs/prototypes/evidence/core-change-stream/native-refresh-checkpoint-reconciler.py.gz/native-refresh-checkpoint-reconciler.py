from pathlib import Path
import gzip,hashlib,json
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
root=workspace/'docs/prototypes/evidence/core-change-stream'
phases=['native-stream-final-core','native-stream-final-controller','native-stream-phone-overflow','native-stream-dark-tablet-overflow','native-stream-final-mac-compiler']
rows=[]
for phase in phases:
 packet=root/phase
 validation=json.loads((packet/'boundary-validation.json').read_text())
 assert validation['exitCode']==0 and not validation['sourceDifferences'] and not validation['productDifferences']
 sources=json.loads((packet/'source-sha256.json').read_text())
 differences=[name for name,digest in sources.items() if hashlib.sha256((workspace/name).read_bytes()).hexdigest()!=digest]
 allowed=['PlannerFixtureUITests/ChangeObservationJourneyTests.swift'] if phase=='native-stream-final-controller' else []
 assert differences==allowed,(phase,differences)
 row={'phase':phase,'validatedInputs':len(sources),'validatedProducts':len(json.loads((packet/'product-sha256.json').read_text())),'differencesFromCurrent':differences,'meaning':'The controller run predates only the UI-test Add-overflow driver correction; its production and exercised controller/Intent test sources are unchanged.' if differences else 'All recorded inputs match current source.','boundarySha256':hashlib.sha256((packet/'boundary-validation.json').read_bytes()).hexdigest()}
 if phase.endswith('core'):
  execution=json.loads((packet/'execution.json').read_text())
  assert len(execution['cases'])==12 and all(not case['failures'] and not case['skipped'] for case in execution['cases']) and execution['sqliteUnlinkWarnings']==0
  row['passingFunctions']=12
 elif (packet/'test-summary.json').exists():
  summary=json.loads((packet/'test-summary.json').read_text())
  expected=38 if phase.endswith('controller') else 4
  assert summary['result']=='Passed' and summary['passedTests']==expected and summary['failedTests']==0 and summary['skippedTests']==0
  row['passingFunctions']=expected
 if (packet/'fixture-cleanup.json').exists():
  cleanup=json.loads((packet/'fixture-cleanup.json').read_text())
  assert cleanup['success']
  row['ownedFixturesRemovedAfterHostAndHandleClosure']=len(cleanup['removedDirectories'])
 if (packet/'capture-manifest.json').exists():
  captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
  inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
  assert len(captures)==5 and set(inspected)=={capture['file'] for capture in captures}
  for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256']
  row['inspectedOriginalCaptures']=5
 rows.append(row)
appearance=json.loads((root/'native-stream-dark-tablet-overflow/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
report={'boundaries':rows,'limits':['Original failed invocations and rejected cleanup remain unqualified.','Mac build is compilation only; controller execution is not external Mac UI.','Fixture footer is outside the shipping layout.','Broader view/window/source-deletion lifecycle, account/cloud/system invocation, physical scale and final UI polish remain open.'],'sourceAndProductValidation':'Each phase was validated at completion before staged roots/products were reused. Recorded product hashes are not re-read after later builds overwrite derived products.','staticChecks':'Strict swift-format passes for all eight affected Swift files; Markdown and diff checks are separate before commit.'}
(root/'native-refresh-checkpoint-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'native-refresh-checkpoint-reconciler.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'phases':len(rows),'coreFunctions':12,'controllerFunctions':38,'nativeExecutions':8,'inspectedCaptures':10,'ownedFixturesRemoved':65}))
