import gzip,hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
base=workspace/'docs/prototypes/evidence/capture/genuine-ios-map-reference'
audit=base/'cleanup'
audit.mkdir(exist_ok=False)
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
subprocess.run(['git','diff','--exit-code','HEAD','--',str(base)],cwd=workspace,check=True,capture_output=True)
manifest=json.loads((base/'build/source-sha256.json').read_text())
assert all(hashlib.sha256((workspace/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
for platform in ['phone','tablet']:
 products=json.loads((base/f'{platform}-runtime/product-sha256.json').read_text())
 assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
 fixture=json.loads((base/f'{platform}-runtime/fixture.json').read_text())
 assert hashlib.sha256(Path(fixture['path']).read_bytes()).hexdigest()==fixture['sha256']
raw_packets=[]
for platform in ['phone','tablet']:
 raw_packets.append((Path(f'/private/tmp/PlannerGenuineIOSCapture-{platform}.xcresult'),base/f'{platform}-runtime'))
 raw_packets.append((Path(f'/private/tmp/PlannerWindowedScaleCurrent-{platform}.xcresult'),workspace/f'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-windowed-scale-current-{platform}'))
for raw,packet in raw_packets:
 command=['xcrun','xcresulttool','get','test-results','summary','--path',str(raw)]
 result=subprocess.run(command,env=environment,check=True,capture_output=True)
 assert json.loads(result.stdout)==json.loads((packet/'test-summary.json').read_text())
for raw,packet in raw_packets:
 log=raw.with_suffix('.log')
 assert log.read_bytes()==gzip.decompress((packet/'test.log.gz').read_bytes())
assert Path('/private/tmp/PlannerGenuineIOSCaptureBuild.log').read_bytes()==gzip.decompress((base/'build/build.log.gz').read_bytes())
paths=[Path('/private/tmp/PlannerGenuineIOSCaptureDerivedData')]+[raw for raw,_ in raw_packets]
records=[]
for path in paths:
 assert path.parent==Path('/private/tmp') and path.is_dir() and not path.is_symlink()
 check=subprocess.run(['lsof','-nP','+D',str(path),'-Fpfn'],capture_output=True)
 assert check.returncode==1 and not check.stdout and not check.stderr,(path,check.stdout[:100],check.stderr[:100])
 files=[candidate for candidate in path.rglob('*') if stat.S_ISREG(candidate.lstat().st_mode)]
 records.append({'path':str(path),'regularFileCount':len(files),'nominalFileBytes':sum(candidate.stat().st_size for candidate in files),'openFileCheckExitCode':check.returncode})
for path,record in zip(paths,records):
 shutil.rmtree(path)
 record['removed']=not path.exists()
 assert record['removed']
report={'evidenceCommits':['ba052c13999e19df9474e2c8b4748e57152d3a81','82ec576ac7f168d3fb26d8d27467259b1e6f6aed'],'verifiedPackageInputs':len(manifest),'verifiedRawSummaries':4,'verifiedOriginalLogs':5,'removed':records,'nominalFileBytes':sum(record['nominalFileBytes'] for record in records),'metric':'Regular-file logical bytes, not an equal APFS free-space promise.','preserved':'Committed evidence, original scale attachment exports, raw logs, both native MapKit archives, named store fixtures, temporary source copies, current app/UI products, Simulator data and Planner datasets.'}
(audit/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
(audit/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'removedDirectories':len(records),'nominalFileBytes':report['nominalFileBytes'],'nominalGiB':round(report['nominalFileBytes']/1024**3,2)}))
