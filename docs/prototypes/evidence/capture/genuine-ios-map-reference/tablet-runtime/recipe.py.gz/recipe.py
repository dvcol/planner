import gzip,hashlib,json,os,plistlib,subprocess,sys,time
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
platform=sys.argv[1]
assert platform in ['phone','tablet']
base=workspace/'docs/prototypes/evidence/capture/genuine-ios-map-reference'
packet=base/f'{platform}-runtime'
packet.mkdir(exist_ok=False)
source=Path('/private/tmp/PlannerCaptureTransportIOSSource')
manifest=json.loads((base/'build/source-sha256.json').read_text())
assert all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
for name in ['source-sha256.json','source-root.json']:(packet/name).write_bytes((base/'build'/name).read_bytes())
probe=base/('probe' if platform=='phone' else 'tablet-probe')
provenance=json.loads((probe/'execution.json').read_text())
fixture=Path('/private/tmp/PlannerGenuineIOSMapFixture.data' if platform=='phone' else '/private/tmp/PlannerGenuineIPadMapFixture.data')
assert hashlib.sha256(fixture.read_bytes()).hexdigest()==provenance['fixtureSHA256']
(packet/'fixture.json').write_text(json.dumps({'path':str(fixture),'sha256':provenance['fixtureSHA256'],'bytes':fixture.stat().st_size,'nativeProducerPacket':str(probe.relative_to(workspace))},indent=2)+'\n')
products=Path('/private/tmp/PlannerGenuineIOSCaptureDerivedData/Build/Products')
original_plans=list(products.glob('PlannerCore_*.xctestrun'))
assert len(original_plans)==1
original=original_plans[0]
plan=plistlib.loads(original.read_bytes())
targets=[target for configuration in plan['TestConfigurations'] for target in configuration['TestTargets'] if target.get('ProductModuleName')=='PlannerCoreStoreTests']
assert len(targets)==1
targets[0].setdefault('EnvironmentVariables',{})['PLANNER_GENUINE_MAP_FIXTURE']=str(fixture)
input_plan=products/f'PlannerGenuineCapture-{platform}.xctestrun'
input_plan.write_bytes(plistlib.dumps(plan))
(packet/'input-test-plan.plist.gz').write_bytes(gzip.compress(input_plan.read_bytes(),mtime=0))
recorded_products={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in products.rglob('*') if path.is_file() and (path.name in ['PlannerCore','PlannerCoreStoreTests','PlannerCoreTests'] or path==original)}
assert any(Path(path).name=='PlannerCoreStoreTests' for path in recorded_products)
(packet/'product-sha256.json').write_text(json.dumps(recorded_products,indent=2)+'\n')
device='2A49C66C-C8A4-435F-B98A-9A90706780DE' if platform=='phone' else 'FBD72DAB-1D40-4E64-912D-7F9763E00446'
raw=Path(f'/private/tmp/PlannerGenuineIOSCapture-{platform}.xcresult')
command=['xcodebuild','test-without-building','-xctestrun',str(input_plan),'-destination','platform=iOS Simulator,id='+device,'-parallel-testing-enabled','NO','-jobs','1','-only-testing:PlannerCoreStoreTests/GenuineNativeMapCaptureTests','-resultBundlePath',str(raw)]
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
log=Path(f'/private/tmp/PlannerGenuineIOSCapture-{platform}.log')
started=time.monotonic()
with log.open('wb') as output:
 process=subprocess.Popen(command,cwd=source/'Packages/PlannerCore',env=environment,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try:exit_code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True;process.terminate()
  try:exit_code=process.wait(timeout=20)
  except subprocess.TimeoutExpired:process.kill();exit_code=process.wait()
outcome={'exitCode':exit_code,'runnerTimedOut':timed_out,'elapsedSeconds':round(time.monotonic()-started,3),'sourceInputsUnchanged':all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items()),'productsUnchanged':all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in recorded_products.items()),'fixtureUnchanged':hashlib.sha256(fixture.read_bytes()).hexdigest()==provenance['fixtureSHA256'],'runtimeCredit':False}
(packet/'exit.json').write_text(json.dumps(outcome,indent=2)+'\n')
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
commands=[]
if raw.exists():
 for kind in ['summary','tests']:
  extract=['xcrun','xcresulttool','get','test-results',kind,'--path',str(raw)]
  result=subprocess.run(extract,env=environment,capture_output=True)
  commands.append({'command':extract,'exitCode':result.returncode})
  if result.returncode==0:
   if kind=='summary':(packet/'test-summary.json').write_bytes(result.stdout)
   else:(packet/'test-results-tests.json.gz').write_bytes(gzip.compress(result.stdout,mtime=0))
 (packet/'evidence-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(platform,json.dumps(outcome))
print(log.read_text(errors='replace')[-3000:])
