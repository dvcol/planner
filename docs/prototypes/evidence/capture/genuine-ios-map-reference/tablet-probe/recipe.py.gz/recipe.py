import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
source=Path('/private/tmp/PlannerGenuineIOSMapProbe')
packet=workspace/'docs/prototypes/evidence/capture/genuine-ios-map-reference/tablet-probe'
packet.mkdir(exist_ok=False)
original=workspace/'docs/prototypes/evidence/navigation/genuine-native-map-reference/PlannerGenuineAppleMapProbe.swift'
text=original.read_text().replace('/private/tmp/PlannerGenuineAppleMapFixture.data','/private/tmp/PlannerGenuineIPadMapFixture.data')
(source/'PadProbe.swift').write_text(text)
(packet/'Probe.swift.gz').write_bytes(gzip.compress(text.encode(),mtime=0))
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
sdk=subprocess.check_output(['xcrun','--sdk','iphonesimulator','--show-sdk-path'],env=environment,text=True).strip()
commands=[]
for command,label in [(['xcrun','swiftc','-parse-as-library','-swift-version','6','-target','arm64-apple-ios27.0-simulator','-sdk',sdk,str(source/'PadProbe.swift'),'-o',str(source/'pad-probe')],'compile'),(['xcrun','simctl','spawn','FBD72DAB-1D40-4E64-912D-7F9763E00446',str(source/'pad-probe')],'runtime')]:
 started=time.monotonic()
 result=subprocess.run(command,cwd=source,env=environment,capture_output=True,timeout=45)
 commands.append({'command':command,'exitCode':result.returncode,'elapsedSeconds':round(time.monotonic()-started,3)})
 for name,content in [('stdout',result.stdout),('stderr',result.stderr)]:
  (packet/(label+'-'+name+'.gz')).write_bytes(gzip.compress(content,mtime=0))
 print(label,'exit',result.returncode)
 print(result.stdout.decode(errors='replace')[-1300:])
 if result.returncode!=0:
  print(result.stderr.decode(errors='replace')[-1000:]);break
fixture=Path('/private/tmp/PlannerGenuineIPadMapFixture.data')
report={'originalProbe':str(original.relative_to(workspace)),'originalSHA256':hashlib.sha256(original.read_bytes()).hexdigest(),'probeSHA256':hashlib.sha256((source/'PadProbe.swift').read_bytes()).hexdigest(),'onlySourceChange':'Separate temporary archive output path for the iPad attempt.','commands':commands,'fixtureExistsOnHost':fixture.exists(),'runtimeCredit':False,'scope':'Separate genuine iPad Simulator producer and secure archive; public Core integration remains unqualified.'}
if fixture.exists():report['fixtureSHA256']=hashlib.sha256(fixture.read_bytes()).hexdigest();report['fixtureBytes']=fixture.stat().st_size
(packet/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(report))
