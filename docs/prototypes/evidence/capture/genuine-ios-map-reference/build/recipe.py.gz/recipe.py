import gzip,hashlib,io,json,os,subprocess,tarfile,time
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
packet=workspace/'docs/prototypes/evidence/capture/genuine-ios-map-reference/build'
packet.mkdir(exist_ok=False)
source=Path('/private/tmp/PlannerCaptureTransportIOSSource')
source.mkdir(exist_ok=True)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip()
archive=subprocess.check_output(['git','archive',base,'Packages/PlannerCore'],cwd=workspace)
paths=[]
with tarfile.open(fileobj=io.BytesIO(archive)) as contents:
 for member in contents.getmembers():
  if not member.isfile():continue
  paths.append(member.name)
  destination=source/member.name
  destination.parent.mkdir(parents=True,exist_ok=True)
  content=contents.extractfile(member).read()
  if not destination.exists() or destination.read_bytes()!=content:destination.write_bytes(content)
overlay='Packages/PlannerCore/Tests/PlannerCoreStoreTests/GenuineNativeMapCaptureTests.swift'
(source/overlay).write_bytes((workspace/overlay).read_bytes())
manifest={path:hashlib.sha256((source/path).read_bytes()).hexdigest() for path in paths}
(packet/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(source),'base':base,'overlays':[overlay],'scope':'Existing public Core/provider I/O test enabled on iOS; no production change. Named local store fixtures remain until the test process exits.'},indent=2)+'\n')
(packet/'GenuineNativeMapCaptureTests.swift.gz').write_bytes(gzip.compress((source/overlay).read_bytes(),mtime=0))
command=['xcodebuild','build-for-testing','-scheme','PlannerCore','-destination','generic/platform=iOS Simulator','-derivedDataPath','/private/tmp/PlannerGenuineIOSCaptureDerivedData','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1','-only-testing:PlannerCoreStoreTests/GenuineNativeMapCaptureTests','CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
log=Path('/private/tmp/PlannerGenuineIOSCaptureBuild.log')
started=time.monotonic()
with log.open('wb') as output:
 process=subprocess.Popen(command,cwd=source/'Packages/PlannerCore',env=environment,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try:exit_code=process.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timed_out=True;process.terminate()
  try:exit_code=process.wait(timeout=20)
  except subprocess.TimeoutExpired:process.kill();exit_code=process.wait()
unchanged=all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
(packet/'exit.json').write_text(json.dumps({'exitCode':exit_code,'runnerTimedOut':timed_out,'elapsedSeconds':round(time.monotonic()-started,3),'frozenInputsUnchanged':unchanged,'runtimeCredit':False},indent=2)+'\n')
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'recipe.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Build exit',exit_code,'source unchanged',unchanged)
print(log.read_text(errors='replace')[-2000:])
