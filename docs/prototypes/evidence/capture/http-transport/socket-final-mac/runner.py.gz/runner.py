import gzip, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
source = Path('/private/tmp/PlannerCaptureTransportIOSSource')
base_packet = workspace / 'docs/prototypes/evidence/capture/http-transport/ios-runtime'
platform, epoch = sys.argv[1:]
packet = workspace / f'docs/prototypes/evidence/capture/http-transport/{epoch}-{platform}'
packet.mkdir(exist_ok=False)
manifest = json.loads((base_packet / 'source-sha256.json').read_text())
for relative_path in manifest:
    source_path = workspace / relative_path
    if hashlib.sha256(source_path.read_bytes()).hexdigest() != manifest[relative_path]:
        shutil.copy2(source_path, source / relative_path)
input_hashes = {path: hashlib.sha256((source / path).read_bytes()).hexdigest() for path in manifest}
(packet / 'source-sha256.json').write_text(json.dumps(input_hashes, indent=2) + '\n')
metadata = json.loads((base_packet / 'source-root.json').read_text())
metadata['overlays'] = [path for path in manifest if input_hashes[path] != manifest[path]]
(packet / 'source-root.json').write_text(json.dumps(metadata, indent=2) + '\n')
for path in metadata['overlays']:
    with gzip.open(packet / (Path(path).name + '.gz'), 'wb') as snapshot:
        snapshot.write((source / path).read_bytes())
environment = os.environ.copy()
environment['DEVELOPER_DIR'] = '/Applications/Xcode.app/Contents/Developer'
result_path = Path(f'/private/tmp/PlannerCaptureTransport-{epoch}-{platform}.xcresult')
if platform == 'mac':
    command = ['xcrun', 'swift', 'test', '--scratch-path', '/private/tmp/PlannerCaptureTransportMacBuild', '--jobs', '1', '--filter', 'CaptureHTTPTransportTests']
else:
    command = json.loads((base_packet / 'command.json').read_text())
    command[command.index('-resultBundlePath') + 1] = str(result_path)
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log_path = Path(f'/private/tmp/PlannerCaptureTransport-{epoch}-{platform}.log')
started = time.monotonic()
with log_path.open('wb') as log:
    process = subprocess.Popen(command, cwd=source / 'Packages/PlannerCore', env=environment, stdout=log, stderr=subprocess.STDOUT)
    timed_out = False
    try:
        exit_code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.terminate()
        try:
            exit_code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.kill()
            exit_code = process.wait()
unchanged = all(hashlib.sha256((source / path).read_bytes()).hexdigest() == digest for path, digest in input_hashes.items())
outcome = {'exitCode': exit_code, 'runnerTimedOut': timed_out, 'elapsedSeconds': round(time.monotonic()-started,3), 'frozenInputsUnchanged': unchanged, 'runtimeCredit': False, 'scope': 'Selected native HTTP transport suite only; inspect original runtime outcomes before qualification.'}
(packet / 'exit.json').write_text(json.dumps(outcome, indent=2) + '\n')
with gzip.open(packet / 'test.log.gz', 'wb') as log:
    log.write(log_path.read_bytes())
with gzip.open(packet / 'runner.py.gz', 'wb') as runner:
    runner.write(Path(__file__).read_bytes())
if platform == 'ios' and result_path.exists():
    evidence_commands = []
    for kind in ['summary', 'tests']:
        extract = ['xcrun', 'xcresulttool', 'get', 'test-results', kind, '--path', str(result_path)]
        result = subprocess.run(extract, env=environment, capture_output=True)
        evidence_commands.append({'command': extract, 'exitCode': result.returncode})
        if result.returncode == 0:
            if kind == 'summary':
                (packet / 'test-results-summary.json').write_bytes(result.stdout)
            else:
                with gzip.open(packet / 'test-results-tests.json.gz', 'wb') as output:
                    output.write(result.stdout)
    (packet / 'evidence-commands.json').write_text(json.dumps(evidence_commands, indent=2) + '\n')
print(json.dumps(outcome))
print(log_path.read_text(errors='replace')[-4500:])
