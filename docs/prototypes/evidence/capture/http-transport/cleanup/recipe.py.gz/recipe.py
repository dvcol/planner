import gzip, hashlib, json, os, shutil, stat, subprocess
from pathlib import Path

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
evidence = workspace / 'docs/prototypes/evidence/capture/http-transport'
audit = evidence / 'cleanup'
audit.mkdir(exist_ok=True)
assert not (audit/'verification.json').exists()
environment = os.environ.copy()
environment['DEVELOPER_DIR'] = '/Applications/Xcode.app/Contents/Developer'
subprocess.run(['git','diff','--exit-code','HEAD','--',str(evidence)],cwd=workspace,check=True,capture_output=True)
source = Path('/private/tmp/PlannerCaptureTransportIOSSource')
manifest = json.loads((evidence/'socket-final-ios/source-sha256.json').read_text())
assert all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in manifest.items())
for raw_name, packet_name in [('PlannerCaptureTransportIOS.xcresult','ios-runtime'),('PlannerCaptureTransport-socket-final-ios.xcresult','socket-final-ios')]:
 raw=Path('/private/tmp')/raw_name
 command=['xcrun','xcresulttool','get','test-results','summary','--path',str(raw)]
 result=subprocess.run(command,env=environment,check=True,capture_output=True)
 assert json.loads(result.stdout)==json.loads((evidence/packet_name/'test-results-summary.json').read_text())
for log_name,packet_name in [('PlannerCaptureTransportIOS.log','ios-runtime'),('PlannerCaptureTransport-socket-head-mac.log','socket-head-mac'),('PlannerCaptureTransport-socket-cancellation-mac.log','socket-cancellation-mac'),('PlannerCaptureTransport-socket-redirect-mac.log','socket-redirect-mac'),('PlannerCaptureTransport-socket-final-mac.log','socket-final-mac'),('PlannerCaptureTransport-socket-final-ios.log','socket-final-ios')]:
 assert (Path('/private/tmp')/log_name).read_bytes()==gzip.decompress((evidence/packet_name/'test.log.gz').read_bytes())
paths=[Path('/private/tmp')/name for name in ['PlannerCaptureTransportIOSDerivedData','PlannerCaptureTransportMacBuild','PlannerCaptureTransportIOS.xcresult','PlannerCaptureTransport-socket-final-ios.xcresult']]
records=[]
for path in paths:
 assert path.parent==Path('/private/tmp') and path.is_dir() and not path.is_symlink()
 check=subprocess.run(['lsof','-nP','+D',str(path),'-Fpfn'],capture_output=True)
 assert check.returncode==1 and not check.stdout and not check.stderr,(path,check.returncode,check.stdout[:100],check.stderr[:100])
 files=[candidate for candidate in path.rglob('*') if stat.S_ISREG(candidate.lstat().st_mode)]
 records.append({'path':str(path),'regularFileCount':len(files),'nominalFileBytes':sum(candidate.stat().st_size for candidate in files),'openFileCheckExitCode':check.returncode})
for record,path in zip(records,paths):
 shutil.rmtree(path)
 record['removed']=not path.exists()
 assert record['removed']
report={'evidenceCommit':'248334080b32153761a4a416f158691cd4238ca7','verifiedFrozenPackageInputs':len(manifest),'verifiedRawSummaries':2,'verifiedOriginalCompressedLogs':6,'removed':records,'nominalFileBytes':sum(record['nominalFileBytes'] for record in records),'metric':'Regular-file logical bytes, not a promise of equal APFS free-space change.','preserved':'Committed evidence, raw text logs, the transport source copy retained by DTServiceHub cwd, app/UI frozen source and products, other package caches, Simulator data and Planner datasets.', 'retainedSource': {'path':str(source), 'reason':'Preflight found DTServiceHub with cwd in this source. No deletion occurred in that preflight; the helper was not stopped.'}}
(audit/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
with gzip.open(audit/'recipe.py.gz','wb') as output: output.write(Path(__file__).read_bytes())
print(json.dumps({'removedDirectories':len(records),'nominalFileBytes':report['nominalFileBytes'],'nominalGiB':round(report['nominalFileBytes']/1024**3,2)}))
