import gzip,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
packet=workspace/'docs/prototypes/evidence/capture/http-transport/live-https-mac'
packet.mkdir(exist_ok=False)
source=Path('/private/tmp/PlannerCaptureLiveHTTPS')
source.mkdir(exist_ok=False)
production=workspace/'Packages/PlannerCore/Sources/PlannerCore/PlannerCaptureHTTPTransport.swift'
shutil.copy2(production,source/production.name)
shutil.copy2('/private/tmp/PlannerCaptureLiveHTTPSDriver.swift',source/'Driver.swift')
inputs={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in source.iterdir()}
(packet/'source-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip(),'root':str(source),'productionSource':'Packages/PlannerCore/Sources/PlannerCore/PlannerCaptureHTTPTransport.swift','scope':'Exact standalone production transport compiled with a temporary public-interface driver. No Planner store, app data, package, target or production configuration changes.'},indent=2)+'\n')
for path in source.iterdir():
 with gzip.open(packet/(path.name+'.gz'),'wb') as snapshot: snapshot.write(path.read_bytes())
environment=os.environ.copy()
environment['DEVELOPER_DIR']='/Applications/Xcode.app/Contents/Developer'
commands=[]
for command,label in [(['xcrun','swift-format','lint','--strict',str(source/'Driver.swift'),str(source/production.name)],'lint'),(['xcrun','swiftc','-parse-as-library','-swift-version','6','-target','arm64-apple-macos27.0',str(source/production.name),str(source/'Driver.swift'),'-o',str(source/'probe')],'compile'),([str(source/'probe')],'runtime')]:
 started=time.monotonic()
 result=subprocess.run(command,cwd=source,env=environment,capture_output=True,timeout=60)
 commands.append({'command':command,'exitCode':result.returncode,'elapsedSeconds':round(time.monotonic()-started,3)})
 with gzip.open(packet/(label+'-stdout.gz'),'wb') as output: output.write(result.stdout)
 with gzip.open(packet/(label+'-stderr.gz'),'wb') as output: output.write(result.stderr)
 if label=='runtime' and result.returncode==0:
  observations=json.loads(result.stdout)
  (packet/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
  print(json.dumps(observations))
 if result.returncode!=0:
  print(label,result.returncode,result.stderr.decode(errors='replace')[:1800])
  break
unchanged=all(hashlib.sha256((source/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
assert hashlib.sha256(production.read_bytes()).hexdigest()==inputs[production.name]
(packet/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(packet/'outcome.json').write_text(json.dumps({'frozenInputsUnchanged':unchanged,'runtimeExecuted':any(record['command']==[str(source/'probe')] for record in commands),'runtimeCredit':False,'scope':'Inspect per-provider observations separately. Exit zero does not require either provider to succeed.'},indent=2)+'\n')
with gzip.open(packet/'recipe.py.gz','wb') as output: output.write(Path(__file__).read_bytes())
print(json.dumps(commands))
