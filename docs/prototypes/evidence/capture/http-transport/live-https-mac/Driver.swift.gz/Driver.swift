import Foundation

@main
struct CaptureLiveHTTPSDriver {
  struct Observation: Encodable {
    let requestURL: String
    let observedAt: String
    let elapsedSeconds: Double
    let responseURL: String?
    let statusCode: Int?
    let location: String?
    let errorDomain: String?
    let errorCode: Int?
  }

  static func main() async throws {
    let requestURLs = [
      "https://maps.apple.com/place?coordinate=40.779092,-73.962932",
      "https://www.google.com/maps/search/?api=1&query=47.5951518%2C-122.3316393",
    ]
    var observations: [Observation] = []
    for originalURL in requestURLs {
      let requestURL = URL(string: originalURL)!
      let observedAt = ISO8601DateFormatter().string(from: Date())
      let clock = ContinuousClock()
      let started = clock.now
      let transport = PlannerNativeCaptureHTTPTransport()
      do {
        let response = try await transport.head(requestURL: requestURL, timeout: .seconds(4))
        observations.append(
          Observation(
            requestURL: originalURL, observedAt: observedAt,
            elapsedSeconds: elapsedSeconds(started.duration(to: clock.now)),
            responseURL: response.url?.absoluteString, statusCode: response.statusCode,
            location: response.value(forHTTPHeaderField: "Location"),
            errorDomain: nil, errorCode: nil))
      } catch {
        let nativeError = error as NSError
        observations.append(
          Observation(
            requestURL: originalURL, observedAt: observedAt,
            elapsedSeconds: elapsedSeconds(started.duration(to: clock.now)),
            responseURL: nil, statusCode: nil, location: nil,
            errorDomain: nativeError.domain, errorCode: nativeError.code))
      }
    }
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
    let output = try encoder.encode(observations)
    FileHandle.standardOutput.write(output)
  }

  static func elapsedSeconds(_ duration: Duration) -> Double {
    Double(duration.components.seconds)
      + Double(duration.components.attoseconds) / 1_000_000_000_000_000_000
  }
}
