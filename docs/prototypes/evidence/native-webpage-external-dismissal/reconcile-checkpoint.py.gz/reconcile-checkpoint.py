import hashlib,json,subprocess
from pathlib import Path
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-webpage-external-dismissal'
phases={'external-initial-and-dismissal-phone':(2,3),'external-dismissal-policy-regressions-phone':(2,2),'external-initial-dismissal-and-policy-dark-tablet':(4,6)}
reference=None
results=[]
for phase,(expected_tests,expected_captures) in phases.items():
 packet=root/phase
 inputs=json.loads((packet/'source-sha256.json').read_text())
 if reference is None:reference=inputs
 assert inputs==reference
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
 boundary=json.loads((packet/'boundary-validation.json').read_text())
 assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
 summary=json.loads((packet/'test-summary.json').read_text())
 assert summary['result']=='Passed' and summary['passedTests']==expected_tests and summary['totalTestCount']==expected_tests and summary['failedTests']==summary['skippedTests']==0
 captures=json.loads((packet/'capture-manifest.json').read_text())['captures']
 inspected=json.loads((packet/'visual-inspection.json').read_text())['inspectedOriginalFiles']
 assert len(captures)==expected_captures and set(inspected)=={capture['file'] for capture in captures}
 for capture in captures:assert hashlib.sha256((packet/capture['file']).read_bytes()).hexdigest()==capture['sha256']
 if 'dark-tablet' in phase:assert json.loads((packet/'appearance-observation.json').read_text())['restoredToOriginal']
 results.append({'phase':phase,'passedFunctions':expected_tests,'inspectedOriginalCaptures':expected_captures,'sourceInputs':len(inputs),'retainedProducts':boundary['retainedProductCount']})
mac=root/'external-dismissal-mac-compiler'
assert json.loads((mac/'source-sha256.json').read_text())==reference
boundary=json.loads((mac/'boundary-validation.json').read_text())
assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
assert not subprocess.check_output(['git','diff','--name-only','--','Packages','Planner','PlannerShareMobile','PlannerShareMac'],text=True).strip()
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(reference),'nativeExecutions':results,'totalPassedNativeExecutions':sum(result['passedFunctions'] for result in results),'totalInspectedOriginalCaptures':sum(result['inspectedOriginalCaptures'] for result in results),'macCompiler':{'phase':mac.name,'retainedProducts':boundary['retainedProductCount'],'runtimeCredit':False},'limits':['Initial HTTP app redirect and interactive dismissal only at the represented native mobile boundaries; no external Open is selected.','Actual Mac UI/modal interaction, broader accessibility, physical devices and final whole-app polish remain open.'],'meaning':'Each product boundary was validated before reuse. Earlier mobile products need not equal the subsequently rebuilt shared output directory; exact source and original capture bytes reconcile here.'}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
