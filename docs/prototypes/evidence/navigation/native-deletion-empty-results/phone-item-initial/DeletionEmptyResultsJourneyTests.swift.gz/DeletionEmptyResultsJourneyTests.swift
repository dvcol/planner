import XCTest

@MainActor
final class DeletionEmptyResultsJourneyTests: XCTestCase {
  func testDeletingTheLastVisibleItemKeepsTheEmptyCatalogWithoutSelectingAnArchivedItem() {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = [
      "--fixture", "deletion-empty-results", "--fixture-dataset", UUID().uuidString,
    ]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    let visible = application.savedPlannerItemRows("Visible Item").firstMatch
    let hidden = application.savedPlannerItemRows("Hidden Item").firstMatch
    let filters = application.plannerElement("saved.items.filters")
    XCTAssertTrue(visible.waitForExistence(timeout: 20))
    XCTAssertFalse(hidden.exists)
    application.chooseSavedPlannerStateFilter("All archive states", control: filters)
    XCTAssertTrue(hidden.waitForExistence(timeout: 10))
    let hiddenIdentifier = hidden.identifier
    application.chooseSavedPlannerStateFilter("Active", control: filters)
    XCTAssertTrue(hidden.waitForNonExistence(timeout: 10))
    visible.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Visible saved notes"].waitForExistence(timeout: 10))
    application.plannerElement("saved.item.actions").activateForPlannerJourney()
    application.plannerElement("saved.item.delete").activateForPlannerJourney()
    application.plannerElement("saved.item.delete.confirm").activateForPlannerJourney()
    XCTAssertTrue(
      application.plannerElement("saved.item.delete.confirm").waitForNonExistence(timeout: 10))
    XCTAssertTrue(visible.waitForNonExistence(timeout: 10))
    XCTAssertTrue(application.staticTexts["No matching items"].waitForExistence(timeout: 10))
    XCTAssertFalse(hidden.exists)
    XCTAssertFalse(application.staticTexts["Hidden saved notes"].exists)
    XCTAssertFalse(application.plannerElement("saved.item.completion").exists)
    XCTAssertFalse(application.staticTexts["Item unavailable"].exists)
    XCTAssertFalse(application.alerts["Planner"].exists)
    capture(application, name: "Deleting the last visible Item leaves its filtered catalog empty")
    application.chooseSavedPlannerStateFilter("All archive states", control: filters)
    XCTAssertTrue(hidden.waitForExistence(timeout: 10))
    XCTAssertEqual(hidden.identifier, hiddenIdentifier)
    hidden.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Hidden saved notes"].waitForExistence(timeout: 10))
    application.terminate()
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    application.chooseSavedPlannerStateFilter("All archive states", control: filters)
    XCTAssertTrue(hidden.waitForExistence(timeout: 10))
    XCTAssertEqual(hidden.identifier, hiddenIdentifier)
    XCTAssertFalse(visible.exists)
    hidden.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Hidden saved notes"].waitForExistence(timeout: 10))
    capture(application, name: "Archived Item remains available with its identity after relaunch")
  }

  private func capture(_ application: XCUIApplication, name: String) {
    let attachment = XCTAttachment(screenshot: application.screenshot())
    attachment.name = name
    attachment.lifetime = .keepAlways
    add(attachment)
  }
}
