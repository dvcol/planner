import Foundation

enum SavedScheduleTimeResolution: Sendable, Equatable {
  case unavailable
  case nonexistent
  case unique(Date)
  case repeated([Date])
}

struct SavedScheduleTimeInput {
  private(set) var pickerValue: Date
  var resolution: SavedScheduleTimeResolution { .unavailable }
  var selectedOccurrence: Date? { nil }
  var resolvedInstant: Date? { nil }

  init(proposedInstant: Date, planningTimeZone: TimeZone) {
    pickerValue = proposedInstant
  }

  mutating func setPickerValue(_ value: Date) {
    pickerValue = value
  }
}
