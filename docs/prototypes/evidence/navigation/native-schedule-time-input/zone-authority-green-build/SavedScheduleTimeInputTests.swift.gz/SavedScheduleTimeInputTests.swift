import Foundation
import XCTest

@testable import Planner

@MainActor
final class SavedScheduleTimeInputTests: XCTestCase {
  func testNonexistentNewYorkMinuteStaysEnteredAndCannotResolve() throws {
    let planningTimeZone = try XCTUnwrap(TimeZone(identifier: "America/New_York"))
    let formatter = ISO8601DateFormatter()
    let proposedInstant = try XCTUnwrap(formatter.date(from: "2026-03-08T06:30:00Z"))
    let enteredCivilMinute = try XCTUnwrap(formatter.date(from: "2026-03-08T02:30:00Z"))
    var input = SavedScheduleTimeInput(
      proposedInstant: proposedInstant, planningTimeZone: planningTimeZone)
    input.setPickerValue(enteredCivilMinute)
    XCTAssertEqual(input.pickerValue, enteredCivilMinute)
    XCTAssertEqual(input.resolution, .nonexistent)
    XCTAssertNil(input.selectedOccurrence)
    XCTAssertNil(input.resolvedInstant)
  }

  func testRepeatedNewYorkMinuteRequiresAnExplicitCurrentOccurrence() throws {
    let planningTimeZone = try XCTUnwrap(TimeZone(identifier: "America/New_York"))
    let formatter = ISO8601DateFormatter()
    let earlier = try XCTUnwrap(formatter.date(from: "2026-11-01T05:30:00Z"))
    let later = try XCTUnwrap(formatter.date(from: "2026-11-01T06:30:00Z"))
    let civilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T01:30:00Z"))
    let nextCivilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T02:30:00Z"))
    let nextInstant = try XCTUnwrap(formatter.date(from: "2026-11-01T07:30:00Z"))
    var input = SavedScheduleTimeInput(
      proposedInstant: earlier, planningTimeZone: planningTimeZone)

    XCTAssertEqual(input.pickerValue, civilMinute)
    XCTAssertEqual(input.resolution, .repeated([earlier, later]))
    XCTAssertNil(input.selectedOccurrence)
    XCTAssertNil(input.resolvedInstant)
    XCTAssertFalse(input.selectOccurrence(nextInstant))
    XCTAssertNil(input.resolvedInstant)
    XCTAssertTrue(input.selectOccurrence(earlier))
    XCTAssertEqual(input.resolvedInstant, earlier)
    XCTAssertTrue(input.selectOccurrence(later))
    XCTAssertEqual(input.resolvedInstant, later)

    input.setPickerValue(nextCivilMinute)
    XCTAssertEqual(input.resolution, .unique(nextInstant))
    XCTAssertFalse(input.selectOccurrence(later))
    XCTAssertEqual(input.resolvedInstant, nextInstant)
    input.setPickerValue(civilMinute)
    XCTAssertEqual(input.resolution, .repeated([earlier, later]))
    XCTAssertNil(input.selectedOccurrence)
    XCTAssertNil(input.resolvedInstant)
  }

  func testLordHoweRepeatFindsBothHalfHourOccurrences() throws {
    let planningTimeZone = try XCTUnwrap(TimeZone(identifier: "Australia/Lord_Howe"))
    let formatter = ISO8601DateFormatter()
    let earlier = try XCTUnwrap(formatter.date(from: "2026-04-04T14:45:00Z"))
    let later = try XCTUnwrap(formatter.date(from: "2026-04-04T15:15:00Z"))
    let civilMinute = try XCTUnwrap(formatter.date(from: "2026-04-05T01:45:00Z"))
    var input = SavedScheduleTimeInput(
      proposedInstant: earlier, planningTimeZone: planningTimeZone)

    XCTAssertEqual(input.pickerValue, civilMinute)
    XCTAssertEqual(input.resolution, .repeated([earlier, later]))
    XCTAssertNil(input.selectedOccurrence)
    XCTAssertNil(input.resolvedInstant)
    XCTAssertTrue(input.selectOccurrence(later))
    XCTAssertEqual(input.resolvedInstant, later)
  }

  func testUnchangedSavedOccurrenceRetainsFractionsUntilExplicitClockOrOccurrenceEdit() throws {
    let planningTimeZone = try XCTUnwrap(TimeZone(identifier: "America/New_York"))
    let formatter = ISO8601DateFormatter()
    let earlier = try XCTUnwrap(formatter.date(from: "2026-11-01T05:30:00Z"))
    let later = try XCTUnwrap(formatter.date(from: "2026-11-01T06:30:00Z"))
    let civilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T01:30:00Z"))
    let changedCivilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T01:31:00Z"))
    let changedEarlier = try XCTUnwrap(formatter.date(from: "2026-11-01T05:31:00Z"))
    let savedInstant = later.addingTimeInterval(0.125)
    var input = SavedScheduleTimeInput(
      savedInstant: savedInstant, planningTimeZone: planningTimeZone)

    XCTAssertEqual(input.pickerValue, civilMinute)
    XCTAssertEqual(input.selectedOccurrence, later)
    XCTAssertEqual(input.resolvedInstant, savedInstant)
    input.setPickerValue(civilMinute.addingTimeInterval(49.75))
    XCTAssertEqual(input.pickerValue, civilMinute)
    XCTAssertEqual(input.selectedOccurrence, later)
    XCTAssertEqual(input.resolvedInstant, savedInstant)
    XCTAssertTrue(input.selectOccurrence(later))
    XCTAssertEqual(input.resolvedInstant, savedInstant)

    input.setPickerValue(changedCivilMinute)
    XCTAssertNil(input.resolvedInstant)
    XCTAssertTrue(input.selectOccurrence(changedEarlier))
    XCTAssertEqual(input.resolvedInstant, changedEarlier)
    input.setPickerValue(civilMinute)
    XCTAssertNil(input.resolvedInstant)
    XCTAssertTrue(input.selectOccurrence(later))
    XCTAssertEqual(input.resolvedInstant, later)

    var changedOccurrence = SavedScheduleTimeInput(
      savedInstant: savedInstant, planningTimeZone: planningTimeZone)
    XCTAssertTrue(changedOccurrence.selectOccurrence(earlier))
    XCTAssertEqual(changedOccurrence.resolvedInstant, earlier)
    XCTAssertTrue(changedOccurrence.selectOccurrence(later))
    XCTAssertEqual(changedOccurrence.resolvedInstant, later)
  }

  func testPlanningZoneChangesDistinguishSavedAuthorityFromNewAndRescheduledInput() throws {
    let newYork = try XCTUnwrap(TimeZone(identifier: "America/New_York"))
    let paris = try XCTUnwrap(TimeZone(identifier: "Europe/Paris"))
    let formatter = ISO8601DateFormatter()
    let earlier = try XCTUnwrap(formatter.date(from: "2026-11-01T05:30:00Z"))
    let later = try XCTUnwrap(formatter.date(from: "2026-11-01T06:30:00Z"))
    let newYorkCivilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T01:30:00Z"))
    let parisCivilMinute = try XCTUnwrap(formatter.date(from: "2026-11-01T06:30:00Z"))
    let savedInstant = earlier.addingTimeInterval(0.125)
    var saved = SavedScheduleTimeInput(savedInstant: savedInstant, planningTimeZone: .gmt)
    XCTAssertEqual(saved.resolvedInstant, savedInstant)
    saved.changePlanningTimeZone(newYork)
    XCTAssertEqual(saved.pickerValue, newYorkCivilMinute)
    XCTAssertEqual(saved.resolution, .repeated([earlier, later]))
    XCTAssertEqual(saved.selectedOccurrence, earlier)
    XCTAssertEqual(saved.resolvedInstant, savedInstant)
    saved.changePlanningTimeZone(paris)
    XCTAssertEqual(saved.pickerValue, parisCivilMinute)
    XCTAssertEqual(saved.resolvedInstant, savedInstant)
    saved.changePlanningTimeZone(newYork)
    XCTAssertEqual(saved.resolvedInstant, savedInstant)
    XCTAssertEqual(saved.selectedOccurrence, earlier)

    var proposed = SavedScheduleTimeInput(proposedInstant: earlier, planningTimeZone: .gmt)
    proposed.changePlanningTimeZone(newYork)
    XCTAssertEqual(proposed.pickerValue, newYorkCivilMinute)
    XCTAssertEqual(proposed.resolution, .repeated([earlier, later]))
    XCTAssertNil(proposed.selectedOccurrence)
    XCTAssertNil(proposed.resolvedInstant)

    var rescheduled = SavedScheduleTimeInput(savedInstant: savedInstant, planningTimeZone: .gmt)
    rescheduled.setPickerValue(earlier.addingTimeInterval(60))
    rescheduled.setPickerValue(earlier)
    XCTAssertEqual(rescheduled.resolvedInstant, earlier)
    rescheduled.changePlanningTimeZone(newYork)
    XCTAssertEqual(rescheduled.pickerValue, newYorkCivilMinute)
    XCTAssertEqual(rescheduled.resolution, .repeated([earlier, later]))
    XCTAssertNil(rescheduled.selectedOccurrence)
    XCTAssertNil(rescheduled.resolvedInstant)
  }
}
