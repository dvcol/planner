import Foundation

enum SavedScheduleTimeResolution: Sendable, Equatable {
  case unavailable
  case nonexistent
  case unique(Date)
  case repeated([Date])
}

struct SavedScheduleTimeInput {
  private(set) var pickerValue: Date
  private(set) var resolution = SavedScheduleTimeResolution.unavailable
  private(set) var selectedOccurrence: Date?
  private var planningTimeZone: TimeZone

  var resolvedInstant: Date? { selectedOccurrence }

  private static var pickerCalendar: Calendar {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = .gmt
    return calendar
  }

  private var planningCalendar: Calendar {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = planningTimeZone
    return calendar
  }

  init(proposedInstant: Date, planningTimeZone: TimeZone) {
    pickerValue = proposedInstant
    self.planningTimeZone = planningTimeZone
    guard proposedInstant.timeIntervalSinceReferenceDate.isFinite else { return }
    var components = planningCalendar.dateComponents(
      [.era, .year, .month, .day, .hour, .minute], from: proposedInstant)
    components.second = 0
    guard let civilMinute = Self.pickerCalendar.date(from: components) else { return }
    pickerValue = civilMinute
    resolve()
  }

  mutating func setPickerValue(_ value: Date) {
    pickerValue = value
    selectedOccurrence = nil
    guard value.timeIntervalSinceReferenceDate.isFinite,
      let minute = Self.pickerCalendar.dateInterval(of: .minute, for: value)
    else {
      resolution = .unavailable
      return
    }
    pickerValue = minute.start
    resolve()
  }

  private mutating func resolve() {
    let calendar = planningCalendar
    let components = Self.pickerCalendar.dateComponents(
      [.era, .year, .month, .day, .hour, .minute, .second], from: pickerValue)
    guard let approximate = calendar.date(from: components),
      let day = calendar.dateInterval(of: .day, for: approximate)
    else {
      resolution = .unavailable
      return
    }
    guard let candidate = calendar.nextDate(
      after: day.start.addingTimeInterval(-1), matching: components,
      matchingPolicy: .strict, repeatedTimePolicy: .first),
      calendar.date(candidate, matchesComponents: components)
    else {
      resolution = .nonexistent
      return
    }
    resolution = .unique(candidate)
    selectedOccurrence = candidate
  }
}
