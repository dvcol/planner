import Foundation
import XCTest

@testable import Planner

@MainActor
final class SavedScheduleTimeInputTests: XCTestCase {
  func testNonexistentNewYorkMinuteStaysEnteredAndCannotResolve() throws {
    let planningTimeZone = try XCTUnwrap(TimeZone(identifier: "America/New_York"))
    let formatter = ISO8601DateFormatter()
    let proposedInstant = try XCTUnwrap(formatter.date(from: "2026-03-08T06:30:00Z"))
    let enteredCivilMinute = try XCTUnwrap(formatter.date(from: "2026-03-08T02:30:00Z"))
    var input = SavedScheduleTimeInput(
      proposedInstant: proposedInstant, planningTimeZone: planningTimeZone)
    input.setPickerValue(enteredCivilMinute)
    XCTAssertEqual(input.pickerValue, enteredCivilMinute)
    XCTAssertEqual(input.resolution, .nonexistent)
    XCTAssertNil(input.selectedOccurrence)
    XCTAssertNil(input.resolvedInstant)
  }
}
