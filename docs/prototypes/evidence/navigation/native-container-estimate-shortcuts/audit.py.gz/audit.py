from pathlib import Path
import hashlib,json
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-container-estimate-shortcuts'
def read_json(path):
 return json.loads(path.read_text())
def sha256(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()
runs={value['epoch']:value for value in read_json(packet/'historical-run-index.json')['runs']}
compiler_epochs=['mobile-list-shortcuts-menu-label-build','mac-list-shortcuts-menu-label-build']
for epoch in compiler_epochs:
 inputs=read_json(packet/epoch/'source-sha256.json')
 assert len(inputs)==945 and all(sha256(repository/path)==digest for path,digest in inputs.items())
 assert read_json(packet/epoch/'exit.json')['exitCode']==0
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
expected='PlannerNavigationUITests.SavedContainerEstimateJourneyTests testListEstimateShortcutsStageCancelSaveAndResetAfterRelaunch'
for epoch in ['phone-list-shortcuts-final','tablet-list-shortcuts-menu-label']:
 result=runs[epoch]
 assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
 assert len(result['functions'])==1 and result['functions'][0]['function']==expected
 assert result['functions'][0]['outcome']=='passed' and not result['startedWithoutCompletedOutcome']
 current=read_json(packet/epoch/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
 assert all(sha256(repository/path)==digest for path,digest in current.items())
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
visual=read_json(packet/'visual-review.json')['images']
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
assert len(visual)==6 and all(value['individuallyInspected'] and sha256(packet/value['path'])==value['sha256'] for value in visual)
lint=read_json(packet/'affected-swift-lint.json')
review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(sha256(repository/path)==digest for path,digest in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(sha256(repository/path)==digest for path,digest in markdown['sourceSHA256'].items())
result={'finalCompilerInputsPerPlatform':945,'frozenRuntimeInputsPerInvocation':469,'verifiedProductsPerPlatform':6,'passingFunctionsPerPlatform':{'phone':1,'tablet':1,'mac':0},'passingNativeFunctionInvocations':2,'retainedIndividuallyInspectedPNGs':6,'historicalPassingPhoneInvocation':1,'failedIPadSetupInvocations':2,'scope':'List native estimate shortcuts, literal saved minutes, Cancel, units, List identity and reset through relaunch. Production code unchanged. Mac compiler-only; no new Mac runtime, physical/account/CloudKit, accessibility or performance qualification.'}
(packet/'evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
