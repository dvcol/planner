from pathlib import Path
import gzip,json,os,shutil,subprocess,sys
phase=sys.argv[1]
packet=Path('docs/prototypes/evidence/navigation/native-container-estimate-shortcuts')/phase
metadata=json.loads((packet/'exit.json').read_text())
out=Path('/private/tmp/PlannerContainerShortcutRuntime-'+phase+'-attachments')
result=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',metadata['bundle'],'--output-path',str(out)],capture_output=True,text=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
assert result.returncode==0,result.stderr
selected=[]
prefixes=['List Weekend shortcut','List estimate shortcut clears']
for group in json.loads((out/'manifest.json').read_text()):
    for attachment in group['attachments']:
        title=attachment['suggestedHumanReadableName']
        name=attachment['exportedFileName']
        if title.startswith(tuple(prefixes)) and name.endswith('.png'):
            shutil.copy2(out/name,packet/name)
            selected.append(attachment)
        elif title.startswith(('Draft navigation own-window hierarchy','Original List window after source Item deletion','Planner window identities after source Item deletion','Original Planner window after another window deletes its selection')) and name.endswith('.txt'):
            (packet/(name+'.gz')).write_bytes(gzip.compress((out/name).read_bytes(),mtime=0))
            selected.append(attachment)
(packet/'selected-captures.json').write_text(json.dumps(selected,indent=2)+'\n')
for item in selected:print(phase,item['exportedFileName'],item['suggestedHumanReadableName'])
