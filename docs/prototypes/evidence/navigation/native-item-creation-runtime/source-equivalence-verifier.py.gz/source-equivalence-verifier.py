from pathlib import Path
import gzip,hashlib,json,re
repository=Path.cwd()
root=Path('docs/prototypes/evidence/navigation/native-item-creation-runtime')
records=[
 ('mac-destination-rich-and-capture-qualified','SavedAppearanceJourneyTests','testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList'),
 ('mac-final-creation-navigation','SavedAppearanceJourneyTests','testNewItemNavigationRequiresExplicitChoiceAndKeepsInvalidDraftsOpen'),
 ('phone-current-rich-creation','SavedAppearanceJourneyTests','testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList'),
 ('phone-final-creation-navigation','SavedAppearanceJourneyTests','testNewItemNavigationRequiresExplicitChoiceAndKeepsInvalidDraftsOpen'),
 ('tablet-bookmark-visibility-qualified','SavedAppearanceJourneyTests','testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList'),
 ('tablet-final-creation-navigation','SavedAppearanceJourneyTests','testNewItemNavigationRequiresExplicitChoiceAndKeepsInvalidDraftsOpen'),
 ('mac-window-scoped-review','SavedAppearanceJourneyTests','testRenamingTheOriginatingListRequiresReviewBeforeSavingTheRetainedItemDraft'),
 ('mac-destination-rich-and-capture-qualified','SavedCaptureJourneyTests','testGoogleMapsCaptureShowsATemporarySavedMapAndRetainsItsBookmarkAfterRelaunch'),
 ('mac-list-window-evidence-qualified','SavedListCaptureJourneyTests','testCurrentListCaptureStagesDestinationAndRetainsMembershipScopeAfterRelaunch')]
def digest(content):return hashlib.sha256(content).hexdigest()
def functions(source):
    result={}
    for match in re.finditer(r'\bfunc\s+(\w+)\s*\(',source):
        start=source.index('{',match.end())
        depth=1
        position=start+1
        while depth:
            if source[position]=='{':depth+=1
            if source[position]=='}':depth-=1
            position+=1
        result.setdefault(match[1],[]).append(source[match.start():position])
    return result
outputs=[]
for phase,test_class,test in records:
    packet=root/phase
    current=json.loads((packet/'current-source-sha256.json').read_text())
    production={name:checksum for name,checksum in current.items() if name.startswith(('Planner/','Configuration/','Planner.xcodeproj/')) or ('/Sources/' in name and name.startswith('Packages/'))}
    assert production and all(digest(Path(name).read_bytes())==checksum for name,checksum in production.items()),phase
    helper='PlannerNavigationUITests/NativeNavigationElements.swift'
    assert digest(Path(helper).read_bytes())==current[helper],phase
    log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
    results=[line for line in log.splitlines() if line.startswith('Test Case ') and f'{test_class} {test}]' in line and ' passed ' in line]
    assert len(results)==1,(phase,test,results)
    file='PlannerNavigationUITests/'+test_class+'.swift'
    output={'phase':phase,'function':test_class+'/'+test,'passedInvocation':results[0],'wholeBatchPassed':json.loads((packet/'exit.json').read_text())['exitCode']==0,'unchangedProductionInputs':len(production),'productionInputSHA256':digest(json.dumps(production,sort_keys=True).encode()),'sharedNativeUIHelperUnchanged':True}
    if digest(Path(file).read_bytes())==current[file]:
        output['testFileUnchanged']=True
    else:
        assert test_class=='SavedAppearanceJourneyTests'
        old=functions(gzip.decompress((packet/(test_class+'.swift.gz')).read_bytes()).decode())
        new=functions(Path(file).read_text())
        queue=[test]
        seen=set()
        while queue:
            name=queue.pop()
            if name in seen:continue
            assert old[name]==new[name],(phase,name)
            seen.add(name)
            calls=set(re.findall(r'\b(\w+)\s*\(', '\n'.join(new[name])))&set(new)
            queue.extend(calls-seen)
        output['testFileUnchanged']=False
        output['unchangedTestAndLocalHelpers']={name:digest('\n'.join(new[name]).encode()) for name in sorted(seen)}
    outputs.append(output)
(root/'runtime-source-equivalence.json').write_text(json.dumps({'method':'Production input hashes and shared native UI helper are identical. For a changed test file, compare the full recorded test function and all locally defined functions it calls transitively. Recorded invocation and batch result remain separate; no new run is inferred.','invocations':outputs},indent=2)+'\n')
(root/'source-equivalence-verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(len(outputs),'passing invocations verified against unchanged current production inputs and executed test functions/helpers')
