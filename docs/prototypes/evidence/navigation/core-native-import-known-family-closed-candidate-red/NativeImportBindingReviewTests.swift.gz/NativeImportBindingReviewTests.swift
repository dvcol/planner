import Foundation
import PlannerCore
import Testing

struct NativeImportBindingReviewTests {
  enum BindingCase: CaseIterable { case live, missing, wrongLifetime }

  @Test(arguments: [PlannerImportMode.skip, .overwrite])
  func aNewListCanReferenceAnotherKnownCandidateOfTheOpenFamily(mode: PlannerImportMode)
    async throws
  {
    let directory = FileManager.default.temporaryDirectory
      .appendingPathComponent("PlannerNativeImportFamilyBindingTests", isDirectory: true)
      .appendingPathComponent(UUID().uuidString, isDirectory: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    var seed = try #require(
      JSONSerialization.jsonObject(with: nativeImportFixtureData()) as? [String: Any])
    let fixtureSources = try #require(seed["sources"] as? [[String: Any]])
    var museum = try #require(fixtureSources.first { $0["kind"] as? String == "item" })
    museum["lifetimeId"] = "00000000-0000-4000-8000-000000000814"
    for name in seed.keys where name != "format" && name != "formatVersion" { seed[name] = [] }
    seed["sources"] = [museum]
    let predecessor: [String: Any] = [
      "kind": "item", "id": "00000000-0000-4000-8000-000000000101",
      "lifetimeId": "00000000-0000-4000-8000-000000000811",
    ]
    seed["deletionMarkers"] = [
      [
        "deletionId": "00000000-0000-4000-8000-000000000892",
        "operationId": "00000000-0000-4000-8000-000000000992",
        "target": ["kind": "source", "source": predecessor], "closedFamilyId": NSNull(),
      ]
    ]
    seed["restorationFamilies"] = [
      [
        "familyId": "00000000-0000-4000-8000-000000000890", "predecessor": predecessor,
        "candidates": [
          [
            "lifetimeId": "00000000-0000-4000-8000-000000000814",
            "operationId": "00000000-0000-4000-8000-000000000994",
          ],
          [
            "lifetimeId": "00000000-0000-4000-8000-000000000815",
            "operationId": "00000000-0000-4000-8000-000000000995",
          ],
        ],
      ]
    ]
    guard case .ready(let session) = await planner.bootstrap(),
      case .decoded(let seedBackup) = planner.decodeImport(
        try JSONSerialization.data(withJSONObject: seed)),
      case .reviewed(let seedReview) = await planner.prepareReview(
        session: session, command: .applyImport(backup: seedBackup)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: seedReview.command,
          reviewToken: seedReview.reviewToken)
      ).outcome,
      case .exported(let before) = await planner.exportData(session: session),
      case .decoded(let current) = planner.decodeImport(before)
    else { throw CancellationError() }
    #expect(
      current.backup.restorationFamilies.first?.candidates.map(\.lifetimeId.uuidString)
        == [
          "00000000-0000-4000-8000-000000000814", "00000000-0000-4000-8000-000000000815",
        ])
    #expect(
      current.backup.items.first?.lifetimeId.uuidString == "00000000-0000-4000-8000-000000000814")
    var incoming = seed
    for name in incoming.keys where name != "format" && name != "formatVersion" {
      incoming[name] = []
    }
    var list = try #require(fixtureSources.first { $0["kind"] as? String == "list" })
    list["id"] = "00000000-0000-4000-8000-000000000277"
    list["lifetimeId"] = "00000000-0000-4000-8000-000000000827"
    incoming["sources"] = [list]
    incoming["memberships"] = [
      [
        "id": "00000000-0000-4000-8000-000000000477",
        "lifetimeId": "00000000-0000-4000-8000-000000000477",
        "list": [
          "kind": "list", "id": "00000000-0000-4000-8000-000000000277",
          "lifetimeId": "00000000-0000-4000-8000-000000000827",
        ],
        "item": [
          "kind": "item", "id": "00000000-0000-4000-8000-000000000101",
          "lifetimeId": "00000000-0000-4000-8000-000000000815",
        ],
        "rank": "1024", "localDone": false,
      ]
    ]
    guard
      case .decoded(let backup) = planner.decodeImport(
        try JSONSerialization.data(withJSONObject: incoming))
    else { throw CancellationError() }
    #expect(backup.externalBindings.count == 1)
    #expect(
      backup.externalBindings.first?.lifetimeId.uuidString
        == "00000000-0000-4000-8000-000000000815")
    #expect(backup.backup.restorationFamilies.isEmpty)
    for invalidLifetime in [
      "00000000-0000-4000-8000-000000000811", "00000000-0000-4000-8000-000000000999",
    ] {
      var invalid = incoming
      var memberships = try #require(invalid["memberships"] as? [[String: Any]])
      var item = try #require(memberships[0]["item"] as? [String: Any])
      item["lifetimeId"] = invalidLifetime
      memberships[0]["item"] = item
      invalid["memberships"] = memberships
      guard
        case .decoded(let invalidBackup) = planner.decodeImport(
          try JSONSerialization.data(withJSONObject: invalid)),
        case .failed(let failure) = await planner.prepareReview(
          session: session, command: .applyImport(backup: invalidBackup, mode: mode)),
        case .exported(let unchangedData) = await planner.exportData(session: session)
      else {
        Issue.record("Predecessor and unrelated bindings cannot redirect to the live Item.")
        return
      }
      #expect(failure.code == "missingReference")
      #expect(failure.propertyPath == "/memberships/0/item/lifetimeId")
      #expect(unchangedData == before)
    }
    let outcome = await planner.prepareReview(
      session: session, command: .applyImport(backup: backup, mode: mode))
    guard case .reviewed(let review) = outcome else {
      Issue.record("The current open family authorizes the candidate reference: \(outcome)")
      return
    }
    let details = try #require(review.impact.importDetails)
    #expect(details.imports.map(\.owner.id.uuidString) == ["00000000-0000-4000-8000-000000000277"])
    #expect(details.skippedConflicts.isEmpty && details.skippedDependents.isEmpty)
    #expect(details.replacements.isEmpty && details.restorations.isEmpty)
    #expect(
      details.imports.first?.dependencies.first?.lifetimeId.uuidString
        == "00000000-0000-4000-8000-000000000814")
    guard case .exported(let afterReview) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    #expect(afterReview == before)
    let operationIdentifier = UUID()
    let response = await planner.execute(
      .init(
        operationId: operationIdentifier, session: session, command: review.command,
        reviewToken: review.reviewToken))
    guard case .applied(let result, .complete(let checkpoint)) = response.outcome,
      case .exported(let after) = await planner.exportData(session: session),
      case .decoded(let saved) = planner.decodeImport(after)
    else {
      Issue.record("Save the complete new List against its authorized candidate: \(response)")
      return
    }
    #expect(saved.backup.items.count == 1 && saved.backup.lists.count == 1)
    #expect(
      saved.backup.items.first?.lifetimeId.uuidString == "00000000-0000-4000-8000-000000000814")
    #expect(saved.backup.memberships.count == 1)
    #expect(
      saved.backup.memberships.first?.itemLifetimeId.uuidString
        == "00000000-0000-4000-8000-000000000814")
    var protectedGraph = try #require(JSONSerialization.jsonObject(with: after) as? [String: Any])
    let protectedSources = try #require(protectedGraph["sources"] as? [[String: Any]])
    protectedGraph["sources"] = protectedSources.filter { $0["kind"] as? String != "list" }
    protectedGraph["memberships"] = []
    let originalGraph = try #require(JSONSerialization.jsonObject(with: before) as? [String: Any])
    #expect(NSDictionary(dictionary: protectedGraph).isEqual(to: originalGraph))
    let listIdentifier = UUID(uuidString: "00000000-0000-4000-8000-000000000277")!
    guard
      case .snapshot(let snapshot) = await planner.query(
        .init(session: session, request: .items(.init(scope: .list(listIdentifier))))),
      case .rows(let page) = await planner.read(
        session: session, request: .rows(generation: snapshot.generation, offset: 0, limit: 64)),
      case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces),
      let namespace = namespaces.first,
      case .selected(let recovered) = await planner.inspectRecovery(
        request: .acknowledgedSnapshot(
          namespaceId: namespace.namespaceId, checkpointGeneration: checkpoint))
    else { throw CancellationError() }
    #expect(snapshot.matchingCount == 1)
    #expect(snapshot.progress.first?.totalCount == 1)
    #expect(page.rows.map(\.title) == ["Nezu Museum"])
    let recoveredGraph = try #require(
      JSONSerialization.jsonObject(with: recovered.portableData) as? [String: Any])
    let savedGraph = try #require(JSONSerialization.jsonObject(with: after) as? [String: Any])
    #expect(NSDictionary(dictionary: recoveredGraph).isEqual(to: savedGraph))
    #expect(
      result.importSummary?.imports.first?.dependencies.first?.lifetimeId.uuidString
        == "00000000-0000-4000-8000-000000000814")
    #expect(
      backup.externalBindings.first?.lifetimeId.uuidString
        == "00000000-0000-4000-8000-000000000815")
    let reopened = Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .exported(let reopenedData) = await reopened.exportData(session: reopenedSession),
      case .applied(let replayed, .complete(let replayCheckpoint)) = await reopened.execute(
        .init(operationId: operationIdentifier, session: reopenedSession, command: review.command)
      ).outcome,
      case .reviewed(let repeatedReview) = await reopened.prepareReview(
        session: reopenedSession, command: .applyImport(backup: backup, mode: mode)),
      case .applied(let repeated, .complete) = await reopened.execute(
        .init(
          operationId: UUID(), session: reopenedSession, command: repeatedReview.command,
          reviewToken: repeatedReview.reviewToken)
      ).outcome,
      case .exported(let repeatedData) = await reopened.exportData(session: reopenedSession)
    else { throw CancellationError() }
    #expect(reopenedData == after)
    #expect(replayed == result && replayCheckpoint == checkpoint)
    #expect(repeated.generated.isEmpty && repeatedData == after)
    let itemIdentifier = UUID(uuidString: "00000000-0000-4000-8000-000000000101")!
    guard
      case .reviewed(let deletion) = await reopened.prepareReview(
        session: reopenedSession,
        command: .deleteSource(source: .init(kind: .item, id: itemIdentifier))),
      case .applied(_, .complete) = await reopened.execute(
        .init(
          operationId: UUID(), session: reopenedSession, command: deletion.command,
          reviewToken: deletion.reviewToken)
      ).outcome,
      case .exported(let deletedData) = await reopened.exportData(session: reopenedSession)
    else { throw CancellationError() }
    var late = incoming
    var lateList = list
    lateList["id"] = "00000000-0000-4000-8000-000000000278"
    lateList["lifetimeId"] = "00000000-0000-4000-8000-000000000828"
    let independentTag = try #require(fixtureSources.first { $0["kind"] as? String == "tag" })
    late["sources"] = [lateList, independentTag]
    var lateMemberships = try #require(late["memberships"] as? [[String: Any]])
    lateMemberships[0]["id"] = "00000000-0000-4000-8000-000000000478"
    lateMemberships[0]["lifetimeId"] = "00000000-0000-4000-8000-000000000478"
    lateMemberships[0]["list"] = [
      "kind": "list", "id": "00000000-0000-4000-8000-000000000278",
      "lifetimeId": "00000000-0000-4000-8000-000000000828",
    ]
    late["memberships"] = lateMemberships
    guard
      case .decoded(let lateBackup) = reopened.decodeImport(
        try JSONSerialization.data(withJSONObject: late))
    else { throw CancellationError() }
    let lateOutcome = await reopened.prepareReview(
      session: reopenedSession, command: .applyImport(backup: lateBackup, mode: mode))
    guard case .reviewed(let lateReview) = lateOutcome else {
      Issue.record("Skip the whole dependent owner after family Delete: \(lateOutcome)")
      return
    }
    let lateDetails = try #require(lateReview.impact.importDetails)
    #expect(
      lateDetails.imports.map(\.owner.id.uuidString) == ["00000000-0000-4000-8000-000000000601"])
    #expect(
      lateDetails.skippedDependents.map(\.owner.id.uuidString)
        == ["00000000-0000-4000-8000-000000000278"])
    #expect(lateDetails.restorations.isEmpty && lateDetails.replacements.isEmpty)
    guard
      case .applied(_, .complete) = await reopened.execute(
        .init(
          operationId: UUID(), session: reopenedSession, command: lateReview.command,
          reviewToken: lateReview.reviewToken)
      ).outcome,
      case .exported(let lateData) = await reopened.exportData(session: reopenedSession),
      case .decoded(let lateSaved) = reopened.decodeImport(lateData)
    else { throw CancellationError() }
    #expect(lateSaved.backup.items.isEmpty && lateSaved.backup.memberships.isEmpty)
    #expect(lateSaved.backup.lists.map(\.id) == [listIdentifier])
    var lateGraph = try #require(JSONSerialization.jsonObject(with: lateData) as? [String: Any])
    let lateSources = try #require(lateGraph["sources"] as? [[String: Any]])
    lateGraph["sources"] = lateSources.filter { $0["kind"] as? String != "tag" }
    let deletedGraph = try #require(
      JSONSerialization.jsonObject(with: deletedData) as? [String: Any])
    #expect(NSDictionary(dictionary: lateGraph).isEqual(to: deletedGraph))
  }

  @Test(arguments: BindingCase.allCases)
  func declaredNewOwnerResolvesItsExternalItemOrRejectsTheWholeReview(bindingCase: BindingCase)
    async throws
  {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let created, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(content: .init(title: "Current museum")))
      ).outcome,
      let item = created.generated.first,
      case .exported(let before) = await planner.exportData(session: session)
    else { throw CancellationError() }
    var object = try #require(JSONSerialization.jsonObject(with: before) as? [String: Any])
    let currentItem = try #require((object["sources"] as? [[String: Any]])?.first)
    let itemId =
      bindingCase == .missing ? "00000000-0000-4000-8000-000000000199" : item.id.uuidString
    let itemLifetime =
      bindingCase == .wrongLifetime
      ? "00000000-0000-4000-8000-000000000999" : try #require(currentItem["lifetimeId"] as? String)
    object["sources"] = [
      [
        "kind": "list", "id": "00000000-0000-4000-8000-000000000277",
        "lifetimeId": "00000000-0000-4000-8000-000000000827",
        "createdAt": 10.25, "updatedAt": 20.125,
        "content": [
          "name": "New plan", "notes": NSNull(), "color": NSNull(), "iconName": NSNull(),
          "manualEstimate": NSNull(),
        ],
        "globalDone": NSNull(), "archived": false, "contentOrigins": ["name": "independent"],
      ]
    ]
    object["memberships"] = [
      [
        "id": "00000000-0000-4000-8000-000000000477",
        "lifetimeId": "00000000-0000-4000-8000-000000000477",
        "list": [
          "kind": "list", "id": "00000000-0000-4000-8000-000000000277",
          "lifetimeId": "00000000-0000-4000-8000-000000000827",
        ],
        "item": ["kind": "item", "id": itemId, "lifetimeId": itemLifetime],
        "rank": "1024", "localDone": false,
      ]
    ]
    guard
      case .decoded(let decoded) = planner.decodeImport(
        try JSONSerialization.data(withJSONObject: object))
    else { throw CancellationError() }
    #expect(decoded.externalBindings.count == 1)
    let response = await planner.prepareReview(
      session: session, command: .applyImport(backup: decoded))
    if bindingCase == .live {
      guard case .reviewed(let review) = response else {
        Issue.record("Use the current live external Item for a complete new List: \(response)")
        return
      }
      let details = try #require(review.impact.importDetails)
      #expect(details.imports.count == 1 && details.imports.first?.after?.title == "New plan")
      #expect(details.imports.first?.dependencies.first?.id == item.id)
      #expect(details.skippedConflicts.isEmpty && details.skippedDependents.isEmpty)
      #expect(
        details.unchanged.isEmpty && details.replacements.isEmpty && details.restorations.isEmpty)
      #expect(details.referenceChanges.count == 1 && details.referenceChanges.first?.change == .add)
    } else {
      guard case .failed(let failure) = response else {
        Issue.record("Reject every unresolved binding before issuing an import review.")
        return
      }
      #expect(failure.code == "missingReference")
      #expect(
        failure.propertyPath
          == (bindingCase == .missing ? "/memberships/0/item/id" : "/memberships/0/item/lifetimeId")
      )
    }
    guard case .exported(let after) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    #expect(before == after)
  }
}
