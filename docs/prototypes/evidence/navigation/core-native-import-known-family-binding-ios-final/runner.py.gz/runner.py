from pathlib import Path
import gzip
import hashlib
import json
import os
import signal
import subprocess
import time

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
phase = 'core-native-import-known-family-binding-ios-final'
packet = workspace / 'docs/prototypes/evidence/navigation' / phase
packet.mkdir(exist_ok=False)
compilation = workspace / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/core-native-import-known-family-binding-final-mac-build'
manifest = json.loads((compilation / 'source-sha256.json').read_text())
root = Path('/private/tmp/PlannerNativeItemWindowSource')
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
assert all((root / name).read_bytes() == (workspace / name).read_bytes() for name in manifest)
(packet / 'source-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
(packet / 'source-root.json').write_bytes((compilation / 'source-root.json').read_bytes())
for name in json.loads((compilation / 'source-root.json').read_text())['overlays']:
    (packet / (Path(name).name + '.gz')).write_bytes(gzip.compress((root / name).read_bytes(), mtime=0))
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
mac_result = json.loads((workspace / 'docs/prototypes/evidence/navigation/core-native-import-known-family-final-package/execution.json').read_text())
classes = sorted({case['className'].removeprefix('PlannerCoreStoreTests.') for case in mac_result['cases']})
result_path = '/private/tmp/PlannerKnownFamilyIOSCoreFinal.xcresult'
command = ['xcodebuild', 'test', '-project', 'Planner.xcodeproj', '-scheme', 'PlannerCore', '-destination', 'platform=iOS Simulator,id=2A49C66C-C8A4-435F-B98A-9A90706780DE', '-derivedDataPath', '/private/tmp/PlannerItemWindowsNativemobileDerivedData', '-clonedSourcePackagesDirPath', '/private/tmp/PlannerCalendarMonthSourcePackages', '-disableAutomaticPackageResolution', '-parallel-testing-enabled', 'NO', '-jobs', '1', *['-only-testing:PlannerCoreStoreTests/' + name for name in classes], '-resultBundlePath', result_path, 'CODE_SIGNING_ALLOWED=NO', 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerKnownFamilyIOSCoreFinal.log')
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
started = time.monotonic()
timed_out = False
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
unchanged = all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
commands = []
summary = None
for name, arguments in [('test-summary.json', ['get', 'test-results', 'summary']), ('test-results-tests.json.gz', ['get', 'test-results', 'tests'])]:
    extraction = ['xcrun', 'xcresulttool', *arguments, '--path', result_path, '--format', 'json']
    outcome = subprocess.run(extraction, capture_output=True, env=environment, timeout=60)
    commands.append({'command': extraction, 'exitCode': outcome.returncode})
    if outcome.returncode == 0:
        (packet / name).write_bytes(gzip.compress(outcome.stdout, mtime=0) if name.endswith('.gz') else outcome.stdout)
        if name == 'test-summary.json': summary = json.loads(outcome.stdout)
(packet / 'evidence-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
product_root = Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products')
products = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in product_root.rglob('*') if path.is_file() and (path.name in ['PlannerCoreTests', 'PlannerCoreStoreTests'] or (path.name.startswith('PlannerCore_') and path.suffix == '.xctestrun'))}
(packet / 'product-sha256.json').write_text(json.dumps(products, indent=2) + '\n')
report = {'exitCode': code, 'runnerTimedOut': timed_out, 'elapsedSeconds': round(time.monotonic() - started, 3), 'frozenInputsUnchanged': unchanged, 'requestedClasses': classes, 'summary': {name: summary.get(name) for name in ['result', 'passedTests', 'failedTests', 'skippedTests']} if summary else None}
(packet / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
for line in log.read_text(errors='replace').splitlines():
    if 'recorded an issue' in line or 'failed after' in line or '** TEST' in line or ('.swift:' in line and ': error:' in line): print(line[:1000])
raise SystemExit(code)
