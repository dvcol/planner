import Foundation
import Observation
import PlannerCore

struct SavedItemWindowIdentity: Equatable {
  let namespace: String
  let savedRevision: UUID
}

enum SavedItemWindowState: Equatable {
  case idle, loading, ready
  case failed(String)
}

enum SavedItemWindowPresentation {
  case loading
  case loaded(SavedPlannerItem)
  case failed(String)
}

@MainActor @Observable
final class SavedItemWindow {
  private let planner: PlannerCore.Planner
  private let session: PlannerDatasetSession
  private(set) var sourceIdentifiers: [UUID] = []
  private(set) var matchingCount: Int64 = 0
  private(set) var state = SavedItemWindowState.idle

  init(planner: PlannerCore.Planner, session: PlannerDatasetSession) {
    self.planner = planner
    self.session = session
  }

  func reload(query: PlannerItemQuery, identity: SavedItemWindowIdentity) async {}

  func presentation(at index: Int) -> SavedItemWindowPresentation { .loading }
}
