import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class SavedItemWindowTests: XCTestCase {
  func testOpensWithOnePageAndKeepsEveryOrderedSourceIdentity() async throws {
    let fixture = try await makeFixture(itemCount: 65)
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let window = SavedItemWindow(planner: fixture.planner, session: fixture.session)
    await window.reload(
      query: .init(completion: .all, archive: .all),
      identity: .init(namespace: "first-page", savedRevision: UUID()))
    XCTAssertEqual(window.state, .ready)
    XCTAssertEqual(window.sourceIdentifiers, fixture.identifiers)
    XCTAssertEqual(window.matchingCount, 65)
    for (index, title) in [(0, "Activity 000"), (63, "Activity 063")] {
      guard case .loaded(let item) = window.presentation(at: index) else {
        XCTFail("The initial page must be readable before the catalog is ready.")
        return
      }
      XCTAssertEqual(item.id, fixture.identifiers[index])
      XCTAssertEqual(item.row.title, title)
    }
    guard case .loading = window.presentation(at: 64) else {
      XCTFail("The catalog must not accumulate all matching row presentations.")
      return
    }
  }

  func testLoadsVisibleAndNeighborPagesReleasesDistantRowsAndRevisitsTheirIdentities() async throws
  {
    let fixture = try await makeFixture(itemCount: 193)
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let window = SavedItemWindow(planner: fixture.planner, session: fixture.session)
    await window.reload(
      query: .init(completion: .all, archive: .all),
      identity: .init(namespace: "page-traversal", savedRevision: UUID()))
    await window.requestRows(at: [192])
    XCTAssertEqual(window.state, .ready)
    XCTAssertEqual(window.sourceIdentifiers, fixture.identifiers)
    for (index, title) in [(128, "Activity 128"), (192, "Activity 192")] {
      guard case .loaded(let item) = window.presentation(at: index) else {
        XCTFail("Visible and neighboring pages must load through the same catalog.")
        return
      }
      XCTAssertEqual(item.id, fixture.identifiers[index])
      XCTAssertEqual(item.row.title, title)
    }
    for index in [0, 64] {
      guard case .loading = window.presentation(at: index) else {
        XCTFail("Distant row presentations must be released.")
        return
      }
    }
    await window.requestRows(at: [0])
    for (index, title) in [(0, "Activity 000"), (64, "Activity 064")] {
      guard case .loaded(let item) = window.presentation(at: index) else {
        XCTFail("Revisiting a released page must reload its original Items.")
        return
      }
      XCTAssertEqual(item.id, fixture.identifiers[index])
      XCTAssertEqual(item.row.title, title)
    }
    for index in [128, 192] {
      guard case .loading = window.presentation(at: index) else {
        XCTFail("Returning to the beginning must release the distant pages.")
        return
      }
    }
  }

  func testRefreshesAStaleGenerationWithoutMixingItsRowsAndKeepsTheVisibleSource() async throws {
    let fixture = try await makeFixture(itemCount: 193)
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let window = SavedItemWindow(planner: fixture.planner, session: fixture.session)
    await window.reload(
      query: .init(completion: .todo, archive: .all),
      identity: .init(namespace: "saved-mutation", savedRevision: UUID()))
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setCompletion(scope: .globalItem(itemId: fixture.identifiers[0]), done: true))
      ).outcome
    else { throw CancellationError() }
    await window.requestRows(at: [192])
    XCTAssertEqual(window.state, .ready)
    XCTAssertEqual(window.matchingCount, 192)
    XCTAssertEqual(window.sourceIdentifiers, Array(fixture.identifiers.dropFirst()))
    guard case .loaded(let lastItem) = window.presentation(at: 191) else {
      XCTFail("A stale page must refresh and retain the source that was visible before the change.")
      return
    }
    XCTAssertEqual(lastItem.id, fixture.identifiers[192])
    XCTAssertEqual(lastItem.row.title, "Activity 192")
    for index in window.sourceIdentifiers.indices {
      if case .loaded(let item) = window.presentation(at: index) {
        XCTAssertEqual(item.id, fixture.identifiers[index + 1])
        XCTAssertFalse(item.row.globalDone == true)
      }
    }
  }

  private struct Fixture {
    let directory: URL
    let planner: PlannerCore.Planner
    let session: PlannerDatasetSession
    let identifiers: [UUID]
  }

  private func makeFixture(itemCount: Int) async throws -> Fixture {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    let planner = PlannerCore.Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      throw CancellationError()
    }
    var expectedIdentifiers: [UUID] = []
    var sources: [[String: Any]] = []
    for index in 0..<itemCount {
      let identifier = UUID()
      expectedIdentifiers.append(identifier)
      sources.append([
        "kind": "item", "id": identifier.uuidString, "lifetimeId": UUID().uuidString,
        "createdAt": 813_000_000 + index, "updatedAt": 813_000_000 + index,
        "content": [
          "title": String(format: "Activity %03d", index), "subtitle": NSNull(),
          "notes": NSNull(), "location": NSNull(), "estimate": NSNull(),
        ],
        "globalDone": false, "archived": false, "contentOrigins": ["title": "independent"],
      ])
    }
    let data = try JSONSerialization.data(withJSONObject: [
      "format": "planner-data", "formatVersion": 2, "sources": sources,
      "memberships": [], "itineraryEntries": [], "schedules": [],
      "labelAssociations": [], "ownedLinks": [], "completionChanges": [],
      "expandedCompletions": [], "contextAliases": [], "restorationFamilies": [],
      "deletionMarkers": [],
    ])
    guard case .decoded(let backup) = planner.decodeImport(data),
      case .reviewed(let review) = await planner.prepareReview(
        session: datasetSession, command: .applyImport(backup: backup)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: datasetSession, command: review.command,
          reviewToken: review.reviewToken)
      ).outcome
    else { throw CancellationError() }
    return Fixture(
      directory: directory, planner: planner, session: datasetSession,
      identifiers: expectedIdentifiers)
  }
}
