import Foundation
import Observation
import PlannerCore

struct SavedItemWindowIdentity: Equatable {
  let namespace: String
  let savedRevision: UUID
}

enum SavedItemWindowState: Equatable {
  case idle, loading, ready
  case failed(String)
}

enum SavedItemWindowPresentation {
  case loading
  case loaded(SavedPlannerItem)
  case failed(String)
}

@MainActor @Observable
final class SavedItemWindow {
  private let planner: PlannerCore.Planner
  private let session: PlannerDatasetSession
  private(set) var sourceIdentifiers: [UUID] = []
  private(set) var matchingCount: Int64 = 0
  private(set) var state = SavedItemWindowState.idle
  private var reloadIdentifier = UUID()
  private var pages: [Int: [SavedPlannerItem]] = [:]

  init(planner: PlannerCore.Planner, session: PlannerDatasetSession) {
    self.planner = planner
    self.session = session
  }

  func reload(query: PlannerItemQuery, identity: SavedItemWindowIdentity) async {
    let requestIdentifier = UUID()
    reloadIdentifier = requestIdentifier
    state = .loading
    sourceIdentifiers = []
    matchingCount = 0
    pages = [:]
    while !Task.isCancelled {
      let result = await planner.query(.init(session: session, request: .items(query)))
      guard !Task.isCancelled, reloadIdentifier == requestIdentifier else { return }
      guard case .snapshot(let snapshot) = result else {
        if case .failed(let reason) = result { state = .failed(reason.message) }
        return
      }
      var identifiers: [UUID] = []
      for identity in snapshot.rows {
        guard case .source(let source) = identity, source.kind == .item else {
          state = .failed("Planner could not resolve its Items.")
          return
        }
        identifiers.append(source.id)
      }
      guard Int64(identifiers.count) == snapshot.matchingCount,
        Set(identifiers).count == identifiers.count
      else {
        state = .failed("Planner could not resolve its complete Items.")
        return
      }
      if identifiers.isEmpty {
        state = .ready
        return
      }
      let read = await planner.read(
        session: session, request: .rows(generation: snapshot.generation, offset: 0, limit: 64))
      guard !Task.isCancelled, reloadIdentifier == requestIdentifier else { return }
      switch read {
      case .rows(let window):
        guard window.generation == snapshot.generation, window.offset == 0,
          window.matchingCount == snapshot.matchingCount,
          window.rows.count == min(64, identifiers.count)
        else {
          state = .failed("Planner could not read its complete Item page.")
          return
        }
        var items: [SavedPlannerItem] = []
        for (index, row) in window.rows.enumerated() {
          guard row.identity == .source(.init(kind: .item, id: identifiers[index])) else {
            state = .failed("Planner could not resolve its Item page.")
            return
          }
          items.append(
            .init(id: identifiers[index], row: row, rowPresentation: window.rowPresentation))
        }
        sourceIdentifiers = identifiers
        matchingCount = snapshot.matchingCount
        pages[0] = items
        state = .ready
        return
      case .failed(let reason):
        if reason.code == "staleSnapshot" { continue }
        state = .failed(reason.message)
        return
      default:
        state = .failed("Planner could not read its Items.")
        return
      }
    }
  }

  func presentation(at index: Int) -> SavedItemWindowPresentation {
    guard sourceIdentifiers.indices.contains(index), let page = pages[index / 64],
      page.indices.contains(index % 64)
    else { return .loading }
    return .loaded(page[index % 64])
  }
}
