import Foundation
import PlannerCore
import Testing

@testable import Planner

@MainActor
struct SavedItemWindowTests {
  @Test func opensWithOnePageAndKeepsEveryOrderedSourceIdentity() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      throw CancellationError()
    }
    var expectedIdentifiers: [UUID] = []
    for index in 0..<65 {
      let title = String(format: "Activity %03d", index)
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(
            operationId: UUID(), session: datasetSession,
            command: .createItem(content: .init(title: title)))
        ).outcome,
        let source = result.generated.first
      else { throw CancellationError() }
      expectedIdentifiers.append(source.id)
    }
    let window = SavedItemWindow(planner: planner, session: datasetSession)
    await window.reload(
      query: .init(completion: .all, archive: .all),
      identity: .init(namespace: "first-page", savedRevision: UUID()))
    #expect(window.state == .ready)
    #expect(window.sourceIdentifiers == expectedIdentifiers)
    #expect(window.matchingCount == 65)
    for (index, title) in [(0, "Activity 000"), (63, "Activity 063")] {
      guard case .loaded(let item) = window.presentation(at: index) else {
        Issue.record("The initial page must be readable before the catalog is ready.")
        return
      }
      #expect(item.id == expectedIdentifiers[index])
      #expect(item.row.title == title)
    }
    guard case .loading = window.presentation(at: 64) else {
      Issue.record("The catalog must not accumulate all matching row presentations.")
      return
    }
  }
}
