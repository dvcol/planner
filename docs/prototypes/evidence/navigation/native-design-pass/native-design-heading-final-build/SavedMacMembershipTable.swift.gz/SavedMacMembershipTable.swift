import CoreTransferable
import PlannerCore
import PlannerPreviews
import SwiftUI
import UniformTypeIdentifiers

#if os(macOS)
  private struct SavedMembershipDragReference: Codable, Transferable {
    let listId: UUID
    let membershipId: UUID

    static var transferRepresentation: some TransferRepresentation {
      CodableRepresentation(
        contentType: UTType(exportedAs: "com.dvcol.planner.list-membership", conformingTo: .data))
    }
  }

  struct SavedMacMembershipTable: View {
    @Environment(PlannerPreviews.self) private var previews
    let store: SavedPlannerStore
    let list: PlannerListSourceRead
    let items: [SavedPlannerItem]
    let selection: Binding<UUID?>
    let canReorderMemberships: Bool
    let addToList: (SavedPlannerItem) -> Void
    let moveMembership: (SavedPlannerItem) -> Void
    let removeMembership: (UUID) -> Void

    var body: some View {
      VStack(alignment: .leading, spacing: 0) {
        SavedListProgress(
          listName: list.content.name, progress: list.progress, estimates: list.estimates,
          manualEstimate: list.content.manualEstimate, matchingCount: items.count,
          isArchived: list.state.archived == true
        ).padding()
        Table(of: SavedPlannerItem.self, selection: selection) {
          TableColumn("Items") { item in
            SavedMembershipRow(item: item, canChange: store.canCreate) {
              guard case .appearance(_, let appearance) = item.row.identity else { return }
              Task {
                _ = await store.setAppearanceCompletion(
                  appearance, done: item.row.effectiveDone != true)
              }
            }
            .environment(store)
            .environment(previews)
            .contextMenu {
              Button("Move to Beginning") { reorder(item.id, placement: .first) }
                .disabled(!canReorderMemberships || items.first?.id == item.id)
              Button("Move to End") { reorder(item.id, placement: .last) }
                .disabled(!canReorderMemberships || items.last?.id == item.id)
              Divider()
              Button("Add to List") { addToList(item) }
                .disabled(!store.canCreate)
              Button("Move to List") { moveMembership(item) }
                .disabled(!store.canCreate)
              Button("Remove from List", role: .destructive) { removeMembership(item.id) }
                .disabled(!store.canCreate)
            }
          }
        } rows: {
          ForEach(items) { item in
            if canReorderMemberships {
              TableRow(item)
                .draggable(
                  SavedMembershipDragReference(listId: list.source.id, membershipId: item.id))
            } else {
              TableRow(item)
            }
          }
          .dropDestination(for: SavedMembershipDragReference.self) { insertionIndex, references in
            guard canReorderMemberships, references.count == 1, let reference = references.first,
              reference.listId == list.source.id, (0...items.count).contains(insertionIndex)
            else { return }
            if insertionIndex == items.count {
              reorder(reference.membershipId, placement: .last)
              return
            }
            let anchor = items[insertionIndex].id
            guard anchor != reference.membershipId else { return }
            reorder(reference.membershipId, placement: .before(associationId: anchor))
          }
        }
        .tableStyle(.inset(alternatesRowBackgrounds: false))
      }
    }

    private func reorder(_ membershipId: UUID, placement: PlannerPlacement) {
      guard canReorderMemberships else { return }
      Task {
        _ = await store.reorderMembership(
          membershipId, listId: list.source.id, placement: placement)
      }
    }
  }
#endif
