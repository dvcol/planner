from pathlib import Path
import gzip,hashlib,json,re
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/navigation/native-design-pass'
results=[]
for path in sorted(root.glob('*/exit.json')):
 packet=path.parent
 result=json.loads(path.read_text())
 log_path=packet/'test.log.gz'
 tests=[]
 if log_path.is_file():
  log=gzip.decompress(log_path.read_bytes()).decode(errors='replace')
  for name,status,duration in re.findall(r"Test Case '-\[PlannerNavigationUITests\.(.*?)\]' (passed|failed) \(([\d.]+) seconds\)\.",log):
   tests.append({'name':name,'status':status,'seconds':float(duration)})
 results.append({'phase':packet.name,**result,'tests':tests})
(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
credential_pattern=re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}')
checked=[]
for path in sorted(root.rglob('*')):
 if not path.is_file():continue
 content=path.read_bytes()
 if path.suffix=='.gz':content=gzip.decompress(content)
 assert not credential_pattern.search(content), 'Credential-like value found in '+str(path.relative_to(root))
 checked.append(str(path.relative_to(root)))
(root/'credential-scan.json').write_text(json.dumps({'pattern':'GitHub credential value signatures; guard keywords alone are not values','filesChecked':len(checked),'matches':0},indent=2)+'\n')
index={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(root.rglob('*')) if path.is_file() and path.name!='sha256.json'}
(root/'sha256.json').write_text(json.dumps(index,indent=2)+'\n')
print('Indexed',len(index),'evidence files; no GitHub credential value signatures')
