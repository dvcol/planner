import Foundation
import PlannerCore
import PlannerPreviews

@MainActor
enum PlannerSavedMapsFixture {
  static let delayedURL = "https://maps.apple.com/place?name=Delayed&coordinate=35,139"
  static let currentURL = "https://maps.apple.com/place?name=Current&coordinate=36,140"

  static func seed(_ planner: PlannerCore.Planner, session: PlannerDatasetSession) async throws {
    let result = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .createItem(
          content: .init(
            title: "Delayed map", notes: "Owned map notes",
            links: [
              .init(originalUrl: delayedURL, label: "Delayed place"),
              .init(originalUrl: currentURL, label: "Current place"),
            ]))))
    guard case .applied(_, .complete) = result.outcome else { throw CancellationError() }
  }
}

@MainActor
final class FixtureMapsPreviewProvider: PlannerMapsPreviewProvider {
  private let native = NativeMapsPreviewProvider()
  private var pendingPreview: CheckedContinuation<PlannerCapturePreviewCandidate?, Never>?

  func mapsPreview(for originalURL: String) async -> PlannerCapturePreviewCandidate? {
    if originalURL == PlannerSavedMapsFixture.delayedURL {
      return await withCheckedContinuation { continuation in
        guard pendingPreview == nil else {
          continuation.resume(returning: nil)
          return
        }
        pendingPreview = continuation
      }
    }
    if originalURL == PlannerSavedMapsFixture.currentURL, let continuation = pendingPreview {
      pendingPreview = nil
      let obsolete = await native.mapsPreview(
        for: "https://maps.apple.com/place?name=Outdated&coordinate=35,139")
      continuation.resume(returning: obsolete)
    }
    return await native.mapsPreview(for: originalURL)
  }
}
