import XCTest

@MainActor
final class SavedMapsPreviewJourneyTests: XCTestCase {
  func testSwitchingSavedMapsLinksRejectsTheReleasedObsoletePreview() {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = [
      "--fixture", "saved-maps-delay", "--fixture-dataset", UUID().uuidString,
    ]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    let row = application.savedPlannerItemRows("Delayed map").firstMatch
    XCTAssertTrue(row.waitForExistence(timeout: 20))
    row.activateForPlannerJourney()
    let picker = application.plannerElement("saved.item.maps.preview.source")
    reveal(picker, application: application)
    let loading = application.descendants(matching: .any).matching(
      NSPredicate(format: "label == %@", "Loading map preview")
    ).firstMatch
    XCTAssertTrue(loading.waitForExistence(timeout: 5))
    XCTAssertFalse(application.staticTexts["Current"].exists)
    picker.activateForPlannerJourney()
    application.plannerElement("Current place").activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Current"].waitForExistence(timeout: 10))
    XCTAssertTrue(loading.waitForNonExistence(timeout: 5))
    XCTAssertFalse(application.staticTexts["Outdated"].exists)
    XCTAssertTrue(
      application.descendants(matching: .any)
        .matching(identifier: "saved.item.maps.preview.map").firstMatch.exists)
    XCTAssertTrue(application.staticTexts["Owned map notes"].exists)
    XCTAssertTrue(
      application.plannerElement("saved.item.completion").waitForPlannerBooleanState(false))
    capture(application, name: "Selected saved Maps link survives the released obsolete preview")
    let bookmarks = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link."))
    let current = bookmarks.matching(NSPredicate(format: "label == %@", "Current place"))
      .firstMatch
    reveal(current, application: application)
    XCTAssertEqual(bookmarks.count, 2)
    XCTAssertEqual(
      current.value as? String, "https://maps.apple.com/place?name=Current&coordinate=36,140")
    let delayed = bookmarks.matching(NSPredicate(format: "label == %@", "Delayed place"))
      .firstMatch
    XCTAssertEqual(
      delayed.value as? String, "https://maps.apple.com/place?name=Delayed&coordinate=35,139")
  }

  private func reveal(_ element: XCUIElement, application: XCUIApplication) {
    for _ in 0..<6 {
      if element.exists && element.isHittable { return }
      #if os(macOS)
        let form = application.scrollViews.containing(
          .any, identifier: "saved.item.completion"
        ).firstMatch
      #else
        let form = application.collectionViews.containing(
          .any, identifier: "saved.item.completion"
        ).firstMatch
      #endif
      XCTAssertTrue(form.waitForExistence(timeout: 5))
      let start = form.coordinate(withNormalizedOffset: .init(dx: 0.97, dy: 0.8))
      let end = form.coordinate(withNormalizedOffset: .init(dx: 0.97, dy: 0.25))
      start.press(forDuration: 0.05, thenDragTo: end)
    }
    XCTAssertTrue(element.waitForExistence(timeout: 5))
  }

  private func capture(_ application: XCUIApplication, name: String) {
    let attachment = XCTAttachment(screenshot: application.screenshot())
    attachment.name = name
    attachment.lifetime = .keepAlways
    add(attachment)
  }
}
