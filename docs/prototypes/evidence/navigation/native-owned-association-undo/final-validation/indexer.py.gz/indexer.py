from pathlib import Path
import gzip,hashlib,json,os,re,struct,subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packets=sorted(path for path in root.iterdir() if path.is_dir() and path.name.startswith(('owned-group-native-','phone-owned-group-native-','tablet-owned-group-native-')))
assert len(packets)==49,len(packets)
validation=repository/'docs/prototypes/evidence/navigation/native-owned-association-undo/final-validation'
validation.mkdir(parents=True,exist_ok=True)
final_epochs={'owned-group-native-final-history-http','owned-group-native-final-mac','owned-group-native-final-mobile','phone-owned-group-native-final-qualified','tablet-owned-group-native-final-qualified'}
observations=[]
comparisons=[]
for packet in packets:
 if (packet/'invocation-error.json').exists():
  observations.append({'epoch':packet.name,**json.loads((packet/'invocation-error.json').read_text())})
  continue
 result=json.loads((packet/'exit.json').read_text())
 log_path=next(path for path in [packet/'test.log.gz',packet/'build.log.gz'] if path.exists())
 log=gzip.decompress(log_path.read_bytes()).decode(errors='replace')
 observations.append({'epoch':packet.name,'exitCode':result['exitCode'],'executedSummaries':[line.strip() for line in log.splitlines() if ('Executed ' in line and ' test' in line) or 'Test run with ' in line][-4:]})
 hashes_path=next(path for path in [packet/'source-sha256.json',packet/'current-source-sha256.json'] if path.exists())
 hashes=json.loads(hashes_path.read_text())
 production={name:digest for name,digest in hashes.items() if name.endswith('.swift') and (name.startswith('Planner/') or '/Sources/' in name)}
 assert len(production)==150,len(production)
 differences=[name for name,digest in hashes.items() if not (repository/name).is_file() or hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
 comparisons.append({'epoch':packet.name,'productionInputs':len(production),'allDifferentCurrentInputs':differences})
 if packet.name in final_epochs:assert result['exitCode']==0 and not differences,(packet.name,differences)
 if packet.name in final_epochs-{'owned-group-native-final-history-http'}:
  products=json.loads((packet/'product-sha256.json').read_text())
  assert all(Path(name).exists() and hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
(validation/'observed-results.json').write_text(json.dumps(observations,indent=2)+'\n')
(validation/'source-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
for name in ['phone-owned-group-native-final-qualified','tablet-owned-group-native-final-qualified','owned-group-native-final-history-http']:
 bundle=json.loads((root/name/'exit.json').read_text())['bundle']
 summary=json.loads(subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',bundle],env=environment,text=True))
 assert summary['result']=='Passed' and summary['failedTests']==0
 (validation/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
visual=[]
for name in ['phone-owned-group-native-final-qualified','tablet-owned-group-native-final-qualified']:
 captures=json.loads((root/name/'selected-captures.json').read_text())
 images=[capture for capture in captures if capture['exportedFileName'].endswith('.png')]
 assert len(images)==6,len(images)
 for capture in images:
  path=root/name/capture['exportedFileName']
  raw=path.read_bytes()
  assert raw.startswith(b'\x89PNG\r\n\x1a\n')
  width,height=struct.unpack('>II',raw[16:24])
  visual.append({'path':str(path.relative_to(repository)),'sha256':hashlib.sha256(raw).hexdigest(),'width':width,'height':height,'inspectedOriginal':True,'caption':capture['suggestedHumanReadableName']})
(validation/'visual-review.json').write_text(json.dumps({'originals':visual,'observations':['Both editor journeys show one named native Undo, restored link labels/current Tag and retained notes after relaunch. Native assertions separately verify exact bookmark identities and order.','Dark phone and light tablet originals were inspected. Lower phone link content lies behind floating tabs at the captured scroll position. No scroll-clearance, measured contrast, Increase Contrast, full-scene or Mac window acceptance is claimed.']},indent=2)+'\n')
reports=['docs/prototypes/native-owned-association-undo.md','docs/prototypes/core-owned-association-undo.md','docs/open-decisions.md','docs/native-ui-scene-inventory.md']
swift_files=['Planner/Scenes/SavedAssociationUndoHistory.swift','Planner/Scenes/SavedEditItemForm.swift','Planner/Scenes/SavedItineraryViews.swift','Planner/Scenes/SavedPlannerStore.swift','Planner/Scenes/SavedPlannerView.swift','PlannerMCPTests/SavedAssociationUndoHistoryTests.swift','PlannerNavigationUITests/SavedLabelsJourneyTests.swift']
checks=[]
for index,command in enumerate([['xcrun','swift-format','lint','--strict',*swift_files],['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json',*reports],['git','diff','--check']]):
 result=subprocess.run(command,env=environment,capture_output=True,text=True)
 (validation/f'check-{index}.log.gz').write_bytes(gzip.compress((result.stdout+result.stderr).encode(),mtime=0))
 checks.append({'command':command,'exitCode':result.returncode})
 assert result.returncode==0,(command,result.stdout,result.stderr)
links=[]
for report in reports:
 for target in re.findall(r'\]\(([^)]+)\)',(repository/report).read_text()):
  if target.startswith(('http:','https:','#')):continue
  destination=(repository/report).parent.joinpath(target.split('#')[0]).resolve()
  assert destination.exists() or destination in [validation/'checks.json',validation/'evidence-sha256.json'],target
  links.append({'report':report,'target':target})
(validation/'checks.json').write_text(json.dumps({'commands':checks,'localLinksChecked':len(links),'missingLinks':[],'originalImagesInspected':len(visual),'finalSourceEpochs':sorted(final_epochs)},indent=2)+'\n')
patterns={'githubCredential':r'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}','privateKey':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','openaiCredential':r'sk-(?:proj-)?[A-Za-z0-9_-]{30,}'}
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
findings=[]
for path in files:
 data=path.read_bytes()
 if path.suffix=='.gz':data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data.decode(errors='replace')):findings.append({'path':str(path.relative_to(repository)),'pattern':name})
assert not findings
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(files),'decompressedGzip':True,'findings':findings},indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
(validation/'evidence-sha256.json').write_text(json.dumps({str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)},indent=2)+'\n')
assert all((repository/entry['report']).parent.joinpath(entry['target'].split('#')[0]).exists() for entry in links)
print('Verified forty-nine native epochs, five matching final source epochs, twelve inspected originals,',len(files),'evidence hashes, affected lint/links pass.')
