from pathlib import Path
import gzip
import hashlib
import json
import os
import signal
import subprocess
import time
import sys

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
phase = sys.argv[1]
packet = workspace / 'docs/prototypes/evidence/navigation' / phase
packet.mkdir(exist_ok=False)
root = Path('/private/tmp/PlannerIncomingFamilyNativeSource')
previous = workspace / 'docs/prototypes/evidence/navigation/core-incoming-family-import-regression-ios'
manifest = json.loads((previous / 'source-sha256.json').read_text())
products = json.loads((previous / 'product-sha256.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
for name in ['source-sha256.json','source-root.json','product-sha256.json']:
    (packet/name).write_bytes((previous/name).read_bytes())
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
mac_result = json.loads((workspace / 'docs/prototypes/evidence/navigation/core-incoming-family-receipt-regression-mac/execution.json').read_text())
classes = sorted({case['className'].removeprefix('PlannerCoreStoreTests.') for case in mac_result['cases']})
result_path = '/private/tmp/PlannerIncomingFamily-' + phase + '.xcresult'
command = ['xcodebuild','test','-project','Planner.xcodeproj','-scheme','PlannerCore','-destination','platform=iOS Simulator,id=2A49C66C-C8A4-435F-B98A-9A90706780DE','-derivedDataPath','/private/tmp/PlannerIncomingFamilyMobileDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1',*['-only-testing:PlannerCoreStoreTests/'+name for name in classes],'-resultBundlePath',result_path,'CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerIncomingFamily-' + phase + '.log')
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
started = time.monotonic()
timed_out = False
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
unchanged = all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
commands = []
summary = None
for name, arguments in [('test-summary.json', ['get', 'test-results', 'summary']), ('test-results-tests.json.gz', ['get', 'test-results', 'tests'])]:
    extraction = ['xcrun', 'xcresulttool', *arguments, '--path', result_path]
    outcome = subprocess.run(extraction, capture_output=True, env=environment, timeout=60)
    commands.append({'command': extraction, 'exitCode': outcome.returncode})
    if outcome.returncode == 0:
        (packet / name).write_bytes(gzip.compress(outcome.stdout, mtime=0) if name.endswith('.gz') else outcome.stdout)
        if name == 'test-summary.json': summary = json.loads(outcome.stdout)
(packet / 'evidence-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
product_root = Path('/private/tmp/PlannerIncomingFamilyMobileDerivedData/Build/Products')
products = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in product_root.rglob('*') if path.is_file() and (path.name in ['PlannerCoreTests', 'PlannerCoreStoreTests'] or (path.name.startswith('PlannerCore_') and path.suffix == '.xctestrun'))}
(packet / 'product-sha256.json').write_text(json.dumps(products, indent=2) + '\n')
report = {'exitCode': code, 'runnerTimedOut': timed_out, 'elapsedSeconds': round(time.monotonic() - started, 3), 'frozenInputsUnchanged': unchanged, 'requestedClasses': classes, 'sqliteUnlinkWarnings': log.read_text(errors='replace').count('vnode unlinked while in use'), 'summary': {name: summary.get(name) for name in ['result', 'passedTests', 'failedTests', 'skippedTests']} if summary else None}
(packet / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
for line in log.read_text(errors='replace').splitlines():
    if 'recorded an issue' in line or 'failed after' in line or '** TEST' in line or ('.swift:' in line and ': error:' in line): print(line[:1000])
raise SystemExit(code)
