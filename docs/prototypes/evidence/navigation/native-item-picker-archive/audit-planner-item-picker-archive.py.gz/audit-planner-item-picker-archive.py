from pathlib import Path
import hashlib,json,gzip
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-item-picker-archive'
def read_json(path):return json.loads(path.read_text())
def sha256(path):return hashlib.sha256(path.read_bytes()).hexdigest()
runs={value['epoch']:value for value in read_json(packet/'historical-run-index.json')['runs']}
for epoch in ['mobile-picker-active-copy-build','mac-picker-active-copy-build']:
 inputs=read_json(packet/epoch/'source-sha256.json')
 assert len(inputs)==945 and all(sha256(repository/path)==digest for path,digest in inputs.items())
 assert read_json(packet/epoch/'exit.json')['exitCode']==0
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
function='PlannerNavigationUITests.SavedListMembershipJourneyTests testExistingItemPickerExcludesArchivedSourcesAndReloadsAfterUnarchiving'
for epoch in ['phone-picker-active-copy','tablet-picker-active-copy']:
 result=runs[epoch]
 assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
 assert len(result['functions'])==1 and result['functions'][0]['function']==function and result['functions'][0]['outcome']=='passed'
 assert not result['startedWithoutCompletedOutcome']
 current=read_json(packet/epoch/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
 assert all(sha256(repository/path)==digest for path,digest in current.items())
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
for epoch in ['phone-picker-archive','tablet-picker-archive']:
 result=runs[epoch]
 assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
 assert len(result['functions'])==1 and result['functions'][0]['function']==function and result['functions'][0]['outcome']=='passed'
 assert not result['startedWithoutCompletedOutcome']
 assert read_json(packet/epoch/'source-variant.json')['historicalPreCopyEvidence']
 current=read_json(packet/epoch/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
 compiled=read_json(packet/'mobile-picker-archive-build'/'source-sha256.json')
 assert all(compiled[path]==digest for path,digest in current.items())
 differences={path for path,digest in current.items() if sha256(repository/path)!=digest}
 assert differences=={'Planner/Scenes/SavedAddItemForm.swift','PlannerNavigationUITests/SavedListMembershipJourneyTests.swift'},differences
 for path in differences:
  archived=gzip.decompress((packet/epoch/(Path(path).name+'.gz')).read_bytes())
  assert hashlib.sha256(archived).hexdigest()==current[path]

visual=read_json(packet/'visual-review.json')['images']
assert len(visual)==12 and all(value['individuallyInspected'] and sha256(packet/value['path'])==value['sha256'] for value in visual)
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
lint=read_json(packet/'affected-swift-lint.json')
review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(sha256(repository/path)==digest for path,digest in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(sha256(repository/path)==digest for path,digest in markdown['sourceSHA256'].items())
value={'compilerInputsPerPlatform':945,'frozenRuntimeInputsPerInvocation':469,'productsPerPlatform':6,'finalSourcePassingFunctionsPerPlatform':{'phone':1,'tablet':1,'mac':0},'preCopyWorkflowPasses':2,'individuallyInspectedPNGs':12,'productionChanged':'Two native empty-state strings; commands, filtering, persistence and loading unchanged','scope':'Existing active-only picker excludes archived source after loaded-empty state; Add disabled until explicit selection; Cancel retains empty List; same source becomes selectable after Unarchive without relaunch; source/List/membership identities and notes retained through relaunch. No adversarial delay/Retry, performance, accessibility, signing or Mac runtime credit. Q94/Q95 remain unanswered.'}
(packet/'evidence-audit.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
