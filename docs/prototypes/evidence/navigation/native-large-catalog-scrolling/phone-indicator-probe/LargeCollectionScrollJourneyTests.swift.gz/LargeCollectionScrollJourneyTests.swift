import XCTest

#if os(iOS)
  @MainActor
  final class LargeCollectionScrollJourneyTests: XCTestCase {
    func testUnfilteredCatalogScrollsToBothEndsAndReopensTheSameSource() {
      continueAfterFailure = false
      let application = XCUIApplication()
      application.launchArguments = [
        "--fixture", "large-collection", "--fixture-dataset", UUID().uuidString,
      ]
      application.launchSavedPlannerJourney()
      XCTAssertTrue(application.buttons["Items"].firstMatch.waitForExistence(timeout: 120))
      application.openPlannerSection("Items")
      let first = application.savedPlannerItemRows("Scale Item 00001").firstMatch
      XCTAssertTrue(first.waitForExistence(timeout: 30))
      XCTAssertTrue(first.isHittable)
      let firstIdentifier = first.identifier
      let contents = application.collectionViews.containing(
        NSPredicate(
          format: "identifier BEGINSWITH %@ AND label BEGINSWITH %@", "saved.item.", "Scale Item ")
      ).firstMatch
      XCTAssertTrue(contents.waitForExistence(timeout: 15))
      capture("The unfiltered native catalog begins at Item 00001")
      contents.swipeUp()
      XCTAssertFalse(first.isHittable)
      scrollToEnd(true, contents: contents, application: application)
      let last = application.savedPlannerItemRows("Scale Item 05000").firstMatch
      let hierarchy = XCTAttachment(string: application.debugDescription)
      hierarchy.name = "Unfiltered native catalog after scrolling toward its end"
      hierarchy.lifetime = .keepAlways
      add(hierarchy)
      XCTAssertTrue(last.waitForExistence(timeout: 30))
      XCTAssertTrue(last.isHittable)
      let lastIdentifier = last.identifier
      capture("The unfiltered native catalog reaches Item 05000 without search")
      last.activateForPlannerJourney()
      XCTAssertTrue(
        application.staticTexts["Far-end collection marker"].waitForExistence(timeout: 10))
      let completion = application.descendants(matching: .any).matching(
        identifier: "saved.item.completion"
      ).firstMatch
      XCTAssertTrue(completion.waitForPlannerBooleanState(false))
      revealCatalog(application, contents: contents)
      scrollToEnd(false, contents: contents, application: application)
      XCTAssertTrue(first.waitForExistence(timeout: 30))
      XCTAssertTrue(first.isHittable)
      XCTAssertEqual(first.identifier, firstIdentifier)
      capture("Returning to the beginning retains the first source identity")
      scrollToEnd(true, contents: contents, application: application)
      XCTAssertTrue(last.waitForExistence(timeout: 30))
      XCTAssertTrue(last.isHittable)
      XCTAssertEqual(last.identifier, lastIdentifier)
      last.activateForPlannerJourney()
      XCTAssertTrue(
        application.staticTexts["Far-end collection marker"].waitForExistence(timeout: 10))
      XCTAssertTrue(completion.waitForPlannerBooleanState(false))
      let identities = XCTAttachment(
        string: "First source: \(firstIdentifier)\nLast source: \(lastIdentifier)")
      identities.name = "Unfiltered catalog observed endpoint identities"
      identities.lifetime = .keepAlways
      add(identities)
      capture("The far-end source reopens with the same notes and Todo state")
    }

    private func scrollToEnd(
      _ towardEnd: Bool, contents: XCUIElement, application: XCUIApplication
    ) {
      let hierarchy = XCTAttachment(string: application.debugDescription)
      hierarchy.name = "Native catalog hierarchy before scroll-indicator drag"
      hierarchy.lifetime = .keepAlways
      add(hierarchy)
      let indicator = contents.descendants(matching: .any).matching(
        NSPredicate(format: "label BEGINSWITH %@", "Vertical scroll bar")
      ).firstMatch
      XCTAssertTrue(indicator.waitForExistence(timeout: 10))
      let indicatorFrame = indicator.frame
      var startFraction: CGFloat = towardEnd ? 0.01 : 0.99
      if indicatorFrame.height < contents.frame.height / 2 { startFraction = 0.5 }
      let start = indicator.coordinate(
        withNormalizedOffset: .init(dx: 0.5, dy: startFraction))
      let targetY = towardEnd ? contents.frame.maxY - 1 : contents.frame.minY + 1
      let target = application.coordinate(withNormalizedOffset: .zero).withOffset(
        .init(dx: indicatorFrame.midX, dy: targetY))
      start.press(forDuration: 0.8, thenDragTo: target)
    }

    private func revealCatalog(_ application: XCUIApplication, contents: XCUIElement) {
      if contents.exists && contents.isHittable { return }
      let back = application.buttons["BackButton"].firstMatch
      if back.exists { back.activateForPlannerJourney() }
      XCTAssertTrue(contents.waitForExistence(timeout: 10))
      XCTAssertTrue(contents.isHittable)
    }

    private func capture(_ name: String) {
      let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
      attachment.name = name
      attachment.lifetime = .keepAlways
      add(attachment)
    }
  }
#endif
