import XCTest

#if os(iOS)
  @MainActor
  final class LargeCollectionScrollDiagnosticTests: XCTestCase {
    func testSelectedCatalogRowDoesNotPreventReturningToTheBeginning() throws {
      continueAfterFailure = false
      let application = XCUIApplication()
      application.launchArguments = [
        "--fixture", "large-collection", "--fixture-dataset", UUID().uuidString,
      ]
      application.launchSavedPlannerJourney()
      XCTAssertTrue(application.buttons["Items"].firstMatch.waitForExistence(timeout: 120))
      application.openPlannerSection("Items")
      let firstItem = application.savedPlannerItemRows("Scale Item 00001").firstMatch
      XCTAssertTrue(firstItem.waitForExistence(timeout: 30))
      let contents = application.collectionViews.containing(
        NSPredicate(
          format: "identifier BEGINSWITH %@ AND label BEGINSWITH %@", "saved.item.", "Scale Item ")
      ).firstMatch
      for _ in 0..<3 { contents.swipeUp(velocity: .init(rawValue: 2_500)) }
      XCTAssertFalse(firstItem.isHittable)
      let rows = contents.buttons.matching(
        NSPredicate(format: "label BEGINSWITH %@", "Scale Item "))
      let visibleRows = rows.allElementsBoundByIndex.filter(\.isHittable)
      let orderedRows = visibleRows.sorted { $0.frame.midY < $1.frame.midY }
      let selectedItem = try XCTUnwrap(orderedRows.dropFirst(orderedRows.count / 2).first)
      let selectedTitle = selectedItem.label
      print("[scroll-diagnostic] Selected source: \(selectedTitle)")
      selectedItem.activateForPlannerJourney()
      record("Selected row after activation", application: application, contents: contents)
      let selectedNumber = try XCTUnwrap(Int(selectedTitle.suffix(5)))
      XCTAssertTrue(
        application.staticTexts["Scale notes \(selectedNumber)"].waitForExistence(timeout: 10))
      let completion = application.descendants(matching: .any).matching(
        identifier: "saved.item.completion"
      ).firstMatch
      XCTAssertTrue(completion.waitForPlannerBooleanState(false))
      record("Selected row before return", application: application, contents: contents)
      for _ in 0..<10 {
        if firstItem.exists && firstItem.isHittable { break }
        contents.swipeDown(velocity: .init(rawValue: 2_500))
        record("Selected row during return", application: application, contents: contents)
      }
      XCTAssertTrue(firstItem.exists && firstItem.isHittable)
    }

    private func record(
      _ name: String, application: XCUIApplication, contents: XCUIElement
    ) {
      let rows = contents.buttons.matching(
        NSPredicate(format: "label BEGINSWITH %@", "Scale Item "))
      let visibleTitles = rows.allElementsBoundByIndex.filter(\.isHittable).map(\.label)
      print("[scroll-diagnostic] \(name): \(visibleTitles)")
      let hierarchy = XCTAttachment(string: application.debugDescription)
      hierarchy.name = name
      hierarchy.lifetime = .keepAlways
      add(hierarchy)
      let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
      screenshot.name = name
      screenshot.lifetime = .keepAlways
      add(screenshot)
    }
  }
#endif
