from pathlib import Path
import gzip
import hashlib
import json
import os
import re
import subprocess

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = Path('docs/prototypes/evidence/navigation/native-itinerary-window-compatibility')
validation = Path('docs/prototypes/evidence/navigation/native-itinerary-caption-contrast/final-validation')
packets = sorted(path for path in root.iterdir() if path.is_dir() and 'itinerary-caption-' in path.name)
assert len(packets) == 15
rows = []
comparisons = []
regression_path = 'PlannerNavigationUITests/SavedItineraryBulkJourneyTests.swift'
regression_digest = hashlib.sha256(Path(regression_path).read_bytes()).hexdigest()
expected_failures = {
    'phone-itinerary-caption-native-audit-light',
    'tablet-itinerary-caption-light-reproduction',
    'tablet-itinerary-caption-native-audit-light',
    'tablet-itinerary-caption-nested-red',
}
for packet in packets:
    result = json.loads((packet / 'exit.json').read_text())
    assert result['exitCode'] == (65 if packet.name in expected_failures else 0), packet.name
    row = {'epoch': str(packet), 'result': result}
    log = next(packet / name for name in ['test.log.gz', 'build.log.gz'] if (packet / name).is_file())
    lines = gzip.decompress(log.read_bytes()).decode(errors='replace').splitlines()
    row['observedSummary'] = [line.strip() for line in lines if re.search(r'Test Case .* (?:passed|failed) \(|\*\* TEST (?:BUILD|EXECUTE)', line)]
    rows.append(row)
    source = next(packet / name for name in ['current-source-sha256.json', 'source-sha256.json'] if (packet / name).is_file())
    hashes = json.loads(source.read_text())
    production = {name: digest for name, digest in hashes.items() if name.endswith('.swift') and (name.startswith('Planner/') or '/Sources/' in name)}
    differences = sorted(name for name, digest in production.items() if not Path(name).is_file() or hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest)
    expected = [] if '-primary-' in packet.name else ['Planner/Scenes/SavedItineraryViews.swift']
    assert len(production) == 149 and differences == expected, (packet.name, differences)
    same_regression = hashes.get(regression_path) == regression_digest
    if '-primary-' in packet.name or 'nested-' in packet.name:
        assert same_regression, packet.name
    comparisons.append({'epoch': packet.name, 'productionInputs': len(production), 'differentProductionPaths': differences, 'regressionMatchesFinalSource': same_regression})
(validation / 'observed-results.json').write_text(json.dumps(rows, indent=2) + '\n')
(validation / 'production-source-comparison.json').write_text(json.dumps(comparisons, indent=2) + '\n')
visual = json.loads((validation / 'visual-review.json').read_text())
assert len(visual['captures']) == 17
for capture in visual['captures']:
    assert hashlib.sha256(Path(capture['path']).read_bytes()).hexdigest() == capture['sha256']
reports = ['docs/prototypes/native-itinerary-caption-contrast.md', 'docs/native-ui-polish.md']
checks = [
    ('swift-lint', ['xcrun', 'swift-format', 'lint', '--strict', 'Planner/Scenes/SavedItineraryViews.swift', regression_path]),
    ('markdown-lint', ['pnpm', 'dlx', 'markdownlint-cli2', '--config', '/private/tmp/PlannerItemWindowMarkdownlint.json', *reports]),
    ('whitespace', ['git', 'diff', '--check']),
]
for name, command in checks:
    completed = subprocess.run(command, capture_output=True, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
    (validation / (name + '.json')).write_text(json.dumps({'command': command, 'exitCode': completed.returncode}, indent=2) + '\n')
    (validation / (name + '.log.gz')).write_bytes(gzip.compress(completed.stdout + completed.stderr, mtime=0))
    assert completed.returncode == 0, (name, (completed.stdout + completed.stderr).decode()[:1500])
checked_links = []
for report in reports:
    path = Path(report)
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        target = target.strip().strip('<>')
        if not target or target.startswith(('https:', 'http:', '#', 'mailto:')):
            continue
        destination = (path.parent / target.split('#', 1)[0]).resolve()
        assert destination.is_file(), (report, target)
        checked_links.append({'report': report, 'target': target})
(validation / 'local-links.json').write_text(json.dumps({'checked': len(checked_links), 'links': checked_links}, indent=2) + '\n')
(validation / 'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
paths = sorted(path for directory in [*packets, validation] for path in directory.rglob('*') if path.is_file() and path.name not in ['evidence-sha256.json', 'credential-scan.json'])
patterns = {
    'githubCredential': rb'gh[pousr]_[A-Za-z0-9]{30,}',
    'privateKey': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'openaiCredential': rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}',
}
findings = []
for path in paths:
    data = path.read_bytes()
    if path.suffix == '.gz':
        data = gzip.decompress(data)
    for name, pattern in patterns.items():
        if re.search(pattern, data):
            findings.append({'path': str(path), 'pattern': name})
(validation / 'credential-scan.json').write_text(json.dumps({'filesRead': len(paths), 'decompressedGzip': True, 'patterns': list(patterns), 'findings': findings}, indent=2) + '\n')
assert not findings, findings
paths.append(validation / 'credential-scan.json')
(validation / 'evidence-sha256.json').write_text(json.dumps({str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}, indent=2) + '\n')
print(f'Validated {len(packets)} epochs, {len(paths)} files and 17 inspected originals; affected lint, source comparisons, links and bounded credential-pattern scan pass.')
