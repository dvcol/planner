from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
validation=repository/'docs/prototypes/evidence/navigation/native-association-history-controller/final-validation'
validation.mkdir(parents=True,exist_ok=True)
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
packets=sorted(root.glob('history-controller-*'))
assert len(packets)==9
observations=[]
comparisons=[]
for packet in packets:
 result=json.loads((packet/'exit.json').read_text())
 log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode(errors='replace')
 functions=re.findall(r"Test Case '-\[PlannerMCPTests\.SavedAssociationUndoHistoryTests ([^]]+)\]' (passed|failed) \(([\d.]+) seconds\)",log)
 observations.append({'epoch':packet.name,'exitCode':result['exitCode'],'functions':[{'name':name,'result':outcome,'seconds':float(seconds)} for name,outcome,seconds in functions],'executionSummary':[line.strip() for line in log.splitlines() if 'Executed ' in line and ' test' in line][-1:]})
 hashes=json.loads((packet/'source-sha256.json').read_text())
 production={name:digest for name,digest in hashes.items() if name.endswith('.swift') and (name.startswith('Planner/') or '/Sources/' in name)}
 differences=[name for name,digest in production.items() if hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
 assert len(production)==149 and not differences
 test='PlannerMCPTests/SavedAssociationUndoHistoryTests.swift'
 comparisons.append({'epoch':packet.name,'productionInputs':len(production),'differentProductionInputs':differences,'testMatchesCurrent':hashlib.sha256((repository/test).read_bytes()).hexdigest()==hashes[test]})
final=next(entry for entry in observations if entry['epoch']=='history-controller-final-regressions')
assert final['exitCode']==0 and len(final['functions'])==5
assert all(function['result']=='passed' for function in final['functions'])
final_hashes=json.loads((root/'history-controller-final-regressions/source-sha256.json').read_text())
assert all((repository/name).is_file() and hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in final_hashes.items())
(validation/'observed-results.json').write_text(json.dumps(observations,indent=2)+'\n')
(validation/'source-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
result_bundle=json.loads((root/'history-controller-final-regressions/exit.json').read_text())['bundle']
summary=subprocess.run(['xcrun','xcresulttool','get','test-results','summary','--path',result_bundle],env=environment,capture_output=True,text=True,check=True)
summary_data=json.loads(summary.stdout)
assert summary_data['totalTestCount']==5 and summary_data['passedTests']==5 and summary_data['failedTests']==0
(validation/'test-summary.json').write_text(json.dumps(summary_data,indent=2)+'\n')
products_root=Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents')
products=[products_root/'MacOS/Planner',products_root/'MacOS/Planner.debug.dylib',products_root/'PlugIns/PlannerMCPTests.xctest/Contents/MacOS/PlannerMCPTests']
assert all(path.is_file() for path in products)
(validation/'product-sha256.json').write_text(json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in products},indent=2)+'\n')
probe='''import Foundation
final class EditedValue { var text = "Changed" }
let value = EditedValue()
let manager = UndoManager()
manager.groupsByEvent = false
manager.beginUndoGrouping()
manager.registerUndo(withTarget: value) { $0.text = "Original" }
manager.setActionName("Edit Title")
manager.endUndoGrouping()
print("Before empty group:", manager.undoActionName)
manager.beginUndoGrouping()
manager.endUndoGrouping()
print("After empty group:", manager.undoActionName)
manager.undo()
print("After one Undo:", value.text, manager.undoActionName)
'''
probe_command=['xcrun','swift','-e',probe]
probe_result=subprocess.run(probe_command,env=environment,capture_output=True,text=True,check=True)
assert probe_result.stdout=='Before empty group: Edit Title\nAfter empty group: \nAfter one Undo: Changed Edit Title\n'
(validation/'foundation-empty-group-diagnostic.json').write_text(json.dumps({'command':probe_command,'exitCode':probe_result.returncode,'stdout':probe_result.stdout,'stderr':probe_result.stderr},indent=2)+'\n')
reports=['docs/prototypes/native-association-history-controller.md','docs/native-association-history-test-contract-review.md','docs/open-decisions.md','docs/native-compound-association-undo-contract-review.md','docs/native-owned-association-undo-proposal.md']
checks=[]
commands=[['xcrun','swift-format','lint','--strict','PlannerMCPTests/SavedAssociationUndoHistoryTests.swift'],['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json',*reports],['git','diff','--check']]
for index,command in enumerate(commands):
 completed=subprocess.run(command,env=environment,capture_output=True,text=True)
 (validation/f'check-{index}.log.gz').write_bytes(gzip.compress((completed.stdout+completed.stderr).encode(),mtime=0))
 checks.append({'command':command,'exitCode':completed.returncode})
 assert completed.returncode==0,(command,completed.stdout,completed.stderr)
links=[]
for report in reports:
 for target in re.findall(r'\]\(([^)]+)\)',(repository/report).read_text()):
  if target.startswith(('https:','http:','#')):continue
  destination=(repository/report).parent.joinpath(target.split('#')[0]).resolve()
  assert destination.exists() or destination in [validation/'checks.json',validation/'evidence-sha256.json'],target
  links.append({'report':report,'target':target})
(validation/'checks.json').write_text(json.dumps({'commands':checks,'localLinksChecked':len(links),'missingLinks':[],'productionChanged':False,'targetOrConfigurationChanged':False},indent=2)+'\n')
patterns={'githubCredential':r'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}','privateKey':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','openaiCredential':r'sk-(?:proj-)?[A-Za-z0-9_-]{30,}'}
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
findings=[]
for path in files:
 data=path.read_bytes()
 if path.suffix=='.gz':data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data.decode(errors='replace')):findings.append({'path':str(path.relative_to(repository)),'pattern':name})
assert not findings
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(files),'decompressedGzip':True,'findings':findings},indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
(validation/'evidence-sha256.json').write_text(json.dumps({str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)},indent=2)+'\n')
assert all((repository/entry['report']).parent.joinpath(entry['target'].split('#')[0]).exists() for entry in links)
print('Verified nine invocations; final five functions pass; 149 production inputs unchanged;',len(files),'evidence files hashed; lint and links pass.')
