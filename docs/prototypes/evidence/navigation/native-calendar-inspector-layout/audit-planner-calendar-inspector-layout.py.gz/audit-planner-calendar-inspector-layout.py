from pathlib import Path
import hashlib,json
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-calendar-inspector-layout'
def read_json(path):return json.loads(path.read_text())
def sha256(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for epoch in ['mobile-calendar-screen-build','mac-calendar-screen-build']:
 inputs=read_json(packet/epoch/'source-sha256.json')
 assert len(inputs)==945 and all(sha256(repository/path)==digest for path,digest in inputs.items())
 assert read_json(packet/epoch/'exit.json')['exitCode']==0
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
runs={value['epoch']:value for value in read_json(packet/'historical-run-index.json')['runs']}
epoch='tablet-calendar-screen'
result=runs[epoch]
expected='PlannerNavigationUITests.SavedCalendarInspectorJourneyTests testCalendarDetailsCanHideAndReopenWithoutChangingTheSelectedSchedule'
assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
assert len(result['functions'])==1 and result['functions'][0]['function']==expected and result['functions'][0]['outcome']=='passed'
assert not result['startedWithoutCompletedOutcome']
current=read_json(packet/epoch/'current-source-sha256.json')
assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
assert all(sha256(repository/path)==digest for path,digest in current.items())
products=read_json(packet/epoch/'product-sha256.json')
assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
diagnostic=runs['tablet-calendar-visible']
assert diagnostic['exitCode']==0 and diagnostic['wholeInvocationPassed'] and diagnostic['diagnosticOnly']
assert len(diagnostic['functions'])==1 and diagnostic['functions'][0]['function']==expected and diagnostic['functions'][0]['outcome']=='passed'
assert not diagnostic['skippedLines'] and not diagnostic['startedWithoutCompletedOutcome']
visual=read_json(packet/'visual-review.json')['images']
assert len(visual)==12 and all(value['individuallyInspected'] and sha256(packet/value['path'])==value['sha256'] for value in visual)
assert len([value for value in visual if value['finalSourceInvocation'] and value['usableForVisualQualification']])==6
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
lint=read_json(packet/'affected-swift-lint.json')
review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(sha256(repository/path)==digest for path,digest in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(sha256(repository/path)==digest for path,digest in markdown['sourceSHA256'].items())
value={'compilerInputsPerPlatform':945,'frozenRuntimeInputs':469,'productsPerPlatform':6,'passingFunctions':{'tablet':1,'phone':0,'mac':0},'individuallyInspectedPNGs':12,'usableFinalSourcePNGs':6,'productionChanged':False,'scope':'Existing Calendar inspector and same selected Schedule/caption/notes through actual iPad landscape/portrait changes, hidden state after widening and visible same details after reopening. Native phone pushed navigation not qualified by this regular-width journey. Mac compiler-only; no signing, physical/account/CloudKit/Share, accessibility, performance or whole-app polish credit.'}
(packet/'evidence-audit.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
