import XCTest

#if os(iOS)
  @MainActor
  final class ContainerCatalogSortJourneyTests: XCTestCase {
    func testCatalogsRememberSeparateNativeSortsAcrossRelaunchAndDatasetChanges() {
      continueAfterFailure = false
      let application = XCUIApplication()
      let firstDataset = UUID().uuidString
      launch(application, dataset: firstDataset)
      openCatalog("Lists", application: application)
      requireOrder(
        ["Alpha plan", "Manual plan", "Missing plan", "Zulu plan"], kind: "list",
        application: application)
      let listSort = application.plannerElement("saved.lists.sort")
      XCTAssertTrue(listSort.waitForExistence(timeout: 10), application.debugDescription)
      choose("Full estimate", menu: listSort, application: application)
      requireOrder(
        ["Alpha plan", "Zulu plan", "Manual plan", "Missing plan"], kind: "list",
        application: application)
      choose("Descending", menu: listSort, application: application)
      requireOrder(
        ["Manual plan", "Zulu plan", "Alpha plan", "Missing plan"], kind: "list",
        application: application)
      capture("Lists sorted by full estimate descending with incomplete plans last")
      choose("Created", menu: listSort, application: application)
      requireOrder(
        ["Manual plan", "Missing plan", "Alpha plan", "Zulu plan"], kind: "list",
        application: application)
      XCTAssertEqual(listSort.label, "Sort: Created · Descending")
      openCatalog("Itineraries", application: application)
      let itinerarySort = application.plannerElement("saved.itineraries.sort")
      XCTAssertTrue(itinerarySort.waitForExistence(timeout: 10))
      XCTAssertEqual(itinerarySort.label, "Sort: Title · Ascending")
      choose("Full estimate", menu: itinerarySort, application: application)
      requireOrder(
        ["Alpha plan", "Zulu plan", "Manual plan", "Missing plan"], kind: "itinerary",
        application: application)
      capture("Itineraries keep their separate full estimate ascending choice")
      application.terminate()
      launch(application, dataset: firstDataset)
      openCatalog("Lists", application: application)
      XCTAssertEqual(listSort.label, "Sort: Created · Descending")
      requireOrder(
        ["Manual plan", "Missing plan", "Alpha plan", "Zulu plan"], kind: "list",
        application: application)
      openCatalog("Itineraries", application: application)
      XCTAssertEqual(itinerarySort.label, "Sort: Full estimate · Ascending")
      requireOrder(
        ["Alpha plan", "Zulu plan", "Manual plan", "Missing plan"], kind: "itinerary",
        application: application)
      application.terminate()
      launch(application, dataset: UUID().uuidString)
      for section in ["Lists", "Itineraries"] {
        openCatalog(section, application: application)
        let sort = application.plannerElement("saved.\(section.lowercased()).sort")
        XCTAssertTrue(sort.waitForExistence(timeout: 10))
        XCTAssertEqual(sort.label, "Sort: Title · Ascending")
      }
      capture("A separate local dataset starts with alphabetical catalog defaults")
      application.terminate()
      launch(application, dataset: firstDataset)
      openCatalog("Lists", application: application)
      XCTAssertEqual(listSort.label, "Sort: Created · Descending")
      openCatalog("Itineraries", application: application)
      XCTAssertEqual(itinerarySort.label, "Sort: Full estimate · Ascending")
      capture("Returning to the original dataset restores both catalog choices")
    }

    private func launch(_ application: XCUIApplication, dataset: String) {
      application.launchArguments = ["--fixture", "catalog-sorting", "--fixture-dataset", dataset]
      application.launchSavedPlannerJourney()
      XCTAssertTrue(
        application.plannerElement("saved.list.new").waitForExistence(timeout: 30),
        application.debugDescription)
    }

    private func openCatalog(_ section: String, application: XCUIApplication) {
      application.openPlannerSection(section)
      let back = application.navigationBars.buttons[section].firstMatch
      if back.exists { back.activateForPlannerJourney() }
      let identifier = section == "Lists" ? "saved.list.new" : "saved.itinerary.new"
      XCTAssertTrue(
        application.plannerElement(identifier).waitForExistence(timeout: 15),
        application.debugDescription)
    }

    private func choose(_ title: String, menu: XCUIElement, application: XCUIApplication) {
      let option = application.plannerElement(title)
      if !option.exists {
        XCTAssertTrue(menu.waitForPlannerHittability())
        menu.activateForPlannerJourney()
      }
      XCTAssertTrue(option.waitForExistence(timeout: 5), application.debugDescription)
      option.activateForPlannerJourney()
      if option.exists {
        application.navigationBars.firstMatch.coordinate(
          withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)
        ).tap()
      }
    }

    private func requireOrder(_ titles: [String], kind: String, application: XCUIApplication) {
      let prefix = kind == "list" ? "saved.list." : "saved.itinerary.row."
      let rows = titles.map { title in
        application.descendants(matching: .any).matching(
          NSPredicate(format: "identifier BEGINSWITH %@ AND label == %@", prefix, title)
        ).firstMatch
      }
      let ordered = NSPredicate { _, _ in
        rows.allSatisfy { $0.exists && $0.isHittable }
          && zip(rows, rows.dropFirst()).allSatisfy { $0.0.frame.midY < $0.1.frame.midY }
      }
      XCTAssertEqual(
        XCTWaiter.wait(
          for: [XCTNSPredicateExpectation(predicate: ordered, object: application)], timeout: 15),
        .completed, application.debugDescription)
    }

    private func capture(_ name: String) {
      let attachment = XCTAttachment(screenshot: XCUIApplication().screenshot())
      attachment.name = name
      attachment.lifetime = .keepAlways
      add(attachment)
    }
  }
#endif
