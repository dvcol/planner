from pathlib import Path
import gzip,json,re
packet=Path('docs/prototypes/evidence/navigation/native-calendar-grid-inspector-layout')
runs=[]
for directory in sorted(packet.iterdir()):
 if not directory.is_dir() or not (directory/'exit.json').is_file():continue
 exit_value=json.loads((directory/'exit.json').read_text())
 entry={'epoch':directory.name,**exit_value}
 if (directory/'source-variant.json').is_file():
  entry['diagnosticOnly']=json.loads((directory/'source-variant.json').read_text()).get('diagnosticOnly',True)
  entry['correctedSourcePassCredit']=False
  entry['sourceVariant']=json.loads((directory/'source-variant.json').read_text())
 if (directory/'test.log.gz').is_file():
  log=gzip.decompress((directory/'test.log.gz').read_bytes()).decode()
  started=re.findall(r"Test Case '-\[([^\]]+)\]' started\.",log)
  completed=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|failed) \(([\d.]+) seconds\)\.",log)
  entry.update({'type':'native-runtime','functions':[{'function':name,'outcome':outcome,'seconds':float(duration)} for name,outcome,duration in completed], 'startedWithoutCompletedOutcome':[name for name in started if name not in {row[0] for row in completed}],'timedOutFunctions':sorted(set(re.findall(r"Test Case '-\[([^\]]+)\]' exceeded execution time allowance",log))),'wholeInvocationPassed':exit_value['exitCode']==0,'skippedLines':[line for line in log.splitlines() if re.search(r'Test Case.*skipped',line)]})
 else:entry['type']='compiler-only'
 runs.append(entry)
(packet/'historical-run-index.json').write_text(json.dumps({'policy':'Literal recorded function outcomes and whole invocation exits are separate. Compiler-only and setup failures supply no native runtime pass credit. Final qualified epochs are named in the report.', 'runs':runs},indent=2)+'\n')
print('Recorded epochs',len(runs))
for run in runs:
 if run['type']=='native-runtime':print(run['epoch'],run['exitCode'],len([value for value in run['functions'] if value['outcome']=='passed']),'passes',len(run.get('timedOutFunctions',[])),'timeouts','diagnostic' if run.get('diagnosticOnly') else '')
