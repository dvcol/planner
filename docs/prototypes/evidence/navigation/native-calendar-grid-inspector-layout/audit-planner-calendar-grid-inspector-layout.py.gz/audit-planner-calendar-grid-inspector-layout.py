from pathlib import Path
import hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-calendar-grid-inspector-layout'
def read_json(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for epoch in ['mobile-grid-inspector-build','mac-grid-inspector-build']:
 inputs=read_json(packet/epoch/'source-sha256.json')
 assert len(inputs)==945 and all(digest(repository/path)==value for path,value in inputs.items())
 assert read_json(packet/epoch/'exit.json')['exitCode']==0
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(digest(Path(path))==value for path,value in products.items())
runs=read_json(packet/'historical-run-index.json')['runs']
result=next(value for value in runs if value['epoch']=='tablet-grid-inspector-qualified')
expected={'PlannerNavigationUITests.SavedCalendarInspectorJourneyTests '+name for name in ['testCalendarDetailsCanHideAndReopenWithoutChangingTheSelectedSchedule','testDayDetailsSurviveLayoutChangesWithoutChangingTheSelectedSchedule','testWeekDetailsSurviveLayoutChangesWithoutChangingTheSelectedSchedule']}
assert result['exitCode']==0 and result['wholeInvocationPassed']
assert not result['skippedLines'] and not result['startedWithoutCompletedOutcome']
assert len(result['functions'])==3 and {value['function'] for value in result['functions']}==expected
assert all(value['outcome']=='passed' and value['seconds']>0 for value in result['functions'])
epoch=packet/'tablet-grid-inspector-qualified'
inputs=read_json(epoch/'current-source-sha256.json')
assert len(inputs)==469 and inputs==read_json(epoch/'compiled-source-sha256.json')
assert all(digest(repository/path)==value for path,value in inputs.items())
products=read_json(epoch/'product-sha256.json')
assert len(products)==6 and all(digest(Path(path))==value for path,value in products.items())
visual=read_json(packet/'visual-review.json')['images']
assert len(visual)==18 and all(value['individuallyInspected'] and value['usableForVisualQualification'] and digest(packet/value['path'])==value['sha256'] for value in visual)
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
assert sorted([sum(value['mode']==mode for value in visual) for mode in ['Month','Day','Week']])==[6,6,6]
lint=read_json(packet/'affected-swift-lint.json');review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(digest(repository/path)==value for path,value in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(digest(repository/path)==value for path,value in markdown['sourceSHA256'].items())
changed=subprocess.check_output(['git','diff','--name-only','53622e55b455d0fa14d19b4dacfff64b24d77501'],text=True).splitlines()
assert not any(path.startswith(('Planner/','Packages/','Configuration/','Planner.xcodeproj/')) for path in changed)
value={'compilerInputsPerPlatform':945,'frozenRuntimeInputs':469,'productsPerPlatform':6,'passingFunctions':{'tablet':3,'phone':0,'mac':0},'individuallyInspectedPNGs':18,'productionChanged':False,'scope':'Month/Day/Week native inspector selected Schedule and captions retained across actual iPad rotations, hidden state after widening and usable selected entry when inspector is hidden. Mac compiler-only. No phone, Mac runtime, midnight/month-boundary execution, physical, signing, accessibility, measured performance or whole-app polish credit.'}
(packet/'evidence-audit.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
