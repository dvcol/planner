import Foundation
import MapKit

for path in CommandLine.arguments.dropFirst() {
  let data = try Data(contentsOf: URL(fileURLWithPath: path))
  let info = try PropertyListSerialization.propertyList(from: data, format: nil) as! [String: Any]
  let extensionInfo = info["NSExtension"] as! [String: Any]
  let attributes = extensionInfo["NSExtensionAttributes"] as! [String: Any]
  let predicate = NSPredicate(format: attributes["NSExtensionActivationRule"] as! String)
  for (registeredTypes, expected) in [
    (["public.url"], true), (["public.utf8-plain-text"], true),
    ([MKMapItemTypeIdentifier], true), (["public.png"], false), ([], false)
  ] {
    let request = ["extensionItems": [["attachments": [["registeredTypeIdentifiers": registeredTypes]]]]]
    precondition(predicate.evaluate(with: request) == expected, "Unexpected activation for \(registeredTypes)")
  }
  print(URL(fileURLWithPath: path).lastPathComponent, "activation: URL/text/Maps accepted, unsupported/empty rejected")
}
