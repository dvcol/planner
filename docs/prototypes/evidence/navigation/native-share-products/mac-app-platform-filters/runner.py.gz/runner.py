from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform,scheme=sys.argv[1:]
assert platform in ['mobile','mac'] and scheme in ['Planner','PlannerShareMobile','PlannerShareMac']
packet=repository/'docs/prototypes/evidence/navigation/native-share-products'/phase
packet.mkdir(parents=True,exist_ok=False)
paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard'],text=True).splitlines()
inputs=sorted(set(path for path in paths if path.startswith(('Planner/','PlannerShareMobile/','PlannerShareMac/','Packages/','Configuration/','Planner.xcodeproj/')) and path.endswith(('.swift','.pbxproj','.xcscheme','.xcconfig','.plist','.entitlements','.resolved'))))
hashes={path:hashlib.sha256((repository/path).read_bytes()).hexdigest() for path in inputs}
(packet/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
derived=Path('/private/tmp/PlannerShareProducts-'+platform)
destination='generic/platform=iOS Simulator' if platform=='mobile' else 'platform=macOS,arch=arm64'
command=['xcodebuild','build','-project','Planner.xcodeproj','-scheme',scheme,'-destination',destination,'-derivedDataPath',str(derived),'-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-jobs','1','CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerShareProducts-'+phase+'.log')
with log.open('wb') as output:
 result=subprocess.run(command,cwd=repository,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'runtimeCredit':False},indent=2)+'\n')
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
print(phase,'exit',result.returncode)
for line in log.read_text().splitlines():
 if line.startswith(('** BUILD','error:')) or ('.swift:' in line and ': error:' in line):print(line[:1100])
if result.returncode==0:
 products={str(path.relative_to(derived)):hashlib.sha256(path.read_bytes()).hexdigest() for path in (derived/'Build/Products').rglob('*') if path.is_file() and path.name in ['Info.plist','Planner','PlannerShareMobile','PlannerShareMac']}
 (packet/'products-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
 installed=[]
 for application in (derived/'Build/Products').glob('Debug*/Planner.app'):
  installed.extend(str(path.relative_to(application)) for path in application.rglob('*.appex'))
 (packet/'embedded-extensions.json').write_text(json.dumps(installed,indent=2)+'\n')
raise SystemExit(result.returncode)
