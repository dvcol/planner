from pathlib import Path
from urllib.parse import urlsplit
import collections
import gzip
import hashlib
import json
import re
import subprocess

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
prefix = workspace / 'docs/prototypes/evidence/navigation'
mac = prefix / 'core-native-import-declared-full-graph-class-mac'
mobile = prefix / 'core-native-import-declared-full-graph-class-ios'
mac_report = json.loads((mac / 'execution.json').read_text())
mobile_report = json.loads((mobile / 'execution.json').read_text())
mac_log = gzip.decompress((mac / 'test.log.gz').read_bytes()).decode()
parameter_counts = collections.Counter(re.findall(r'^◇ Test case passing .+ to (\S+) started\.$', mac_log, re.MULTILINE))
mac_functions = sorted((case['className'].removeprefix('PlannerCoreStoreTests.'), case['name'], parameter_counts.get(case['name'], 1)) for case in mac_report['cases'])

def nodes(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from nodes(child)

native_nodes = list(nodes(json.loads(gzip.decompress((mobile / 'test-results-tests.json.gz').read_bytes()))))
native_cases = [node for node in native_nodes if node.get('nodeType') == 'Test Case']
assert all(node['result'] == 'Passed' for node in native_nodes if node.get('nodeType') in ['Test Case', 'Arguments'])
mobile_functions = sorted((urlsplit(case['nodeIdentifierURL']).path.split('/')[-2], case['name'], max(1, sum(child.get('nodeType') == 'Arguments' for child in case.get('children', [])))) for case in native_cases)
assert mac_functions == mobile_functions
assert len(mac_functions) == 4
assert sum(record[2] for record in mac_functions) == 10
assert mac_report['exitCode'] == mobile_report['exitCode'] == 0
assert mac_report['frozenInputsUnchanged'] and mobile_report['frozenInputsUnchanged']
assert mac_report['sqliteUnlinkWarnings'] == mobile_report['sqliteUnlinkWarnings'] == 0
mac_inputs = json.loads((mac / 'source-sha256.json').read_text())
mobile_inputs = json.loads((mobile / 'source-sha256.json').read_text())
assert len(mac_inputs) == 740
for relative, digest in mac_inputs.items():
    assert hashlib.sha256((workspace / relative).read_bytes()).hexdigest() == digest, relative
    assert mobile_inputs[relative] == digest, relative
for relative, digest in mobile_inputs.items():
    assert hashlib.sha256((workspace / relative).read_bytes()).hexdigest() == digest, relative
products = {}
for candidate in Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products').rglob('*'):
    if not candidate.is_file():
        continue
    if candidate.name in ['PlannerCore', 'PlannerCoreTests', 'PlannerCoreStoreTests'] or candidate.name.endswith('.xctestrun'):
        products[str(candidate)] = hashlib.sha256(candidate.read_bytes()).hexdigest()
assert products
(mobile / 'product-sha256.json').write_text(json.dumps(products, indent=2) + '\n')
for product, digest in json.loads((mac / 'product-sha256.json').read_text()).items():
    assert hashlib.sha256(Path(product).read_bytes()).hexdigest() == digest
for packet in [mac, mobile]:
    cleanup = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert cleanup['success'] and len(cleanup['removedDirectories']) == 10, packet
report = {'coreInputsMatched': len(mac_inputs), 'nativeInputsMatched': len(mobile_inputs), 'functionsMatched': len(mac_functions), 'invocationsPerPlatform': sum(record[2] for record in mac_functions), 'functions': [{'className': class_name, 'name': function, 'invocations': count} for class_name, function, count in mac_functions], 'productHashesVerified': True, 'sqliteUnlinkWarningsPerPlatform': 0, 'removedFixturesPerPlatform': 10, 'nativeUIOrPhysicalCredit': False}
production_inputs = {name: digest for name, digest in mac_inputs.items() if name.startswith('Packages/PlannerCore/Sources/') or name == 'Packages/PlannerCore/Package.swift'}
for name, digest in production_inputs.items():
    original = subprocess.check_output(['git', 'show', 'b69f40f7:' + name])
    assert hashlib.sha256(original).hexdigest() == digest, name
report['unchangedProductionInputs'] = len(production_inputs)
report['productionBaseline'] = subprocess.check_output(['git', 'rev-parse', 'b69f40f7'], text=True).strip()
(mac / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
(mac / 'qualification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({key: value for key, value in report.items() if key != 'functions'}))
