from pathlib import Path
import gzip
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ElementTree

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
phase, selected = sys.argv[1:3]
root = Path('/private/tmp/PlannerImportLifetimeAuditSource')
packet = workspace / 'docs/prototypes/evidence/navigation' / phase
packet.mkdir(exist_ok=False)
tracked = subprocess.check_output(['git', 'ls-files', 'Packages/PlannerCore'], text=True).splitlines()
changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'Packages/PlannerCore'], text=True).splitlines()
added = [name for name in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines() if name.startswith('Packages/PlannerCore/')]
for name in changed + added:
    (root / name).parent.mkdir(parents=True, exist_ok=True)
    (root / name).write_bytes((workspace / name).read_bytes())
    (packet / (Path(name).name + '.gz')).write_bytes(gzip.compress((workspace / name).read_bytes(), mtime=0))
baseline_path = 'Packages/PlannerCore/Sources/PlannerCore/PlannerImportReview.swift'
if phase in ['core-native-import-live-lifetime-matrix-red', 'core-native-import-live-lifetime-matrix-qualified-red', 'core-native-import-live-lifetime-independent-red']:
    (root / baseline_path).write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + baseline_path]))
    (packet / 'PlannerImportReview.swift.gz').write_bytes(gzip.compress((root / baseline_path).read_bytes(), mtime=0))
    (packet / 'baseline-production.json').write_text(json.dumps({'file': baseline_path, 'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}, indent=2) + '\n')
manifest = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(set(tracked + added))}
differences = [name for name in manifest if (root / name).read_bytes() != (workspace / name).read_bytes()]
assert differences == ([baseline_path] if phase in ['core-native-import-live-lifetime-matrix-red', 'core-native-import-live-lifetime-matrix-qualified-red', 'core-native-import-live-lifetime-independent-red'] else []), differences
(packet / 'source-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root': str(root), 'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'overlays': changed + added}, indent=2) + '\n')
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
result_path = Path('/private/tmp/PlannerImportLifetime-' + phase + '.xml')
command = ['xcrun', 'swift', 'test', '--package-path', str(root / 'Packages/PlannerCore'), '--scratch-path', '/private/tmp/PlannerImportLifetimeAuditBuild', '--jobs', '1', '--disable-xctest', '--enable-swift-testing', '--filter', selected, '--xunit-output', str(result_path)]
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerImportLifetime-' + phase + '.log')
started = time.monotonic()
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    timed_out = False
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
unchanged = all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
cases = []
if result_path.is_file():
    (packet / 'test-results.xml').write_bytes(result_path.read_bytes())
    for case in ElementTree.fromstring(result_path.read_bytes()).iter('testcase'):
        cases.append({'name': case.attrib['name'], 'className': case.attrib.get('classname'), 'seconds': float(case.attrib.get('time', '0')), 'failures': [failure.attrib.get('message') for failure in case.findall('failure')], 'skipped': case.find('skipped') is not None})
products = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in Path('/private/tmp/PlannerImportLifetimeAuditBuild/out/Products/Debug').rglob('*') if path.is_file() and path.name in ['PlannerCoreTests', 'PlannerCoreStoreTests'] and path.parent.name == 'MacOS'}
(packet / 'product-sha256.json').write_text(json.dumps(products, indent=2) + '\n')
report = {'exitCode': code, 'runnerTimedOut': timed_out, 'elapsedSeconds': round(time.monotonic() - started, 3), 'frozenInputsUnchanged': unchanged, 'cases': cases}
(packet / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
for line in log.read_text(errors='replace').splitlines():
    if 'error:' in line or 'recorded an issue' in line or 'failed after' in line or 'Test run with' in line:
        print(line[:1500])
raise SystemExit(code)
