from pathlib import Path
import gzip,hashlib,json,re,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-schedule-clock-input'
def read_json(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
runs=read_json(packet/'historical-run-index.json')['runs']
assert len(runs)==8
indexed={value['epoch']:value for value in runs}
expected=[('tablet-clock-controls',0,'passed',35.905),('tablet-clock-time-controls',0,'passed',36.568),('tablet-clock-occurrence-red',65,'failed',40.831),('tablet-clock-occurrence-numeric',65,'failed',44.581)]
for name,exit_code,outcome,seconds in expected:
 value=indexed[name]
 assert value['exitCode']==exit_code and len(value['functions'])==1
 assert value['functions'][0]['outcome']==outcome and value['functions'][0]['seconds']==seconds
 raw=gzip.decompress((packet/name/'test.log.gz').read_bytes()).decode()
 observed=[{'function':function,'outcome':result,'seconds':float(duration)} for function,result,duration in re.findall(r"Test Case '-\[([^\]]+)\]' (passed|failed) \(([\d.]+) seconds\)\.",raw)]
 assert observed==value['functions']
 assert read_json(packet/name/'exit.json')['exitCode']==value['exitCode']
 assert [line for line in raw.splitlines() if ': error:' in line]==value['errors']
final=packet/'tablet-clock-occurrence-numeric'
requirement_errors=[line for line in indexed[final.name]['errors'] if 'SavedItemJourneyTests.swift:' in line]
assert len(requirement_errors)==1
assert 'XCTAssertFalse failed - A new repeated start' in requirement_errors[0]
assert 'Requested adjust to value' in indexed['tablet-clock-occurrence-red']['errors'][0]
source_path='PlannerNavigationUITests/SavedItemJourneyTests.swift'
for name in ['mobile-clock-occurrence-numeric-build','tablet-clock-occurrence-numeric']:
 epoch=packet/name
 hashes=read_json(epoch/('source-sha256.json' if name.startswith('mobile') else 'current-source-sha256.json'))
 assert len(hashes)==(945 if name.startswith('mobile') else 469)
 expected_source=gzip.decompress((epoch/('SavedItemJourneyTests.swift.gz' if name.startswith('mobile') else 'diagnostic-test-source.swift.gz')).read_bytes())
 assert hashlib.sha256(expected_source).hexdigest()==hashes[source_path]
 assert all(digest(repository/path)==value for path,value in hashes.items() if path!=source_path)
 products=read_json(epoch/'product-sha256.json')
 assert len(products)==6 and all(digest(Path(path))==value for path,value in products.items())
assert read_json(final/'current-source-sha256.json')==read_json(final/'compiled-source-sha256.json')
assert (repository/source_path).read_bytes()==subprocess.check_output(['git','show','7832898c1ac7bb93be1796ad061560c868631f19:'+source_path])
assert not subprocess.check_output(['git','diff','--name-only','7832898c1ac7bb93be1796ad061560c868631f19','--','Planner','Packages','Configuration','Planner.xcodeproj','PlannerNavigationUITests'],text=True).strip()
visual=read_json(packet/'visual-review.json')['images']
assert len(visual)==3 and all(value['individuallyInspected'] and digest(packet/value['path'])==value['sha256'] for value in visual)
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
hierarchy=gzip.decompress((final/'A93F4AF1-4A41-4A0E-A747-F67FA73CA707.txt.gz').read_bytes()).decode()
assert 'value: 01:30, 1 Nov 2026' in hierarchy and 'Time zone, America/New_York' in hierarchy
facts=read_json(packet/'foundation-probe-index.json')['files']
assert all(hashlib.sha256(gzip.decompress((packet/value['packetPath']).read_bytes())).hexdigest()==value['sourceSHA256'] for value in facts)
primary=gzip.decompress((packet/'PlannerNativeScheduleTimeProbe.log.gz').read_bytes()).decode()
assert 'expected last=2026-04-04T15:15:00Z; matches expectation=false' in primary
review=read_json(packet/'source-review.json')
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
assert digest(repository/'docs/native-schedule-time-input-contract-review.md')==review['contractSHA256']
lint=read_json(packet/'diagnostic-swift-lint.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==hashlib.sha256(gzip.decompress((final/'diagnostic-test-source.swift.gz').read_bytes())).hexdigest()
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(digest(repository/path)==value for path,value in markdown['sourceSHA256'].items())
value={'historicalEpochs':8,'nativeControlDiagnosticPasses':2,'controllerFailures':1,'reproducedNativeRequirementFailures':1,'passingDSTImplementationTests':0,'productionChanged':False,'newUnitSeamTestsWritten':False,'restoredCommittedUITestSource':True,'finalCompilerInputs':945,'finalFrozenRuntimeInputs':469,'productsRechecked':6,'individuallyInspectedPNGs':3,'scope':'Current iPad native form enablesSave on observed NewYork1November202601:30 without explicit occurrence choice. NoSchedule submitted. MacFoundation observations separate. No production fix, gap-native proof, new model, phone/MacUI, signing, physical or whole-app polish qualification.'}
(packet/'evidence-audit.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
