import Foundation

/** Throwaway follow-up: inspect the observed half-hour repeat, not Planner behavior. */
let parser = ISO8601DateFormatter()
let earlier = parser.date(from: "2026-04-04T14:45:00Z")!
let later = parser.date(from: "2026-04-04T15:15:00Z")!
let timeZone = TimeZone(identifier: "Australia/Lord_Howe")!
var calendar = Calendar(identifier: .gregorian)
calendar.timeZone = timeZone
let requestedComponents = DateComponents(year: 2026, month: 4, day: 5, hour: 1, minute: 45, second: 0)
let transition = timeZone.nextDaylightSavingTimeTransition(after: earlier)
for instant in [earlier, later] {
  print("candidate \(parser.string(from: instant)); UTC offset seconds=\(timeZone.secondsFromGMT(for: instant)); matches requested civil fields=\(calendar.date(instant, matchesComponents: requestedComponents))")
  precondition(calendar.date(instant, matchesComponents: requestedComponents))
}
print("distinct candidates elapsed seconds=\(later.timeIntervalSince(earlier)); transition=\(transition.map { parser.string(from: $0) } ?? "nil")")
precondition(later.timeIntervalSince(earlier) == 1800)
if let transition {
  print("offset before transition=\(timeZone.secondsFromGMT(for: transition.addingTimeInterval(-1))); after transition=\(timeZone.secondsFromGMT(for: transition))")
}
for anchor in [earlier.addingTimeInterval(1), later.addingTimeInterval(3600)] {
  for direction in [Calendar.SearchDirection.forward, .backward] {
    for occurrence in [Calendar.RepeatedTimePolicy.first, .last] {
      let result = calendar.nextDate(after: anchor, matching: requestedComponents, matchingPolicy: .strict, repeatedTimePolicy: occurrence, direction: direction)
      print("anchor=\(parser.string(from: anchor)); direction=\(direction); occurrence=\(occurrence); result=\(result.map { parser.string(from: $0) } ?? "nil")")
    }
  }
}

let anchor = earlier.addingTimeInterval(-86400)
for occurrence in [Calendar.RepeatedTimePolicy.first, .last] {
  calendar.enumerateDates(startingAfter: anchor, matching: requestedComponents, matchingPolicy: .strict, repeatedTimePolicy: occurrence) { result, exact, stop in
    print("Calendar.enumerateDates policy=\(occurrence); result=\(result.map { parser.string(from: $0) } ?? "nil"); exact=\(exact)")
    stop = true
  }
}
let referenceCalendar = NSCalendar(identifier: .gregorian)!
referenceCalendar.timeZone = timeZone
for options in [NSCalendar.Options([.matchStrictly, .matchFirst]), NSCalendar.Options([.matchStrictly, .matchLast])] {
  let result = referenceCalendar.nextDate(after: anchor, matching: requestedComponents, options: options)
  print("NSCalendar.nextDate options=\(options.rawValue); result=\(result.map { parser.string(from: $0) } ?? "nil")")
  referenceCalendar.enumerateDates(startingAfter: anchor, matching: requestedComponents, options: options) { result, exact, stop in
    print("NSCalendar.enumerateDates options=\(options.rawValue); result=\(result.map { parser.string(from: $0) } ?? "nil"); exact=\(exact)")
    stop.pointee = true
  }
}
var neutralCalendar = Calendar(identifier: .gregorian)
neutralCalendar.timeZone = .gmt
let earlierFields = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: earlier)
let laterFields = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: later)
let earlierCarrier = neutralCalendar.date(from: earlierFields)!
let laterCarrier = neutralCalendar.date(from: laterFields)!
print("Earlier/later occurrences become same neutral civil-field carrier=\(earlierCarrier == laterCarrier); carrier=\(parser.string(from: earlierCarrier))")
precondition(earlierCarrier == laterCarrier)
print("Supplement completed four Foundation-only assertions; observational calls above are not pass/fail qualification of Planner.")
