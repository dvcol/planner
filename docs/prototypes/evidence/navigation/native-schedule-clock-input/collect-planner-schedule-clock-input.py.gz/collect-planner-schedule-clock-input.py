from pathlib import Path
import gzip,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/navigation/native-schedule-clock-input'
epoch=packet/phase
value=json.loads((epoch/'exit.json').read_text())
output=Path('/private/tmp/PlannerScheduleClockInputAttachments-'+phase)
result=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',value['bundle'],'--output-path',str(output)],capture_output=True,text=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
assert result.returncode==0,result.stderr
captures=[]
for group in json.loads((output/'manifest.json').read_text()):
 for attachment in group['attachments']:
  name=attachment['exportedFileName'];title=attachment['suggestedHumanReadableName']
  if title.startswith(('Native timed input','Native repeated-date input','Native repeated-time input')):
   if name.endswith('.txt'):(epoch/(name+'.gz')).write_bytes(gzip.compress((output/name).read_bytes(),mtime=0))
   elif name.endswith('.png'):shutil.copy2(output/name,epoch/name)
   else:continue
   captures.append({**attachment,'testIdentifier':group['testIdentifier']})
(epoch/'selected-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
source=repository/'PlannerNavigationUITests/SavedItemJourneyTests.swift'
(epoch/'diagnostic-test-source.swift.gz').write_bytes(gzip.compress(source.read_bytes(),mtime=0))
source.write_bytes(Path('/private/tmp/PlannerSavedItemJourneyBeforeClockProbe.swift').read_bytes())
assert source.read_bytes()==subprocess.check_output(['git','show','HEAD:PlannerNavigationUITests/SavedItemJourneyTests.swift'])
print('Original source restored after terminal runtime')
for capture in captures:print(capture['exportedFileName'],capture['suggestedHumanReadableName'])
