import Foundation

/** Throwaway Foundation API probe. This imports no Planner module and executes no app code. */
struct ScheduleTimeProbeFixture {
  let name: String
  let timeZoneIdentifier: String
  let components: DateComponents
  let expectedFirst: String?
  let expectedLast: String?
}

func probeCalendar(timeZoneIdentifier: String) -> Calendar {
  var calendar = Calendar(identifier: .gregorian)
  calendar.locale = Locale(identifier: "en_US_POSIX")
  calendar.timeZone = TimeZone(identifier: timeZoneIdentifier)!
  return calendar
}

func probeISODescription(_ date: Date?) -> String {
  guard let date else { return "nil" }
  let formatter = ISO8601DateFormatter()
  formatter.timeZone = .gmt
  return formatter.string(from: date)
}

func probeLocalDescription(_ date: Date?, calendar: Calendar) -> String {
  guard let date else { return "nil" }
  let formatter = DateFormatter()
  formatter.calendar = calendar
  formatter.locale = Locale(identifier: "en_US_POSIX")
  formatter.timeZone = calendar.timeZone
  formatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZZZ"
  return formatter.string(from: date)
}

let fixtures: [ScheduleTimeProbeFixture] = [
  .init(name: "ordinary Tokyo", timeZoneIdentifier: "Asia/Tokyo",
    components: DateComponents(year: 2026, month: 10, day: 9, hour: 10, minute: 0, second: 0),
    expectedFirst: "2026-10-09T01:00:00Z", expectedLast: "2026-10-09T01:00:00Z"),
  .init(name: "New York gap", timeZoneIdentifier: "America/New_York",
    components: DateComponents(year: 2026, month: 3, day: 8, hour: 2, minute: 30, second: 0),
    expectedFirst: nil, expectedLast: nil),
  .init(name: "New York repeat", timeZoneIdentifier: "America/New_York",
    components: DateComponents(year: 2026, month: 11, day: 1, hour: 1, minute: 30, second: 0),
    expectedFirst: "2026-11-01T05:30:00Z", expectedLast: "2026-11-01T06:30:00Z"),
  .init(name: "Lord Howe half-hour gap", timeZoneIdentifier: "Australia/Lord_Howe",
    components: DateComponents(year: 2026, month: 10, day: 4, hour: 2, minute: 15, second: 0),
    expectedFirst: nil, expectedLast: nil),
  .init(name: "Lord Howe half-hour repeat", timeZoneIdentifier: "Australia/Lord_Howe",
    components: DateComponents(year: 2026, month: 4, day: 5, hour: 1, minute: 45, second: 0),
    expectedFirst: "2026-04-04T14:45:00Z", expectedLast: "2026-04-04T15:15:00Z"),
  .init(name: "Apia skipped civil day", timeZoneIdentifier: "Pacific/Apia",
    components: DateComponents(year: 2011, month: 12, day: 30, hour: 12, minute: 0, second: 0),
    expectedFirst: nil, expectedLast: nil),
]

let neutralCalendar = probeCalendar(timeZoneIdentifier: "GMT")
var successfulChecks = 0
print("THROWAWAY FOUNDATION PROBE. No Planner imports, app production interfaces, stores, UI or settings.")
print("Runtime: \(ProcessInfo.processInfo.operatingSystemVersionString); time zone data: \(TimeZone.timeZoneDataVersion)")
for fixture in fixtures {
  let calendar = probeCalendar(timeZoneIdentifier: fixture.timeZoneIdentifier)
  let anchor = neutralCalendar.date(from: fixture.components)!.addingTimeInterval(-172_800)
  let first = calendar.nextDate(after: anchor, matching: fixture.components,
    matchingPolicy: .strict, repeatedTimePolicy: .first, direction: .forward)
  let last = calendar.nextDate(after: anchor, matching: fixture.components,
    matchingPolicy: .strict, repeatedTimePolicy: .last, direction: .forward)
  let defaultConstruction = calendar.date(from: fixture.components)
  let neutralDate = neutralCalendar.date(from: fixture.components)
  let neutralRoundTrip = neutralDate.map { neutralCalendar.date($0, matchesComponents: fixture.components) } ?? false
  print("\n\(fixture.name) [\(fixture.timeZoneIdentifier)]")
  print("strict first=\(probeISODescription(first)); local=\(probeLocalDescription(first, calendar: calendar))")
  print("strict last=\(probeISODescription(last)); local=\(probeLocalDescription(last, calendar: calendar))")
  print("date(from:)=\(probeISODescription(defaultConstruction)); local=\(probeLocalDescription(defaultConstruction, calendar: calendar)); exact=\(defaultConstruction.map { calendar.date($0, matchesComponents: fixture.components) } ?? false)")
  print("neutral GMT carrier=\(probeISODescription(neutralDate)); exact civil round trip=\(neutralRoundTrip)")
  print("full-component expected first=\(fixture.expectedFirst ?? "nil"); matches expectation=\(probeISODescription(first) == (fixture.expectedFirst ?? "nil"))")
  print("full-component expected last=\(fixture.expectedLast ?? "nil"); matches expectation=\(probeISODescription(last) == (fixture.expectedLast ?? "nil"))")
  let localNoon = calendar.date(from: DateComponents(year: fixture.components.year, month: fixture.components.month, day: fixture.components.day, hour: 12))!
  let dayAnchor = calendar.startOfDay(for: localNoon).addingTimeInterval(-1)
  let timeOnly = DateComponents(hour: fixture.components.hour, minute: fixture.components.minute, second: fixture.components.second)
  let timeOnlyFirst = calendar.nextDate(after: dayAnchor, matching: timeOnly, matchingPolicy: .strict, repeatedTimePolicy: .first)
  let timeOnlyLast = calendar.nextDate(after: dayAnchor, matching: timeOnly, matchingPolicy: .strict, repeatedTimePolicy: .last)
  let fullDayAnchorLast = calendar.nextDate(after: dayAnchor, matching: fixture.components, matchingPolicy: .strict, repeatedTimePolicy: .last)
  let setHourLast = calendar.date(bySettingHour: fixture.components.hour!, minute: fixture.components.minute!, second: fixture.components.second!, of: localNoon, matchingPolicy: .strict, repeatedTimePolicy: .last)
  print("local-day anchor last full=\(probeISODescription(fullDayAnchorLast)); time-only first=\(probeISODescription(timeOnlyFirst)); time-only last=\(probeISODescription(timeOnlyLast)); bySettingHour last=\(probeISODescription(setHourLast))")
  print("time-only first exact requested fields=\(timeOnlyFirst.map { calendar.date($0, matchesComponents: fixture.components) } ?? false); last exact requested fields=\(timeOnlyLast.map { calendar.date($0, matchesComponents: fixture.components) } ?? false)")
  precondition(neutralRoundTrip)
  successfulChecks += 1
  if let first, let last {
    precondition(calendar.date(first, matchesComponents: fixture.components))
    precondition(calendar.date(last, matchesComponents: fixture.components))
    print("candidate difference seconds=\(last.timeIntervalSince(first))")
    successfulChecks += 2
  }
}

let parser = ISO8601DateFormatter()
let newYorkCalendar = probeCalendar(timeZoneIdentifier: "America/New_York")
let parisCalendar = probeCalendar(timeZoneIdentifier: "Europe/Paris")
let retainedInstant = parser.date(from: "2026-11-01T06:30:00Z")!.addingTimeInterval(0.125)
let retainedNumber = retainedInstant.timeIntervalSinceReferenceDate
let retainedCivilFields = newYorkCalendar.dateComponents([.year, .month, .day, .hour, .minute], from: retainedInstant)
let minuteOnlyReconstruction = newYorkCalendar.date(from: retainedCivilFields)!
print("\nRetained later occurrence with fractional seconds")
print("stored reference seconds=\(retainedNumber); New York=\(probeLocalDescription(retainedInstant, calendar: newYorkCalendar)); Paris=\(probeLocalDescription(retainedInstant, calendar: parisCalendar))")
print("reconstructed minute-only reference seconds=\(minuteOnlyReconstruction.timeIntervalSinceReferenceDate); difference from retained=\(minuteOnlyReconstruction.timeIntervalSince(retainedInstant))")
precondition(retainedInstant.timeIntervalSinceReferenceDate == retainedNumber)
precondition(minuteOnlyReconstruction != retainedInstant)
successfulChecks += 2

let earlierStart = parser.date(from: "2026-11-01T05:45:00Z")!
let laterEnd = parser.date(from: "2026-11-01T06:15:00Z")!
let earlierEnd = parser.date(from: "2026-11-01T05:15:00Z")!
print("\nCoupled endpoints: earlier 01:45 start, later 01:15 end elapsed seconds=\(laterEnd.timeIntervalSince(earlierStart)); earlier 01:15 end elapsed seconds=\(earlierEnd.timeIntervalSince(earlierStart))")
precondition(laterEnd > earlierStart)
precondition(earlierEnd < earlierStart)
successfulChecks += 2
print("\nCompleted \(fixtures.count) civil fixtures and \(successfulChecks) Foundation-only assertions.")
