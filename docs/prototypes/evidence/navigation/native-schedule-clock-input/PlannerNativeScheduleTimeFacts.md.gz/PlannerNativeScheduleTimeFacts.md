# Native scheduling civil-time facts

Read-only repository/SDK investigation on **2026-10-17**, plus explicitly throwaway Foundation-only probes in `/private/tmp`. Repository HEAD was `7832898`. No Planner module was imported or executed by the probes. No app products, packages, settings or repository files were changed, and no app/UI tests ran.

Environment: **Xcode 27.1, build 27A9275**; **Apple Swift 6.4**, swiftlang-6.4.0.34.1; macOS SDK **27.0**; runtime **macOS 27.0.1, build 26A434**; runtime time-zone data **2026e**. Xcode was selected only through the command-scoped `DEVELOPER_DIR` environment variable.

## Existing app interfaces and accepted behavior

- `SavedScheduleForm` stores `startInstant` and `endInstant` as resolved `Date` values, initializes an existing timed entry from its exact stored values, and constructs `PlannerScheduleForm.timed` directly from those states. Validation checks only initial availability and instant ordering. Its two native `DatePicker` controls bind directly to those dates in `planningCalendar`/the planning-zone environment. There are no civil-time resolution states, gap errors or explicit occurrence controls. [Form state and initialization](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedItemScheduleViews.swift:180), [Validation/output](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedItemScheduleViews.swift:238), [Controls](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedItemScheduleViews.swift:269)
- Both Item and Itinerary sheets use that same form. The zone picker changes only the zone identifier binding. Saving currently calls `SavedPlannerStore.createSchedule` or `editSchedule`, which pass already resolved forms to Core. [Item caller](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedItemViews.swift:175), [Itinerary caller](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedItineraryViews.swift:416), [Zone binding](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedPlanningTimeZonePicker.swift:39), [Store boundary](/Users/dinh-van.colomban/Workspace/private/planner/Planner/Scenes/SavedPlannerStore.swift:456)
- Core's timed form takes `Date`/optional `Date` plus a valid zone string. It validates finite instants and `end > start`; it receives no unresolved civil date/time that could identify a rejected gap or an unchosen repeated occurrence. Core already has the distinct `changeScheduleZone` command. Its `.zone` change retains the existing start/end and replaces only the zone. [Form validation](/Users/dinh-van.colomban/Workspace/private/planner/Packages/PlannerCore/Sources/PlannerCore/PlannerScheduleValues.swift:90), [Existing zone change](/Users/dinh-van.colomban/Workspace/private/planner/Packages/PlannerCore/Sources/PlannerCore/PlannerScheduleValues.swift:172)
- Accepted Q10/Q11 require gap rejection and explicit earlier/later selection for new or changed repeated endpoints, while retaining unchanged stored occurrences. Q13 requires exact instant preservation for zone-only edits. These requirements already exist; this investigation chooses no new policy. [Accepted DST behavior](/Users/dinh-van.colomban/Workspace/private/planner/docs/itineraries-and-scheduling.md:97), [Zone-only behavior](/Users/dinh-van.colomban/Workspace/private/planner/docs/itineraries-and-scheduling.md:153)

## Documented native capabilities

SwiftUI `DatePicker` selects an absolute `Date`. The installed SwiftUI interface at lines 25920-25974 exposes `Binding<Date>` initializers, with optional date ranges and displayed components. It exposes no civil-time binding or `matchingPolicy`/`repeatedTimePolicy` parameter. Calendar and time-zone environments can be overridden around the control. [DatePicker](https://developer.apple.com/documentation/swiftui/datepicker), [Time-zone environment](https://developer.apple.com/documentation/swiftui/environmentvalues/timezone)

A Gregorian/GMT date can therefore carry civil fields for a native picker while the actual planning zone remains separate app state. The Foundation probes show exact neutral carriers for the tested gap/repeat/skipped-day fields. This establishes representation and API feasibility, **not native widget behavior**; no DatePicker interaction ran here. Two repeated occurrences map to the same neutral carrier, so that carrier alone cannot retain the selected occurrence or an original exact instant. These are consequences of converting between absolute dates and civil fields. [DateComponents](https://developer.apple.com/documentation/foundation/datecomponents), [Component extraction](https://developer.apple.com/documentation/foundation/calendar/datecomponents(_:from:))

Foundation exposes `Calendar.nextDate(after:matching:matchingPolicy:repeatedTimePolicy:direction:)`, `enumerateDates`, `.strict`, `.first`/`.last`, and `date(_:matchesComponents:)`. A strict search can travel to a later matching date when only clock fields are supplied. Complete requested civil fields and exact component checks therefore matter. `date(from:)` has no occurrence-policy argument and must not be assumed to reject a nonexistent local time. [Matching API](https://developer.apple.com/documentation/foundation/calendar/nextdate(after:matching:matchingpolicy:repeatedtimepolicy:direction:)), [Strict policy](https://developer.apple.com/documentation/foundation/calendar/matchingpolicy/strict), [Occurrence policies](https://developer.apple.com/documentation/foundation/calendar/repeatedtimepolicy), [Exact comparison](https://developer.apple.com/documentation/foundation/calendar/date(_:matchescomponents:)), [Construction](https://developer.apple.com/documentation/foundation/calendar/date(from:))

Installed SDK evidence is in `MacOSX27.0.sdk/System/Library/Frameworks/Foundation.framework/Modules/Foundation.swiftmodule/arm64e-apple-macos.swiftinterface`: matching policies at lines 2105-2137 and time-zone APIs at 12356-12360. `Foundation.framework/Headers/NSCalendar.h:585` documents first/last behavior and the default-first policy. SwiftUI's corresponding public interface contains zero `matchingPolicy` and zero `repeatedTimePolicy` mentions.

## Executed Foundation observations

The primary probe uses complete year/month/day/hour/minute/second matching with `.strict`, separately requesting `.first` and `.last`. Its search anchor is a fixture-specific GMT carrier minus 172,800 seconds; that anchor is probe setup, not a proposed production algorithm or validation limit.

| Requested civil time | Strict first / last observed | Other observed behavior |
| --- | --- | --- |
| Tokyo 2026-10-09 10:00 | Both `2026-10-09T01:00:00Z` | Ordinary single candidate. |
| New York 2026-03-08 02:30 | Both nil | `date(from:)` returns `07:30Z`, which is **03:30 -04:00**, not the requested time. |
| New York 2026-11-01 01:30 | `05:30Z` / `06:30Z` | Both round-trip exactly, with offsets -04:00/-05:00; 3,600 seconds apart. |
| Lord Howe 2026-10-04 02:15 | Both nil | `date(from:)` returns `2026-10-03T15:45Z`, which is **02:45 +11:00**. |
| Lord Howe 2026-04-05 01:45 | **Both `2026-04-04T14:45Z`** | `.last` does not expose the later occurrence on this tested runtime. |
| Apia 2011-12-30 12:00 | Both nil | `date(from:)` substitutes 31 December noon, a different civil day. |

For the New York gap, time-only strict matching returns **9 March 02:30**, rather than nil. Lord Howe's time-only gap search similarly returns the next day. Their full civil round-trip checks fail. This is why an existing later match is not proof that the originally entered civil date/time exists.

The supplement independently starts from **Lord Howe `14:45Z` and `15:15Z`**. Both round-trip exactly to **5 April 01:45**. Their offsets are **39,600 / 37,800 seconds**, respectively. `TimeZone.nextDaylightSavingTimeTransition(after:)` reports **15:00Z**, with the observed offset decreasing by **1,800 seconds**. Nevertheless, `Calendar.enumerateDates`, `NSCalendar.nextDate` and `NSCalendar.enumerateDates` all return `14:45Z` for both first/last policies. Alternative local-day anchors, time-only matching and `date(bySettingHour:...)` did not expose `15:15Z`. These results establish a limit of these invocations on this runtime, not universal Foundation/iOS behavior.

The transition API is documented for daylight-saving transitions and may return nil when the zone does not observe DST. These observations do not establish a complete algorithm for every political/historical offset change, or justify adding a fixed offset or one-hour correction. [Transition API and limits](https://developer.apple.com/documentation/foundation/timezone/nextdaylightsavingtimetransition(after:)), [Offset at an instant](https://developer.apple.com/documentation/foundation/timezone/secondsfromgmt(for:))

Exact-retention probe: an existing later New York occurrence at reference seconds **815207400.125** displays 01:30 -05:00 in New York and 07:30 +01:00 in Paris without changing its value. Reconstructing it from minute-only New York civil fields instead gives **815203800.0**, losing the later occurrence and 0.125 seconds. Keeping an existing exact `Date` avoids this lossy reconstruction. Actual untouched-picker and zone-change binding behavior remains a native UI question.

The coupled endpoint fixture also confirms that earlier 01:45 `05:45Z` to later 01:15 `06:15Z` is a valid **1,800-second** span, whereas earlier 01:15 `05:15Z` is before that start. Wall-clock ordering cannot replace resolved-instant ordering.

## Commands, raw files and qualification limits

The initial asserting probe, retained as `/private/tmp/PlannerNativeScheduleTimeProbe.initial.swift`, stopped at its expected-last assertion. Buffered stdout was empty. The subsequent diagnostic source retains the Lord Howe mismatch explicitly rather than calling it a passing result. The final primary run completes six civil fixtures and 16 narrower Foundation-only assertions; the supplement completes four. They are API observations, not production-interface tests.

```sh
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcodebuild -version
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun --sdk macosx --show-sdk-version
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun swiftc --version
sw_vers
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun --sdk macosx swiftc -module-cache-path /private/tmp/PlannerNativeScheduleTimeProbeModuleCache /private/tmp/PlannerNativeScheduleTimeProbe.swift -o /private/tmp/PlannerNativeScheduleTimeProbe
/private/tmp/PlannerNativeScheduleTimeProbe > /private/tmp/PlannerNativeScheduleTimeProbe.log
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun --sdk macosx swiftc -module-cache-path /private/tmp/PlannerNativeScheduleTimeProbeModuleCache /private/tmp/PlannerNativeScheduleRepeatSupplement.swift -o /private/tmp/PlannerNativeScheduleRepeatSupplement
/private/tmp/PlannerNativeScheduleRepeatSupplement > /private/tmp/PlannerNativeScheduleRepeatSupplement.log
```

Final primary/supplement compilations and separate executions returned **exit 0**. Raw output is preserved in the two `.log` files above; the primary log explicitly reports the failed Lord Howe expected-last comparison. The informational `xcodebuild -version` emitted cache/event-stream diagnostics but reported its version. No project build or test was requested.

SHA-256:

| Artifact | Hash |
| --- | --- |
| Final primary source | `3fdb46a5e52272d2c4fa98a42b88bc54fad72634324473f0736233990b372212` |
| Final primary log | `00f15c64c1a997ebe41ae15ec6b06392569161c47771788085e35d6595e5585b` |
| Supplement source | `7319aac6061f320b9eab6494a532bd8ea8d584d12264a49fd0e96a36b8d63bf1` |
| Supplement log | `139dae00e41d7a400017bb22ae1febbf749438cf93cbb4db81a83414c024572d` |
| Inspected `SavedItemScheduleViews.swift` | `437d5aa84ca9c1804d7abf840ad40fca54ad3645f3714ae62ef5aed1036c88e6` |

## Existing test hosts if an app-internal interface is proposed

`PlannerMCPTests` is an existing **macOS app-hosted unit-test target**, with `TEST_HOST`/`BUNDLE_LOADER` pointing at Planner.app and Swift Testing files using `@testable import Planner`. It can exercise a real app-internal resolver/draft interface if such an interface is deliberately introduced. Current private computed form properties are not an accessible resolver contract. The target is Mac-only; it supplies no iOS widget evidence. [Host configuration](/Users/dinh-van.colomban/Workspace/private/planner/Configuration/PlannerMCPTests.xcconfig:5), [Existing testable import](/Users/dinh-van.colomban/Workspace/private/planner/PlannerMCPTests/CalendarWindowRoutingTests.swift:5)

Core's existing store tests cover resolved instant/zone persistence and guards, including `ScheduleZoneTests`; those inputs cannot prove rejection of unresolved civil fields that the Core API does not receive. `PlannerNavigationUITests` already hosts real schedule/date-picker journeys on its supported native platforms, so native entry, Save disabled/error, explicit occurrence selection, Cancel, unchanged exact dates and zone-only edits remain UI qualification work. No new test-only injection seam, package or test boundary is selected by this note. [Core zone tests](/Users/dinh-van.colomban/Workspace/private/planner/Packages/PlannerCore/Tests/PlannerCoreStoreTests/ScheduleZoneTests.swift:5), [Native schedule journey](/Users/dinh-van.colomban/Workspace/private/planner/PlannerNavigationUITests/SavedCalendarJourneyTests.swift:5)
