import XCTest

#if os(iOS)
  import UIKit

  @MainActor
  final class ListWindowJourneyTests: XCTestCase {
    func testListCrossesPagesRevisitsMembershipsAndKeepsLocalCompletionAfterRelaunch() {
      continueAfterFailure = false
      XCUIDevice.shared.orientation = .portrait
      addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
      let application = XCUIApplication()
      application.launchArguments = [
        "--fixture", "list-windows", "--fixture-dataset", UUID().uuidString,
      ]
      application.launchSavedPlannerJourney()
      application.openPlannerSection("Lists")
      let route = application.savedPlannerListRow("Window Route")
      XCTAssertTrue(route.waitForExistence(timeout: 30))
      route.activateForPlannerJourney()
      XCTAssertTrue(application.staticTexts["0 of 193 items done"].waitForExistence(timeout: 30))
      let first = application.savedPlannerItemRows("Window Item 001").firstMatch
      XCTAssertTrue(first.waitForExistence(timeout: 15))
      let firstIdentifier = first.identifier
      let contents = application.collectionViews.containing(
        NSPredicate(
          format: "identifier BEGINSWITH %@ AND label BEGINSWITH %@",
          "saved.appearance.", "Window Item ")
      ).firstMatch
      XCTAssertTrue(contents.waitForExistence(timeout: 10))
      for title in ["Window Item 065", "Window Item 129", "Window Item 193"] {
        let row = application.savedPlannerItemRows(title).firstMatch
        scroll(contents, to: row, towardEnd: true)
        XCTAssertTrue(row.waitForExistence(timeout: 10))
        XCTAssertTrue(row.isHittable)
        capture("Windowed List reaches \(title)")
      }
      let last = application.savedPlannerItemRows("Window Item 193").firstMatch
      let lastIdentifier = last.identifier
      let completionIdentifier = lastIdentifier.replacingOccurrences(
        of: "saved.appearance.", with: "saved.appearance.completion.")
      let completion = application.buttons[completionIdentifier]
      XCTAssertTrue(completion.waitForPlannerValue("To do"))
      completion.activateForPlannerJourney()
      XCTAssertTrue(completion.waitForPlannerValue("Completed"))
      last.activateForPlannerJourney()
      XCTAssertTrue(application.staticTexts["Window notes 193"].waitForExistence(timeout: 10))
      revealContents(application, contents: contents)
      scroll(contents, to: first, towardEnd: false)
      XCTAssertEqual(first.identifier, firstIdentifier)
      XCTAssertTrue(application.staticTexts["1 of 193 items done"].waitForExistence(timeout: 10))
      capture("Windowed List revisits its first membership with full progress")
      scroll(contents, to: last, towardEnd: true)
      XCTAssertEqual(last.identifier, lastIdentifier)
      XCTAssertTrue(completion.waitForPlannerValue("Completed"))
      capture("Windowed List rereads the same completed final membership")
      application.terminate()
      application.launchSavedPlannerJourney()
      application.openPlannerSection("Lists")
      XCTAssertTrue(route.waitForExistence(timeout: 10))
      route.activateForPlannerJourney()
      XCTAssertTrue(application.staticTexts["1 of 193 items done"].waitForExistence(timeout: 10))
      scroll(contents, to: last, towardEnd: true)
      XCTAssertEqual(last.identifier, lastIdentifier)
      XCTAssertTrue(completion.waitForPlannerValue("Completed"))
      capture("Windowed List preserves membership identity and completion after relaunch")
    }

    private func revealContents(_ application: XCUIApplication, contents: XCUIElement) {
      if contents.exists && contents.isHittable { return }
      let back = application.buttons["BackButton"].firstMatch
      XCTAssertTrue(back.waitForExistence(timeout: 5))
      back.activateForPlannerJourney()
      XCTAssertTrue(contents.waitForExistence(timeout: 10))
    }

    private func scroll(_ contents: XCUIElement, to target: XCUIElement, towardEnd: Bool) {
      for _ in 0..<150 {
        if target.exists && target.isHittable { return }
        if towardEnd {
          contents.swipeUp(velocity: .init(rawValue: 1_500))
        } else {
          contents.swipeDown(velocity: .init(rawValue: 1_500))
        }
      }
      XCTFail("Native List did not expose the requested membership.")
    }

    private func capture(_ name: String) {
      let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
      attachment.name = name
      attachment.lifetime = .keepAlways
      add(attachment)
    }
  }
#endif
