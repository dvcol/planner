import Foundation
import PlannerCore

@MainActor
enum PlannerItineraryWindowFixture {
  static func makeStore(directory: URL) async throws -> SavedPlannerStore {
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .snapshot(let initial) = await planner.query(
        .init(session: session, request: .items(.init(completion: .all, archive: .all))))
    else { throw CancellationError() }
    if initial.matchingCount > 0 { return SavedPlannerStore(configuration: configuration) }
    let createdList = try await apply(
      .createList(content: .init(name: "Route activities")), planner: planner, session: session)
    guard let list = createdList.generated.first else { throw CancellationError() }
    var items: [PlannerEntityReference] = []
    for index in 1...65 {
      let result = try await apply(
        .createItem(
          content: .init(
            title: String(format: "Window Activity %03d", index),
            notes: "Window itinerary notes \(index)",
            estimate: .init(minutes: 5, displayUnit: .minute))), planner: planner, session: session)
      guard let item = result.generated.first else { throw CancellationError() }
      items.append(item)
      _ = try await apply(
        .addMembership(itemId: item.id, listId: list.id, placement: .last),
        planner: planner, session: session)
    }
    guard let first = items.first else { throw CancellationError() }
    let route = try await apply(
      .createItinerary(content: .init(title: "Windowed route")), planner: planner, session: session)
    guard let itinerary = route.generated.first else { throw CancellationError() }
    for source in [first, list, list, first] {
      _ = try await apply(
        .addItineraryEntry(itineraryId: itinerary.id, source: source, placement: .last),
        planner: planner, session: session)
    }
    let reordered = try await apply(
      .createItinerary(content: .init(title: "Reorder route")), planner: planner, session: session)
    guard let reorderItinerary = reordered.generated.first else { throw CancellationError() }
    for (index, source) in items.prefix(3).enumerated() {
      let result = try await apply(
        .addItineraryEntry(itineraryId: reorderItinerary.id, source: source, placement: .last),
        planner: planner, session: session)
      if index == 0 {
        guard case .itineraryEntry(let entryIdentifier, _, _)? = result.generatedReferences.first
        else { throw CancellationError() }
        _ = try await apply(
          .setCompletion(
            scope: .appearance(
              .directItineraryItem(itineraryId: reorderItinerary.id, entryId: entryIdentifier)),
            done: true), planner: planner, session: session)
      }
    }
    return SavedPlannerStore(configuration: configuration)
  }

  private static func apply(
    _ command: PlannerCommand, planner: PlannerCore.Planner, session: PlannerDatasetSession
  ) async throws -> PlannerAppliedResult {
    let result = await planner.execute(
      .init(operationId: UUID(), session: session, command: command))
    guard case .applied(let applied, .complete) = result.outcome else { throw CancellationError() }
    return applied
  }
}
