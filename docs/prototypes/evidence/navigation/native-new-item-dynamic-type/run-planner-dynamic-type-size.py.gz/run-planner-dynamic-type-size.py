from pathlib import Path
import json, os, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform, requested_size, compiled_epoch = sys.argv[1:]
assert platform in ['phone', 'tablet']
assert requested_size in ['large', 'accessibility-extra-extra-extra-large']
identifier = {'phone': '2A49C66C-C8A4-435F-B98A-9A90706780DE', 'tablet': 'FBD72DAB-1D40-4E64-912D-7F9763E00446'}[platform]
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
base_command = ['xcrun', 'simctl', 'ui', identifier, 'content_size']
original_size = subprocess.check_output(base_command, env=environment, text=True).strip()
subprocess.run(base_command + [requested_size], env=environment, check=True)
observed_size = subprocess.check_output(base_command, env=environment, text=True).strip()
assert observed_size == requested_size, observed_size
command = ['python3', '/private/tmp/run-planner-new-item-dynamic-type-runtime.py', phase, platform, 'SavedAppearanceJourneyTests/testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList', compiled_epoch, '360']
record = {'device': identifier, 'platform': platform, 'requestedSize': requested_size, 'observedSize': observed_size, 'originalSize': original_size, 'command': command}
try:
    result = subprocess.run(command, cwd=repository, env=environment)
    record['runnerExitCode'] = result.returncode
finally:
    restored = subprocess.run(base_command + [original_size], env=environment, capture_output=True, text=True)
    record['restoreExitCode'] = restored.returncode
    record['restoreOutput'] = restored.stdout + restored.stderr
    if restored.returncode == 0:
        record['restoredSize'] = subprocess.check_output(base_command, env=environment, text=True).strip()
    packet = repository / 'docs/prototypes/evidence/navigation/native-new-item-dynamic-type' / phase
    packet.mkdir(parents=True, exist_ok=True)
    (packet / 'content-size.json').write_text(json.dumps(record, indent=2) + '\n')
    assert restored.returncode == 0, record
    assert record['restoredSize'] == original_size, record
assert result.returncode == 0, record
