from pathlib import Path
import gzip, hashlib, json, re, subprocess
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
packet = repository / 'docs/prototypes/evidence/navigation/native-new-item-dynamic-type'
def read_json(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
expected_phases = ['tablet-large', 'tablet-accessibility-maximum', 'phone-large', 'phone-accessibility-maximum']
runs = read_json(packet / 'historical-run-index.json')['runs']
assert [value['epoch'] for value in runs] == expected_phases
mobile_products = read_json(packet / 'mobile-form-build/product-sha256.json')
assert len(mobile_products) == 6
for value in runs:
    epoch = packet / value['epoch']
    raw = gzip.decompress((epoch / 'test.log.gz').read_bytes()).decode()
    observed = [{'function': function, 'outcome': outcome, 'seconds': float(seconds)} for function, outcome, seconds in re.findall(r"Test Case '-\[([^\]]+)\]' (passed|failed) \(([\d.]+) seconds\)\.", raw)]
    assert observed == value['functions'] and len(observed) == 1 and observed[0]['outcome'] == 'passed'
    assert read_json(epoch / 'exit.json')['exitCode'] == value['exitCode'] == 0
    assert [line for line in raw.splitlines() if ': error:' in line] == value['errors'] == []
    assert '** TEST EXECUTE SUCCEEDED **' in raw
    assert read_json(epoch / 'product-sha256.json') == mobile_products
    current = read_json(epoch / 'current-source-sha256.json')
    compiled = read_json(epoch / 'compiled-source-sha256.json')
    assert len(current) == len(compiled) == 469
    assert current == compiled
    assert all(digest(repository / path) == value for path, value in current.items())
    size = read_json(epoch / 'content-size.json')
    assert size['requestedSize'] == size['observedSize'] == value['contentSize']
    assert size['originalSize'] == size['restoredSize'] == 'large' and size['restoreExitCode'] == 0
for phase in ['mobile-form-build', 'mac-form-build']:
    epoch = packet / phase
    assert read_json(epoch / 'exit.json')['exitCode'] == 0
    assert '** TEST BUILD SUCCEEDED **' in gzip.decompress((epoch / 'build.log.gz').read_bytes()).decode()
    sources = read_json(epoch / 'source-sha256.json')
    assert len(sources) == 945
    assert all(digest(repository / path) == value for path, value in sources.items())
    products = read_json(epoch / 'product-sha256.json')
    assert len(products) == 6 and all(digest(Path(path)) == value for path, value in products.items())
geometry = read_json(packet / 'rendered-text-geometry.json')['observations']
assert [value['epoch'] for value in geometry] == expected_phases
assert [value['titleFieldFrame'][3] for value in geometry] == [22, 64, 22, 64]
for value in geometry:
    raw = gzip.decompress((packet / value['hierarchy']).read_bytes()).decode()
    assert value['titleFieldLine'] in raw and value['windowLine'] in raw
images = read_json(packet / 'visual-review.json')['images']
assert len(images) == 16
assert {value['path'] for value in images} == {str(path.relative_to(packet)) for path in packet.rglob('*.png')}
assert all(value['individuallyInspected'] and digest(packet / value['path']) == value['sha256'] for value in images)
assert not subprocess.check_output(['git', 'diff', 'a199b438899f901e39dbae1ddfd4b657b557b10d', '--name-only', '--', 'Planner', 'Packages', 'Configuration', 'Planner.xcodeproj'], text=True).strip()
restoration = read_json(packet / 'simulator-restoration.json')
assert restoration[0]['value'] == restoration[1]['value'] == 'large'
assert restoration[-1]['phoneFinalState'] == 'Shutdown'
for filename in ['affected-swift-lint.json', 'affected-markdown-lint.json']:
    lint = read_json(packet / filename)
    assert lint['exitCode'] == 0
    assert all(digest(repository / path) == value for path, value in lint['sourceSHA256'].items())
result = {'nativeInvocations': 4, 'passingFunctions': 4, 'failedFunctions': 0, 'mobileCompilerInputs': 945, 'macCompilerInputs': 945, 'frozenRuntimeInputsPerInvocation': 469, 'productsRecheckedPerPlatform': 6, 'inspectedOriginalPNGs': 16, 'originalTextSizeRestored': True, 'phoneReturnedToShutdown': True, 'productionChanged': False, 'macRuntimeExecuted': False, 'newUnitSeamIntroduced': False, 'overallMapGateClosed': False, 'scope': 'Existing rich New Item creation at large and maximum accessibility text sizes in portrait iPhone/iPad simulator layouts. Visual readability, whole-app accessibility, pending Q94-Q96, signing and physical gates remain open.'}
(packet / 'evidence-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
