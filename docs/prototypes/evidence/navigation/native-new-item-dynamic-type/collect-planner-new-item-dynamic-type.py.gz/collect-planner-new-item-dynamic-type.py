from pathlib import Path
import gzip, json, os, shutil, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
epoch = repository / 'docs/prototypes/evidence/navigation/native-new-item-dynamic-type' / phase
value = json.loads((epoch / 'exit.json').read_text())
output = Path('/private/tmp/PlannerNewItemDynamicTypeAttachments-' + phase)
command = ['xcrun', 'xcresulttool', 'export', 'attachments', '--path', value['bundle'], '--output-path', str(output)]
result = subprocess.run(command, capture_output=True, text=True, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
assert result.returncode == 0, result.stderr
captures = []
for group in json.loads((output / 'manifest.json').read_text()):
    for attachment in group['attachments']:
        name = attachment['exportedFileName']
        title = attachment['suggestedHumanReadableName']
        if title.startswith(('New Item initial native form', 'New Item fields before authoring', 'Authored New Item address fields', 'Rich New Item draft', 'Created rich Item', 'Item editor own-app hierarchy before visibility failure', 'Item editor window before visibility failure')):
            if name.endswith('.txt'):
                (epoch / (name + '.gz')).write_bytes(gzip.compress((output / name).read_bytes(), mtime=0))
            elif name.endswith('.png'):
                shutil.copy2(output / name, epoch / name)
            else:
                continue
            captures.append({**attachment, 'testIdentifier': group['testIdentifier']})
(epoch / 'selected-captures.json').write_text(json.dumps(captures, indent=2) + '\n')
print(json.dumps(captures, indent=2))
