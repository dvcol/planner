import Observation
import PlannerCore
import SwiftUI

@MainActor @Observable
final class SavedNewItemDraft: Identifiable {
  let id = UUID()
  let listIdentifier: UUID?
  let namespace: String
  var title = ""
  var subtitle = ""
  var notes = ""
  var estimate: PlannerEstimate?
  var location = SavedOwnedLocationDraft(nil)
  var links: [SavedOwnedLinkDraft] = []
  var categoryIdentifiers: Set<UUID> = []
  var tagIdentifiers: Set<UUID> = []

  init(listIdentifier: UUID?, namespace: String) {
    self.listIdentifier = listIdentifier
    self.namespace = namespace
  }

  var hasChanges: Bool {
    !title.isEmpty || !subtitle.isEmpty || !notes.isEmpty || estimate != nil
      || location.value != nil || !links.isEmpty
      || !categoryIdentifiers.isEmpty || !tagIdentifiers.isEmpty
  }

  var content: PlannerItemContentInput {
    .init(
      title: title, subtitle: subtitle.isEmpty ? nil : subtitle,
      notes: notes.isEmpty ? nil : notes, location: location.value,
      estimate: estimate, links: links.map(\.input),
      categoryIds: categoryIdentifiers, tagIds: tagIdentifiers)
  }
}

struct SavedNewItemForm: View {
  let store: SavedPlannerStore
  @Bindable var draft: SavedNewItemDraft
  let isSaving: Bool
  let cancel: () -> Void
  let save: () -> Void

  var body: some View {
    NavigationStack {
      Form {
        Section {
          TextField("Title", text: $draft.title)
            .accessibilityIdentifier("saved.item.title")
          TextField("Subtitle", text: $draft.subtitle)
            .accessibilityIdentifier("saved.item.subtitle")
          TextField("Notes", text: $draft.notes, axis: .vertical)
            .lineLimit(3...8)
            .accessibilityIdentifier("saved.item.notes")
        }
        SavedActivityEstimateEditor(
          estimate: $draft.estimate, accessibilityIdentifierPrefix: "saved.item.estimate")
        Section("Labels") {
          NavigationLink {
            SavedItemLabelPicker(
              store: store, kind: .category, selection: $draft.categoryIdentifiers)
          } label: {
            LabeledContent("Categories", value: labelSummary(draft.categoryIdentifiers))
          }
          .accessibilityIdentifier("saved.item.categories")
          NavigationLink {
            SavedItemLabelPicker(store: store, kind: .tag, selection: $draft.tagIdentifiers)
          } label: {
            LabeledContent("Tags", value: labelSummary(draft.tagIdentifiers))
          }
          .accessibilityIdentifier("saved.item.tags")
        }
        SavedOwnedLocationEditor(
          draft: $draft.location, title: draft.title,
          accessibilityIdentifierPrefix: "saved.item.location")
        SavedOwnedLinksEditor(links: $draft.links, accessibilityIdentifierPrefix: "saved.item.link")
        if let message = store.alertMessage {
          Section { Label(message, systemImage: "exclamationmark.triangle") }
        }
      }
      .disabled(isSaving)
      .formStyle(.grouped)
      .navigationTitle("New Item")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Cancel", action: cancel)
            .disabled(isSaving)
            .keyboardShortcut(.cancelAction)
            .accessibilityIdentifier("saved.item.cancel")
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Save", action: save)
            .disabled(
              isSaving || !store.canCreate
                || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            )
            .keyboardShortcut(.defaultAction)
            .accessibilityIdentifier("saved.item.save")
        }
      }
      .overlay {
        if isSaving { ProgressView("Saving Item") }
      }
    }
  }

  private func labelSummary(_ identifiers: Set<UUID>) -> String {
    identifiers.isEmpty ? "None" : "\(identifiers.count) selected"
  }
}
