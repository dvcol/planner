from pathlib import Path
from urllib.parse import urlsplit
import collections
import gzip
import hashlib
import json
import re

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
prefix = workspace / 'docs/prototypes/evidence/navigation'
mac = prefix / 'core-incoming-family-import-regression-mac'
mobile = prefix / 'core-incoming-family-import-regression-ios'
mac_packets = [mac, prefix/'core-incoming-family-receipt-regression-mac']
mobile_packets = [mobile, prefix/'core-incoming-family-receipt-regression-ios-xcode']
mac_functions = []
for packet in mac_packets:
    report = json.loads((packet/'execution.json').read_text())
    assert report['exitCode']==0 and report['frozenInputsUnchanged'] and report['sqliteUnlinkWarnings']==0
    log = gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
    counts = collections.Counter(re.findall(r'^◇ Test case passing .+ to (\S+) started\.$',log,re.MULTILINE))
    mac_functions += [(case['className'].removeprefix('PlannerCoreStoreTests.'),case['name'],counts.get(case['name'],1)) for case in report['cases']]
mac_functions.sort()

def nodes(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from nodes(child)

mobile_functions=[]
for packet in mobile_packets:
    report=json.loads((packet/'execution.json').read_text())
    assert report['exitCode']==0 and report['frozenInputsUnchanged'] and report['sqliteUnlinkWarnings']==0
    native_nodes=list(nodes(json.loads(gzip.decompress((packet/'test-results-tests.json.gz').read_bytes()))))
    assert all(node['result']=='Passed' for node in native_nodes if node.get('nodeType') in ['Test Case','Arguments'])
    for case in native_nodes:
        if case.get('nodeType')!='Test Case':continue
        mobile_functions.append((urlsplit(case['nodeIdentifierURL']).path.split('/')[-2],case['name'],max(1,sum(child.get('nodeType')=='Arguments' for child in case.get('children',[])))))
mobile_functions.sort()
assert mac_functions==mobile_functions
assert len(mac_functions)==len(set(mac_functions))==60
assert sum(record[2] for record in mac_functions)==242
mac_inputs = json.loads((mac / 'source-sha256.json').read_text())
mobile_inputs = json.loads((mobile / 'source-sha256.json').read_text())
assert len(mac_inputs) == 740
for relative, digest in mac_inputs.items():
    assert hashlib.sha256((workspace / relative).read_bytes()).hexdigest() == digest, relative
    assert mobile_inputs[relative] == digest, relative
for relative, digest in mobile_inputs.items():
    assert hashlib.sha256((workspace / relative).read_bytes()).hexdigest() == digest, relative
for packet in mac_packets+mobile_packets:
    product_hashes=json.loads((packet/'product-sha256.json').read_text())
    assert product_hashes
    assert all(hashlib.sha256(Path(product).read_bytes()).hexdigest()==digest for product,digest in product_hashes.items())
    cleanup=json.loads((packet/'fixture-lifecycle-report.json').read_text())
    assert cleanup['success']
for packets in [mac_packets,mobile_packets]:
    assert sum(json.loads((packet/'fixture-lifecycle-report.json').read_text())['fixtureCount'] for packet in packets)==242
red=prefix/'core-incoming-family-all-sources-red'
green=prefix/'core-incoming-family-all-sources-green'
assert (red/'NativeImportBindingReviewTests.swift.gz').read_bytes()==(green/'NativeImportBindingReviewTests.swift.gz').read_bytes()
report={'coreInputsMatched':len(mac_inputs),'nativeInputsMatched':len(mobile_inputs),'functionsPerPlatform':60,'invocationsPerPlatform':242,'newEmptyRestoreCasesPerPlatform':10,'functions':[{'className':kind,'name':name,'invocations':count} for kind,name,count in mac_functions],'productHashesVerified':True,'sqliteUnlinkWarningsPerPlatform':0,'removedFixturesPerPlatform':242,'expandedRedAndGreenTestBytesIdentical':True,'nativeUIOrPhysicalCredit':False}
(mac/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
(mac/'qualification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({key:value for key,value in report.items() if key!='functions'}))
