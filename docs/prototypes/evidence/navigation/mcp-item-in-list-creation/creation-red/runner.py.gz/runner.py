from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tarfile,io,shutil
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
selected=sys.argv[2] if len(sys.argv)>2 else 'ItemInListCreationRoutingTests'
packet=repository/'docs/prototypes/evidence/navigation/mcp-item-in-list-creation'/phase
packet.mkdir(parents=True,exist_ok=False)
root=Path('/private/tmp/PlannerQ93HTTPSource')
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if not root.exists():
    root.mkdir()
    archive=subprocess.check_output(['git','archive',base,'Configuration','Packages','Planner.xcodeproj','Planner','PlannerMCPTests','PlannerFixtures','PlannerFixtureUITests','PlannerNavigationUITests'])
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        source.extractall(root,filter='data')
overlays=['Planner/AgentControl/PlannerMCPExecutionTool.swift','Planner/AgentControl/PlannerMCPReviewTool.swift','PlannerMCPTests/ItemInListCreationRoutingTests.swift']
for path in overlays:shutil.copy2(repository/path,root/path)
inputs=sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(root),'base':base,'overlays':overlays},indent=2)+'\n')
for path in overlays:(packet/(Path(path).name+'.gz')).write_bytes(gzip.compress((root/path).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
bundle='/private/tmp/PlannerQ93HTTP-'+phase+'.xcresult'
command=['xcodebuild','-project','Planner.xcodeproj','-scheme','Planner','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/PlannerQ93HTTPDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerMCPSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1',*[f'-only-testing:PlannerMCPTests/{name}' for name in selected.split(',')],'-resultBundlePath',bundle,'CODE_SIGNING_ALLOWED=NO','test']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerQ93HTTP-'+phase+'.log')
with log.open('wb') as output:result=subprocess.run(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'bundle':bundle},indent=2)+'\n')
assert all(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
assert all((root/path).read_bytes()==(repository/path).read_bytes() for path in overlays)
products=Path('/private/tmp/PlannerQ93HTTPDerivedData/Build/Products/Debug')
binaries=[path for path in products.rglob('*') if path.is_file() and (path.name.endswith('.dylib') or path.name in ['Planner','PlannerMCPTests'])]
(packet/'product-sha256.json').write_text(json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in binaries},indent=2)+'\n')
print(phase,'exit',result.returncode)
for line in log.read_text().splitlines():
    if line.startswith(('✔','✘','Test Suite ','Test Case ','** TEST')) or ': error:' in line:print(line)
