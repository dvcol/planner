from pathlib import Path
import gzip, hashlib, json, os, signal, subprocess, sys, time
workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
phase, revision, selection = sys.argv[1:4]
root = Path('/private/tmp/PlannerNativeItemWindowSource')
packet = workspace / 'docs/prototypes/evidence/navigation' / phase
packet.mkdir(exist_ok=False)
previous_manifest = json.loads((workspace / 'docs/prototypes/evidence/navigation/core-native-import-known-family-binding-ios-final/source-sha256.json').read_text())
changed = []
for name in previous_manifest:
    data = subprocess.check_output(['git', 'show', revision + ':' + name]) if revision != 'workspace' else (workspace / name).read_bytes()
    if (root / name).read_bytes() != data:
        (root / name).write_bytes(data)
        changed.append(name)
if revision == 'workspace':
    for path in (workspace / 'Packages/PlannerCore/Tests/PlannerCoreStoreTests').glob('*.swift'):
        name = str(path.relative_to(workspace))
        if name not in previous_manifest:
            (root / name).write_bytes(path.read_bytes())
            changed.append(name)
manifest = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path)}
(packet / 'source-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root':str(root),'revision':revision,'changedFiles':changed},indent=2)+'\n')
for name in changed:
    (packet / (Path(name).name + '.gz')).write_bytes(gzip.compress((root/name).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
if selection == 'all-affected':
    executed = json.loads((workspace/'docs/prototypes/evidence/navigation/core-native-import-known-family-final-package/execution.json').read_text())
    classes = sorted({case['className'].removeprefix('PlannerCoreStoreTests.') for case in executed['cases']})
else:
    classes = selection.split(',')
result_path = '/private/tmp/PlannerImportLifecycle-' + phase + '.xcresult'
command = ['xcodebuild','test','-project','Planner.xcodeproj','-scheme','PlannerCore','-destination','platform=iOS Simulator,id=2A49C66C-C8A4-435F-B98A-9A90706780DE','-derivedDataPath','/private/tmp/PlannerItemWindowsNativemobileDerivedData','-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1',*['-only-testing:PlannerCoreStoreTests/'+name for name in classes],'-resultBundlePath',result_path,'CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log = Path('/private/tmp/PlannerImportLifecycle-'+phase+'.log')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
started=time.monotonic(); timed_out=False
with log.open('wb') as output:
    process=subprocess.Popen(command,cwd=root,env=environment,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    try: code=process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out=True; os.killpg(process.pid,signal.SIGINT)
        try:code=process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);code=process.wait()
content=log.read_text(errors='replace')
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
commands=[];summary=None
for name,arguments in [('test-summary.json',['get','test-results','summary']),('test-results-tests.json.gz',['get','test-results','tests'])]:
    command=['xcrun','xcresulttool',*arguments,'--path',result_path,'--format','json']
    extraction=subprocess.run(command,capture_output=True,env=environment,timeout=60)
    commands.append({'command':command,'exitCode':extraction.returncode})
    if extraction.returncode==0:
        (packet/name).write_bytes(gzip.compress(extraction.stdout,mtime=0) if name.endswith('.gz') else extraction.stdout)
        if name=='test-summary.json':summary=json.loads(extraction.stdout)
(packet/'evidence-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
report={'exitCode':code,'runnerTimedOut':timed_out,'elapsedSeconds':round(time.monotonic()-started,3),'frozenInputsUnchanged':all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items()),'requestedClasses':classes,'sqliteUnlinkWarnings':content.count('vnode unlinked while in use'),'summary':{name:summary.get(name) for name in ['result','passedTests','failedTests','skippedTests']} if summary else None}
(packet/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
for line in content.splitlines():
    if 'recorded an issue' in line or 'failed after' in line or '** TEST' in line or ('.swift:' in line and ': error:' in line):print(line[:600])
raise SystemExit(code)
