from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-association-undo'
packets=sorted(root.glob('move-*'))
assert len(packets)==11,len(packets)
validation=repository/'docs/prototypes/evidence/navigation/core-move-undo/final-validation'
validation.mkdir(parents=True,exist_ok=True)
observations=[]
for packet in packets:
 result=json.loads((packet/'exit.json').read_text())
 log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode(errors='replace')
 summaries=re.findall(r'Test run with (\d+) tests? in (\d+) suites? (passed|failed) after ([\d.]+) seconds',log)
 observations.append({'epoch':packet.name,'exitCode':result['exitCode'],'selectedFilter':result['filter'],'lastExecutedSummary':summaries[-1:]})
final=next(entry for entry in observations if entry['epoch']=='move-full-affected-core-regressions')
assert final['exitCode']==0 and final['lastExecutedSummary']==[('27','9','passed','1.514')]
final_hashes=json.loads((root/'move-full-affected-core-regressions/source-sha256.json').read_text())
differences=[name for name,digest in final_hashes.items() if not (repository/name).is_file() or hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
assert not differences,differences
(validation/'observed-results.json').write_text(json.dumps(observations,indent=2)+'\n')
(validation/'source-comparison.json').write_text(json.dumps({'finalEpoch':'move-full-affected-core-regressions','verifiedPackageInputs':len(final_hashes),'differentCurrentInputs':differences},indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
reports=['docs/prototypes/core-move-undo.md','docs/native-compound-association-undo-contract-review.md']
swift_files=['Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift','Packages/PlannerCore/Sources/PlannerCore/PlannerAssociationUndoValues.swift','Packages/PlannerCore/Tests/PlannerCoreStoreTests/AssociationMoveUndoTests.swift','Packages/PlannerCore/Tests/PlannerCoreStoreTests/AssociationUndoSaveFailureTests.swift']
checks=[]
for index,command in enumerate([['xcrun','swift-format','lint','--strict',*swift_files],['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json',*reports],['git','diff','--check']]):
 completed=subprocess.run(command,env=environment,capture_output=True,text=True)
 (validation/f'check-{index}.log.gz').write_bytes(gzip.compress((completed.stdout+completed.stderr).encode(),mtime=0))
 checks.append({'command':command,'exitCode':completed.returncode})
 assert completed.returncode==0,(command,completed.stdout,completed.stderr)
links=[]
for report in reports:
 for target in re.findall(r'\]\(([^)]+)\)',(repository/report).read_text()):
  if target.startswith(('http:','https:','#')):continue
  destination=(repository/report).parent.joinpath(target.split('#')[0]).resolve()
  assert destination.exists() or destination in [validation/'checks.json',validation/'evidence-sha256.json'],target
  links.append({'report':report,'target':target})
(validation/'checks.json').write_text(json.dumps({'commands':checks,'localLinksChecked':len(links),'missingLinks':[],'verifiedFinalPackageInputs':len(final_hashes),'changedFinalInputs':differences},indent=2)+'\n')
patterns={'githubCredential':r'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}','privateKey':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','openaiCredential':r'sk-(?:proj-)?[A-Za-z0-9_-]{30,}'}
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
findings=[]
for path in files:
 data=path.read_bytes()
 if path.suffix=='.gz':data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data.decode(errors='replace')):findings.append({'path':str(path.relative_to(repository)),'pattern':name})
assert not findings
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(files),'decompressedGzip':True,'findings':findings},indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
(validation/'evidence-sha256.json').write_text(json.dumps({str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)},indent=2)+'\n')
assert all((repository/entry['report']).parent.joinpath(entry['target'].split('#')[0]).exists() for entry in links)
print('Verified 11 Core epochs; final 27 tests in 9 suites pass;',len(final_hashes),'package inputs match;',len(files),'evidence files hashed; affected lint/links pass.')
