from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase, selected=sys.argv[1:]
packet=repository/'docs/prototypes/evidence/navigation/native-association-undo'/phase
packet.mkdir(parents=True,exist_ok=False)
package=repository/'Packages/PlannerCore'
source_paths=sorted([package/'Package.swift', *(path for directory in [package/'Sources', package/'Tests'] for path in directory.rglob('*.swift'))])
source_hashes={str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_paths}
(packet/'source-sha256.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
(packet/'base.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
for relative in sorted(set(changed+new)):
 if relative not in source_hashes: continue
 destination=packet/'sources'/relative
 destination=destination.with_name(destination.name+'.gz')
 destination.parent.mkdir(parents=True,exist_ok=True)
 destination.write_bytes(gzip.compress((repository/relative).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
command=['xcrun','swift','test','--package-path','Packages/PlannerCore','--scratch-path','/private/tmp/PlannerLargeCollectionCoreBuild','--filter',selected,'--jobs','1']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerAssociationUndo-'+phase+'.log')
with log.open('wb') as output:
 result=subprocess.run(command,cwd=repository,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'filter':selected},indent=2)+'\n')
assert source_hashes=={relative:hashlib.sha256((repository/relative).read_bytes()).hexdigest() for relative in source_hashes}
product=Path('/private/tmp/PlannerLargeCollectionCoreBuild/out/Products/Debug/PlannerCoreStoreTests.xctest/Contents/MacOS/PlannerCoreStoreTests')
if product.is_file():
 (packet/'product-sha256.json').write_text(json.dumps({str(product):hashlib.sha256(product.read_bytes()).hexdigest()},indent=2)+'\n')
print(phase,'exit',result.returncode)
for line in log.read_text().splitlines():
 if ': error:' in line or 'recorded an issue' in line or 'passed after' in line or 'failed after' in line: print(line[:900])
raise SystemExit(result.returncode)
