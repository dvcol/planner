import Foundation
import PlannerCore
import Testing

struct AssociationMoveUndoTests {
  @Test func moveUndoRestoresOriginAndRemovesOnlyItsCreatedDestination() async throws {
    let fixture = try await AssociationUndoFixture()
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let destinationCreation = try await fixture.save(
      .createList(content: .init(name: "Destination")))
    let destination = try #require(destinationCreation.generated.first)
    let otherCreation = try await fixture.save(.createItem(content: .init(title: "Other")))
    let other = try #require(otherCreation.generated.first)
    let otherAddition = try await fixture.save(
      .addMembership(itemId: other.id, listId: destination.id, placement: .last))
    guard case .membership(let otherMembership, _, _)? = otherAddition.generatedReferences.first,
      case .decoded(let original) = fixture.planner.decodeImport(try await fixture.export())
    else { throw CancellationError() }
    let originalMembership = try #require(
      original.backup.memberships.first { $0.id == fixture.membershipIdentifier })
    let moveIdentifier = UUID()
    let moveCommand = PlannerCommand.moveMembership(
      listId: fixture.list.id, membershipId: fixture.membershipIdentifier,
      destinationListId: destination.id, placement: .last)
    let moved = await fixture.planner.execute(
      .init(operationId: moveIdentifier, session: fixture.session, command: moveCommand))
    guard case .applied(_, .complete) = moved.outcome,
      case .source(.item(let item)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    let snapshot = try #require(moved.associationUndoSnapshot)
    #expect(snapshot.identity.id == fixture.membershipIdentifier)
    _ = try await fixture.save(
      .editItem(
        sourceId: fixture.item.id, changes: .init(notes: .set("Edited after Move")),
        expectedFieldHashes: item.fieldHashes))
    let operationIdentifier = UUID()
    let operation = PlannerOperation(
      operationId: operationIdentifier, session: fixture.session,
      command: .restoreAssociation(snapshot: snapshot))
    let restored = await fixture.planner.execute(operation)
    guard case .applied(let result, .complete) = restored.outcome,
      case .decoded(let saved) = fixture.planner.decodeImport(try await fixture.export()),
      case .source(.item(let updatedItem)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    let origin = try #require(
      saved.backup.memberships.first { $0.id == fixture.membershipIdentifier })
    #expect(origin.lifetimeId != originalMembership.lifetimeId)
    #expect(origin.rank == 0 && origin.localDone)
    #expect(origin.list == fixture.list && origin.item == fixture.item)
    #expect(
      saved.backup.memberships.filter { $0.list == destination }.map(\.id) == [otherMembership])
    #expect(
      updatedItem.content.notes == "Edited after Move" && updatedItem.state.globalDone == false)
    let beforeReplay = try await fixture.export()
    let replay = await fixture.planner.execute(operation)
    let moveReplay = await fixture.planner.execute(
      .init(operationId: moveIdentifier, session: fixture.session, command: moveCommand))
    guard case .applied(let replayed, .complete) = replay.outcome else {
      throw CancellationError()
    }
    #expect(replayed == result)
    #expect(moveReplay.associationUndoSnapshot?.closingOperationId == snapshot.closingOperationId)
    #expect(try await fixture.export() == beforeReplay)
  }
}
