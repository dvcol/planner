import Foundation
import PlannerCore
import Testing

struct OwnedAssociationUndoTests {
  @Test func oneSaveRestoresItsRemovedLinksAndTagTogetherWithoutOverwritingLaterEdits()
    async throws
  {
    let fixture = try await AssociationUndoFixture()
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let tagCreation = try await fixture.save(.createTag(content: .init(name: "Rainy day")))
    let tag = try #require(tagCreation.generated.first)
    func readItem() async throws -> PlannerItemSourceRead {
      guard
        case .source(.item(let item)) = await fixture.planner.read(
          session: fixture.session, request: .source(fixture.item))
      else { throw CancellationError() }
      return item
    }
    let initial = try await readItem()
    _ = try await fixture.save(
      .editItem(
        sourceId: fixture.item.id,
        changes: .init(
          links: .set(
            ["a", "b", "c", "d"].map { .init(originalUrl: "https://example.com/\($0)") }),
          tagIds: .set([tag.id])), expectedFieldHashes: initial.fieldHashes))
    let beforeRemoval = try await readItem()
    let originalLinks = beforeRemoval.content.links
    #expect(originalLinks.count == 4)
    guard case .decoded(let originalData) = fixture.planner.decodeImport(try await fixture.export())
    else { throw CancellationError() }
    let originalTagAssociation = try #require(
      originalData.backup.labelAssociations.first {
        $0.owner == fixture.item && $0.label == tag
      })
    let removalIdentifier = UUID()
    let removal = await fixture.planner.execute(
      .init(
        operationId: removalIdentifier, session: fixture.session,
        command: .editItem(
          sourceId: fixture.item.id,
          changes: .init(
            notes: .set("Notes saved with removal"),
            links: .set(
              [originalLinks[1], originalLinks[3]].map {
                .init(linkId: $0.linkId, originalUrl: $0.originalUrl, label: $0.label)
              }), tagIds: .set([])),
          expectedFieldHashes: beforeRemoval.fieldHashes)))
    guard case .applied(_, .complete) = removal.outcome else { throw CancellationError() }
    let snapshot = try #require(removal.associationUndoSnapshot)
    let afterRemoval = try await readItem()
    _ = try await fixture.save(
      .editItem(
        sourceId: fixture.item.id,
        changes: .init(
          notes: .set("Later notes"),
          links: .set([
            .init(originalUrl: "https://example.com/x"),
            .init(
              linkId: originalLinks[1].linkId, originalUrl: originalLinks[1].originalUrl,
              label: "Updated retained bookmark"),
            .init(linkId: originalLinks[3].linkId, originalUrl: originalLinks[3].originalUrl),
          ])), expectedFieldHashes: afterRemoval.fieldHashes))
    let beforeUndo = try await readItem()
    let addedLink = try #require(beforeUndo.content.links.first)
    let operation = PlannerOperation(
      operationId: UUID(), session: fixture.session,
      command: .restoreAssociation(snapshot: snapshot))
    let restored = await fixture.planner.execute(operation)
    guard case .applied(let result, .complete) = restored.outcome else {
      throw CancellationError()
    }
    let item = try await readItem()
    #expect(item.content.notes == "Later notes")
    #expect(
      item.content.links.map(\.linkId)
        == [
          addedLink.linkId, originalLinks[0].linkId, originalLinks[1].linkId,
          originalLinks[2].linkId, originalLinks[3].linkId,
        ])
    #expect(item.content.links[2].label == "Updated retained bookmark")
    #expect(item.content.tagIds == [tag.id])
    guard case .decoded(let saved) = fixture.planner.decodeImport(try await fixture.export()) else {
      throw CancellationError()
    }
    let restoredTag = try #require(
      saved.backup.labelAssociations.first { $0.id == originalTagAssociation.id })
    #expect(restoredTag.lifetimeId != originalTagAssociation.lifetimeId)
    for removedIndex in [0, 2] {
      let original = try #require(
        originalData.backup.ownedLinks.first { $0.id == originalLinks[removedIndex].linkId })
      let restoredLink = try #require(saved.backup.ownedLinks.first { $0.id == original.id })
      #expect(restoredLink.lifetimeId != original.lifetimeId)
      #expect(restoredLink.originalUrl == original.originalUrl)
    }
    let beforeReplay = try await fixture.export()
    let replay = await fixture.planner.execute(operation)
    guard case .applied(let replayed, .complete) = replay.outcome else {
      throw CancellationError()
    }
    #expect(replayed == result)
    #expect(try await fixture.export() == beforeReplay)
  }
}
