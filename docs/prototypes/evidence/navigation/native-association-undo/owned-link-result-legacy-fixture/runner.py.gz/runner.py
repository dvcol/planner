from pathlib import Path
import gzip, hashlib, io, json, os, subprocess, tarfile
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
base = 'cb05fc36525e4d7b92519fec97957983a73e0290'
root = Path('/private/tmp/PlannerLegacyOwnedLinkGenerator')
root.mkdir(exist_ok=False)
packet = repository / 'docs/prototypes/evidence/navigation/native-association-undo/owned-link-result-legacy-fixture'
packet.mkdir(parents=True, exist_ok=False)
archive = subprocess.check_output(['git', 'archive', base, 'Packages/PlannerCore/Package.swift', 'Packages/PlannerCore/Sources'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    source.extractall(root / 'source', filter='data')
package = '''// swift-tools-version: 6.4
import PackageDescription
let package = Package(name: "LegacyOwnedLinkGenerator", platforms: [.macOS("27.0")], dependencies: [.package(path: "source/Packages/PlannerCore")], targets: [.executableTarget(name: "LegacyOwnedLinkGenerator", dependencies: [.product(name: "PlannerCore", package: "PlannerCore")])])
'''
(root / 'Package.swift').write_text(package)
source = root / 'Sources/LegacyOwnedLinkGenerator/main.swift'
source.parent.mkdir(parents=True)
source.write_bytes(Path('/private/tmp/PlannerLegacyOwnedLinkGenerator.swift').read_bytes())
inputs = sorted(path for path in root.rglob('*') if path.is_file())
(packet / 'source-sha256.json').write_text(json.dumps({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}, indent=2) + '\n')
(packet / 'base.json').write_text(json.dumps({'commit': base}, indent=2) + '\n')
for name, content in [('generator.swift',source.read_bytes()),('Package.swift',package.encode()),('runner.py',Path(__file__).read_bytes())]:
    (packet / (name + '.gz')).write_bytes(gzip.compress(content, mtime=0))
fixture = root / 'fixture'
command = ['xcrun','swift','run','--package-path',str(root),'--scratch-path','/private/tmp/PlannerLegacyOwnedLinkGeneratorBuild','--jobs','1','LegacyOwnedLinkGenerator',str(fixture)]
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerLegacyOwnedLinkGenerator.log')
with log.open('wb') as output:
    result = subprocess.run(command, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT)
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode':result.returncode},indent=2)+'\n')
assert result.returncode == 0, log.read_text()[-4000:]
assert len(json.loads((fixture / 'manifest.json').read_text())) == 2
(packet / 'fixture-sha256.json').write_text(json.dumps({str(path.relative_to(fixture)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(fixture.rglob('*')) if path.is_file()},indent=2)+'\n')
print('Baseline fixture generated after process exit:', fixture)
