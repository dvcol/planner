// swift-tools-version: 6.4
import PackageDescription
let package = Package(name: "LegacyOwnedLinkGenerator", platforms: [.macOS("27.0")], dependencies: [.package(path: "source/Packages/PlannerCore")], targets: [.executableTarget(name: "LegacyOwnedLinkGenerator", dependencies: [.product(name: "PlannerCore", package: "PlannerCore")])])
