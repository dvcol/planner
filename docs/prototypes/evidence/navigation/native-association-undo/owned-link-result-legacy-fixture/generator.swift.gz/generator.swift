import Foundation
import PlannerCore
import SwiftData

private struct LegacyLinkEdit: Codable {
  let owner: PlannerEntityReference
  let operationId: UUID
  let linksHash: String
  let result: PlannerAppliedResult
  let checkpoint: Int64
  let incomplete: Bool
  let linkIds: [UUID]
}

@main struct LegacyOwnedLinkGenerator {
  static func main() async throws {
    let directory = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    var records: [LegacyLinkEdit] = []
    let obstruction = LegacyRecoveryObstruction(configuration: configuration)
    var observer: NSObjectProtocol?
    defer {
      if let observer { NotificationCenter.default.removeObserver(observer) }
      try? obstruction.restore()
    }
    for kind in [PlannerEntityKind.item, .itinerary] {
      let creation: PlannerCommand
      if kind == .item {
        creation = .createItem(content: .init(title: "Legacy Item", notes: "Keep"))
      } else {
        creation = .createItinerary(content: .init(title: "Legacy Itinerary", notes: "Keep"))
      }
      guard case .applied(let created, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: creation)).outcome,
        let owner = created.generated.first,
        case .source(let source) = await planner.read(session: session, request: .source(owner))
      else { throw CancellationError() }
      let links = [PlannerLinkInput(originalUrl: "https://example.com/duplicate", label: "First"),
        PlannerLinkInput(originalUrl: "https://example.com/duplicate", label: "Second")]
      let command: PlannerCommand
      let hash: PlannerFieldHash
      switch source {
      case .item(let item):
        hash = item.fieldHashes[.links]!
        command = .editItem(sourceId: owner.id, changes: .init(links: .set(links)), expectedFieldHashes: [.links: hash])
      case .itinerary(let itinerary):
        hash = itinerary.fieldHashes[.links]!
        command = .editItinerary(sourceId: owner.id, changes: .init(links: .set(links)), expectedFieldHashes: [.links: hash])
        observer = NotificationCenter.default.addObserver(forName: ModelContext.didSave, object: nil, queue: nil) {
          notification in obstruction.observe(notification)
        }
      default: throw CancellationError()
      }
      let operationId = UUID()
      let outcome = await planner.execute(.init(operationId: operationId, session: session, command: command)).outcome
      let result: PlannerAppliedResult
      let checkpoint: Int64
      let incomplete: Bool
      switch outcome {
      case .applied(let applied, .complete(let generation)):
        guard kind == .item else { throw CancellationError() }
        result = applied; checkpoint = generation; incomplete = false
      case .applied(let applied, .incomplete):
        guard kind == .itinerary, obstruction.didObstruct else { throw CancellationError() }
        result = applied; checkpoint = 4; incomplete = true
        try obstruction.restore()
      default: throw CancellationError()
      }
      guard result.generatedIdentities.isEmpty, result.affectedIdentities == [.source(owner)],
        case .source(let current) = await planner.read(session: session, request: .source(owner))
      else { throw CancellationError() }
      let linkIds: [UUID]
      switch current {
      case .item(let item): linkIds = item.content.links.map(\.linkId)
      case .itinerary(let itinerary): linkIds = itinerary.content.links.map(\.linkId)
      default: throw CancellationError()
      }
      records.append(.init(owner: owner, operationId: operationId, linksHash: hash.value,
        result: result, checkpoint: checkpoint, incomplete: incomplete, linkIds: linkIds))
    }
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
    try encoder.encode(records).write(to: directory.appendingPathComponent("manifest.json"))
  }
}

private final class LegacyRecoveryObstruction: @unchecked Sendable {
  private let lock = NSLock()
  private let storeURL: URL
  private let recoveryURL: URL
  private let retainedURL: URL
  private var obstructed = false
  var didObstruct: Bool { lock.withLock { obstructed } }
  init(configuration: PlannerStorageConfiguration) {
    storeURL = configuration.storeURL.standardizedFileURL
    recoveryURL = configuration.recoveryDirectoryURL
    retainedURL = recoveryURL.deletingLastPathComponent().appendingPathComponent("retained-recovery")
  }
  func observe(_ notification: Notification) {
    guard let context = notification.object as? ModelContext,
      context.container.configurations.contains(where: { $0.url.standardizedFileURL == storeURL }) else { return }
    lock.withLock {
      guard !obstructed else { return }
      obstructed = true
      do {
        try FileManager.default.moveItem(at: recoveryURL, to: retainedURL)
        try Data("Obstruct recovery after native save".utf8).write(to: recoveryURL)
      } catch { fatalError("Fixture obstruction failed: \(error)") }
    }
  }
  func restore() throws {
    guard FileManager.default.fileExists(atPath: retainedURL.path) else { return }
    try FileManager.default.removeItem(at: recoveryURL)
    try FileManager.default.moveItem(at: retainedURL, to: recoveryURL)
  }
}
