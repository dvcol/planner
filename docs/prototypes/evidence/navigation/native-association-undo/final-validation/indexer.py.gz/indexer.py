from pathlib import Path
import gzip,hashlib,json,re
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
core=Path('docs/prototypes/evidence/navigation/native-association-undo')
compatibility=Path('docs/prototypes/evidence/navigation/native-itinerary-window-compatibility')
validation=core/'final-validation'
rows=[]
for packet in sorted([*core.glob('*'),*compatibility.glob('association-undo-*')]):
 if not packet.is_dir() or not (packet/'exit.json').is_file(): continue
 row={'epoch':str(packet),'result':json.loads((packet/'exit.json').read_text())}
 for filename in ['test.log.gz','build.log.gz']:
  if not (packet/filename).is_file(): continue
  lines=gzip.decompress((packet/filename).read_bytes()).decode(errors='replace').splitlines()
  row['observedSummary']=[line.strip() for line in lines if re.search(r"Test Case .* (?:passed|failed) \(|Test run with .* (?:passed|failed)|\*\* TEST (?:BUILD|EXECUTE)",line)]
  break
 rows.append(row)
comparisons=[]
for phase in ['association-undo-system-accessory-phone','association-undo-tablet-dark-increased','association-undo-tablet-history-qualified','association-undo-mcp-admission-final-green']:
 packet=compatibility/phase
 candidate=next((packet/name for name in ['current-source-sha256.json','source-sha256.json'] if (packet/name).is_file()),None)
 assert candidate is not None
 hashes=json.loads(candidate.read_text())
 production={path:digest for path,digest in hashes.items() if path.endswith('.swift') and (path.startswith('Planner/') or '/Sources/' in path)}
 differences=[path for path,digest in production.items() if not Path(path).is_file() or hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
 comparisons.append({'epoch':phase,'productionInputs':len(production),'differentProductionPaths':differences})
(validation/'observed-results.json').write_text(json.dumps(rows,indent=2)+'\n')
(validation/'production-source-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
completedCompatibility=[packet for packet in compatibility.glob('association-undo-*') if (packet/'exit.json').is_file()]
paths=sorted(path for directory in [core,*completedCompatibility] for path in directory.rglob('*') if path.is_file() and path.name not in ['evidence-sha256.json','credential-scan.json'])
patterns={
 'githubCredential':rb'gh[pousr]_[A-Za-z0-9]{30,}',
 'privateKey':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'openaiCredential':rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}',
}
findings=[]
for path in paths:
 data=path.read_bytes()
 if path.suffix=='.gz': data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data):findings.append({'path':str(path),'pattern':name})
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(paths),'decompressedGzip':True,'patterns':list(patterns),'findings':findings},indent=2)+'\n')
assert not findings,findings
paths.append(validation/'credential-scan.json')
(validation/'evidence-sha256.json').write_text(json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)},indent=2)+'\n')
print('Indexed',len(rows),'epochs and',len(paths),'files; credential-pattern findings:',len(findings))
