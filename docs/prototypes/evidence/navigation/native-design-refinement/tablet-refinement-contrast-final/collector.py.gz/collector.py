from pathlib import Path
import gzip,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
epoch=repository/'docs/prototypes/evidence/navigation/native-design-refinement'/phase
result=json.loads((epoch/'exit.json').read_text())
output=Path('/private/tmp/PlannerScheduleTimeAttachments-'+phase)
if not (output/'manifest.json').is_file():
 completed=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',result['bundle'],'--output-path',str(output)],capture_output=True,text=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 assert completed.returncode==0,completed.stderr
captures=[]
for group in json.loads((output/'manifest.json').read_text()):
 for attachment in group['attachments']:
  filename=attachment['exportedFileName']
  title=attachment['suggestedHumanReadableName']
  if not title.startswith(("Saved List", "Global completion", "Native row", "Native design", "Native Calendar", "Calendar inspector", "Calendar uses", "Selected Calendar", "New Item draft", "Rich New Item", "Edited Item draft")):continue
  if filename.endswith('.png'):
   shutil.copy2(output/filename,epoch/filename)
  elif filename.endswith('.txt'):
   (epoch/(filename+'.gz')).write_bytes(gzip.compress((output/filename).read_bytes(),mtime=0))
  else:continue
  captures.append({**attachment,'testIdentifier':group['testIdentifier']})
(epoch/'selected-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
(epoch/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
for capture in captures:print(capture['exportedFileName'],capture['suggestedHumanReadableName'])
