from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tarfile,io,shutil
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
platform=sys.argv[2]
assert platform in ['mobile','mac']
packet=repository/'docs/prototypes/evidence/navigation/native-design-refinement'/phase
packet.mkdir(parents=True,exist_ok=False)
root=Path('/private/tmp/PlannerItemWindowCompatibilitySource')
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
root.mkdir(exist_ok=True)
archive=subprocess.check_output(['git','archive',base,'Configuration','Packages','Planner.xcodeproj','Planner','PlannerMCPTests','PlannerFixtures','PlannerFixtureUITests','PlannerNavigationUITests','docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for member in source.getmembers():
        if not member.isfile():continue
        destination=root/member.name
        content=source.extractfile(member).read()
        if destination.is_file() and destination.read_bytes()==content:continue
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(content)
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
overlays=sorted({path for path in changed+new if path.endswith('.swift') and path.startswith(('Planner/','PlannerMCPTests/','PlannerNavigationUITests/','PlannerFixtureUITests/'))})
for path in overlays:
    (root/path).parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(repository/path,root/path)
inputs=sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(packet/'source-root.json').write_text(json.dumps({'root':str(root),'base':base,'overlays':overlays},indent=2)+'\n')
for path in overlays:(packet/(Path(path).name+'.gz')).write_bytes(gzip.compress((root/path).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
destination='generic/platform=iOS Simulator' if platform=='mobile' else 'platform=macOS,arch=arm64'
derived='/private/tmp/PlannerItemWindowCompatibility'+platform+'DerivedData'
if platform=='mac':derived='/private/tmp/PlannerNativeItemWindowDerivedData'
command=['xcodebuild','build-for-testing','-project','Planner.xcodeproj','-scheme','PlannerNavigation','-destination',destination,'-derivedDataPath',derived,'-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1','-only-testing:PlannerNavigationUITests/SavedItemJourneyTests','CODE_SIGNING_ALLOWED=NO','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
if platform=='mac':
    command[command.index('CODE_SIGNING_ALLOWED=NO')]='CODE_SIGNING_ALLOWED=YES'
    command+=['CODE_SIGN_IDENTITY=-','CODE_SIGN_STYLE=Manual','DEVELOPMENT_TEAM=']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerItemWindowsBuild-'+phase+'.log')
with log.open('wb') as output:result=subprocess.run(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'runtimeCredit':False},indent=2)+'\n')
assert all(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
assert all((root/path).read_bytes()==(repository/path).read_bytes() for path in overlays)
print(phase,'exit',result.returncode,'compiler evidence only')
for line in log.read_text().splitlines():
    if line.startswith(('** TEST','** BUILD','error:')) or ('.swift:' in line and ': error:' in line):print(line[:1000])

if result.returncode==0:
    product_root=Path(derived)/'Build/Products'
    products={}
    for candidate in product_root.rglob('*'):
        if not candidate.is_file():continue
        if candidate.name in ['Planner','Planner.debug.dylib','PlannerNavigationUITests-Runner','PlannerNavigationUITests'] or candidate.name.endswith('.xctestrun'):
            products[str(candidate)]=hashlib.sha256(candidate.read_bytes()).hexdigest()
    assert products
    (packet/'product-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
raise SystemExit(result.returncode)
