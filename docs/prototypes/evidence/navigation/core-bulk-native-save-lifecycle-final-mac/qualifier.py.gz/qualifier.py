from pathlib import Path
import gzip
import hashlib
import json
import re

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
root = workspace / 'docs/prototypes/evidence/navigation'
mac = root / 'core-bulk-native-save-lifecycle-final-mac'
mobile = root / 'core-bulk-native-save-lifecycle-final-ios'
red = root / 'core-bulk-native-save-final-red'
mac_execution = json.loads((mac / 'execution.json').read_text())
mobile_execution = json.loads((mobile / 'execution.json').read_text())
assert mac_execution['exitCode'] == mobile_execution['exitCode'] == 0
assert mac_execution['sqliteUnlinkWarnings'] == mobile_execution['sqliteUnlinkWarnings'] == 0
assert mac_execution['frozenInputsUnchanged'] and mobile_execution['frozenInputsUnchanged']
assert len(mac_execution['cases']) == 5
assert all(not case['failures'] and not case['skipped'] for case in mac_execution['cases'])
mobile_tree = json.loads(gzip.decompress((mobile / 'test-results-tests.json.gz').read_bytes()))
mobile_cases = []
def collect(value):
    if isinstance(value, dict):
        if value.get('nodeType') == 'Test Case':
            mobile_cases.append(value)
        for child in value.values():
            collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)
collect(mobile_tree)
assert len(mobile_cases) == 4
assert all(case['result'] == 'Passed' for case in mobile_cases)
mobile_invocations = sum(len([child for child in case.get('children', []) if child.get('nodeType') == 'Arguments']) or 1 for case in mobile_cases)
assert mobile_invocations == 6
mac_log = Path('/private/tmp/PlannerImportLifetime-core-bulk-native-save-lifecycle-final-mac.log').read_text()
mac_parameters = re.findall(r'^◇ Test case passing .+ to (\S+) started\.$', mac_log, re.MULTILINE)
mac_invocations = len(mac_execution['cases']) - len(set(mac_parameters)) + len(mac_parameters)
assert mac_invocations == 7
child_log = Path(re.search(r'^Bulk isolated write-fault child log: (.+)$', mac_log, re.MULTILINE).group(1))
child_content = child_log.read_text()
assert 'Test run with 1 test in 1 suite passed' in child_content
assert child_content.count('SwiftData.DefaultStore save failed with error:') == 3
assert 'vnode unlinked while in use' not in child_content
(mac / 'isolated-child.log.gz').write_bytes(gzip.compress(child_log.read_bytes(), mtime=0))
mac_sources = json.loads((mac / 'source-sha256.json').read_text())
mobile_sources = json.loads((mobile / 'source-sha256.json').read_text())
assert len(mac_sources) == 740
assert len(mobile_sources) == 1062
for name, digest in mac_sources.items():
    assert hashlib.sha256((workspace / name).read_bytes()).hexdigest() == digest, name
    assert mobile_sources[name] == digest, name
for name, digest in mobile_sources.items():
    assert hashlib.sha256((workspace / name).read_bytes()).hexdigest() == digest, name
red_execution = json.loads((red / 'execution.json').read_text())
assert red_execution['exitCode'] != 0 and len(red_execution['cases']) == 1
red_sources = json.loads((red / 'source-sha256.json').read_text())
test_name = 'Packages/PlannerCore/Tests/PlannerCoreStoreTests/BulkCompletionAdmissionTests.swift'
assert mac_sources[test_name] == red_sources[test_name]
assert 'A known failed bulk save must discard its prepared evidence: .preparedUnverified' in gzip.decompress((red / 'test.log.gz').read_bytes()).decode()
products_directory = Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products')
products = {str(candidate): hashlib.sha256(candidate.read_bytes()).hexdigest() for candidate in products_directory.rglob('*') if candidate.is_file() and candidate.name in ['Planner', 'Planner.debug.dylib', 'PlannerCoreTests', 'PlannerCoreStoreTests']}
assert any(Path(name).name == 'PlannerCoreStoreTests' for name in products)
(mobile / 'product-sha256.json').write_text(json.dumps(products, indent=2) + '\n')
for name, digest in json.loads((mac / 'product-sha256.json').read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
cleanup = {}
for name, packet, expected in [('mac', mac, 9), ('iPhoneSimulator', mobile, 6)]:
    lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] and len(lifecycle['removedDirectories']) == expected
    cleanup[name] = expected
report = {'mac': {'functions': 5, 'topLevelExecutions': mac_invocations, 'additionalIsolatedChildFunctions': 1, 'scopesCheckedSequentiallyInChild': ['list', 'itinerary', 'itineraryListEntry']}, 'iPhoneSimulator': {'functions': 4, 'executions': mobile_invocations, 'genuineFilesystemFaultExecuted': False}, 'matchingCoreInputs': len(mac_sources), 'matchingNativeInputs': len(mobile_sources), 'unchangedFinalRegressionFailsPreFix': True, 'sqliteUnlinkWarnings': 0, 'removedMarkedFixtures': cleanup, 'productionFilesChanged': ['Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift'], 'nativeUiOrPhysicalCredit': False}
(mac / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
(mac / 'qualifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps(report))
