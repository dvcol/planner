import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItemIntentTests: XCTestCase {
  func testCreateIntentReturnsTheSingleSavedIdentityAndPreservesContentAndRecoveryAfterReopen()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerItemIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let store = SavedPlannerStore(configuration: configuration)
    AppDependencyManager.shared.add(dependency: store)
    var intent = CreatePlannerItemIntent()
    intent.title = "Train tickets"
    intent.notes = "Collect at the station"
    let created = try await intent.callAsFunction(donate: false)
    XCTAssertEqual(created.title, "Train tickets")
    XCTAssertFalse(created.done)
    XCTAssertFalse(created.archived)
    XCTAssertTrue(store.isReady)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: created.id))),
      case .snapshot(let items) = await reopened.query(
        .init(session: session, request: .items(.init(completion: .all, archive: .all)))),
      case .status(let status) = await reopened.read(session: session, request: .status)
    else { return XCTFail("The returned Item must be readable from reopened real storage.") }
    XCTAssertEqual(items.rows, [.source(saved.source)])
    XCTAssertEqual(saved.source.id, created.id)
    XCTAssertEqual(saved.content.title, "Train tickets")
    XCTAssertEqual(saved.content.notes, "Collect at the station")
    guard case .known(let checkpoint, let incomplete, let blocked) = status.recovery else {
      return XCTFail("The actual recovery status must remain available.")
    }
    XCTAssertNotNil(checkpoint)
    XCTAssertTrue(incomplete.isEmpty)
    XCTAssertFalse(blocked)
  }
}
