import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryItemIntentTests: XCTestCase {
  func testGetRetainsExactRepeatedDirectAppearanceAndReturnsLiveLocalState() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Hotel", notes: "Shared notes")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    let firstEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    let secondEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let firstIdentifier, _, _)? = firstEntry.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondEntry.generatedReferences.first
    else { return XCTFail("Repeated Item stops must have distinct saved entry identities.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .directItineraryItem(itineraryId: itinerary.id, entryId: secondIdentifier)),
        done: true))
    let firstIdentity = "v1/direct/\(itinerary.id)/\(firstIdentifier)/\(item.id)"
    let secondIdentity = "v1/direct/\(itinerary.id)/\(secondIdentifier)/\(item.id)"
    let reading = GetPlannerItineraryItemIntent()
    reading.itinerary = .init(id: itinerary.id, title: "Cached route", archived: true)
    reading.item = .init(
      id: secondIdentity, title: "Cached Hotel", context: "Cached position", globallyDone: true,
      locallyDone: false, done: false, archived: true)
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, secondIdentity)
    XCTAssertEqual(current.title, "Hotel")
    XCTAssertEqual(current.context, "Tokyo Weekend · Stop 2")
    XCTAssertFalse(current.globallyDone)
    XCTAssertTrue(current.locallyDone)
    XCTAssertTrue(current.done)
    XCTAssertFalse(current.archived)
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [secondIdentity, firstIdentity, secondIdentity])
    XCTAssertEqual(resolved.map(\.id), [secondIdentity, firstIdentity])
    XCTAssertEqual(resolved.map(\.context), ["Tokyo Weekend · Stop 2", "Tokyo Weekend · Stop 1"])
    XCTAssertEqual(resolved.map(\.locallyDone), [true, false])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
