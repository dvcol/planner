from pathlib import Path
import json,os,sqlite3,subprocess,tempfile,uuid
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
verifier=repository/'scripts/verify-intent-fixtures.py'
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/app-intent-fixture-cleanup-final-qualified'
completed=subprocess.Popen(['/usr/bin/true'])
completed.wait()
closed_identifier=completed.pid
results=[]
with tempfile.TemporaryDirectory(prefix='PlannerIntentFixtureSafety-',dir='/private/tmp') as temporary:
    root=Path(temporary)
    def fixture(parent='PlannerIntentFixtures',identifier=closed_identifier):
        directory=root/parent/str(uuid.uuid4())
        directory.mkdir(parents=True)
        record={'formatVersion':1,'directory':str(directory),'hostProcessIdentifier':identifier}
        (directory/'.planner-intent-fixture.json').write_text(json.dumps(record))
        (directory/'sentinel').write_text('Preserve unless verified for cleanup.')
        return directory,record
    def run(name,records,preserved,error=None,extra=''):
        log=root/(name+'.log')
        content='\n'.join('PLANNER_INTENT_FIXTURE '+json.dumps(record) for record in records)
        content+="\nTest Suite 'Selected tests' passed at 2026-10-20 00:00:00.\n\t Executed 1 test, with 0 failures\n** TEST SUCCEEDED **\n"+extra
        log.write_text(content)
        report=root/(name+'.json')
        execution=subprocess.run(['python3',str(verifier),str(log),'--report',str(report)],capture_output=True,text=True)
        observed=json.loads(report.read_text())
        if error is None:
            assert execution.returncode==0 and observed['success'],observed
            assert len(observed['removedDirectories'])==len(records)
            assert all(not Path(record['directory']).exists() for record in records)
        else:
            assert execution.returncode==1 and not observed['success'],observed
            assert error in observed['error'],observed
            assert observed['removedDirectories']==[]
            assert all((directory/'sentinel').read_text()=='Preserve unless verified for cleanup.' for directory in preserved)
        results.append({'name':name,'passed':True,'expectedRejection':error is not None})
    directory,record=fixture()
    run('diagnostic-log',[record],[directory],'SQLite lifetime diagnostics',extra='vnode unlinked while in use\n')
    directory,record=fixture()
    run('failed-run',[record],[directory],'successful completed XCTest',extra='** TEST FAILED **\n')
    directory,record=fixture(identifier=os.getpid())
    run('live-recorded-host',[record],[directory],'still alive')
    directory,record=fixture()
    database=directory/'store/Planner.sqlite'
    database.parent.mkdir()
    connection=sqlite3.connect(database)
    connection.execute('CREATE TABLE guard_check(value TEXT)')
    connection.commit()
    try:run('another-open-database-owner',[record],[directory],'Database handles remain open')
    finally:connection.close()
    directory,record=fixture(parent='OutsideOwnedNamespace')
    run('unowned-path',[record],[directory],'outside the disposable')
    directory,record=fixture()
    changed=dict(record,hostProcessIdentifier=os.getpid())
    run('mismatched-ownership',[changed],[directory],'ownership marker')
    directory,record=fixture()
    target=root/'outside-symlink-target'
    target.mkdir()
    (target/'sentinel').write_text('Preserve unless verified for cleanup.')
    link=directory.parent/str(uuid.uuid4())
    link.symlink_to(target,target_is_directory=True)
    linked=dict(record,directory=str(link))
    run('symlink-path',[linked],[target],'not a symlink')
    valid,valid_record=fixture()
    invalid,invalid_record=fixture(parent='OutsideOwnedNamespace')
    run('validate-all-before-removing-any',[valid_record,invalid_record],[valid,invalid],'outside the disposable')
    directory,record=fixture()
    run('closed-owned-fixture',[record],[])
    for name,mode in [('source-log-report','source'),('hardlinked-log-report','hardlink'),('fixture-internal-report','inside')]:
        directory,record=fixture()
        log=root/(name+'.log')
        log.write_text('PLANNER_INTENT_FIXTURE '+json.dumps(record)+"\nTest Suite 'Selected tests' passed at 2026-10-20.\nExecuted 1 test, with 0 failures\n** TEST SUCCEEDED **\n")
        before=log.read_bytes()
        ownership=(directory/'.planner-intent-fixture.json').read_bytes()
        if mode=='source': report_path=log
        elif mode=='hardlink':
            report_path=root/(name+'.json')
            report_path.hardlink_to(log)
        else: report_path=directory/'forbidden-report.json'
        execution=subprocess.run(['python3',str(verifier),str(log),'--report',str(report_path)],capture_output=True,text=True)
        observed=json.loads(execution.stdout)
        assert execution.returncode==1 and not observed['success'],observed
        assert observed['removedFixtures']==0
        assert log.read_bytes()==before
        assert (directory/'.planner-intent-fixture.json').read_bytes()==ownership
        assert (directory/'sentinel').exists()
        if mode=='inside':assert not report_path.exists()
        results.append({'name':name,'passed':True,'expectedRejection':True})
report={'evidenceKind':'controlled CLI filesystem/process safety checks','appIntentExecutionCredit':False,'passedChecks':len(results),'checks':results}
(packet/'verifier-safety-checks-final.json').write_text(json.dumps(report,indent=2)+'\n')
print({'controlledChecksPassed':len(results),'appIntentExecutionCredit':False})
