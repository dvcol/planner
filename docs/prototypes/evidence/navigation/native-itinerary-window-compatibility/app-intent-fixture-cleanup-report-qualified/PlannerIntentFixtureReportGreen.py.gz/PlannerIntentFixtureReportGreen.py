from pathlib import Path
import json,os,subprocess,tempfile,uuid
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/app-intent-fixture-cleanup-final-qualified'
process=subprocess.Popen(['/usr/bin/true']); process.wait()
with tempfile.TemporaryDirectory(prefix='PlannerIntentFixtureReportRed-',dir='/private/tmp') as temporary:
    root=Path(temporary)
    directory=root/'PlannerIntentFixtures'/str(uuid.uuid4()); directory.mkdir(parents=True)
    record={'formatVersion':1,'directory':str(directory),'hostProcessIdentifier':process.pid}
    (directory/'.planner-intent-fixture.json').write_text(json.dumps(record))
    (directory/'sentinel').write_text('preserve')
    log=root/'run.log'
    log.write_text('PLANNER_INTENT_FIXTURE '+json.dumps(record)+"\nTest Suite 'Selected tests' passed at 2026-10-20.\nExecuted 1 test, with 0 failures\n** TEST SUCCEEDED **\n")
    blocker=root/'report-parent'; blocker.write_text('Not a directory')
    result=subprocess.run(['python3',str(repository/'scripts/verify-intent-fixtures.py'),str(log),'--report',str(blocker/'report.json')],capture_output=True,text=True)
    observed={'evidenceKind':'controlled CLI reporting failure','appIntentExecutionCredit':False,'exitCode':result.returncode,'fixturePreserved':directory.exists(),'reportCreated':(blocker/'report.json').exists()}
    (packet/'reporting-failure-green.json').write_text(json.dumps(observed,indent=2)+'\n')
    print(observed)
    assert directory.exists(),'A failed report preflight must preserve disposable fixtures.'
