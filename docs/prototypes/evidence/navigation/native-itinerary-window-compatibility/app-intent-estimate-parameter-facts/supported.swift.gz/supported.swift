import AppIntents
import Foundation

enum PlanningDurationUnit: String, AppEnum {
  case minute, hour, day, week, month, year
  static let typeDisplayRepresentation: TypeDisplayRepresentation = "Duration unit"
  static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
    .minute: "Minutes", .hour: "Hours", .day: "Days", .week: "Weeks", .month: "Months", .year: "Years"
  ]
}
struct DurationParameterProbe: AppIntent {
  static let title: LocalizedStringResource = "Probe"
  func perform() async throws -> some IntentResult { .result() }
  @Parameter(title: "Measurement", defaultUnit: .minutes, supportsNegativeNumbers: false)
  var measurement: Measurement<UnitDuration>
  @Parameter(title: "Components", kind: .time)
  var components: DateComponents
  @Parameter(title: "Duration", defaultUnit: .minutes)
  var duration: Duration
  @Parameter(title: "Quantity", inclusiveRange: (1, 9_223_372_036_854_775_807))
  var quantity: Int
  @Parameter(title: "Unit")
  var unit: PlanningDurationUnit
}
let mixedDuration = Measurement(value: 1.5, unit: UnitDuration.hours).converted(to: .minutes)
let maximumInteger = Int64.max
let maximumDouble = Double(maximumInteger)
let maximumMinusOneDouble = Double(maximumInteger - 1)
let wholeMinuteDouble = Double(9_007_199_254_740_993 as Int64)
print("measurementUnits", IntentParameter<Measurement<UnitDuration>>.Duration.allCases)
print("durationUnits", IntentParameter<Duration>.DurationUnit.allCases.map(\.rawValue))
print("mixed90Minutes", mixedDuration.value)
print("DoubleInt64Max", maximumDouble, "exactInt64", Int64(exactly: maximumDouble) as Any)
print("DoubleAdjacentMaxDistinct", maximumDouble != maximumMinusOneDouble)
print("Beyond2Pow53", wholeMinuteDouble, Int64(exactly: wholeMinuteDouble) as Any)
print("nativeIntBits", Int.bitWidth, Int.max)
print("durationWholeMinutes", Duration.seconds(5_400).components)

print("durationMaxWholeMinutes", Int128.max / 60_000_000_000_000_000_000)
print("CoreMaxMinutes", Int64.max)
print("equalDifferentDurationConstruction", Duration.seconds(5_400) == Duration.seconds(90 * 60))
