#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  enum PlannerItemFindCompletion: String, AppEnum, CaseIterable {
    case all, todo, done
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Item completion filter")
    static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
      .all: .init(title: "All"), .todo: .init(title: "Todo"), .done: .init(title: "Done"),
    ]

    var queryValue: PlannerItemQuery.Completion {
      switch self {
      case .all: .all
      case .todo: .todo
      case .done: .done
      }
    }
  }

  enum PlannerItemFindArchive: String, AppEnum, CaseIterable {
    case all, active, archived
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Item archive filter")
    static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
      .all: .init(title: "All"), .active: .init(title: "Active"),
      .archived: .init(title: "Archived"),
    ]

    var queryValue: PlannerItemQuery.Archive {
      switch self {
      case .all: .all
      case .active: .active
      case .archived: .archived
      }
    }
  }

  struct FindPlannerItemsIntent: AppIntent {
    static let title: LocalizedStringResource = "Find Planner Items"
    static let description = IntentDescription(
      "Find shared Items with cumulative criteria. Completion is the Item's global state.")
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Search text", default: "") var text: String
    @Parameter(title: "Completion", default: .all) var completion: PlannerItemFindCompletion
    @Parameter(title: "Archive", default: .all) var archive: PlannerItemFindArchive
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<[PlannerItemEntity], Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      let query = PlannerItemEntityQuery()
      query.plannerStore = plannerStore
      let items = try await query.loadItems(
        query: .init(text: text, completion: completion.queryValue, archive: archive.queryValue))
      return .result(value: items)
    }
  }
#endif
