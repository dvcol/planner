import PlannerCore
import PlannerPreviews
import SwiftUI

extension PlannerOwnedLinkRead {
  var editInput: PlannerLinkInput {
    PlannerLinkInput(linkId: linkId, originalUrl: originalUrl, label: label)
  }

  var displayTitle: String {
    if let label, !label.isEmpty { return label }
    return URL(string: originalUrl)?.host() ?? originalUrl
  }

  var systemImage: String {
    if kind == .appleMaps || kind == .googleMaps { return "map" }
    return "link"
  }
}

struct ItemLinksSection: View {
  let links: [PlannerOwnedLinkRead]
  let source: PlannerEntityReference
  let sourceLifetimeId: UUID
  var appearance: PlannerAppearance?
  @Environment(SavedPlannerStore.self) private var store
  @Environment(\.openURL) private var openURL
  @Environment(\.savedWebsiteOpening) private var openWebsite

  var body: some View {
    if !links.isEmpty {
      Section("Links") {
        ForEach(links, id: \.linkId) { link in
          if let destination = URL(string: link.originalUrl) {
            Link(destination: destination) {
              Label(link.displayTitle, systemImage: link.systemImage)
            }
            .contextMenu {
              Button("Open in default browser", systemImage: "arrow.up.right.square") {
                openURL(destination)
              }
            }
            .help(link.originalUrl)
            .accessibilityLabel(link.displayTitle)
            .accessibilityValue(link.originalUrl)
            .accessibilityIdentifier("saved.item.link.\(link.linkId.uuidString)")
            if link.kind != .appleMaps && link.kind != .googleMaps,
              let namespace = store.devicePreferenceNamespace
            {
              ItemLinkPreviewCard(
                link: link,
                request: .init(
                  source: .init(
                    namespace: namespace, sourceId: source.id,
                    sourceLifetimeId: sourceLifetimeId),
                  linkId: link.linkId, originalURL: link.originalUrl))
            }
          }
        }
      }
      .environment(
        \.openURL,
        OpenURLAction { destination in
          guard let openWebsite, let namespace = store.devicePreferenceNamespace,
            let link = links.first(where: { $0.originalUrl == destination.absoluteString }),
            link.kind != .appleMaps, link.kind != .googleMaps,
            ["http", "https"].contains(destination.scheme?.lowercased() ?? "")
          else { return .systemAction }
          openWebsite(
            .init(
              destination: destination, linkIdentifier: link.linkId, source: source,
              sourceLifetimeIdentifier: sourceLifetimeId, appearance: appearance,
              namespace: namespace))
          return .handled
        })
    }
  }
}
