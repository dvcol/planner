from pathlib import Path
import gzip,hashlib,importlib.util,json,shutil,sys,uuid
sys.dont_write_bytecode=True
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-plan-opening-direct-module-green'
log=Path('/private/tmp/PlannerItemWindow-native-plan-opening-direct-module-green.log').read_text()
assert 'Executed 13 tests, with 0 failures' in log and "Test Suite 'Selected tests' passed" in log
specification=importlib.util.spec_from_file_location('planner_fixture_verifier',repository/'scripts/verify-intent-fixtures.py')
verifier=importlib.util.module_from_spec(specification);specification.loader.exec_module(verifier)
records={}
for line in log.splitlines():
    if 'PLANNER_INTENT_FIXTURE ' not in line:continue
    record,_=json.JSONDecoder().raw_decode(line.split('PLANNER_INTENT_FIXTURE ',1)[1])
    assert set(record)=={'formatVersion','directory','hostProcessIdentifier'} and record['formatVersion']==1
    original=Path(record['directory']);canonical=original.resolve(strict=True)
    assert str(original).startswith('/var/folders/') and str(canonical)=='/private'+str(original)
    assert canonical.parent.name=='PlannerIntentFixtures' and not original.is_symlink() and not canonical.is_symlink()
    uuid.UUID(canonical.name)
    marker=canonical/'.planner-intent-fixture.json'
    assert not marker.is_symlink() and json.loads(marker.read_text())==record
    assert canonical not in records or records[canonical]==record
    records[canonical]=record
assert len(records)==17
hosts=verifier.require_closed_hosts(records)
verifier.require_closed_databases(records)
report={'standardVerifierOutcome':'rejected noncanonical Foundation /var alias; original failure retained','testResult':'13 passing tests','aliasRule':'Only /var/folders to /private/var/folders; no leaf or ownership symlinks','hostProcessIdentifiers':hosts,'removedCanonicalDirectories':[]}
for directory,record in records.items():
    assert directory==directory.resolve(strict=True) and not directory.is_symlink()
    assert json.loads((directory/'.planner-intent-fixture.json').read_text())==record
    shutil.rmtree(directory)
    report['removedCanonicalDirectories'].append(str(directory))
(packet/'canonical-fixture-disposition.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'canonical-fixture-disposition.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Disposed',len(records),'closed owned fixtures through canonical paths; strict verifier failure remains recorded.')
