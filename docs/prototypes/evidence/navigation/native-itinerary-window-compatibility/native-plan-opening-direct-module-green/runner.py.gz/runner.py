from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
phase=sys.argv[1]
packet=Path('docs/prototypes/evidence/navigation/native-itinerary-window-compatibility')/phase
packet.mkdir(parents=True,exist_ok=False)
products=Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug')
bundle=products/'Planner.app/Contents/PlugIns/PlannerMCPTests.xctest'
library=products/'Planner.app/Contents/MacOS/Planner.debug.dylib'
assert bundle.is_dir() and library.is_file()
compiled=Path(sys.argv[2])
source_hashes=json.loads((compiled/'source-sha256.json').read_text())
source_inputs=source_hashes
assert all(Path(name).is_file() and hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in source_inputs.items())
(packet/'build-link.json').write_text(json.dumps({'compiledEpoch':str(compiled),'base':json.loads((compiled/'source-root.json').read_text())['base']},indent=2)+'\n')
(packet/'source-sha256.json').write_text(json.dumps(source_inputs,indent=2)+'\n')
selection='PlannerMCPTests.SavedPlanOpeningTests'
if len(sys.argv)>3: selection += '/'+sys.argv[3]
command=['/Applications/Xcode.app/Contents/Developer/usr/bin/xctest','-XCTest',selection,str(bundle)]
environment={key:os.environ[key] for key in ['PATH','HOME','TMPDIR','USER','LOGNAME','LANG','SHELL'] if key in os.environ}
environment.update(DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',DYLD_INSERT_LIBRARIES=str(library),DYLD_FRAMEWORK_PATH=str(products)+':/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/Library/Frameworks',DYLD_LIBRARY_PATH=str(products))
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
(packet/'environment-keys.json').write_text(json.dumps(sorted(environment),indent=2)+'\n')
(packet/'products.json').write_text(json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [library,bundle/'Contents/MacOS/PlannerMCPTests',Path('/Applications/Xcode.app/Contents/Developer/usr/bin/xctest')]},indent=2)+'\n')
try:
 result=subprocess.run(command,env=environment,capture_output=True,timeout=180)
 output=result.stdout+result.stderr
 outcome={'exitCode':result.returncode,'timedOut':False}
except subprocess.TimeoutExpired as error:
 output=(error.stdout or b'')+(error.stderr or b'')
 outcome={'exitCode':None,'timedOut':True}
assert b'ghp_' not in output and b'GIT_CREDENTIALS' not in output
(packet/'test.log.gz').write_bytes(gzip.compress(output,mtime=0))
(packet/'exit.json').write_text(json.dumps(outcome,indent=2)+'\n')
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in source_inputs.items())
product_hashes=json.loads((packet/'products.json').read_text())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in product_hashes.items())
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
Path('/private/tmp/PlannerItemWindow-'+phase+'.log').write_bytes(output)
for line in output.decode(errors='replace').splitlines():
 if line.startswith(('Test Case ', 'Test Suite ', '\t Executed')) or ': error:' in line: print(line[:700])
print(outcome)

raise SystemExit(outcome['exitCode'] if outcome['exitCode'] is not None else 124)
