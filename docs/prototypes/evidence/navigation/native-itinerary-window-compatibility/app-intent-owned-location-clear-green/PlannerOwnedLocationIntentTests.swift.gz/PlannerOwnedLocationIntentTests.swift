import AppIntents
import CoreLocation
import Foundation
import GeoToolbox
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerOwnedLocationIntentTests: XCTestCase {
  func testItemLocationTextEditKeepsItsPinAndOtherPlanningDataAfterReopen() async throws {
    let fixture = try await makeOwnedLocationIntentFixture()
    let before = try await readOwnedLocationSources(fixture)
    let editing = EditPlannerItemLocationIntent()
    editing.item = .init(id: fixture.item.id, title: "Cached title", done: true, archived: true)
    editing.placeName = "  Musée · 東京  "
    editing.address = "New authored address"
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readOwnedLocationSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(
      after.item.content.location,
      .init(
        displayName: "  Musée · 東京  ", formattedAddress: "New authored address",
        coordinate: .init(latitude: 35.6622, longitude: 139.7171)))
    assertOwnedLocationPreservesOtherData(before, after, changedKind: .item)
    try await assertOwnedLocationPlanningContexts(fixture, planner: reopened, session: session)
  }

  func testItineraryTextAndExplicitPinRemovalKeepItemLocationAndRouteState() async throws {
    let fixture = try await makeOwnedLocationIntentFixture()
    let before = try await readOwnedLocationSources(fixture)
    let editing = EditPlannerItineraryLocationIntent()
    editing.itinerary = .init(id: fixture.itinerary.id, title: "Cached route", archived: true)
    editing.address = "  Rendez-vous · vendredi  "
    editing.removeSavedPin = true
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readOwnedLocationSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(
      after.itinerary.content.location,
      .init(
        displayName: "Meeting point", formattedAddress: "  Rendez-vous · vendredi  ",
        coordinate: nil))
    assertOwnedLocationPreservesOtherData(before, after, changedKind: .itinerary)
    try await assertOwnedLocationPlanningContexts(fixture, planner: reopened, session: session)
  }

  func testNativePinInputKeepsAuthoredItemTextAndIgnoresDescriptorAddressAndName() async throws {
    let fixture = try await makeOwnedLocationIntentFixture()
    let before = try await readOwnedLocationSources(fixture)
    let setting = SetPlannerItemLocationPinIntent()
    setting.item = .init(id: fixture.item.id, title: "Cached title", done: true, archived: true)
    setting.location = PlaceDescriptor(
      representations: [
        .coordinate(.init(latitude: 51.5, longitude: -0.12)),
        .address("Provider address must not be adopted"),
      ], commonName: "Provider name must not be adopted")
    let _: Void = try await setting.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readOwnedLocationSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(
      after.item.content.location,
      .init(
        displayName: "Saved place",
        formattedAddress: "Original address", coordinate: .init(latitude: 51.5, longitude: -0.12)))
    assertOwnedLocationPreservesOtherData(before, after, changedKind: .item)
    try await assertOwnedLocationPlanningContexts(fixture, planner: reopened, session: session)
  }

  func testItineraryPinAcceptsMatchingDeviceAndCoordinatePointsWithoutChangingItemPin() async throws
  {
    let fixture = try await makeOwnedLocationIntentFixture()
    let before = try await readOwnedLocationSources(fixture)
    let setting = SetPlannerItineraryLocationPinIntent()
    setting.itinerary = .init(id: fixture.itinerary.id, title: "Cached route", archived: true)
    setting.location = PlaceDescriptor(
      representations: [
        .deviceLocation(CLLocation(latitude: -33.86, longitude: 151.2)),
        .coordinate(.init(latitude: -33.86, longitude: 151.2)),
      ], commonName: "Ignore provider name")
    let _: Void = try await setting.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readOwnedLocationSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(
      after.itinerary.content.location,
      .init(
        displayName: "Meeting point",
        formattedAddress: "Meeting address", coordinate: .init(latitude: -33.86, longitude: 151.2)))
    assertOwnedLocationPreservesOtherData(before, after, changedKind: .itinerary)
    try await assertOwnedLocationPlanningContexts(fixture, planner: reopened, session: session)
  }
  func testClearingOwnedLocationsRetainsOriginalLinksAndAllPlanningContextsAfterReopen()
    async throws
  {
    let fixture = try await makeOwnedLocationIntentFixture()
    let before = try await readOwnedLocationSources(fixture)
    let itemClearing = ClearPlannerItemLocationIntent()
    itemClearing.item = .init(
      id: fixture.item.id, title: "Cached title", done: true, archived: true)
    let _: Void = try await itemClearing.callAsFunction(donate: false)
    let _: Void = try await itemClearing.callAsFunction(donate: false)
    let afterItem = try await readOwnedLocationSources(fixture)
    XCTAssertNil(afterItem.item.content.location)
    XCTAssertEqual(
      afterItem.item.content.links.first?.originalUrl,
      "https://www.google.com/maps/search/?api=1&query=35.6622,139.7171")
    assertOwnedLocationPreservesOtherData(before, afterItem, changedKind: .item)
    let itineraryClearing = ClearPlannerItineraryLocationIntent()
    itineraryClearing.itinerary = .init(
      id: fixture.itinerary.id, title: "Cached route", archived: true)
    let _: Void = try await itineraryClearing.callAsFunction(donate: false)
    let _: Void = try await itineraryClearing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readOwnedLocationSources(fixture, planner: reopened, session: session)
    XCTAssertNil(after.item.content.location)
    XCTAssertNil(after.itinerary.content.location)
    XCTAssertEqual(after.itinerary.content.links.first?.originalUrl, "https://example.com/route")
    assertOwnedLocationPreservesOtherData(afterItem, after, changedKind: .itinerary)
    try await assertOwnedLocationPlanningContexts(fixture, planner: reopened, session: session)
  }
}

private struct OwnedLocationIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let list: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let appearances: [PlannerAppearance]
  let schedules: [PlannerEntityReference]
}

private struct OwnedLocationSourceObservations {
  let item: PlannerItemSourceRead
  let list: PlannerListSourceRead
  let itinerary: PlannerItinerarySourceRead
}

@MainActor
private func makeOwnedLocationIntentFixture() async throws -> OwnedLocationIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }
  let category = try await save(.createCategory(content: .init(name: "Museum")))
  let tag = try await save(.createTag(content: .init(name: "Rainy day")))
  let categoryIdentifier = try XCTUnwrap(category.generated.first?.id)
  let tagIdentifier = try XCTUnwrap(tag.generated.first?.id)
  let createdItem = try await save(
    .createItem(
      content: .init(
        title: "Museum", subtitle: "Booking", notes: "Keep notes",
        location: .init(
          displayName: "Saved place", formattedAddress: "Original address",
          coordinate: .init(latitude: 35.6622, longitude: 139.7171)),
        estimate: .init(minutes: 125, displayUnit: .hour),
        links: [
          .init(
            originalUrl: "https://www.google.com/maps/search/?api=1&query=35.6622,139.7171",
            label: "Original Maps link"),
          .init(originalUrl: "https://example.com/museum", label: "Guide"),
        ],
        categoryIds: [categoryIdentifier], tagIds: [tagIdentifier])))
  let item = try XCTUnwrap(createdItem.generated.first)
  let createdList = try await save(.createList(content: .init(name: "Wishlist")))
  let list = try XCTUnwrap(createdList.generated.first)
  let membership = try await save(
    .addMembership(itemId: item.id, listId: list.id, placement: .last))
  guard case .membership(let membershipIdentifier, _, _)? = membership.generatedReferences.first
  else { throw CancellationError() }
  let createdItinerary = try await save(
    .createItinerary(
      content: .init(
        title: "Weekend", notes: "Keep route notes",
        location: .init(
          displayName: "Meeting point", formattedAddress: "Meeting address",
          coordinate: .init(latitude: 48.8584, longitude: 2.2945)),
        links: [.init(originalUrl: "https://example.com/route", label: "Route")],
        categoryIds: [categoryIdentifier], tagIds: [tagIdentifier],
        manualEstimate: .init(minutes: 480, displayUnit: .hour))))
  let itinerary = try XCTUnwrap(createdItinerary.generated.first)
  var appearances = [
    PlannerAppearance.listMembership(listId: list.id, membershipId: membershipIdentifier)
  ]
  for _ in 0..<2 {
    let added = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let entryIdentifier, _, _)? = added.generatedReferences.first
    else { throw CancellationError() }
    appearances.append(.directItineraryItem(itineraryId: itinerary.id, entryId: entryIdentifier))
  }
  for appearance in appearances.prefix(2) {
    _ = try await save(.setCompletion(scope: .appearance(appearance), done: true))
  }
  var schedules: [PlannerEntityReference] = []
  for (source, form) in [
    (
      item,
      PlannerScheduleForm.timed(
        start: Date(timeIntervalSinceReferenceDate: 814_000_000),
        end: Date(timeIntervalSinceReferenceDate: 814_007_200), planningTimeZone: "Asia/Tokyo")
    ),
    (
      itinerary,
      .allDay(
        start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    ),
  ] {
    let created = try await save(.createSchedule(source: source, form: form))
    schedules.append(try XCTUnwrap(created.generated.first))
  }
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    item: item, list: list, itinerary: itinerary, appearances: appearances, schedules: schedules)
}

@MainActor
private func readOwnedLocationSources(
  _ fixture: OwnedLocationIntentFixture,
  planner: PlannerCore.Planner? = nil, session: PlannerDatasetSession? = nil
) async throws -> OwnedLocationSourceObservations {
  let planner = planner ?? fixture.planner
  let session = session ?? fixture.session
  guard
    case .source(.item(let item)) = await planner.read(
      session: session, request: .source(fixture.item)),
    case .source(.list(let list)) = await planner.read(
      session: session, request: .source(fixture.list)),
    case .source(.itinerary(let itinerary)) = await planner.read(
      session: session, request: .source(fixture.itinerary))
  else { throw CancellationError() }
  return .init(item: item, list: list, itinerary: itinerary)
}

@MainActor
private func assertOwnedLocationPreservesOtherData(
  _ before: OwnedLocationSourceObservations,
  _ after: OwnedLocationSourceObservations, changedKind: PlannerEntityKind?
) {
  let ignoredItemFields: Set<PlannerItemField> = changedKind == .item ? [.location] : []
  let ignoredItineraryFields: Set<PlannerItineraryField> =
    changedKind == .itinerary ? [.location] : []
  XCTAssertEqual(
    after.item.fieldHashes.filter { !ignoredItemFields.contains($0.key) },
    before.item.fieldHashes.filter { !ignoredItemFields.contains($0.key) })
  XCTAssertEqual(
    after.itinerary.fieldHashes.filter { !ignoredItineraryFields.contains($0.key) },
    before.itinerary.fieldHashes.filter { !ignoredItineraryFields.contains($0.key) })
  XCTAssertEqual(after.list.fieldHashes, before.list.fieldHashes)
  XCTAssertEqual(after.list.updatedAt, before.list.updatedAt)
  XCTAssertEqual(after.item.sourceLifetimeId, before.item.sourceLifetimeId)
  XCTAssertEqual(after.itinerary.sourceLifetimeId, before.itinerary.sourceLifetimeId)
  XCTAssertEqual(after.item.createdAt, before.item.createdAt)
  XCTAssertEqual(after.itinerary.createdAt, before.itinerary.createdAt)
  XCTAssertEqual(after.item.references, before.item.references)
  XCTAssertEqual(after.list.references, before.list.references)
  XCTAssertEqual(after.itinerary.references, before.itinerary.references)
  XCTAssertEqual(after.item.state.globalDone, before.item.state.globalDone)
  XCTAssertEqual(after.item.state.archived, before.item.state.archived)
  XCTAssertEqual(after.itinerary.state.archived, before.itinerary.state.archived)
  if changedKind != .item { XCTAssertEqual(after.item.updatedAt, before.item.updatedAt) }
  if changedKind != .itinerary {
    XCTAssertEqual(after.itinerary.updatedAt, before.itinerary.updatedAt)
  }
}

@MainActor
private func assertOwnedLocationPlanningContexts(
  _ fixture: OwnedLocationIntentFixture,
  planner: PlannerCore.Planner, session: PlannerDatasetSession
) async throws {
  for (index, appearance) in fixture.appearances.enumerated() {
    guard
      case .appearance(let saved) = await planner.read(
        session: session, request: .appearance(appearance))
    else { return XCTFail("Location editing must retain each independent appearance.") }
    XCTAssertFalse(saved.globalDone)
    XCTAssertEqual(saved.localDone, index < 2)
  }
  let forms: [PlannerScheduleForm] = [
    .timed(
      start: Date(timeIntervalSinceReferenceDate: 814_000_000),
      end: Date(timeIntervalSinceReferenceDate: 814_007_200), planningTimeZone: "Asia/Tokyo"),
    .allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21)),
  ]
  for (index, schedule) in fixture.schedules.enumerated() {
    guard
      case .source(.schedule(let saved)) = await planner.read(
        session: session, request: .source(schedule))
    else { return XCTFail("Location editing must retain booked Schedules.") }
    XCTAssertEqual(saved.content.form, forms[index])
  }
  XCTAssertFalse(fixture.store.isSaving)
}
