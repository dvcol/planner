import Network
import XCTest

@MainActor
final class SavedBrowserJourneyTests: XCTestCase {
  func testSavedWebsiteOpensInsidePlannerAndReturnsToTheSameItem() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    #if os(macOS)
      application.plannerElement("saved.section.items").activateForPlannerJourney()
    #else
      application.buttons["Items"].firstMatch.activateForPlannerJourney()
    #endif
    application.openSavedPlannerNewItemEditor()
    let title = application.textFields["saved.item.title"]
    XCTAssertTrue(title.waitForExistence(timeout: 5))
    title.activateForPlannerJourney()
    title.typeText("Museum reading")
    let addLink = application.plannerElement("saved.item.link.add")
    for _ in 0..<6 where !addLink.isHittable { application.swipeUp() }
    XCTAssertTrue(addLink.isHittable)
    addLink.activateForPlannerJourney()
    let linkInput = application.textFields.matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.url.")
    ).firstMatch
    XCTAssertTrue(linkInput.waitForExistence(timeout: 5))
    linkInput.activateForPlannerJourney()
    linkInput.typeText(destination.absoluteString)
    application.plannerElement("saved.item.save").activateForPlannerJourney()
    let savedLink = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.")
    ).firstMatch
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    for _ in 0..<6 where !savedLink.isHittable { application.swipeUp() }
    let originalLinkIdentity = savedLink.identifier
    XCTAssertEqual(savedLink.value as? String, destination.absoluteString)
    savedLink.activateForPlannerJourney()
    let returnToItem = application.buttons["saved.browser.return"]
    XCTAssertTrue(returnToItem.waitForExistence(timeout: 10))
    XCTAssertEqual(application.state, .runningForeground)
    let page = application.webViews.firstMatch
    XCTAssertTrue(page.waitForExistence(timeout: 10))
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].waitForExistence(timeout: 10))
    XCTAssertTrue(server.requestLines.contains("GET /guide HTTP/1.1"))
    let capture = XCTAttachment(screenshot: application.windows.firstMatch.screenshot())
    capture.name = "Saved guide opens in native Planner webpage"
    capture.lifetime = .keepAlways
    add(capture)
    returnToItem.activateForPlannerJourney()
    let restoredLink = application.plannerElement(originalLinkIdentity)
    XCTAssertTrue(restoredLink.waitForExistence(timeout: 10))
    XCTAssertEqual(restoredLink.value as? String, destination.absoluteString)
    XCTAssertEqual(application.savedPlannerItemRows("Museum reading").count, 1)
  }
}

private final class BrowserJourneyServer: @unchecked Sendable {
  private let listener: NWListener
  private let queue = DispatchQueue(label: "Planner.BrowserJourneyServer")
  private let lock = NSLock()
  private var port: NWEndpoint.Port?
  private var failure: NWError?
  private var observedRequestLines: [String] = []
  private var connections: [NWConnection] = []

  init() throws {
    let parameters = NWParameters.tcp
    parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
    listener = try NWListener(using: parameters)
  }

  var requestLines: [String] { lock.withLock { observedRequestLines } }

  func start() async throws -> URL {
    listener.stateUpdateHandler = { [weak self] state in
      guard let self else { return }
      lock.withLock {
        if case .ready = state { port = listener.port }
        if case .failed(let error) = state { failure = error }
      }
    }
    listener.newConnectionHandler = { [weak self] connection in
      guard let self else { return }
      connections.append(connection)
      connection.start(queue: queue)
      receive(connection, bytes: Data())
    }
    listener.start(queue: queue)
    let deadline = ContinuousClock.now.advanced(by: .seconds(5))
    while ContinuousClock.now < deadline {
      let observation = lock.withLock { (port, failure) }
      if let failure = observation.1 { throw failure }
      if let port = observation.0,
        let destination = URL(string: "http://localhost:\(port.rawValue)/guide")
      {
        return destination
      }
      try await Task.sleep(for: .milliseconds(10))
    }
    throw URLError(.timedOut)
  }

  func stop() {
    queue.async { [self] in
      listener.cancel()
      for connection in connections { connection.cancel() }
      connections.removeAll()
    }
  }

  private func receive(_ connection: NWConnection, bytes: Data) {
    connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) {
      [weak self] incoming, _, complete, error in
      guard let self else { return }
      let received = bytes + (incoming ?? Data())
      guard error == nil, received.count <= 8192 else {
        connection.cancel()
        return
      }
      guard let header = String(data: received, encoding: .utf8), header.contains("\r\n\r\n") else {
        if complete { connection.cancel() } else { receive(connection, bytes: received) }
        return
      }
      let requestLine = header.components(separatedBy: "\r\n").first ?? ""
      lock.withLock { observedRequestLines.append(requestLine) }
      let body = """
        <!doctype html><html><head><title>Museum guide</title></head>
        <body><h1>Museum guide fixture</h1><p>Meet at the garden entrance.</p></body></html>
        """
      let content = requestLine.hasPrefix("HEAD ") ? "" : body
      let response =
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(content)"
      connection.send(
        content: Data(response.utf8),
        completion: .contentProcessed { _ in connection.cancel() })
    }
  }
}
