from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/phase
bundle=Path('/private/tmp/PlannerItemWindow-'+phase+'.xcresult')
export=Path('/private/tmp/PlannerLabelAttachments-'+phase)
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
commands=[]
def run(arguments):
    result=subprocess.run(arguments,capture_output=True,text=True,env=environment)
    commands.append({'command':arguments,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    assert result.returncode==0,result.stderr
    return result.stdout
summary=json.loads(run(['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle)]))
(packet/'test-results-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
run(['xcrun','xcresulttool','export','attachments','--path',str(bundle),'--output-path',str(export)])
manifest=json.loads((export/'manifest.json').read_text())
(packet/'original-attachment-manifest.json.gz').write_bytes(gzip.compress((export/'manifest.json').read_bytes(),mtime=0))
selected=[]
for case in manifest:
    for attachment in case.get('attachments',[]):
        filename=attachment['exportedFileName']
        source=export/filename
        if source.suffix.lower() not in ['.png','.txt','.json']:continue
        data=source.read_bytes()
        retained=filename if source.suffix.lower()=='.png' else filename+'.gz'
        if (packet/retained).exists():assert (packet/retained).read_bytes()==(data if retained==filename else gzip.compress(data,mtime=0))
        else:(packet/retained).write_bytes(data if retained==filename else gzip.compress(data,mtime=0))
        selected.append(dict(attachment,retainedFileName=retained,sha256=hashlib.sha256(data).hexdigest()))
(packet/'selected-attachments.json').write_text(json.dumps({'attachments':selected},indent=2)+'\n')
(packet/'evidence-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(packet/'evidence-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(phase,{key:summary[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests']},'retained',len(selected),'original image/text attachments')
