from pathlib import Path
import gzip
import hashlib
import json
import os
import plistlib
import subprocess

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
compiled = root / 'app-intent-archive-green'
packet = root / 'app-intent-archive-prebuilt-probe'
packet.mkdir(exist_ok=False)
configuration = Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Planner_macosx27.0-arm64.xctestrun')
products = configuration.parent
host = products / 'Debug/Planner.app'
test_bundle = host / 'Contents/PlugIns/PlannerMCPTests.xctest'
configuration_values = plistlib.loads(configuration.read_bytes())
assert configuration_values['PlannerMCPTests']['TestHostPath'] == '__TESTROOT__/Debug/Planner.app'
assert configuration_values['PlannerMCPTests']['TestBundlePath'] == '__TESTHOST__/Contents/PlugIns/PlannerMCPTests.xctest'
source_hashes = json.loads((compiled / 'source-sha256.json').read_text())
checked_sources = {name: digest for name, digest in source_hashes.items() if name.endswith(('.swift', '.pbxproj', '.xcscheme', '.xcconfig', '.plist', '.entitlements', '.resolved'))}
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in checked_sources.items())
checked_products = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [configuration, host / 'Contents/MacOS/Planner', host / 'Contents/MacOS/Planner.debug.dylib', test_bundle / 'Contents/MacOS/PlannerMCPTests']}
(packet / 'source-sha256.json').write_text(json.dumps(checked_sources, indent=2) + '\n')
(packet / 'product-sha256.json').write_text(json.dumps(checked_products, indent=2) + '\n')
(packet / 'build-link.json').write_text(json.dumps({'compiledEpoch': str(compiled.relative_to(repository)), 'currentCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'prebuiltConfiguration': str(configuration), 'signatureVerifiedBeforeRun': True, 'scope': 'Same compiled Mac app-hosted production interfaces; no signing, source, target or dependency changes.'}, indent=2) + '\n')
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
bundle = '/private/tmp/PlannerArchivePrebuiltProbe.xcresult'
command = ['xcodebuild', 'test-without-building', '-xctestrun', str(configuration), '-destination', 'platform=macOS,arch=arm64', '-destination-timeout', '20', '-parallel-testing-enabled', 'NO', '-jobs', '1', '-test-timeouts-enabled', 'YES', '-default-test-execution-time-allowance', '120', '-maximum-test-execution-time-allowance', '120', '-only-testing:PlannerMCPTests/PlannerItemIntentTests/testArchiveIntentRetainsItemIdentityContentAndIndependentListCompletionAfterReopen', '-only-testing:PlannerMCPTests/PlannerItemIntentTests/testInvalidCreationAndMissingItemReadFailWithoutCreatingData', '-resultBundlePath', bundle]
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerArchivePrebuiltProbe.log')
with log.open('wb') as output:
    process = subprocess.Popen(command, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT)
    (packet / 'process.json').write_text(json.dumps({'pid': process.pid, 'command': command}, indent=2) + '\n')
    try:
        exit_code = process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        exit_code = 124
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode': exit_code, 'bundle': bundle}, indent=2) + '\n')
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in checked_sources.items())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in checked_products.items())
for line in log.read_text().splitlines():
    if line.startswith(('Test Case ', '** TEST')) or ': error:' in line or line.lstrip().startswith('Executed '):
        print(line[:1500])
print('Prebuilt probe exit:', exit_code)
raise SystemExit(exit_code)
