import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerLinkRemovalIntentTests: XCTestCase {
  func testRemovingOneBookmarkKeepsDuplicateSiblingAndBothOwnerSources() async throws {
    let fixture = try await makeLinkIntentFixture()
    let before = try await readLinkIntentSources(fixture)
    let itemLinks = try await readLinksUsingIntent(fixture.item)
    let itineraryLinks = try await readLinksUsingIntent(fixture.itinerary)
    XCTAssertEqual(itemLinks[0].originalURL, itemLinks[2].originalURL)
    try await removeLinkUsingIntent(owner: fixture.item, link: itemLinks[0])
    try await removeLinkUsingIntent(owner: fixture.itinerary, link: itineraryLinks[0])
    let after = try await readLinkIntentSources(fixture)
    XCTAssertEqual(after.item.content.links, Array(before.item.content.links.dropFirst()))
    XCTAssertTrue(after.itinerary.content.links.isEmpty)
    XCTAssertEqual(after.item.sourceLifetimeId, before.item.sourceLifetimeId)
    XCTAssertEqual(after.itinerary.sourceLifetimeId, before.itinerary.sourceLifetimeId)
    let removedItemLink = PlannerReferenceRead.ownedLink(
      id: before.item.content.links[0].linkId, owner: fixture.item)
    let removedItineraryLink = PlannerReferenceRead.ownedLink(
      id: before.itinerary.content.links[0].linkId, owner: fixture.itinerary)
    XCTAssertEqual(after.item.references, before.item.references.filter { $0 != removedItemLink })
    XCTAssertEqual(
      after.itinerary.references, before.itinerary.references.filter { $0 != removedItineraryLink })
    for (field, hash) in before.item.fieldHashes where field != .links {
      XCTAssertEqual(after.item.fieldHashes[field], hash)
    }
    for (field, hash) in before.itinerary.fieldHashes where field != .links {
      XCTAssertEqual(after.itinerary.fieldHashes[field], hash)
    }
    XCTAssertFalse(fixture.store.recoveryBlocked)
    let query = PlannerLinkEntityQuery()
    query.plannerStore = fixture.store
    let resolved = try await query.entities(for: [
      itemLinks[0].id, itineraryLinks[0].id, itemLinks[2].id,
    ])
    XCTAssertEqual(resolved.map(\.id), [itemLinks[2].id])
  }
}

@MainActor
private func removeLinkUsingIntent(owner: PlannerEntityReference, link: PlannerLinkEntity)
  async throws
{
  if owner.kind == .item {
    let removal = RemovePlannerItemLinkIntent()
    removal.item = .init(id: owner.id, title: "Cached Item", done: true, archived: true)
    removal.link = link
    let _: Void = try await removal.callAsFunction(donate: false)
    return
  }
  let removal = RemovePlannerItineraryLinkIntent()
  removal.itinerary = .init(id: owner.id, title: "Cached Itinerary", archived: true)
  removal.link = link
  let _: Void = try await removal.callAsFunction(donate: false)
}
