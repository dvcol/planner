import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleEndIntentTests: XCTestCase {
  func testClearingCurrentAllDayEndIgnoresCachedTimedFormAndPreservesArchivedItinerary()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let choices = try await query.entities(for: [fixture.allDay.id])
    let cached = try XCTUnwrap(choices.first)
    let currentStart = PlannerCivilDate(year: 2027, month: 1, day: 31)
    guard
      case .source(.schedule(let initial)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.allDay)),
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .editSchedule(
            scheduleId: fixture.allDay.id,
            changes: .init(
              form: .allDay(start: currentStart, end: .init(year: 2027, month: 2, day: 2))),
            expectedFieldHashes: initial.fieldHashes))
      ).outcome,
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setArchive(source: fixture.itinerary, archived: true))
      ).outcome,
      case .source(.itinerary(let before)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.itinerary))
    else { return XCTFail("Save the archived owner's current inclusive all-day span.") }
    cached.allDay = false
    cached.start = fixture.instant
    cached.end = fixture.instant.addingTimeInterval(7200)
    cached.startDay = nil
    cached.endDay = nil
    cached.planningTimeZone = PlannerTimeZoneEntity(identifier: "Asia/Tokyo")
    let clear = ClearPlannerScheduleEndIntent()
    clear.schedule = cached
    let _: Void = try await clear.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let current)) = await reopened.read(
        session: session, request: .source(fixture.allDay)),
      case .source(.itinerary(let after)) = await reopened.read(
        session: session, request: .source(fixture.itinerary)),
      case .source(.schedule(let timed)) = await reopened.read(
        session: session, request: .source(fixture.timed))
    else { return XCTFail("Read the original identities after clearing the all-day end.") }
    XCTAssertEqual(current.source, fixture.allDay)
    XCTAssertEqual(current.content.source, fixture.itinerary)
    XCTAssertEqual(current.content.form, .allDay(start: currentStart, end: nil))
    XCTAssertEqual(after.content.title, "Tokyo Weekend")
    XCTAssertEqual(after.state.archived, true)
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(
      timed.content.form,
      .timed(start: fixture.instant, end: nil, planningTimeZone: "Asia/Tokyo"))
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }

  func testClearingTimedEndPreservesCurrentFractionalStartZoneOwnerAndOtherBookings() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let choices = try await query.entities(for: [fixture.timed.id])
    let cached = try XCTUnwrap(choices.first)
    let start = try Date.ISO8601FormatStyle().parse("2026-11-01T06:30:00Z").addingTimeInterval(0.75)
    guard
      case .source(.schedule(let initial)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.timed)),
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .editSchedule(
            scheduleId: fixture.timed.id,
            changes: .init(
              form: .timed(
                start: start, end: start.addingTimeInterval(3600.125),
                planningTimeZone: "America/New_York")),
            expectedFieldHashes: initial.fieldHashes))
      ).outcome,
      case .source(.item(let before)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { return XCTFail("Save the current repeated-hour span before clearing only its end.") }
    let clear = ClearPlannerScheduleEndIntent()
    clear.schedule = cached
    let _: Void = try await clear.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let current)) = await reopened.read(
        session: session, request: .source(fixture.timed)),
      case .source(.item(let after)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.schedule(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.allDay)),
      case .source(.schedule(let outside)) = await reopened.read(
        session: session, request: .source(fixture.outside))
    else { return XCTFail("Reopen the same booking, source and other bookings after clearing.") }
    XCTAssertEqual(current.source, fixture.timed)
    XCTAssertEqual(current.content.source, fixture.item)
    XCTAssertEqual(
      current.content.form,
      .timed(start: start, end: nil, planningTimeZone: "America/New_York"))
    XCTAssertEqual(after.content.title, before.content.title)
    XCTAssertEqual(after.content.notes, before.content.notes)
    XCTAssertEqual(after.state.globalDone, before.state.globalDone)
    XCTAssertEqual(after.state.archived, before.state.archived)
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(after.content.estimate?.minutes, 90)
    XCTAssertEqual(
      itinerary.content.form,
      .allDay(
        start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11)))
    XCTAssertEqual(
      outside.content.form, .allDay(start: .init(year: 2026, month: 10, day: 12), end: nil))
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}
