import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryItemIntentTests: XCTestCase {
  func testGetRetainsExactRepeatedDirectAppearanceAndReturnsLiveLocalState() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Hotel", notes: "Shared notes")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    let firstEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    let secondEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let firstIdentifier, _, _)? = firstEntry.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondEntry.generatedReferences.first
    else { return XCTFail("Repeated Item stops must have distinct saved entry identities.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .directItineraryItem(itineraryId: itinerary.id, entryId: secondIdentifier)),
        done: true))
    let firstIdentity = "v1/direct/\(itinerary.id)/\(firstIdentifier)/\(item.id)"
    let secondIdentity = "v1/direct/\(itinerary.id)/\(secondIdentifier)/\(item.id)"
    let reading = GetPlannerItineraryItemIntent()
    reading.itinerary = .init(id: itinerary.id, title: "Cached route", archived: true)
    reading.item = .init(
      id: secondIdentity, title: "Cached Hotel", context: "Cached position", globallyDone: true,
      locallyDone: false, done: false, archived: true)
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, secondIdentity)
    XCTAssertEqual(current.title, "Hotel")
    XCTAssertEqual(current.context, "Tokyo Weekend · Stop 2")
    XCTAssertFalse(current.globallyDone)
    XCTAssertTrue(current.locallyDone)
    XCTAssertTrue(current.done)
    XCTAssertFalse(current.archived)
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [secondIdentity, firstIdentity, secondIdentity])
    XCTAssertEqual(resolved.map(\.id), [secondIdentity, firstIdentity])
    XCTAssertEqual(resolved.map(\.context), ["Tokyo Weekend · Stop 2", "Tokyo Weekend · Stop 1"])
    XCTAssertEqual(resolved.map(\.locallyDone), [true, false])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testExpandedRepeatsKeepTheirIdentityWhileNamesAndSavedPositionsChange() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdMuseum = try await save(.createItem(content: .init(title: "Museum")))
    let museum = try XCTUnwrap(createdMuseum.generated.first)
    let createdLunch = try await save(.createItem(content: .init(title: "Lunch")))
    let lunch = try XCTUnwrap(createdLunch.generated.first)
    let createdList = try await save(.createList(content: .init(name: "Food")))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdEmptyList = try await save(.createList(content: .init(name: "Empty stop")))
    let emptyList = try XCTUnwrap(createdEmptyList.generated.first)
    let museumMembership = try await save(
      .addMembership(itemId: museum.id, listId: list.id, placement: .last))
    let lunchMembership = try await save(
      .addMembership(itemId: lunch.id, listId: list.id, placement: .last))
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    let direct = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: museum, placement: .last))
    let firstBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
    _ = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: emptyList, placement: .last))
    let secondBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
    guard
      case .membership(let museumIdentifier, _, _)? = museumMembership.generatedReferences.first,
      case .membership(let lunchIdentifier, _, _)? = lunchMembership.generatedReferences.first,
      case .itineraryEntry(let directIdentifier, _, _)? = direct.generatedReferences.first,
      case .itineraryEntry(let firstIdentifier, _, _)? = firstBranch.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondBranch.generatedReferences.first,
      case .source(.item(let originalMuseum)) = await planner.read(
        session: session, request: .source(museum)),
      case .source(.list(let originalList)) = await planner.read(
        session: session, request: .source(list)),
      case .source(.itinerary(let originalItinerary)) = await planner.read(
        session: session, request: .source(itinerary))
    else { return XCTFail("Repeated List entries need their own complete saved identities.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .expandedListItem(
            itineraryId: itinerary.id, listEntryId: secondIdentifier, membershipId: museumIdentifier
          )),
        done: true))
    _ = try await save(.setArchive(source: museum, archived: true))
    _ = try await save(
      .editItem(
        sourceId: museum.id, changes: .init(title: .set("Nezu Museum")),
        expectedFieldHashes: originalMuseum.fieldHashes))
    _ = try await save(
      .editList(
        sourceId: list.id, changes: .init(name: .set("Tokyo Food")),
        expectedFieldHashes: originalList.fieldHashes))
    _ = try await save(
      .editItinerary(
        sourceId: itinerary.id, changes: .init(title: .set("Tokyo Weekend")),
        expectedFieldHashes: originalItinerary.fieldHashes))
    _ = try await save(
      .reorderItineraryEntry(
        itineraryId: itinerary.id, entryId: directIdentifier,
        placement: .before(associationId: secondIdentifier)))
    _ = try await save(
      .reorderMembership(listId: list.id, membershipId: lunchIdentifier, placement: .first))
    let secondMuseum =
      "v1/list/\(itinerary.id)/\(secondIdentifier)/\(museumIdentifier)/\(museum.id)"
    let firstLunch = "v1/list/\(itinerary.id)/\(firstIdentifier)/\(lunchIdentifier)/\(lunch.id)"
    let directMuseum = "v1/direct/\(itinerary.id)/\(directIdentifier)/\(museum.id)"
    let firstMuseum = "v1/list/\(itinerary.id)/\(firstIdentifier)/\(museumIdentifier)/\(museum.id)"
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [
      secondMuseum, firstLunch, directMuseum, firstMuseum,
    ])
    XCTAssertEqual(resolved.map(\.id), [secondMuseum, firstLunch, directMuseum, firstMuseum])
    XCTAssertEqual(resolved.map(\.title), ["Nezu Museum", "Lunch", "Nezu Museum", "Nezu Museum"])
    XCTAssertEqual(
      resolved.map(\.context),
      [
        "Tokyo Weekend · Stop 4 · Tokyo Food · Item 2",
        "Tokyo Weekend · Stop 1 · Tokyo Food · Item 1",
        "Tokyo Weekend · Stop 3", "Tokyo Weekend · Stop 1 · Tokyo Food · Item 2",
      ])
    XCTAssertEqual(resolved.map(\.globallyDone), [false, false, false, false])
    XCTAssertEqual(resolved.map(\.locallyDone), [true, false, false, false])
    XCTAssertEqual(resolved.map(\.done), [true, false, false, false])
    XCTAssertEqual(resolved.map(\.archived), [true, false, true, true])
  }

  func testIdentityReadsCrossPagesNormalizeUUIDCaseAndNeverInventUnscopedChoices() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(.createItem(content: .init(title: "Hotel")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Long route")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    var identifiers: [String] = []
    for _ in 0..<65 {
      let created = try await save(
        .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
      guard case .itineraryEntry(let entry, _, _)? = created.generatedReferences.first else {
        return XCTFail("Every repeated stop needs its own saved identity.")
      }
      identifiers.append("v1/direct/\(itinerary.id)/\(entry)/\(item.id)")
    }
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let reversedIdentifiers = Array(identifiers.reversed())
    let resolved = try await query.entities(
      for: reversedIdentifiers + [
        identifiers[0].lowercased(), "", "v2/direct/\(itinerary.id)/\(UUID())/\(item.id)",
        "v1/direct/invalid", "v1/list/\(itinerary.id)/\(UUID())/\(UUID())/\(item.id)",
      ])
    XCTAssertEqual(resolved.map(\.id), reversedIdentifiers)
    XCTAssertEqual(Set(resolved.map(\.id)).count, 65)
    XCTAssertEqual(resolved.first?.context, "Long route · Stop 65")
    XCTAssertEqual(resolved.last?.context, "Long route · Stop 1")
    XCTAssertTrue(resolved.allSatisfy { $0.title == "Hotel" && !$0.done })
    let suggestions = try await query.suggestedEntities()
    let search = try await query.entities(matching: "Hotel")
    XCTAssertTrue(suggestions.isEmpty)
    XCTAssertTrue(search.isEmpty)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testCompletionChangesOnlyTheSelectedAppearanceAndKeepsGlobalPrecedence() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Hotel", notes: "Keep booking")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdList = try await save(.createList(content: .init(name: "Food")))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdMembership = try await save(
      .addMembership(itemId: item.id, listId: list.id, placement: .last))
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    var entries: [UUID] = []
    for source in [item, list, item, list] {
      let added = try await save(
        .addItineraryEntry(itineraryId: itinerary.id, source: source, placement: .last))
      guard case .itineraryEntry(let identifier, _, _)? = added.generatedReferences.first else {
        return XCTFail("Every route stop needs a distinct saved entry.")
      }
      entries.append(identifier)
    }
    guard case .membership(let membership, _, _)? = createdMembership.generatedReferences.first
    else {
      return XCTFail("The source List needs its own independent completion context.")
    }
    let standalone = PlannerAppearance.listMembership(listId: list.id, membershipId: membership)
    let direct = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: entries[0])
    let firstBranch = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: entries[1], membershipId: membership)
    let otherDirect = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: entries[2])
    let selected = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: entries[3], membershipId: membership)
    _ = try await save(.setCompletion(scope: .appearance(standalone), done: true))
    _ = try await save(.setCompletion(scope: .appearance(direct), done: true))
    let form = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let createdSchedule = try await save(.createSchedule(source: itinerary, form: form))
    let schedule = try XCTUnwrap(createdSchedule.generated.first)
    let manual = PlannerItemQuery(
      scope: .itinerary(itinerary.id), completion: .all, archive: .all, sort: .init(mode: .manual))
    guard
      case .source(.item(let before)) = await planner.read(session: session, request: .source(item)),
      case .snapshot(let beforeOrder) = await planner.query(
        .init(session: session, request: .items(manual)))
    else {
      return XCTFail("Shared content and saved route must be readable before the local action.")
    }
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let identity = "v1/list/\(itinerary.id)/\(entries[3])/\(membership)/\(item.id)"
    let resolved = try await query.entities(for: [identity])
    let completion = SetPlannerItineraryItemCompletionIntent()
    completion.itinerary = .init(id: itinerary.id, title: "Cached route", archived: true)
    completion.item = try XCTUnwrap(resolved.first)
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    guard
      case .source(.item(let afterLocal)) = await planner.read(
        session: session, request: .source(item)),
      case .appearance(let selectedDone) = await planner.read(
        session: session, request: .appearance(selected))
    else { return XCTFail("The exact selected local flag must change without editing the Item.") }
    XCTAssertEqual(afterLocal.fieldHashes, before.fieldHashes)
    XCTAssertEqual(afterLocal.updatedAt, before.updatedAt)
    XCTAssertFalse(selectedDone.globalDone)
    XCTAssertTrue(selectedDone.localDone)
    let global = SetPlannerItemCompletionIntent()
    global.item = .init(id: item.id, title: "Cached Hotel", done: false, archived: false)
    global.done = true
    let _: Void = try await global.callAsFunction(donate: false)
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    let masked = try await query.entities(for: [identity])
    XCTAssertEqual(masked.map(\.globallyDone), [true])
    XCTAssertEqual(masked.map(\.locallyDone), [false])
    XCTAssertEqual(masked.map(\.done), [true])
    global.done = false
    let _: Void = try await global.callAsFunction(donate: false)
    _ = try await save(.setArchive(source: list, archived: true))
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let savedItem)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.itinerary(let savedItinerary)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let savedSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule)),
      case .snapshot(let afterOrder) = await reopened.query(
        .init(session: reopenedSession, request: .items(manual)))
    else { return XCTFail("The entire graph must survive reopening after local/global changes.") }
    for (appearance, expectedLocal) in [
      (standalone, true), (direct, true), (firstBranch, false), (otherDirect, false),
      (selected, false),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(appearance))
      else { return XCTFail("Every original context must survive.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocal)
      XCTAssertEqual(current.effectiveDone, expectedLocal)
    }
    XCTAssertEqual(savedItem.content.title, "Hotel")
    XCTAssertEqual(savedItem.content.notes, "Keep booking")
    XCTAssertEqual(savedItem.state.archived, false)
    XCTAssertEqual(savedSchedule.content.form, form)
    XCTAssertEqual(afterOrder.rows, beforeOrder.rows)
    XCTAssertEqual(savedItinerary.progress.totalCount, 4)
    XCTAssertEqual(savedItinerary.progress.doneCount, 1)
    XCTAssertEqual(savedItinerary.progress.archivedCount, 2)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
