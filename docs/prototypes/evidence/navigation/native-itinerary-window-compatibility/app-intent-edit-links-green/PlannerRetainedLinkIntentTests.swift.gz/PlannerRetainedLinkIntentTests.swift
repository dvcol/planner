import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerRetainedLinkIntentTests: XCTestCase {
  func testEditsKeepExactBookmarkIdentitiesAndDoNotChangeDuplicateSiblingsOrOtherContent()
    async throws
  {
    let fixture = try await makeLinkIntentFixture()
    let before = try await readLinkIntentSources(fixture)
    let itemLinks = try await readLinksUsingIntent(fixture.item)
    let itineraryLinks = try await readLinksUsingIntent(fixture.itinerary)
    let originalURL = "https://booking.com/reviewed?Ref=%2f"
    let label = "  Réservé · 東京  "
    try await editRetainedLinkUsingIntent(
      owner: fixture.item, link: itemLinks[0], originalURL: originalURL, label: label)
    try await editRetainedLinkUsingIntent(
      owner: fixture.itinerary, link: itineraryLinks[0], originalURL: originalURL, label: label)
    let after = try await readLinkIntentSources(fixture)
    XCTAssertEqual(after.item.content.links.map(\.linkId), before.item.content.links.map(\.linkId))
    XCTAssertEqual(
      after.itinerary.content.links.map(\.linkId), before.itinerary.content.links.map(\.linkId))
    XCTAssertEqual(after.item.content.links[0].originalUrl, originalURL)
    XCTAssertEqual(after.itinerary.content.links[0].originalUrl, originalURL)
    XCTAssertEqual(after.item.content.links[0].label, label)
    XCTAssertEqual(after.itinerary.content.links[0].label, label)
    XCTAssertEqual(after.item.content.links[0].kind, .booking)
    XCTAssertEqual(after.itinerary.content.links[0].kind, .booking)
    XCTAssertNil(after.item.content.links[0].providerReference)
    XCTAssertEqual(
      Array(after.item.content.links.dropFirst()), Array(before.item.content.links.dropFirst()))
    XCTAssertEqual(after.item.references, before.item.references)
    XCTAssertEqual(after.itinerary.references, before.itinerary.references)
    for (field, hash) in before.item.fieldHashes where field != .links {
      XCTAssertEqual(after.item.fieldHashes[field], hash)
    }
    for (field, hash) in before.itinerary.fieldHashes where field != .links {
      XCTAssertEqual(after.itinerary.fieldHashes[field], hash)
    }
    XCTAssertFalse(fixture.store.recoveryBlocked)
    let query = PlannerLinkEntityQuery()
    query.plannerStore = fixture.store
    let refreshed = try await query.entities(for: [itemLinks[0].id, itineraryLinks[0].id])
    XCTAssertEqual(refreshed.map(\.originalURL), [originalURL, originalURL])
    XCTAssertEqual(refreshed.map(\.label), [label, label])
  }
}

@MainActor
private func editRetainedLinkUsingIntent(
  owner: PlannerEntityReference, link: PlannerLinkEntity, originalURL: String?, label: String?
) async throws {
  if owner.kind == .item {
    let editing = EditPlannerItemLinkIntent()
    editing.item = .init(id: owner.id, title: "Cached Item", done: true, archived: true)
    editing.link = link
    editing.originalURL = originalURL
    editing.label = label
    let _: Void = try await editing.callAsFunction(donate: false)
    return
  }
  let editing = EditPlannerItineraryLinkIntent()
  editing.itinerary = .init(id: owner.id, title: "Cached Itinerary", archived: true)
  editing.link = link
  editing.originalURL = originalURL
  editing.label = label
  let _: Void = try await editing.callAsFunction(donate: false)
}
