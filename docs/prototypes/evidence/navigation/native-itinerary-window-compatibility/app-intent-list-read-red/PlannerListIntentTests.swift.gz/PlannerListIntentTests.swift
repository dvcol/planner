import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerListIntentTests: XCTestCase {
  func testGetListIntentReturnsLiveValuesAndRejectsMissingIdentity() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Original food"
    let cached = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .list, id: cached.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.list(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editList(
            sourceId: cached.id, changes: .init(name: .set("Renamed food")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome
    else { return XCTFail("The real List must change before resolving its cached Intent entity.") }
    var reading = GetPlannerListIntent()
    reading.list = cached
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, cached.id)
    XCTAssertEqual(current.name, "Renamed food")
    XCTAssertFalse(current.archived)
    reading.list = .init(id: UUID(), name: "Missing", archived: false)
    do {
      _ = try await reading.callAsFunction(donate: false)
      XCTFail("Get List must reject a missing identity instead of inventing an entity.")
    } catch {
      XCTAssertTrue(error.localizedDescription.contains("no longer available"))
    }
  }

  func testListChoicesPreserveCanonicalSearchOrderArchivedSourcesAndEveryPage() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    var identifiers: [UUID] = []
    for index in 0..<65 {
      guard
        case .applied(let created, .complete) = await planner.execute(
          .init(
            operationId: UUID(), session: session,
            command: .createList(content: .init(name: String(format: "Plan %02d", index))))
        ).outcome, let source = created.generated.first
      else { return XCTFail("Every real List must save before querying its choices.") }
      identifiers.append(source.id)
    }
    guard
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: .init(kind: .list, id: identifiers[0]), archived: true))
      ).outcome
    else { return XCTFail("The archived List must remain available by identity.") }
    var query = PlannerListEntityQuery()
    query.plannerStore = store
    let matches = try await query.entities(matching: "PLAN")
    XCTAssertEqual(matches.map(\.id), identifiers)
    XCTAssertEqual(matches.first?.name, "Plan 00")
    XCTAssertEqual(matches.first?.archived, true)
    XCTAssertEqual(matches.last?.name, "Plan 64")
    XCTAssertEqual(Set(matches.map(\.id)).count, 65)
    let suggestions = try await query.suggestedEntities()
    XCTAssertEqual(suggestions.map(\.id), identifiers)
    let missing = try await query.entities(matching: "No such plan")
    XCTAssertTrue(missing.isEmpty)
    let requested = try await query.entities(for: [
      identifiers[64], identifiers[0], identifiers[64],
    ])
    XCTAssertEqual(requested.map(\.id), [identifiers[64], identifiers[0]])
  }

  func testListEntityResolutionUsesCurrentNameAndArchiveWithoutInventingMissingIdentities()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    let cached = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .list, id: cached.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.list(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editList(
            sourceId: cached.id, changes: .init(name: .set("Revised Tokyo Food")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: source, archived: true))
      ).outcome
    else { return XCTFail("Real Core edits must precede resolution of a cached List identity.") }
    var query = PlannerListEntityQuery()
    query.plannerStore = store
    let choices = try await query.entities(for: [cached.id, cached.id, UUID()])
    XCTAssertEqual(choices.map(\.id), [cached.id])
    XCTAssertEqual(choices.first?.name, "Revised Tokyo Food")
    XCTAssertEqual(choices.first?.archived, true)
    XCTAssertFalse(store.recoveryBlocked)
  }

  func testCreateListIntentReturnsTheSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    creation.notes = "Keep these places together"
    let list = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(list.name, "Tokyo Food")
    XCTAssertFalse(list.archived)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.list(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .list, id: list.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .list, archive: .all))))
    else { return XCTFail("The returned List must remain readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, list.id)
    XCTAssertEqual(current.content.name, "Tokyo Food")
    XCTAssertEqual(current.content.notes, "Keep these places together")
    XCTAssertEqual(current.state.archived, false)
    XCTAssertEqual(current.progress.state, .empty)
    XCTAssertEqual(current.progress.totalCount, 0)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .list, id: list.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerListIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
