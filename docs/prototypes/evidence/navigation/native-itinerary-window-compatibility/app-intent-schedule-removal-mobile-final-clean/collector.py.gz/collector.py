from pathlib import Path
import gzip, hashlib, json, plistlib, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = evidence / phase
assert json.loads((packet / 'exit.json').read_text())['exitCode'] == 0
baseline = evidence / 'app-intent-schedule-reads-final-clean'
prior_metadata = json.loads(gzip.decompress((baseline / 'extract.actionsdata.gz').read_bytes()))
paths = {
    'mac': '/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
    'mobile': '/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
    'device': '/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata',
}
metadata_bytes = Path(paths[platform]).read_bytes()
metadata = json.loads(metadata_bytes)
def entity(name):
    return {'entity': {'wrapper': {'typeName': name}}}
def array(name):
    return {'array': {'wrapper': {'capabilities': 3, 'memberValueType': entity(name)}}}
def parameter(value_type, optional=False):
    return {'optional': optional, 'valueType': value_type}
new_actions = {'RemovePlannerScheduleIntent': ({'schedule': parameter(entity('PlannerScheduleEntity'))}, None)}
assert set(metadata['actions']) == set(prior_metadata['actions']) | set(new_actions)
assert len(metadata['actions']) == 64
new_entities = set()
new_queries = set()
assert set(metadata['entities']) == set(prior_metadata['entities']) | new_entities
assert set(metadata['queries']) == set(prior_metadata['queries']) | new_queries
contracts = {identifier: {value['name']: parameter(value['valueType'], value['isOptional']) for value in action['parameters']} for identifier, action in metadata['actions'].items()}
outputs = {identifier: action.get('outputType') for identifier, action in metadata['actions'].items()}
for identifier, action in prior_metadata['actions'].items():
    assert contracts[identifier] == {value['name']: parameter(value['valueType'], value['isOptional']) for value in action['parameters']}
    assert outputs[identifier] == action.get('outputType')
for identifier, (parameters, output_type) in new_actions.items():
    assert contracts[identifier] == parameters, (identifier, contracts[identifier])
    assert outputs[identifier] == output_type, (identifier, outputs[identifier])
    assert metadata['actions'][identifier]['isDiscoverable'] is True
for kind in ['entities', 'queries']:
    for identifier, value in prior_metadata[kind].items():
        assert metadata[kind][identifier] == value, (kind, identifier)
assert metadata['enums'] == prior_metadata['enums']
properties = {value['identifier']: parameter(value['valueType'], value['isOptional']) for value in metadata['entities']['PlannerScheduleEntity']['properties']}
assert properties == {
    'title': parameter({'primitive': {'wrapper': {'typeIdentifier': 0}}}),
    'sourceType': parameter({'primitive': {'wrapper': {'typeIdentifier': 0}}}),
    'allDay': parameter({'primitive': {'wrapper': {'typeIdentifier': 1}}}),
    'start': parameter({'primitive': {'wrapper': {'typeIdentifier': 8}}}, True),
    'end': parameter({'primitive': {'wrapper': {'typeIdentifier': 8}}}, True),
    'startDay': parameter({'primitive': {'wrapper': {'typeIdentifier': 9}}}, True),
    'endDay': parameter({'primitive': {'wrapper': {'typeIdentifier': 9}}}, True),
    'planningTimeZone': parameter(entity('PlannerTimeZoneEntity'), True),
    'when': parameter({'primitive': {'wrapper': {'typeIdentifier': 0}}}),
}
result = {'actions': sorted(metadata['actions']), 'entities': sorted(metadata['entities']), 'queries': sorted(metadata['queries']), 'enumCount': len(metadata['enums']), 'parameterContracts': contracts, 'outputContracts': outputs, 'scheduleProperties': properties, 'priorActionParametersAndOutputsUnchanged': True, 'priorEntitiesQueriesEnumsUnchanged': True, 'metadataSha256': hashlib.sha256(metadata_bytes).hexdigest(), 'systemInvocationQualified': False, 'systemDependencyInjectionQualified': False}
(packet / 'extracted-intent-identifiers.json').write_text(json.dumps(result, indent=2) + '\n')
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes, mtime=0))
source_hashes = json.loads((packet / 'source-sha256.json').read_text())
prior_hashes = json.loads((baseline / 'source-sha256.json').read_text())
changed = sorted(relative for relative, digest in prior_hashes.items() if source_hashes.get(relative) != digest)
added = sorted(set(source_hashes) - set(prior_hashes))
assert changed == ['Planner/AppIntents/PlannerScheduleIntents.swift', 'PlannerMCPTests/ItineraryScheduleRoutingTests.swift', 'PlannerMCPTests/PlannerScheduleReadIntentTests.swift'], changed
assert added == ['PlannerMCPTests/PlannerScheduleRemovalIntentTests.swift'], added
assert len(source_hashes) == 1034
assert all(hashlib.sha256((repository / relative).read_bytes()).hexdigest() == digest for relative, digest in source_hashes.items())
(packet / 'baseline-source-comparison.json').write_text(json.dumps({'priorInputs': len(prior_hashes), 'currentInputs': len(source_hashes), 'changedInputs': changed, 'addedInputs': added, 'otherPriorInputsUnchanged': True}, indent=2) + '\n')
if platform == 'mac':
    summary = json.loads((packet / 'test-results-summary.json').read_text())
    assert summary['passedTests'] == 27 and summary['failedTests'] == 0 and summary['skippedTests'] == 0
    lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] is True and len(lifecycle['removedDirectories']) == 23
else:
    final_mac = evidence / 'app-intent-schedule-removal-final-clean'
    assert source_hashes == json.loads((final_mac / 'source-sha256.json').read_text())
    mac_metadata = json.loads(gzip.decompress((final_mac / 'extract.actionsdata.gz').read_bytes()))
    assert metadata['entities'] == mac_metadata['entities']
    assert metadata['queries'] == mac_metadata['queries']
    assert metadata['enums'] == mac_metadata['enums']
log_path = packet / 'build.log.gz'
if not log_path.exists(): log_path = packet / 'test.log.gz'
log = gzip.decompress(log_path.read_bytes()).decode(errors='replace')
diagnostics = [line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet / 'compiler-diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
baseline_log = gzip.decompress((evidence / 'app-intent-schedule-removal-http-base/test.log.gz').read_bytes()).decode(errors='replace')
baseline_diagnostics = [line[:1000] for line in baseline_log.splitlines() if ': warning:' in line]
introduced = [line for line in diagnostics if line not in baseline_diagnostics]
(packet / 'baseline-compiler-diagnostics.json').write_text(json.dumps({'baselinePacket': 'app-intent-schedule-removal-http-base', 'baselineWarnings': baseline_diagnostics, 'currentDiagnostics': diagnostics, 'introducedDiagnostics': introduced}, indent=2) + '\n')
assert not introduced, introduced
assert not any(phrase in log for phrase in ['vnode unlinked while in use', 'database integrity compromised', 'file descriptor is invalidated'])
if platform == 'device':
    app = Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
    extensions = list((app / 'PlugIns').glob('*.appex'))
    assert len(extensions) == 1
    products = []
    for product in [app, *extensions]:
        values = plistlib.loads((product / 'Info.plist').read_bytes())
        executable = product / values['CFBundleExecutable']
        architectures = subprocess.check_output(['lipo', '-archs', str(executable)], text=True).split()
        assert architectures == ['arm64']
        products.append({'bundleIdentifier': values['CFBundleIdentifier'], 'architectures': architectures, 'sha256': hashlib.sha256(executable.read_bytes()).hexdigest()})
    (packet / 'embedded-products-verification.json').write_text(json.dumps({'products': products, 'embeddedMobileShareCount': 1, 'signingAllowed': False, 'installedOrLaunched': False}, indent=2) + '\n')
(packet / 'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(platform, 'verified: 64 actions, 10 entities/queries, prior native contracts preserved;', len(source_hashes), 'matching inputs; compiler diagnostics', len(diagnostics))
