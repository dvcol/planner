from pathlib import Path
import gzip,hashlib,json,re,subprocess,os
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=Path('docs/prototypes/evidence/navigation/native-itinerary-window-compatibility')
validation=root/'origin-draft-and-caller-checkpoint-validation'
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
prefixes=('association-undo-phone-catalog-caller-regressions','native-archived-origin','native-deleted-origin','native-draft','native-origin-draft','phone-itinerary-filter','tablet-archived-origin','tablet-origin-draft','tablet-deleted-origin')
packets=sorted({root/Path(path).relative_to(root).parts[0] for path in new if path.startswith(str(root)+'/') and Path(path).relative_to(root).parts[0].startswith(prefixes)})
assert packets and all((packet/'exit.json').is_file() for packet in packets)
rows=[]
for packet in packets:
 row={'epoch':str(packet),'result':json.loads((packet/'exit.json').read_text())}
 log=next((packet/name for name in ['test.log.gz','build.log.gz'] if (packet/name).is_file()),None)
 if log:
  lines=gzip.decompress(log.read_bytes()).decode(errors='replace').splitlines()
  row['observedSummary']=[line.strip() for line in lines if re.search(r"Test Case .* (?:passed|failed) \(|\*\* TEST (?:BUILD|EXECUTE)",line)]
 rows.append(row)
validation.mkdir(exist_ok=True)
(validation/'observed-results.json').write_text(json.dumps(rows,indent=2)+'\n')
checks=[('swift-lint',['xcrun','swift-format','lint','--strict','PlannerNavigationUITests/SavedAppearanceJourneyTests.swift','PlannerNavigationUITests/SavedItineraryFilterJourneyTests.swift']),('markdown-lint',['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json','docs/prototypes/native-container-catalog-windows.md','docs/prototypes/native-item-creation.md'])]
for name,command in checks:
 result=subprocess.run(command,capture_output=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 (validation/(name+'.json')).write_text(json.dumps({'command':command,'exitCode':result.returncode},indent=2)+'\n')
 (validation/(name+'.log.gz')).write_bytes(gzip.compress(result.stdout+result.stderr,mtime=0))
 assert result.returncode==0,(name,(result.stdout+result.stderr).decode()[:1000])
comparisons=[]
for packet in packets:
 path=packet/'current-source-sha256.json'
 if not path.is_file():continue
 values=json.loads(path.read_text())
 production={name:digest for name,digest in values.items() if name.endswith('.swift') and (name.startswith('Planner/') or '/Sources/' in name)}
 differences=[name for name,digest in production.items() if not Path(name).is_file() or hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest]
 comparisons.append({'epoch':packet.name,'productionInputs':len(production),'differences':differences})
 assert not differences,(packet.name,differences)
(validation/'production-source-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
paths=sorted(path for directory in [*packets,validation] for path in directory.rglob('*') if path.is_file() and path.name not in ['evidence-sha256.json','credential-scan.json'])
patterns={'githubCredential':rb'gh[pousr]_[A-Za-z0-9]{30,}','privateKey':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','openaiCredential':rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}'}
findings=[]
for path in paths:
 data=path.read_bytes()
 if path.suffix=='.gz':data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data):findings.append({'path':str(path),'pattern':name})
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(paths),'decompressedGzip':True,'patterns':list(patterns),'findings':findings},indent=2)+'\n')
assert not findings,findings
paths.append(validation/'credential-scan.json')
(validation/'evidence-sha256.json').write_text(json.dumps({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)},indent=2)+'\n')
print('Qualified checkpoint:',len(packets),'epochs;',len(paths),'files; lint/production comparisons/pattern scan pass.')
