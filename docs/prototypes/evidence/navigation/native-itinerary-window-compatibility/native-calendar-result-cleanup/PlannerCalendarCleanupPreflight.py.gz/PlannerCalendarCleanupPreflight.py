from pathlib import Path
import subprocess,json,hashlib,gzip,os
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd()==repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
compact=json.loads((root/'native-calendar-resize-iterations/outcomes.json').read_text())
archived=Path('/private/tmp/PlannerHeaderUnpublishedDiagnostics/native-calendar-resize-probes')
candidates=[root/'native-calendar-month-count-value-mac',root/'native-calendar-window-bounds-day-inspection-mac',root/'native-calendar-month-zone-mac-local']
candidates += [archived/record['phase'] for record in compact['records'] if (archived/record['phase']/'test-results-summary.json').is_file()]
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
records=[]
for packet in candidates:
    bundle=Path('/private/tmp/PlannerItemWindow-'+packet.name+'.xcresult')
    assert bundle.is_dir() and not bundle.is_symlink(),bundle
    status=json.loads((packet/'exit.json').read_text())
    assert status['runnerTimedOut'] is False and status['actualTestCaseStarted'] is True,packet
    summary=json.loads((packet/'test-results-summary.json').read_text())
    command=['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle)]
    result=subprocess.run(command,env=environment,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    assert json.loads(result.stdout)==summary,packet
    manifest=json.loads((packet/'selected-attachments.json').read_text())
    export=Path('/private/tmp/PlannerLabelAttachments-'+packet.name)
    attachments=manifest['attachments']+manifest.get('excludedAttachments',[])
    for attachment in attachments:
        original=export/attachment['exportedFileName']
        assert original.is_file() and hashlib.sha256(original.read_bytes()).hexdigest()==attachment['sha256'],original
    handle_check=subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(bundle)],capture_output=True,text=True)
    assert handle_check.returncode==1 and not handle_check.stdout.strip() and not handle_check.stderr.strip(),str(bundle)+handle_check.stdout+handle_check.stderr
    files=[path for path in bundle.rglob('*') if path.is_file()]
    records.append({'phase':packet.name,'rawBundle':str(bundle),'retainedSummary':str(packet/'test-results-summary.json'),'retainedSummarySha256':hashlib.sha256((packet/'test-results-summary.json').read_bytes()).hexdigest(),'rawSummaryCommand':command,'rawSummaryMatchesRetained':True,'openFileCheck':{'command':handle_check.args,'exitCode':handle_check.returncode,'stdout':handle_check.stdout,'stderr':handle_check.stderr},'verifiedOriginalAttachmentCount':len(attachments),'nominalBytes':sum(path.stat().st_size for path in files),'fileCount':len(files),'counts':{key:summary[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests']}})
report={'evidenceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Completed Calendar xcresult bundles only. Retained scoped evidence and original exported attachments remain unchanged. No source, products, packages, Simulator or user datasets are cleanup candidates.','bundles':records,'nominalBytes':sum(record['nominalBytes'] for record in records),'verifiedOriginalAttachmentCount':sum(record['verifiedOriginalAttachmentCount'] for record in records),'deleted':False}
Path('/private/tmp/PlannerCalendarCleanupCandidates.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'eligibleBundleCount':len(records),'nominalBytes':report['nominalBytes'],'verifiedOriginalAttachmentCount':report['verifiedOriginalAttachmentCount'],'deleted':False}))
