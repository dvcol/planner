from pathlib import Path
import json,hashlib,subprocess,shutil
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd()==repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
report=json.loads(Path('/private/tmp/PlannerCalendarCleanupCandidates.json').read_text())
assert report['evidenceCommit']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for record in report['bundles']:
    path=Path(record['rawBundle'])
    assert path.parent.resolve()==Path('/private/tmp').resolve() and path.name.startswith('PlannerItemWindow-native-calendar-') and path.suffix=='.xcresult'
    assert path.is_dir() and not path.is_symlink()
    summary=Path(record['retainedSummary'])
    assert hashlib.sha256(summary.read_bytes()).hexdigest()==record['retainedSummarySha256']
    check=subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(path)],capture_output=True,text=True)
    assert check.returncode==1 and not check.stdout.strip() and not check.stderr.strip(),path
for record in report['bundles']:
    path=Path(record['rawBundle']);shutil.rmtree(path);assert not path.exists()
    record['removed']=True
report['deleted']=True
report['preserved']='All source, current products, packages, Simulator state, user datasets, committed evidence, private diagnostic packets and 152 hash-verified original exported attachments.'
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-calendar-result-cleanup'
packet.mkdir(exist_ok=False)
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
for source in ['/private/tmp/PlannerCalendarCleanupPreflight.py','/private/tmp/PlannerCalendarCleanupRemove.py']:
    import gzip
    path=Path(source);(packet/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
print(json.dumps({'removedBundleCount':len(report['bundles']),'nominalBytesRemoved':report['nominalBytes'],'preservedOriginalAttachments':report['verifiedOriginalAttachmentCount']}))
