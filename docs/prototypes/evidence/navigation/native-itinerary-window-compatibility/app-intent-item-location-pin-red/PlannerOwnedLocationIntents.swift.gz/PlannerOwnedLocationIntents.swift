#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct EditPlannerItemLocationIntent: AppIntent {
    static let title: LocalizedStringResource = "Edit Item location"
    static let description = IntentDescription(
      "Edit saved place text. Omitted text stays unchanged; empty text clears it. Keep the saved pin unless Remove saved pin is selected. Links stay unchanged."
    )
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Item") var item: PlannerItemEntity
    @Parameter(title: "Place name") var placeName: String?
    @Parameter(title: "Address") var address: String?
    @Parameter(title: "Remove saved pin", default: false) var removeSavedPin: Bool
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<Never, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      guard placeName != nil || address != nil || removeSavedPin else {
        throw PlannerOwnedLocationIntentFailure(
          message: "Choose place text to change or remove the saved pin.")
      }
      let dialog = try await updatePlannerOwnedLocation(
        source: .init(kind: .item, id: item.id), store: plannerStore
      ) { current in
        var draft = SavedOwnedLocationDraft(current)
        if let placeName { draft.name = placeName }
        if let address { draft.address = address }
        if removeSavedPin { draft.keepsSavedPin = false }
        return draft.value
      }
      return .result(dialog: dialog)
    }
  }

  struct EditPlannerItineraryLocationIntent: AppIntent {
    static let title: LocalizedStringResource = "Edit Itinerary location"
    static let description = IntentDescription(
      "Edit saved place text. Omitted text stays unchanged; empty text clears it. Keep the saved pin unless Remove saved pin is selected. Links stay unchanged."
    )
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Itinerary") var itinerary: PlannerItineraryEntity
    @Parameter(title: "Place name") var placeName: String?
    @Parameter(title: "Address") var address: String?
    @Parameter(title: "Remove saved pin", default: false) var removeSavedPin: Bool
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<Never, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      guard placeName != nil || address != nil || removeSavedPin else {
        throw PlannerOwnedLocationIntentFailure(
          message: "Choose place text to change or remove the saved pin.")
      }
      let dialog = try await updatePlannerOwnedLocation(
        source: .init(kind: .itinerary, id: itinerary.id), store: plannerStore
      ) { current in
        var draft = SavedOwnedLocationDraft(current)
        if let placeName { draft.name = placeName }
        if let address { draft.address = address }
        if removeSavedPin { draft.keepsSavedPin = false }
        return draft.value
      }
      return .result(dialog: dialog)
    }
  }

  @MainActor
  private func updatePlannerOwnedLocation(
    source: PlannerEntityReference, store: SavedPlannerStore,
    change: (PlannerOwnedLocation?) throws -> PlannerOwnedLocation?
  ) async throws -> IntentDialog {
    let (planner, session) = try await store.appIntentContext()
    try Task.checkCancellation()
    let command: PlannerCommand
    switch await planner.read(session: session, request: .source(source)) {
    case .source(.item(let current)) where source.kind == .item:
      let value = try change(current.content.location)
      let locationChange = value.map(PlannerFieldChange.set) ?? .clear
      command = .editItem(
        sourceId: current.source.id, changes: .init(location: locationChange),
        expectedFieldHashes: current.fieldHashes)
    case .source(.itinerary(let current)) where source.kind == .itinerary:
      let value = try change(current.content.location)
      let locationChange = value.map(PlannerFieldChange.set) ?? .clear
      command = .editItinerary(
        sourceId: current.source.id, changes: .init(location: locationChange),
        expectedFieldHashes: current.fieldHashes)
    case .failed(let reason): throw PlannerOwnedLocationIntentFailure(message: reason.message)
    default:
      throw PlannerOwnedLocationIntentFailure(
        message: "Planner could not read this location's source.")
    }
    let result = try await store.executeAppIntent(command)
    switch result.outcome {
    case .rejected(let reason): throw PlannerOwnedLocationIntentFailure(message: reason.message)
    case .unverified:
      throw PlannerOwnedLocationIntentFailure(
        message:
          "Planner could not verify this change. Open Planner to review recovery before making another change."
      )
    case .applied(_, let recovery):
      switch recovery {
      case .complete: return "Updated the saved location. Links and bookings are unchanged."
      case .incomplete:
        return
          "The location changed on this device, but its recovery copy is incomplete. Open Planner before making more changes."
      }
    }
  }

  private struct PlannerOwnedLocationIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
