from pathlib import Path
import gzip
import hashlib
import json
import sys


def typed_value(value):
    """Keep booleans distinct from numbers and preserve nested sequence order."""
    if value is None:
        return ("null",)
    if isinstance(value, bool):
        return ("boolean", value)
    if isinstance(value, (int, float)):
        return ("number", *value.as_integer_ratio())
    if isinstance(value, str):
        return ("string", value)
    if isinstance(value, list):
        return ("array", tuple(typed_value(element) for element in value))
    assert isinstance(value, dict)
    return ("object", tuple(sorted((key, typed_value(element)) for key, element in value.items())))


repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
assert platform in ['phone', 'tablet']
root = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = root / phase
attachments = json.loads((packet / 'selected-attachments.json').read_text())['attachments']
summary = json.loads((packet / 'test-results-summary.json').read_text())
provenance = json.loads((root / 'native-backup-conflicts-inputs/fixture-provenance.json').read_text())
original = json.loads((repository / provenance['baseFixture']['source']).read_bytes())
incoming = json.loads((repository / provenance['source']).read_bytes())
assert original['sources'][0]['content']['notes'] == 'Original notes'
assert incoming['sources'][0]['content']['notes'] == 'Incoming museum notes'
assert original['memberships'][0]['localDone'] is True
assert incoming['memberships'][0]['localDone'] is False
assert original['completionChanges'][0]['done'] is True
assert incoming['completionChanges'][0]['done'] is False
assert original['sources'][2]['content']['name'] == 'Tokyo Food'
assert incoming['sources'][2]['content']['name'] == 'Revised Tokyo Food'
assert len(original['sources']) == 7 and len(incoming['sources']) == 8
new_item = incoming['sources'][-1]
assert new_item['id'] == '00000000-0000-4000-8000-000000000103'
assert new_item['content']['title'] == 'New backup stop'
log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode(errors='replace')
passes = [line for line in log.splitlines() if line.startswith("Test Case '") and 'testFullGraphSkipPreservesCurrentOwnersAndOverwriteReplacesScopedState' in line and ' passed (' in line]
results = {}
for mode in ['Skip', 'Overwrite']:
    matches = [entry for entry in attachments if entry['suggestedHumanReadableName'].startswith('Conflicting graph ' + mode + ' delivered backup filename')]
    if not matches and summary['failedTests'] > 0:
        results[mode] = {'notProduced': True}
        continue
    assert len(matches) == 1, (mode, matches)
    filename = gzip.decompress((packet / matches[0]['retainedFileName']).read_bytes()).decode().strip()
    assert Path(filename).name == filename and filename.endswith('.json')
    delivered = Path(provenance['destinations'][platform]).parent / filename
    assert delivered.is_file(), delivered
    assert delivered.stat().st_mtime >= summary['startTime'] - 2
    data = delivered.read_bytes()
    actual = json.loads(data)
    expected = json.loads(json.dumps(original if mode == 'Skip' else incoming))
    if mode == 'Skip':
        expected['sources'].append(new_item)
    assert expected['formatVersion'] == 1
    expected['formatVersion'] = 2
    for source in expected['sources']:
        if source['kind'] in ['list', 'itinerary']:
            source['content']['manualEstimate'] = None
    assert set(actual) == set(expected)
    differences = []
    for key, value in expected.items():
        if isinstance(value, list):
            actual_signature = sorted((typed_value(record) for record in actual[key]), key=repr)
            expected_signature = sorted((typed_value(record) for record in value), key=repr)
        else:
            actual_signature = typed_value(actual[key])
            expected_signature = typed_value(value)
        if actual_signature != expected_signature:
            differences.append(key)
    assert not differences, (mode, differences)
    (packet / ('delivered-' + mode.lower() + '-backup.json.gz')).write_bytes(gzip.compress(data, mtime=0))
    results[mode] = {'path':str(delivered),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'modifiedAfterTestStarted':True,'recordCounts':{key:len(value) for key,value in actual.items() if isinstance(value,list)},'differences':differences}
if all('path' in result for result in results.values()):
    assert results['Skip']['path'] != results['Overwrite']['path']
if len(passes) == 1:
    assert all('path' in result for result in results.values())
result = {'sourceFixtureSha256':provenance['sha256'],'baseFixtureSha256':provenance['baseFixture']['sha256'],'comparison':'All typed fields and complete record tables; duplicate counts, ranks and nested sequence order preserved; top-level table order ignored','allowedMigration':'formatVersion 1 to 2 and null manualEstimate on List/Itinerary','uiFunctionPassed':len(passes)==1,'bundlePassed':summary['failedTests']==0 and summary['skippedTests']==0,'results':results}
(packet / 'delivered-backup-verification.json').write_text(json.dumps(result,indent=2)+'\n')
(packet / 'delivered-backup-verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(result,indent=2))
