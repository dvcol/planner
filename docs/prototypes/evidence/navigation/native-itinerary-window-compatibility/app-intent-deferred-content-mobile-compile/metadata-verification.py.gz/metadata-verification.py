from pathlib import Path
import gzip,hashlib,json,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={
'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),
'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),
'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
baseline_phase='app-shortcut-discovery-create-qualified' if platform=='mac' else 'app-shortcut-discovery-'+platform+'-compile'
baseline=json.loads(gzip.decompress((root/baseline_phase/'extract.actionsdata.gz').read_bytes()))
raw=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes()
current=json.loads(raw)
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
for section in ['actions','queries','enums','autoShortcuts']:
    assert normalize(current[section])==normalize(baseline[section]),section
expected={
'PlannerItemEntity':{'notes':'text','subtitle':'text','locationName':'text','address':'text','pin':'pin','created':'date','lastUpdated':'date'},
'PlannerListEntity':{'notes':'text','created':'date','lastUpdated':'date'},
'PlannerItineraryEntity':{'notes':'text','locationName':'text','address':'text','pin':'pin','created':'date','lastUpdated':'date'}}
assert set(current['entities'])==set(baseline['entities'])
property_count=0
for name,old_entity in baseline['entities'].items():
    entity=current['entities'][name]
    if name not in expected:
        assert normalize(entity)==normalize(old_entity),name
        continue
    old_properties=old_entity['properties']
    old_identifiers={field['identifier'] for field in old_properties}
    additions=[field for field in entity['properties'] if field['identifier'] not in old_identifiers]
    assert {field['identifier'] for field in additions}==set(expected[name]),name
    stripped=dict(entity,properties=[field for field in entity['properties'] if field['identifier'] in old_identifiers])
    assert normalize(stripped)==normalize(old_entity),name
    for field in additions:
        kind=expected[name][field['identifier']]
        assert field['capabilities']==2,field
        assert field['isOptional']==(kind!='date'),field
        value=field['valueType']
        if kind=='text':assert value=={'primitive':{'wrapper':{'typeIdentifier':0}}},field
        elif kind=='date':assert value=={'primitive':{'wrapper':{'typeIdentifier':8}}},field
        else:
            assert value['entity']['wrapper']['typeName']=='GeoToolbox.PlaceDescriptorEntity',field
            assert value['entity']['wrapper']['system']['contentTypeIdentifier']=='com.apple.GeoToolbox.PlaceDescriptor',field
        property_count+=1
assert property_count==16
(root/phase/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(root/phase/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
report={'platform':platform,'addedDeferredProperties':expected,'addedPropertyCount':property_count,'all72ActionContractsPreserved':True,'existingPropertiesQueriesEnumsAndFourShortcutsPreserved':True,'comparisonNormalization':'resolvableInputTypes alternatives only','metadataSha256':hashlib.sha256(raw).hexdigest(),'systemPropertyFetchingCredit':False}
(root/phase/'metadata-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(platform,'16 exact deferred properties; existing native contracts retained')
