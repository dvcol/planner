import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryEditingIntentTests: XCTestCase {
  func testEditPreservesRichContentRouteIndependentCompletionAndScheduleAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdCategory = try await save(.createCategory(content: .init(name: "Travel")))
    let category = try XCTUnwrap(createdCategory.generated.first)
    let createdTag = try await save(.createTag(content: .init(name: "Weekend")))
    let tag = try XCTUnwrap(createdTag.generated.first)
    let color = PlannerColor(red: 0.1, green: 0.3, blue: 0.7, alpha: 1)
    let estimate = PlannerEstimate(minutes: 210, displayUnit: .hour)
    let location = PlannerOwnedLocation(
      displayName: "Hotel", formattedAddress: "Tokyo, Japan",
      coordinate: .init(latitude: 35.662, longitude: 139.717))
    let createdPlan = try await save(
      .createItinerary(
        content: .init(
          title: "Tokyo Weekend", notes: "Original route notes", color: color, iconName: "map",
          location: location,
          links: [.init(originalUrl: "https://example.com/route", label: "Route guide")],
          categoryIds: [category.id], tagIds: [tag.id], manualEstimate: estimate)))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    let createdItem = try await save(
      .createItem(
        content: .init(
          title: "Hotel", notes: "Shared Hotel notes",
          estimate: .init(minutes: 60, displayUnit: .hour))))
    let item = try XCTUnwrap(createdItem.generated.first)
    let firstEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    let secondEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard
      case .itineraryEntry(let firstIdentifier, _, _)? = firstEntry.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondEntry.generatedReferences.first
    else { return XCTFail("Repeated references must retain their distinct entry identities.") }
    let firstAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: firstIdentifier)
    let secondAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: secondIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(firstAppearance), done: true))
    let scheduleForm = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11))
    let createdSchedule = try await save(.createSchedule(source: itinerary, form: scheduleForm))
    let schedule = try XCTUnwrap(createdSchedule.generated.first)
    _ = try await save(.setArchive(source: itinerary, archived: true))
    guard
      case .source(.itinerary(let before)) = await planner.read(
        session: session, request: .source(itinerary)),
      case .source(.item(let beforeItem)) = await planner.read(
        session: session, request: .source(item))
    else { return XCTFail("The archived rich plan must be readable before editing.") }
    XCTAssertEqual(before.progress.doneCount, 1)
    XCTAssertEqual(before.progress.totalCount, 2)
    let editing = EditPlannerItineraryIntent()
    editing.itinerary = .init(id: itinerary.id, title: "Obsolete cached title", archived: false)
    editing.title = "Reviewed Tokyo Weekend"
    editing.notes = "Reviewed route notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.itinerary(let after)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.item(let afterItem)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.schedule(let afterSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule)),
      case .appearance(let firstState) = await reopened.read(
        session: reopenedSession, request: .appearance(firstAppearance)),
      case .appearance(let secondState) = await reopened.read(
        session: reopenedSession, request: .appearance(secondAppearance))
    else {
      return XCTFail("Original sources, route appearances and schedule must survive reopening.")
    }
    XCTAssertEqual(after.source, itinerary)
    XCTAssertEqual(after.sourceLifetimeId, before.sourceLifetimeId)
    XCTAssertEqual(after.content.title, "Reviewed Tokyo Weekend")
    XCTAssertEqual(after.content.notes, "Reviewed route notes")
    XCTAssertEqual(after.content.color, color)
    XCTAssertEqual(after.content.iconName, "map")
    XCTAssertEqual(after.content.location, location)
    XCTAssertEqual(after.content.links, before.content.links)
    XCTAssertEqual(after.content.categoryIds, [category.id])
    XCTAssertEqual(after.content.tagIds, [tag.id])
    XCTAssertEqual(after.content.manualEstimate, estimate)
    XCTAssertEqual(after.labels, before.labels)
    XCTAssertEqual(after.state.archived, true)
    XCTAssertNil(after.state.globalDone)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(after.progress.doneCount, 1)
    XCTAssertEqual(after.progress.totalCount, 2)
    XCTAssertEqual(after.estimates, before.estimates)
    XCTAssertEqual(afterItem.content, beforeItem.content)
    XCTAssertEqual(afterItem.updatedAt, beforeItem.updatedAt)
    XCTAssertEqual(afterSchedule.source, schedule)
    XCTAssertEqual(afterSchedule.content.source, itinerary)
    XCTAssertEqual(afterSchedule.content.form, scheduleForm)
    XCTAssertFalse(firstState.globalDone)
    XCTAssertTrue(firstState.localDone)
    XCTAssertTrue(firstState.effectiveDone)
    XCTAssertFalse(secondState.globalDone)
    XCTAssertFalse(secondState.localDone)
    XCTAssertFalse(secondState.effectiveDone)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(
        path: "PlannerItineraryEditingIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory
      )
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
