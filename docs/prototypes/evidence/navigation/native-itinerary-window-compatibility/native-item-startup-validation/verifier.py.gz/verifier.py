from pathlib import Path
import gzip, hashlib, json, subprocess, re
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
root = repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
phases = ['native-item-cold-start-phone-controls','native-item-cold-start-tablet-controls']
expected_case = 'testItemsCreationMenuAfterFreshLaunchCanOpenAndCancelDraft'
source_hashes = json.loads((root/'native-item-cold-start-mac-build/source-sha256.json').read_text())
assert len(source_hashes) == 1061
for relative, digest in source_hashes.items():
    assert hashlib.sha256((repository/relative).read_bytes()).hexdigest() == digest, relative
assert json.loads((root/'native-item-cold-start-mac-build/exit.json').read_text())['exitCode'] == 0
runs = []
for phase in phases:
    packet = root/phase
    assert json.loads((packet/'source-sha256.json').read_text()) == source_hashes
    summary = json.loads((packet/'test-results-summary.json').read_text())
    assert {key:summary[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests']} == {'totalTestCount':1,'passedTests':1,'failedTests':0,'skippedTests':0}
    log = gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
    matches = re.findall(r"Test Case '-\[PlannerNavigationUITests.SavedItemJourneyTests (\w+)\]' passed \(([\d.]+) seconds\)",log)
    assert len(matches) == 1 and matches[0][0] == expected_case
    runs.append({'phase':phase,'case':expected_case,'seconds':float(matches[0][1]),'passed':1,'failed':0,'skipped':0})
boots = []
for phase in ['native-item-cold-start-tablet-boot','native-item-cold-start-tablet-controls-boot']:
    report = json.loads((root/phase/'boot.json').read_text())
    assert report['completed'] and report['udid'] == 'FBD72DAB-1D40-4E64-912D-7F9763E00446'
    assert len(report['commands']) == 3 and all(command['exitCode'] == 0 for command in report['commands'])
    assert [command['command'][2] for command in report['commands']] == ['shutdown','boot','bootstatus']
    boots.append({'phase':phase,'device':report['name'],'commands':3,'completed':True,'erased':False})
mac = root/'native-schedule-actions-mac'
status = json.loads((mac/'exit.json').read_text())
assert status['exitCode'] == 65 and not status['runnerTimedOut'] and not status['actualTestCaseStarted'] and not status['passingCredit']
log = gzip.decompress((mac/'test.log.gz').read_bytes()).decode()
assert "Test Case '-[" not in log and 'Timed out while enabling automation mode.' in log
assert not subprocess.check_output(['git','diff','--name-only','2d360504','--','Planner','Packages','Configuration','Planner.xcodeproj','PlannerShareMobile','PlannerShareMac'],text=True).strip()
packet = root/'native-item-startup-validation';packet.mkdir(exist_ok=False)
report = {'sourceInputs':1061,'finalCompilerAndRuntimeEpochs':3,'allFinalInputsMatchWorkspace':True,'productionChanges':False,'runs':runs,'coldBoots':boots,'macScheduleRequestedCasesExecuted':0,'macRunnerInitializationError':True,'macReadinessRequested':True,'originalAddMenuFailureReproduced':False,'fixClaimed':False,'scope':'Diagnostic startup checkpoint and native test-driver correction only. The original Add-menu failure remains unclassified; Mac Schedule actions/all-day/resize/system/signed/physical qualifications remain open.'}
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'sourceInputs':1061,'passingMobileCases':2,'macRequestedCasesExecuted':0,'originalAddMenuFailureReproduced':False,'productionChanges':False}))
