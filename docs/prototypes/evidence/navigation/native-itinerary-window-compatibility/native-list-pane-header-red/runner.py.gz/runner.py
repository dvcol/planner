from pathlib import Path
import gzip, hashlib, json, os, signal, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, selected = sys.argv[1:3]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
compilation = evidence / 'native-list-pane-header-red-mac-build'
packet = evidence / phase
packet.mkdir(exist_ok=False)
root = Path('/private/tmp/PlannerNativeItemWindowSource')
source_hashes = json.loads((compilation / 'source-sha256.json').read_text())
for relative, digest in source_hashes.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest, relative
(packet / 'source-sha256.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
(packet / 'source-root.json').write_bytes((compilation / 'source-root.json').read_bytes())
product_hashes = json.loads((compilation / 'product-sha256.json').read_text())
for product, digest in product_hashes.items():
    assert hashlib.sha256(Path(product).read_bytes()).hexdigest() == digest, product
(packet / 'product-sha256.json').write_text(json.dumps(product_hashes, indent=2) + '\n')
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
command = ['xcodebuild', 'test-without-building', '-project', 'Planner.xcodeproj', '-scheme', 'PlannerNavigation', '-destination', 'platform=macOS,arch=arm64', '-derivedDataPath', '/private/tmp/PlannerNativeItemWindowDerivedData', '-parallel-testing-enabled', 'NO', '-jobs', '1', '-test-timeouts-enabled', 'YES', '-default-test-execution-time-allowance', '300', '-maximum-test-execution-time-allowance', '300', *['-only-testing:PlannerNavigationUITests/' + name for name in selected.split(',')], '-resultBundlePath', '/private/tmp/PlannerItemWindow-' + phase + '.xcresult']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerItemWindow-' + phase + '.log')
timed_out = False
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
        code = 124
content = log.read_text(errors='replace')
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
report = {'exitCode': code, 'runnerTimedOut': timed_out, 'actualTestCaseStarted': "Test Case '-[" in content, 'passingCredit': code == 0 and any(marker in content for marker in ['** TEST SUCCEEDED **', '** TEST EXECUTE SUCCEEDED **'])}
(packet / 'exit.json').write_text(json.dumps(report, indent=2) + '\n')
for relative, digest in source_hashes.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest, relative
for product, digest in product_hashes.items():
    assert hashlib.sha256(Path(product).read_bytes()).hexdigest() == digest, product
print(json.dumps(report))
for line in content.splitlines():
    if any(marker in line for marker in ['error:', 'Failed to', 'Failed with', '** TEST', 'Test Case ']):
        print(line[:600])
raise SystemExit(code)
