from pathlib import Path
import gzip
import hashlib
import json
import re

workspace = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == workspace
base = workspace / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = base / 'native-saved-preview-follow-up'
packet.mkdir(exist_ok=True)
test_path = 'PlannerNavigationUITests/SavedAppearanceJourneyTests.swift'
final_build = base / 'native-saved-preview-reachability-final-build'
earlier_build = base / 'native-saved-link-keyboard-submit-build'
final_manifest = json.loads((final_build / 'source-sha256.json').read_text())
earlier_manifest = json.loads((earlier_build / 'source-sha256.json').read_text())
assert final_manifest.keys() == earlier_manifest.keys()
changed = [name for name in final_manifest if final_manifest[name] != earlier_manifest[name]]
assert changed == [test_path], changed
assert all(hashlib.sha256((workspace / name).read_bytes()).hexdigest() == digest for name, digest in final_manifest.items())
final_source = (workspace / test_path).read_text()
earlier_source = gzip.decompress((earlier_build / 'SavedAppearanceJourneyTests.swift.gz').read_bytes()).decode()

def function_source(source, name):
    start = re.search(r'^  (?:private )?func ' + re.escape(name) + r'\(', source, re.M)
    assert start, name
    end = re.search(r'^  }\n', source[start.start():], re.M)
    assert end, name
    return source[start.start():start.start() + end.end()]

changed_functions = [
    'testOwnedAddressCreatesANativePreviewAndRemainsLiveInACompletedList',
    'testNativeBookmarkValidationEditOrderAndRemovalPreserveItemStateAfterRelaunch',
]
remaining_final = final_source
remaining_earlier = earlier_source
for name in changed_functions:
    remaining_final = remaining_final.replace(function_source(final_source, name), '<' + name + '>')
    remaining_earlier = remaining_earlier.replace(function_source(earlier_source, name), '<' + name + '>')
assert remaining_final == remaining_earlier

def native_cases(value):
    output = []
    if isinstance(value, dict):
        if value.get('nodeType') == 'Test Case':
            output.append(value)
        for child in value.values():
            output.extend(native_cases(child))
    elif isinstance(value, list):
        for child in value:
            output.extend(native_cases(child))
    return output

selections = {
    'native-saved-link-submit-regression-phone': [
        'testNativeWebsitePreviewsKeepOwnedLinksAndRemainLiveInAList',
        'testNativePreviewFailureKeepsTheOwnedLinkAndAllowsRetry',
    ],
    'native-saved-link-submit-green-tablet': ['testNativeWebsitePreviewsKeepOwnedLinksAndRemainLiveInAList'],
    'native-saved-link-submit-regression-tablet': ['testNativePreviewFailureKeepsTheOwnedLinkAndAllowsRetry'],
    'native-saved-preview-final-validation-and-address-phone': changed_functions,
    'native-saved-preview-final-validation-and-address-tablet': changed_functions,
}
accepted = []
for phase, names in selections.items():
    directory = base / phase
    result = json.loads(gzip.decompress((directory / 'test-results-tests.json.gz').read_bytes()))
    cases = native_cases(result)
    log = gzip.decompress((directory / 'test.log.gz').read_bytes()).decode(errors='replace')
    phase_manifest = json.loads((directory / 'source-sha256.json').read_text())
    assert phase_manifest.keys() == final_manifest.keys()
    assert all(phase_manifest[name] == final_manifest[name] for name in final_manifest if name != test_path)
    for name in names:
        matches = [case for case in cases if case.get('name') == name + '()']
        assert len(matches) == 1 and matches[0]['result'] == 'Passed', (phase, name, matches)
        if phase_manifest[test_path] != final_manifest[test_path]:
            assert function_source(earlier_source, name) == function_source(final_source, name)
        duration = re.search(re.escape(name) + r"\]' passed \(([0-9.]+) seconds\)", log)
        assert duration, (phase, name)
        accepted.append({'phase': phase, 'function': name, 'result': 'Passed', 'seconds': float(duration.group(1)), 'functionSha256': hashlib.sha256(function_source(final_source, name).encode()).hexdigest()})

build_verification = {}
for phase in ['native-saved-preview-reachability-final-build', 'native-saved-preview-reachability-final-mac-build']:
    directory = base / phase
    assert json.loads((directory / 'exit.json').read_text())['exitCode'] == 0
    assert json.loads((directory / 'source-sha256.json').read_text()) == final_manifest
    products = json.loads((directory / 'product-sha256.json').read_text())
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
    build_verification[phase] = {'inputCount': len(final_manifest), 'matchesWorkspace': True, 'productsMatchRecordedBuild': True}

history = []
for phase in ['native-saved-link-current-phone', 'native-saved-link-current-tablet', 'native-saved-link-second-add-diagnostic-tablet', 'native-saved-link-submit-green-tablet', 'native-saved-link-submit-regression-phone', 'native-saved-link-submit-regression-tablet', 'native-saved-preview-final-validation-and-address-phone', 'native-saved-preview-final-validation-and-address-tablet']:
    directory = base / phase
    summary = json.loads((directory / 'test-summary.json').read_text())
    history.append({'phase': phase, 'nativeExit': json.loads((directory / 'exit.json').read_text())['exitCode'], 'passed': summary['passedTests'], 'failed': summary['failedTests'], 'skipped': summary['skippedTests']})

report = {'acceptedCases': accepted, 'acceptedCount': len(accepted), 'sourceCount': len(final_manifest), 'unchangedOtherSourceAndConfigurationInputs': len(final_manifest) - 1, 'changedTestFunctionsSincePreviewPasses': changed_functions, 'allOtherTestCodeIncludingHelpersUnchanged': True, 'finalBuilds': build_verification, 'completeInvocationHistory': history, 'scope': 'Four distinct native functions per simulator, selected from separate recorded epochs. One accepted Retry case belongs to an otherwise failed bundle; those failures remain explicit. This is not a whole-suite or physical-device qualification.'}
assert len(accepted) == 8
(packet / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
(packet / 'verify-evidence.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'acceptedCases': len(accepted), 'sourceInputs': len(final_manifest), 'unchangedOtherSourceInputs': len(final_manifest) - 1, 'history': {'passed': sum(entry['passed'] for entry in history), 'failed': sum(entry['failed'] for entry in history), 'skipped': sum(entry['skipped'] for entry in history)}}))
