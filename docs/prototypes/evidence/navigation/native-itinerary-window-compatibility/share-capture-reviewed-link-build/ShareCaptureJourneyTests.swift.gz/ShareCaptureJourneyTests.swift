import XCTest

@MainActor
final class ShareCaptureJourneyTests: XCTestCase {
  func testNativeProviderShareReviewCreatesNothingUntilSaveAndOpensTheSavedItem() {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = [
      "--share-extension-fixture", "--fixture-dataset", UUID().uuidString,
    ]
    application.launchSavedPlannerJourney()
    let title = application.textFields["saved.capture.title"]
    XCTAssertTrue(title.waitForExistence(timeout: 10))
    XCTAssertEqual(title.value as? String, "Saved link")
    application.plannerElement("saved.capture.cancel").activateForPlannerJourney()
    application.openPlannerSection("Items")
    XCTAssertFalse(application.savedPlannerItemRows("Museum visit").firstMatch.exists)
    application.plannerElement("fixture.share.again").activateForPlannerJourney()
    XCTAssertTrue(title.waitForExistence(timeout: 10))
    title.activateForPlannerJourney()
    title.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: "Saved link".count))
    title.typeText("Museum visit")
    application.plannerElement("saved.capture.add").activateForPlannerJourney()
    application.openPlannerSection("Items")
    let row = application.savedPlannerItemRows("Museum visit").firstMatch
    XCTAssertTrue(row.waitForExistence(timeout: 10))
    let identifier = row.identifier
    row.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Museum visit"].firstMatch.waitForExistence(timeout: 10))
    application.terminate()
    application.launchSavedPlannerJourney()
    application.plannerElement("saved.capture.cancel").activateForPlannerJourney()
    application.openPlannerSection("Items")
    XCTAssertEqual(
      application.savedPlannerItemRows("Museum visit").firstMatch.identifier, identifier)
  }
}
