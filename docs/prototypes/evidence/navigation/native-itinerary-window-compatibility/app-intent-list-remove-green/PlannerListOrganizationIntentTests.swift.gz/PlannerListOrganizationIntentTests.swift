import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerListOrganizationIntentTests: XCTestCase {
  func testRemoveOnlyTheSelectedMembershipPreservesSharedItemOtherContextsOrderAndSchedule()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let museum = try await save(.createItem(content: .init(title: "Museum", notes: "Shared notes")))
    let item = try XCTUnwrap(museum.generated.first)
    let lunch = try await save(.createItem(content: .init(title: "Lunch")))
    let otherItem = try XCTUnwrap(lunch.generated.first)
    let first = try await save(.createList(content: .init(name: "Tokyo Food")))
    let sourceList = try XCTUnwrap(first.generated.first)
    let second = try await save(.createList(content: .init(name: "Wishlist")))
    let otherList = try XCTUnwrap(second.generated.first)
    let selected = try await save(
      .addMembership(itemId: item.id, listId: sourceList.id, placement: .last))
    let survivor = try await save(
      .addMembership(itemId: otherItem.id, listId: sourceList.id, placement: .last))
    let other = try await save(
      .addMembership(itemId: item.id, listId: otherList.id, placement: .last))
    guard case .membership(let removedIdentifier, _, _)? = selected.generatedReferences.first,
      case .membership(let survivorIdentifier, _, _)? = survivor.generatedReferences.first,
      case .membership(let otherIdentifier, _, _)? = other.generatedReferences.first
    else { return XCTFail("The fixture must retain each independent membership identity.") }
    let removedAppearance = PlannerAppearance.listMembership(
      listId: sourceList.id, membershipId: removedIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(removedAppearance), done: true))
    let createdPlan = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    _ = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: sourceList, placement: .last))
    let direct = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let directIdentifier, _, _)? = direct.generatedReferences.first
    else { return XCTFail("The direct route appearance must survive membership removal.") }
    let scheduleForm = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let booking = try await save(.createSchedule(source: item, form: scheduleForm))
    let schedule = try XCTUnwrap(booking.generated.first)
    guard
      case .source(.item(let before)) = await planner.read(
        session: session, request: .source(item))
    else { return XCTFail("Shared content must be readable before organization changes.") }
    let removing = RemovePlannerItemFromListIntent()
    removing.item = .init(id: item.id, title: "Obsolete title", done: true, archived: true)
    removing.list = .init(id: sourceList.id, name: "Obsolete List", archived: true)
    let _: Void = try await removing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let after)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let savedList)) = await reopened.read(
        session: reopenedSession, request: .source(sourceList)),
      case .source(.list(let savedOther)) = await reopened.read(
        session: reopenedSession, request: .source(otherList)),
      case .source(.itinerary(let savedPlan)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let savedSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule)),
      case .appearance(let otherState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(.listMembership(listId: otherList.id, membershipId: otherIdentifier))),
      case .appearance(let directState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(
          .directItineraryItem(itineraryId: itinerary.id, entryId: directIdentifier))),
      case .failed(let removedFailure) = await reopened.read(
        session: reopenedSession, request: .appearance(removedAppearance))
    else { return XCTFail("Only the selected membership may disappear from reopened storage.") }
    XCTAssertEqual(after.content.title, "Museum")
    XCTAssertEqual(after.content.notes, "Shared notes")
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.updatedAt, before.updatedAt)
    XCTAssertEqual(after.state.globalDone, false)
    XCTAssertEqual(after.state.archived, false)
    XCTAssertEqual(
      savedList.references, [.membership(id: survivorIdentifier, list: sourceList, item: otherItem)]
    )
    XCTAssertEqual(savedList.content.name, "Tokyo Food")
    XCTAssertEqual(savedOther.references, other.generatedReferences)
    XCTAssertFalse(otherState.localDone)
    XCTAssertFalse(otherState.effectiveDone)
    XCTAssertFalse(directState.localDone)
    XCTAssertFalse(directState.effectiveDone)
    XCTAssertEqual(savedPlan.progress.totalCount, 2)
    XCTAssertEqual(savedPlan.progress.doneCount, 0)
    XCTAssertEqual(savedSchedule.content.form, scheduleForm)
    XCTAssertEqual(removedFailure.code, "missingReference")
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory.appending(
      path: "PlannerListOrganizationIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
