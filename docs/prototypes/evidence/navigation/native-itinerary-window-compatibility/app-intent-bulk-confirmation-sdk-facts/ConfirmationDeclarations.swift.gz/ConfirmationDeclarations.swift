import AppIntents

func checkConfirmationDeclarations<Intent: AppIntent>(_ intent: Intent, count: Int) async throws {
  try await intent.requestConfirmation()
  try await intent.requestConfirmation(
    conditions: [], actionName: .continue,
    dialog: "Apply changes to all \(count) selected Items in All Items?")
  try await intent.requestConfirmation(
    actionName: .custom(
      acceptLabel: "Apply", acceptAlternatives: [],
      denyLabel: "Cancel", denyAlternatives: [], destructive: false),
    dialog: "Apply changes to all \(count) selected Items in All Items?")
}
