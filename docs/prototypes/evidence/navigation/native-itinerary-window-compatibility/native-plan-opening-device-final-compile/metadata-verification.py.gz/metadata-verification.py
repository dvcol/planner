from pathlib import Path
import gzip, hashlib, json, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase, platform = sys.argv[1:3]
root = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products = {
    'mac': Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),
    'mobile': Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),
    'device': Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app'),
}
baselines = {'mac': 'app-intent-schedule-form-final', 'mobile': 'app-intent-schedule-form-mobile-compile', 'device': 'app-intent-schedule-form-device-compile'}
baseline = json.loads(gzip.decompress((root / baselines[platform] / 'extract.actionsdata.gz').read_bytes()))
raw = (products[platform] / 'Metadata.appintents/extract.actionsdata').read_bytes()
current = json.loads(raw)
def normalized(value):
    if isinstance(value, dict):
        return {key: sorted((normalized(entry) for entry in content), key=lambda entry: json.dumps(entry, sort_keys=True)) if key == 'resolvableInputTypes' else normalized(content) for key, content in value.items()}
    if isinstance(value, list):
        return [normalized(entry) for entry in value]
    return value
for section in ['entities', 'queries', 'enums', 'autoShortcuts']:
    assert normalized(current[section]) == normalized(baseline[section]), section
for name, action in baseline['actions'].items():
    assert normalized(current['actions'][name]) == normalized(action), name
expected = {'OpenPlannerListIntent': 'PlannerListEntity', 'OpenPlannerItineraryIntent': 'PlannerItineraryEntity'}
assert set(current['actions']) - set(baseline['actions']) == set(expected)
assert len(current['actions']) == 83
for name, entity in expected.items():
    action = current['actions'][name]
    assert action['allowedTargets'] == [{'type': 1}]
    assert action['supportedModes'] == 2
    assert action['authenticationPolicy'] == 0
    assert action.get('outputType') is None
    assert len(action['parameters']) == 1
    parameter = action['parameters'][0]
    assert parameter['name'] == 'target' and parameter['isOptional'] is False
    assert 'defaultValue' not in parameter
    assert parameter['valueType'] == {'entity': {'wrapper': {'typeName': entity}}}
packet = root / phase
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(raw, mtime=0))
(packet / 'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(packet / 'metadata-verification.json').write_text(json.dumps({
    'platform': platform, 'actionCount': 83, 'newForegroundOpenActions': expected,
    'previous81ActionsAndEntitiesQueriesEnumsAndFourShortcutsPreserved': True,
    'requiredExactTargetWithoutDefaultsAndNoValueResult': True,
    'normalization': 'resolvableInputTypes alternatives only',
    'sha256': hashlib.sha256(raw).hexdigest(), 'actualSystemInvocationCredit': False,
}, indent=2) + '\n')
print(platform, '83 action contracts verified; previous contracts unchanged')
