import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerContainerFindIntentTests: XCTestCase {
  func testItineraryFindingCombinesFiltersAndEverySortWithoutChangingRoutesOrBookings() async throws
  {
    let fixture = try await makeContainerFindSortFixture(kind: .itinerary)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Record Itinerary routes, completion and bookings before finding.") }
    let find = FindPlannerItinerariesIntent()
    let defaults: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(defaults.map(\.id), [4, 0, 6, 2, 3, 5, 1].map { fixture.containers[$0].id })
    let cases: [(PlannerCatalogFindSort, PlannerCatalogFindDirection, [Int])] = [
      (.title, .ascending, [4, 0, 6, 2, 3, 5, 1]),
      (.title, .descending, [1, 5, 3, 2, 6, 0, 4]),
      (.created, .ascending, [0, 1, 2, 3, 4, 5, 6]),
      (.created, .descending, [6, 5, 4, 3, 2, 1, 0]),
      (.lastUpdated, .ascending, [1, 2, 3, 4, 5, 6, 0]),
      (.lastUpdated, .descending, [0, 6, 5, 4, 3, 2, 1]),
      (.fullEstimate, .ascending, [4, 2, 6, 0, 1, 5, 3]),
      (.fullEstimate, .descending, [0, 6, 2, 4, 5, 1, 3]),
    ]
    for (mode, direction, positions) in cases {
      find.sort = mode
      find.direction = direction
      let matches: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
      XCTAssertEqual(matches.map(\.id), positions.map { fixture.containers[$0].id })
    }
    guard
      case .exported(let afterSorts) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Catalog sorting must retain the saved Itinerary graph.") }
    XCTAssertEqual(afterSorts, before)
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setArchive(source: fixture.containers[1], archived: true))
      ).outcome,
      case .exported(let beforeFilters) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Archive one partial plan before cumulative filter reads.") }
    find.sort = .fullEstimate
    find.direction = .ascending
    find.text = "PARTIAL"
    let partial: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(partial.map(\.id), [1, 5].map { fixture.containers[$0].id })
    find.archive = .active
    let active: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(active.map(\.id), [fixture.containers[5].id])
    find.archive = .archived
    let archived: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(archived.map(\.id), [fixture.containers[1].id])
    XCTAssertEqual(archived.first?.archived, true)
    find.text = "No matching Itinerary"
    let empty: [PlannerItineraryEntity] = try await find.callAsFunction(donate: false)
    XCTAssertTrue(empty.isEmpty)
    guard
      case .exported(let afterFilters) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Cumulative filters must retain source state and bookings.") }
    XCTAssertEqual(afterFilters, beforeFilters)
  }

  func testListSortingUsesEveryModeAndRetainsEstimateGroupsAndSavedGraph() async throws {
    let fixture = try await makeContainerFindSortFixture(kind: .list)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Record the complete saved graph before sorting Lists.") }
    let find = FindPlannerListsIntent()
    let cases: [(PlannerCatalogFindSort, PlannerCatalogFindDirection, [Int])] = [
      (.title, .ascending, [4, 0, 6, 2, 3, 5, 1]),
      (.title, .descending, [1, 5, 3, 2, 6, 0, 4]),
      (.created, .ascending, [0, 1, 2, 3, 4, 5, 6]),
      (.created, .descending, [6, 5, 4, 3, 2, 1, 0]),
      (.lastUpdated, .ascending, [1, 2, 3, 4, 5, 6, 0]),
      (.lastUpdated, .descending, [0, 6, 5, 4, 3, 2, 1]),
      (.fullEstimate, .ascending, [4, 2, 6, 0, 1, 5, 3]),
      (.fullEstimate, .descending, [0, 6, 2, 4, 5, 1, 3]),
    ]
    for (mode, direction, positions) in cases {
      find.sort = mode
      find.direction = direction
      let matches: [PlannerListEntity] = try await find.callAsFunction(donate: false)
      XCTAssertEqual(matches.map(\.id), positions.map { fixture.containers[$0].id })
    }
    find.sort = .fullEstimate
    find.direction = .ascending
    find.text = "PARTIAL"
    let partial: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(partial.map(\.id), [1, 5].map { fixture.containers[$0].id })
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Sorted List finding must preserve all saved source and context data.") }
    XCTAssertEqual(after, before)
  }

  func testListFindingCombinesTextAndArchiveWithoutChangingSavedData() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let create = CreatePlannerListIntent()
    var lists: [PlannerListEntity] = []
    for name in ["Café Tokyo", "Market Tokyo", "Cafe Osaka"] {
      create.name = name
      create.notes = "Saved notes"
      lists.append(try await create.callAsFunction(donate: false))
    }
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: .init(kind: .list, id: lists[1].id), archived: true))
      )
      .outcome,
      case .exported(let before) = await planner.exportData(session: session)
    else { return XCTFail("Seed and record the real Lists before native finding.") }
    let find = FindPlannerListsIntent()
    let all: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(all.map(\.id), [2, 0, 1].map { lists[$0].id })
    find.text = "TOKYO"
    let tokyo: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(tokyo.map(\.id), [0, 1].map { lists[$0].id })
    find.archive = .active
    let active: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(active.map(\.id), [lists[0].id])
    find.archive = .archived
    let archived: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(archived.map(\.id), [lists[1].id])
    XCTAssertEqual(archived.first?.archived, true)
    find.archive = .all
    find.text = "cAfE"
    let folded: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(folded.map(\.id), [2, 0].map { lists[$0].id })
    find.text = "No matching List"
    let empty: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertTrue(empty.isEmpty)
    guard case .exported(let after) = await planner.exportData(session: session) else {
      return XCTFail("Finding cannot change saved Lists or their references.")
    }
    XCTAssertEqual(after, before)
    XCTAssertFalse(store.isSaving)
  }
}

private struct ContainerFindSortFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let containers: [PlannerEntityReference]
}

@MainActor
private func makeContainerFindSortFixture(kind: PlannerEntityKind) async throws
  -> ContainerFindSortFixture
{
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let saved, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return saved
  }
  var items: [PlannerEntityReference] = []
  let inputs: [(String, Int64?)] = [
    ("Museum", 180), ("Short", 120), ("Medium", 240), ("Long", 300),
    ("Missing", nil), ("Maximum", Int64.max), ("One", 1),
  ]
  for (title, minutes) in inputs {
    let saved = try await save(
      .createItem(
        content: .init(
          title: title, estimate: minutes.map { .init(minutes: $0, displayUnit: .minute) })))
    items.append(try XCTUnwrap(saved.generated.first(where: { $0.kind == .item })))
  }
  _ = try await save(.setCompletion(scope: .globalItem(itemId: items[0].id), done: true))
  _ = try await save(.setArchive(source: items[3], archived: true))
  _ = try await save(
    .createSchedule(
      source: items[0],
      form: .timed(
        start: Date(timeIntervalSinceReferenceDate: 813_000_000), end: nil,
        planningTimeZone: "Asia/Tokyo")))
  let plans: [(String, Int64?, [Int])] = [
    ("Long", nil, [3]), ("Partial short", nil, [1, 4]), ("Museum", nil, [0]),
    ("Overflow", nil, [5, 6]), ("Empty", nil, []), ("Partial long", nil, [2, 4]),
    ("Manual", 240, [4, 1]),
  ]
  var containers: [PlannerEntityReference] = []
  for (title, manualMinutes, children) in plans {
    let manualEstimate = manualMinutes.map { PlannerEstimate(minutes: $0, displayUnit: .hour) }
    let command: PlannerCommand
    switch kind {
    case .list: command = .createList(content: .init(name: title, manualEstimate: manualEstimate))
    case .itinerary:
      command = .createItinerary(content: .init(title: title, manualEstimate: manualEstimate))
    default: throw CancellationError()
    }
    let saved = try await save(command)
    let container = try XCTUnwrap(saved.generated.first(where: { $0.kind == kind }))
    containers.append(container)
    for childIndex in children {
      if kind == .list {
        _ = try await save(
          .addMembership(itemId: items[childIndex].id, listId: container.id, placement: .last))
      } else {
        _ = try await save(
          .addItineraryEntry(itineraryId: container.id, source: items[childIndex], placement: .last)
        )
      }
    }
  }
  if kind == .itinerary {
    _ = try await save(
      .createSchedule(
        source: containers[2],
        form: .allDay(
          start: .init(year: 2026, month: 10, day: 9),
          end: .init(year: 2026, month: 10, day: 11))))
  }
  let first = try XCTUnwrap(containers.first)
  switch await planner.read(session: session, request: .source(first)) {
  case .source(.list(let current)):
    _ = try await save(
      .editList(
        sourceId: first.id, changes: .init(notes: .set("Last edited")),
        expectedFieldHashes: current.fieldHashes))
  case .source(.itinerary(let current)):
    _ = try await save(
      .editItinerary(
        sourceId: first.id, changes: .init(notes: .set("Last edited")),
        expectedFieldHashes: current.fieldHashes))
  default: throw CancellationError()
  }
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    containers: containers)
}
