import XCTest

@MainActor
final class SavedListJourneyTests: XCTestCase {
  func testNewListNotesAreStagedAndRetainedAfterNativeRelaunch() {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    application.beginPlannerListCreation()
    let name = application.textFields["saved.list.name"]
    let notes = application.textFields["saved.list.notes"]
    XCTAssertTrue(name.waitForExistence(timeout: 5))
    name.activateForPlannerJourney()
    name.typeText("Canceled notes")
    XCTAssertTrue(notes.waitForExistence(timeout: 5))
    notes.activateForPlannerJourney()
    notes.typeText("This draft should not be saved")
    application.plannerElement("saved.list.cancel").activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["No Lists yet"].firstMatch.waitForExistence(timeout: 5))

    application.beginPlannerListCreation()
    XCTAssertTrue(name.waitForExistence(timeout: 5))
    name.activateForPlannerJourney()
    name.typeText("Rainy afternoon")
    XCTAssertTrue(notes.waitForPlannerValue("Notes"))
    notes.activateForPlannerJourney()
    notes.typeText("Keep indoor options near the hotel")
    application.plannerElement("saved.list.save").activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["No items"].waitForExistence(timeout: 10))
    application.terminate()
    application.launchSavedPlannerJourney()
    let list = application.savedPlannerListRow("Rainy afternoon")
    revealSidebarIfNeeded(application, element: list)
    XCTAssertTrue(list.waitForExistence(timeout: 10))
    let identifier = list.identifier
    list.activateForPlannerJourney()
    application.openSavedPlannerListActionsMenu()
    application.plannerElement("saved.list.estimate.edit").activateForPlannerJourney()
    XCTAssertTrue(notes.waitForPlannerValue("Keep indoor options near the hotel"))
    XCTAssertTrue(name.waitForPlannerValue("Rainy afternoon"))
    recordScreenshot(application, name: "List notes retained in the native editor after relaunch")
    application.plannerElement("saved.list.cancel").activateForPlannerJourney()
    XCTAssertFalse(application.staticTexts["Canceled notes"].exists)
    application.openSavedPlannerListActionsMenu()
    application.plannerElement("saved.list.estimate.edit").activateForPlannerJourney()
    XCTAssertTrue(notes.waitForPlannerValue("Keep indoor options near the hotel"))
    application.plannerElement("saved.list.cancel").activateForPlannerJourney()
    application.terminate()
    application.launchSavedPlannerJourney()
    let retained = application.savedPlannerListRow("Rainy afternoon")
    revealSidebarIfNeeded(application, element: retained)
    XCTAssertTrue(retained.waitForExistence(timeout: 10))
    XCTAssertEqual(retained.identifier, identifier)
  }

  func testListDraftCancellationAndCreationRemainDistinctAfterNativeRelaunch() throws {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    let newList = application.plannerElement("saved.list.new")
    revealSidebarIfNeeded(application, element: newList)
    XCTAssertTrue(newList.waitForExistence(timeout: 10))
    newList.activateForPlannerJourney()
    let name = application.textFields["saved.list.name"]
    XCTAssertTrue(name.waitForExistence(timeout: 5))
    name.activateForPlannerJourney()
    name.typeText("Canceled plan")
    application.plannerElement("saved.list.cancel").activateForPlannerJourney()
    XCTAssertFalse(application.staticTexts["Canceled plan"].exists)
    XCTAssertTrue(application.staticTexts["No Lists yet"].firstMatch.exists)

    newList.activateForPlannerJourney()
    XCTAssertTrue(name.waitForExistence(timeout: 5))
    name.activateForPlannerJourney()
    name.typeText("Tokyo Weekend")
    application.plannerElement("saved.list.save").activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["No items"].waitForExistence(timeout: 10))
    XCTAssertTrue(application.staticTexts["No items"].isHittable)
    XCTAssertFalse(name.exists)
    XCTAssertTrue(application.staticTexts["Tokyo Weekend"].firstMatch.exists)
    recordScreenshot(application, name: "Saved native List with empty progress")

    application.terminate()
    application.launchSavedPlannerJourney()
    let retained = application.savedPlannerListRow("Tokyo Weekend")
    revealSidebarIfNeeded(application, element: retained)
    XCTAssertTrue(retained.waitForExistence(timeout: 10))
    retained.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["No items"].waitForExistence(timeout: 5))
    XCTAssertTrue(application.staticTexts["No items"].isHittable)
    XCTAssertFalse(application.staticTexts["Canceled plan"].exists)
    XCTAssertFalse(application.staticTexts["Global: Todo"].exists)
    XCTAssertFalse(application.plannerElement("Open source Item").exists)
    recordScreenshot(application, name: "Saved native List after relaunch")
  }

  private func revealSidebarIfNeeded(_ application: XCUIApplication, element: XCUIElement) {
    if element.waitForExistence(timeout: 3) { return }
    let sidebar = application.plannerElement("Show Sidebar")
    XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
    sidebar.activateForPlannerJourney()
  }

  private func recordScreenshot(_ application: XCUIApplication, name: String) {
    #if os(macOS)
      let screenshot = application.windows.firstMatch.screenshot()
    #else
      let screenshot = application.screenshot()
    #endif
    let attachment = XCTAttachment(screenshot: screenshot)
    attachment.name = name
    attachment.lifetime = .keepAlways
    add(attachment)
  }
}
