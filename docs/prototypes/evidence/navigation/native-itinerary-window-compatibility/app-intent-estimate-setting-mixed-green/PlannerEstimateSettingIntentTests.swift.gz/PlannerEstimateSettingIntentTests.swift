import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerEstimateSettingIntentTests: XCTestCase {
  func testItemMixedEstimatePreservesOwnedContentAndPersistsExactMinutes() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Museum"
    creation.subtitle = "Keep subtitle"
    creation.notes = "Keep notes\n東京"
    let item = try await creation.callAsFunction(donate: false)
    let setting = SetPlannerItemEstimateIntent()
    setting.item = item
    setting.quantity = 2
    setting.unit = .hour
    setting.additionalMinutes = 5
    let _: Void = try await setting.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: item.id)))
    else { return XCTFail("The estimate must persist on the original Item.") }
    XCTAssertEqual(saved.content.estimate, .init(minutes: 125, displayUnit: .hour))
    XCTAssertEqual(saved.content.title, "Museum")
    XCTAssertEqual(saved.content.subtitle, "Keep subtitle")
    XCTAssertEqual(saved.content.notes, "Keep notes\n東京")
    XCTAssertEqual(saved.state.globalDone, false)
    XCTAssertEqual(saved.state.archived, false)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
