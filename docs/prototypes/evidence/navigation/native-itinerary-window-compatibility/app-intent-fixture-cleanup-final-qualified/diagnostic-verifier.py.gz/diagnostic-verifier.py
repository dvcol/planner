from pathlib import Path
import gzip, json, sys
packet=Path(sys.argv[1])
assert json.loads((packet/'exit.json').read_text())['exitCode']==0, 'The actual test invocation must pass first.'
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode(errors='replace')
markers=['vnode unlinked while in use','invalidated open fd','database integrity compromised']
counts={marker:log.count(marker) for marker in markers}
result={'markers':counts,'diagnosticsAbsent':not any(counts.values())}
(packet/'fixture-lifecycle-diagnostics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(0 if result['diagnosticsAbsent'] else 1)
