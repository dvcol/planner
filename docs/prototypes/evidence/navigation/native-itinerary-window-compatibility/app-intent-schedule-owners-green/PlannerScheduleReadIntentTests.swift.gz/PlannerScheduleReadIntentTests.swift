import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleReadIntentTests: XCTestCase {
  func testScheduleOwnerReadsReturnCurrentTypedOwnersAndNilForTheOtherSourceKind() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setCompletion(scope: .globalItem(itemId: fixture.item.id), done: true))
      ).outcome,
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setArchive(source: fixture.itinerary, archived: true))
      ).outcome,
      case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Schedule owners must keep their current saved state.") }
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let schedules = try await query.entities(for: [fixture.timed.id, fixture.allDay.id])
    for schedule in schedules {
      let itemReading = GetPlannerScheduleItemIntent()
      itemReading.schedule = schedule
      let item = try await itemReading.callAsFunction(donate: false)
      let itineraryReading = GetPlannerScheduleItineraryIntent()
      itineraryReading.schedule = schedule
      let itinerary = try await itineraryReading.callAsFunction(donate: false)
      if schedule.id == fixture.timed.id {
        XCTAssertEqual(item?.id, fixture.item.id)
        XCTAssertEqual(item?.title, "Museum")
        XCTAssertEqual(item?.done, true)
        XCTAssertEqual(item?.archived, false)
        XCTAssertNil(itinerary)
      } else {
        XCTAssertNil(item)
        XCTAssertEqual(itinerary?.id, fixture.itinerary.id)
        XCTAssertEqual(itinerary?.title, "Tokyo Weekend")
        XCTAssertEqual(itinerary?.archived, true)
      }
    }
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Reading typed owners cannot change their graph or states.") }
    XCTAssertEqual(after, before)
  }

  func testItinerarySchedulesRetainArchivedOwnerBookingsWithoutIncludingChildBookings()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setArchive(source: fixture.itinerary, archived: true))
      ).outcome,
      case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Archiving an Itinerary must retain its bookings.") }
    let reading = GetPlannerItinerarySchedulesIntent()
    reading.itinerary = .init(id: fixture.itinerary.id, title: "Cached title", archived: false)
    let schedules = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(schedules.map(\.id), [fixture.allDay.id])
    XCTAssertEqual(schedules.first?.title, "Tokyo Weekend")
    XCTAssertEqual(schedules.first?.sourceType, "Itinerary")
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Reading must preserve the archived Itinerary and child Schedules.") }
    XCTAssertEqual(after, before)
  }

  func testCalendarWindowReturnsExactTimedAndInclusiveAllDayFormsWithoutChangingData()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The native Calendar read must start from saved Schedule forms.") }
    let zones = try await PlannerTimeZoneEntityQuery().entities(for: ["Asia/Tokyo"])
    let reading = FindPlannerSchedulesIntent()
    reading.startDay = .init(year: 2026, month: 10, day: 9)
    reading.endDay = .init(year: 2026, month: 10, day: 11)
    reading.displayTimeZone = try XCTUnwrap(zones.first)
    let schedules = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(schedules.map(\.id)), [fixture.timed.id, fixture.allDay.id])
    let timed = try XCTUnwrap(schedules.first { $0.id == fixture.timed.id })
    XCTAssertEqual(timed.title, "Museum")
    XCTAssertEqual(timed.sourceType, "Item")
    XCTAssertFalse(timed.allDay)
    XCTAssertEqual(timed.start, fixture.instant)
    XCTAssertNil(timed.end)
    XCTAssertNil(timed.startDay)
    XCTAssertNil(timed.endDay)
    XCTAssertEqual(timed.planningTimeZone?.id, "Asia/Tokyo")
    let allDay = try XCTUnwrap(schedules.first { $0.id == fixture.allDay.id })
    XCTAssertEqual(allDay.title, "Tokyo Weekend")
    XCTAssertEqual(allDay.sourceType, "Itinerary")
    XCTAssertTrue(allDay.allDay)
    XCTAssertNil(allDay.start)
    XCTAssertNil(allDay.end)
    XCTAssertNil(allDay.planningTimeZone)
    XCTAssertEqual(allDay.startDay?.year, 2026)
    XCTAssertEqual(allDay.startDay?.month, 10)
    XCTAssertEqual(allDay.startDay?.day, 9)
    XCTAssertEqual(allDay.endDay?.day, 11)
    XCTAssertNil(allDay.startDay?.hour)
    XCTAssertNil(allDay.startDay?.timeZone)
    XCTAssertNil(allDay.endDay?.hour)
    XCTAssertNil(allDay.endDay?.timeZone)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .exported(let after) = await reopened.exportData(session: session)
    else { return XCTFail("Native Calendar reads must preserve the reopened planner.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }

  func testExactScheduleReadKeepsItsIdentityWhenTheSourceTitleAndSavedFormChange() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let initial = try await query.entities(for: [
      fixture.outside.id, fixture.timed.id, fixture.timed.id, UUID(),
    ])
    XCTAssertEqual(initial.map(\.id), [fixture.outside.id, fixture.timed.id])
    let cached = try XCTUnwrap(initial.last)
    XCTAssertEqual(cached.start, fixture.instant)
    let rename = EditPlannerItemIntent()
    rename.item = .init(id: fixture.item.id, title: "Cached title", done: true, archived: true)
    rename.title = "Museum renamed"
    let _: Void = try await rename.callAsFunction(donate: false)
    guard
      case .source(.schedule(let before)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.timed)),
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .editSchedule(
            scheduleId: fixture.timed.id,
            changes: .init(
              form: .allDay(start: .init(year: 2026, month: 10, day: 10), end: nil)),
            expectedFieldHashes: before.fieldHashes))
      ).outcome,
      case .exported(let saved) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The same Schedule must support a saved form change.") }
    let reading = GetPlannerScheduleIntent()
    reading.schedule = cached
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, fixture.timed.id)
    XCTAssertEqual(current.title, "Museum renamed")
    XCTAssertEqual(current.sourceType, "Item")
    XCTAssertTrue(current.allDay)
    XCTAssertNil(current.start)
    XCTAssertNil(current.end)
    XCTAssertNil(current.planningTimeZone)
    XCTAssertEqual(current.startDay?.year, 2026)
    XCTAssertEqual(current.startDay?.month, 10)
    XCTAssertEqual(current.startDay?.day, 10)
    XCTAssertNil(current.endDay)
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Reading current values must preserve the edited Schedule.") }
    XCTAssertEqual(after, saved)
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }

  func testItemSchedulesIncludeDirectBookingsOnArchivedSourcesWithoutInheritedItineraryRecords()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setArchive(source: fixture.item, archived: true))
      ).outcome,
      case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Archiving an Item must retain its owned and inherited Schedules.") }
    let reading = GetPlannerItemSchedulesIntent()
    reading.item = .init(id: fixture.item.id, title: "Cached Item", done: true, archived: false)
    let schedules = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(schedules.map(\.id)), [fixture.timed.id, fixture.outside.id])
    XCTAssertTrue(schedules.allSatisfy { $0.sourceType == "Item" && $0.title == "Museum" })
    XCTAssertFalse(schedules.contains { $0.id == fixture.allDay.id })
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The direct Schedule read must preserve every saved relationship.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}

private struct ScheduleReadIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let timed: PlannerEntityReference
  let allDay: PlannerEntityReference
  let outside: PlannerEntityReference
  let instant: Date
}

@MainActor
private func makeScheduleReadIntentFixture() async throws -> ScheduleReadIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerEntityReference {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome,
      let source = result.generated.first
    else { throw CancellationError() }
    return source
  }
  let item = try await save(
    .createItem(content: .init(title: "Museum", estimate: .init(minutes: 90, displayUnit: .hour))))
  let itinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
  guard
    case .applied(_, .complete) = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    ).outcome
  else { throw CancellationError() }
  let instant = try Date.ISO8601FormatStyle().parse("2026-10-09T01:00:00Z")
    .addingTimeInterval(0.125)
  let timed = try await save(
    .createSchedule(
      source: item, form: .timed(start: instant, end: nil, planningTimeZone: "Asia/Tokyo")))
  let allDay = try await save(
    .createSchedule(
      source: itinerary,
      form: .allDay(
        start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11))))
  let outside = try await save(
    .createSchedule(
      source: item, form: .allDay(start: .init(year: 2026, month: 10, day: 12), end: nil)))
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    item: item, itinerary: itinerary, timed: timed, allDay: allDay, outside: outside,
    instant: instant)
}
