#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerListEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "List")
    static var defaultQuery: PlannerListEntityQuery { PlannerListEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String, archived: Bool) {
      self.id = id
      self.name = name
      self.archived = archived
    }
  }

  struct PlannerListEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List resolution is not implemented yet.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List search is not implemented yet.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List choices are not implemented yet.")
    }
  }

  struct CreatePlannerListIntent: AppIntent {
    static let title: LocalizedStringResource = "Create List"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Parameter(title: "Notes") var notes: String?
    typealias PerformResult = IntentResultContainer<PlannerListEntity, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerListIntentFailure(message: "List creation is not implemented yet.")
    }
  }

  private struct PlannerListIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
