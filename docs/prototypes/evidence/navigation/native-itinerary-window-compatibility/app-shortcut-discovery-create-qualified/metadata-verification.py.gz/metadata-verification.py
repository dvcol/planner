from pathlib import Path
import gzip,hashlib,json,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={
'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),
'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),
'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
baseline_phase='app-intent-timed-options-final' if platform=='mac' else 'app-intent-timed-options-'+platform+'-compile'
baseline=json.loads(gzip.decompress((root/baseline_phase/'extract.actionsdata.gz').read_bytes()))
raw=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes()
current=json.loads(raw)
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
for section in ['actions','entities','queries','enums']:
    assert normalize(current[section])==normalize(baseline[section]),section
expected={
'CreatePlannerItemIntent':('Create an item in ${applicationName}','Create item','plus'),
'FindPlannerItemsIntent':('Find items in ${applicationName}','Find items','checklist'),
'FindPlannerListsIntent':('Find lists in ${applicationName}','Find lists','list.bullet'),
'FindPlannerItinerariesIntent':('Find itineraries in ${applicationName}','Find itineraries','point.topleft.down.to.point.bottomright.curvepath')}
shortcuts=current['autoShortcuts']
assert len(shortcuts)==4
assert {shortcut['actionIdentifier'] for shortcut in shortcuts}==set(expected)
for shortcut in shortcuts:
    phrase,title,symbol=expected[shortcut['actionIdentifier']]
    assert shortcut['phraseTemplates']==[{'alternatives':[],'key':phrase}]
    assert shortcut['shortTitle']=={'alternatives':[],'key':title}
    assert shortcut['systemImageName']==symbol
(root/phase/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(root/phase/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
report={'platform':platform,'nativeShortcuts':shortcuts,'all72ActionContractsPreserved':True,'entitiesQueriesAndEnumsPreserved':True,'comparisonNormalization':'resolvableInputTypes alternatives only','metadataSha256':hashlib.sha256(raw).hexdigest(),'systemDiscoveryOrSiriInvocationCredit':False}
(root/phase/'metadata-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(platform,'four exact create/find shortcuts; all ordinary action contracts retained')
