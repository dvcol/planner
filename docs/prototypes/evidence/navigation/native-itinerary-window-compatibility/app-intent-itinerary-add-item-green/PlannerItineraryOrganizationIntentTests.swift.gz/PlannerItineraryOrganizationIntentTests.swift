import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryOrganizationIntentTests: XCTestCase {
  func testRepeatedItemAddsKeepLiveContentGlobalPrecedenceAndIndependentLocalStatesAfterReopen()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Hotel"
    creation.notes = "Original notes"
    let item = try await creation.callAsFunction(donate: false)
    let planCreation = CreatePlannerItineraryIntent()
    planCreation.title = "Tokyo Weekend"
    let itinerary = try await planCreation.callAsFunction(donate: false)
    let completion = SetPlannerItemCompletionIntent()
    completion.item = item
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    let adding = AddPlannerItemToItineraryIntent()
    adding.item = item
    adding.itinerary = itinerary
    let _: Void = try await adding.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let itinerarySource = PlannerEntityReference(kind: .itinerary, id: itinerary.id)
    let itemSource = PlannerEntityReference(kind: .item, id: item.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.itinerary(let first)) = await planner.read(
        session: session, request: .source(itinerarySource)),
      case .itineraryEntry(let firstIdentifier, let owner, let source)? = first.references.first
    else { return XCTFail("Adding must save a live route reference.") }
    XCTAssertEqual(owner, itinerarySource)
    XCTAssertEqual(source, itemSource)
    XCTAssertEqual(first.references.count, 1)
    let firstAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: firstIdentifier)
    guard
      case .appearance(let initial) = await planner.read(
        session: session, request: .appearance(firstAppearance))
    else { return XCTFail("The first appearance must be readable.") }
    XCTAssertTrue(initial.globalDone)
    XCTAssertFalse(initial.localDone)
    XCTAssertTrue(initial.effectiveDone)
    guard
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setCompletion(scope: .appearance(firstAppearance), done: true))
      ).outcome
    else { return XCTFail("The first appearance can be completed locally.") }
    let _: Void = try await adding.callAsFunction(donate: false)
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    let editing = EditPlannerItemIntent()
    editing.item = item
    editing.notes = "Live Hotel notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.itinerary(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(itinerarySource)),
      saved.references.count == 2,
      case .itineraryEntry(let secondIdentifier, let secondOwner, let secondSource) =
        saved.references[1],
      case .source(.item(let savedItem)) = await reopened.read(
        session: reopenedSession, request: .source(itemSource)),
      case .snapshot(let itemCatalog) = await reopened.query(
        .init(session: reopenedSession, request: .items(.init(completion: .all, archive: .all))))
    else { return XCTFail("Both entries and their single source must survive reopening.") }
    XCTAssertEqual(saved.references.first, first.references.first)
    XCTAssertNotEqual(secondIdentifier, firstIdentifier)
    XCTAssertEqual(secondOwner, itinerarySource)
    XCTAssertEqual(secondSource, itemSource)
    XCTAssertEqual(saved.progress.totalCount, 2)
    XCTAssertEqual(saved.progress.doneCount, 1)
    XCTAssertEqual(savedItem.content.notes, "Live Hotel notes")
    XCTAssertEqual(savedItem.state.globalDone, false)
    XCTAssertEqual(itemCatalog.rows, [.source(itemSource)])
    let secondAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: secondIdentifier)
    for (appearance, expectedLocalDone) in [(firstAppearance, true), (secondAppearance, false)] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(appearance))
      else { return XCTFail("Both original appearances must remain readable.") }
      XCTAssertEqual(current.content.notes, "Live Hotel notes")
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocalDone)
      XCTAssertEqual(current.effectiveDone, expectedLocalDone)
    }
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory.appending(
      path: "PlannerItineraryOrganizationIntentTests/\(UUID().uuidString)",
      directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
