import gzip,hashlib,json,uuid
from pathlib import Path
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
base=workspace/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=base/'native-windowed-scale-reconciliation'
packet.mkdir(exist_ok=False)
expected=[f'Scale Item {number:05d}' for number in range(1,5001)]
relevant=['Planner/Scenes/SavedItemWindow.swift','Planner/Scenes/SavedItemViews.swift','Planner/Scenes/SavedItemRowContent.swift']
old_source=gzip.decompress((base/'native-every-item-visible-row-mobile-build/LargeCollectionScrollJourneyTests.swift.gz').read_bytes()).decode()
current_source=(workspace/'PlannerFixtureUITests/LargeCollectionScrollJourneyTests.swift').read_text()
start='    func testEveryItemCanBeObservedThroughTheUnfilteredNativeCatalog()'
end='    private func visibleItemSnapshots('
assert old_source.split(start,1)[1].split(end,1)[0]==current_source.split(start,1)[1].split(end,1)[0]
records=[]
for name in ['phone-native-every-item-final','tablet-native-every-item-final']:
 previous=base/name
 summary=json.loads((previous/'test-summary.json').read_text())
 assert summary['result']=='Passed' and summary['passedTests']==1 and summary['failedTests']==0 and summary['skippedTests']==0
 identity_record=json.loads((previous/'independent-identity-verification.json').read_text())
 attachment=previous/(identity_record['originalAttachment']+'.gz')
 content=gzip.decompress(attachment.read_bytes())
 assert hashlib.sha256(content).hexdigest()==identity_record['originalSHA256']
 pairs=[line.split(': ',1) for line in content.decode().splitlines()]
 assert [pair[0] for pair in pairs]==expected
 identifiers=[uuid.UUID(pair[1].removeprefix('saved.item.')) for pair in pairs]
 assert len(set(identifiers))==5000
 compiled=json.loads((previous/'compiled-source-sha256.json').read_text())
 matches={path:compiled[path]==hashlib.sha256((workspace/path).read_bytes()).hexdigest() for path in relevant}
 assert all(matches.values())
 records.append({'previousEpoch':str(previous.relative_to(workspace)),'recordedNativeResult':'Passed, one function, no failures/skips','attachment':str(attachment.relative_to(workspace)),'decodedAttachmentSHA256':hashlib.sha256(content).hexdigest(),'matchesRecordedOriginalAttachmentHash':True,'orderedExpectedTitles':len(pairs),'distinctParsedSourceUUIDs':len(set(identifiers)),'currentSourceMatchesRecordedCompiledInputs':matches,'fixtureWindowSetupChangedSinceThatEpoch':True})
report={'historicalTraversalEvidence':records,'exhaustiveJourneyBodyUnchanged':True,'scope':'Existing exhaustive runs already use the windowed loader. This is retained-evidence reconciliation, not new runtime or current whole-app equivalence.','currentFollowUp':'Current fixture compilation and page-boundary/rotation runtime are recorded separately. New main-window setup prevents claiming every current input matches the exhaustive epoch.','limits':['No renewed exhaustive current-source run.','No physical latency, memory bound, hitch, accessibility or Mac UI credit.']}
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
with gzip.open(packet/'recipe.py.gz','wb') as output:output.write(Path(__file__).read_bytes())
print('Verified both complete 5,000-identity attachments, unchanged exhaustive journey and matching loader/catalog/row sources.')
