from pathlib import Path
import gzip,hashlib,json,os,struct,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/phase
summary=json.loads((packet/'test-summary.json').read_text())
assert summary['result']=='Passed' and summary['failedTests']==0 and summary['skippedTests']==0
execution=json.loads((packet/'exit.json').read_text())
assert execution['exitCode']==0
export=Path('/private/tmp/PlannerBrowserReaderAttachments-'+phase)
command=['xcrun','xcresulttool','export','attachments','--path',execution['bundle'],'--output-path',str(export)]
result=subprocess.run(command,capture_output=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
result.check_returncode()
(packet/'attachment-export.log.gz').write_bytes(gzip.compress(result.stdout+result.stderr,mtime=0))
manifest=json.loads((export/'manifest.json').read_text())
(packet/'original-attachment-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
names={'Calendar source guide uses':'calendar-reader.png','Itinerary guide keeps':'itinerary-reader.png','Browser return preserves':'list-appearance-return.png','Native webpage history and reload':'history-reader.png','Saved guide opens':'item-reader.png','Saved Item reopened globally':'global-reopen.png','Saved Item with global':'global-completion.png','Saved guide recovers':'recovered-guide.png','Linked guide recovers':'recovered-linked-guide.png','Toolbar reload recovers':'toolbar-recovered-guide.png'}
captures=[]
for case in manifest:
 for attachment in case['attachments']:
  human_name=attachment['suggestedHumanReadableName']
  matching=[destination for prefix,destination in names.items() if human_name.startswith(prefix)]
  if not matching:continue
  assert len(matching)==1
  data=(export/attachment['exportedFileName']).read_bytes()
  assert data[:8]==b'\x89PNG\r\n\x1a\n'
  destination=matching[0]
  (packet/destination).write_bytes(data)
  captures.append({'file':destination,'original':human_name,'exportedFile':attachment['exportedFileName'],'sha256':hashlib.sha256(data).hexdigest(),'dimensions':list(struct.unpack('>II',data[16:24]))})
assert len(captures)==len(set(capture['file'] for capture in captures))
assert len(captures)==summary['passedTests']
(packet/'capture-manifest.json').write_text(json.dumps(captures,indent=2)+'\n')
sources=json.loads((packet/'source-sha256.json').read_text())
differences=[relative for relative,digest in sources.items() if not (repository/relative).is_file() or hashlib.sha256((repository/relative).read_bytes()).hexdigest()!=digest]
products=json.loads((packet/'product-sha256.json').read_text())
changed_products=[filename for filename,digest in products.items() if not Path(filename).is_file() or hashlib.sha256(Path(filename).read_bytes()).hexdigest()!=digest]
log=gzip.decompress((packet/'test.log.gz').read_bytes()).decode()
unlink_diagnostics=[line for line in log.splitlines() if 'unlinked' in line.lower() and 'sqlite' in line.lower()]
assert not differences and not changed_products and not unlink_diagnostics
qualification={'sourceInputCount':len(sources),'sourceDifferences':differences,'actualProductCount':len(products),'productDifferences':changed_products,'passedFunctions':summary['passedTests'],'failedFunctions':summary['failedTests'],'skippedFunctions':summary['skippedTests'],'sqliteUnlinkDiagnostics':unlink_diagnostics,'originalCaptureCount':len(captures),'meaning':'Actual native UI execution with real loopback WebKit GET requests. Reader captures include the native-pane pixel-contrast assertion; controlled connection failures exercise recovery. Not physical, Mac UI, persistence or broader navigation-policy acceptance.'}
(packet/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(phase,json.dumps(qualification))
