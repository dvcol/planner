import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleEndIntentTests: XCTestCase {
  func testClearingTimedEndPreservesCurrentFractionalStartZoneOwnerAndOtherBookings() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let choices = try await query.entities(for: [fixture.timed.id])
    let cached = try XCTUnwrap(choices.first)
    let start = try Date.ISO8601FormatStyle().parse("2026-11-01T06:30:00Z").addingTimeInterval(0.75)
    guard
      case .source(.schedule(let initial)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.timed)),
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .editSchedule(
            scheduleId: fixture.timed.id,
            changes: .init(
              form: .timed(
                start: start, end: start.addingTimeInterval(3600.125),
                planningTimeZone: "America/New_York")),
            expectedFieldHashes: initial.fieldHashes))),
      case .source(.item(let before)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { return XCTFail("Save the current repeated-hour span before clearing only its end.") }
    let clear = ClearPlannerScheduleEndIntent()
    clear.schedule = cached
    let _: Void = try await clear.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let current)) = await reopened.read(
        session: session, request: .source(fixture.timed)),
      case .source(.item(let after)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.schedule(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.allDay)),
      case .source(.schedule(let outside)) = await reopened.read(
        session: session, request: .source(fixture.outside))
    else { return XCTFail("Reopen the same booking, source and other bookings after clearing.") }
    XCTAssertEqual(current.source, fixture.timed)
    XCTAssertEqual(current.content.source, fixture.item)
    XCTAssertEqual(
      current.content.form,
      .timed(start: start, end: nil, planningTimeZone: "America/New_York"))
    XCTAssertEqual(after.content, before.content)
    XCTAssertEqual(after.state, before.state)
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(after.content.estimate?.minutes, 90)
    XCTAssertEqual(
      itinerary.content.form,
      .allDay(
        start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11)))
    XCTAssertEqual(
      outside.content.form, .allDay(start: .init(year: 2026, month: 10, day: 12), end: nil))
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}
