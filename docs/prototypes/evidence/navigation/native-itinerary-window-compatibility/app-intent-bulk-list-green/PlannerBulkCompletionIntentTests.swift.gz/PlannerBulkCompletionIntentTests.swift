import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerBulkCompletionIntentTests: XCTestCase {
  func testReviewedListCompletionIncludesArchivedChildrenAndPreservesOtherContexts() async throws {
    let fixture = try await makeEstimateResetIntentFixture()
    let archived = try await fixture.store.executeAppIntent(
      .setArchive(source: fixture.lunch, archived: true))
    guard case .applied(_, .complete) = archived.outcome else { throw CancellationError() }
    let before = try await readEstimateResetSources(fixture)
    let review = try await fixture.store.prepareAppIntentBulkCompletion(
      scope: .list(listId: fixture.list.id), done: true)
    XCTAssertEqual(review.targetCount, 2)
    let prepared = try await readEstimateResetSources(fixture)
    XCTAssertEqual(prepared.item.fieldHashes, before.item.fieldHashes)
    XCTAssertEqual(prepared.list.progress.doneCount, 1)
    let result = try await fixture.store.executeAppIntent(
      review.command, reviewToken: review.reviewToken)
    guard case .applied(_, .complete) = result.outcome else {
      return XCTFail("Reviewed bulk completion must durably apply its entire local scope.")
    }
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    for membership in [fixture.membershipIdentifier, fixture.lunchMembershipIdentifier] {
      guard
        case .appearance(let appearance) = await reopened.read(
          session: session,
          request: .appearance(.listMembership(listId: fixture.list.id, membershipId: membership)))
      else { throw CancellationError() }
      XCTAssertTrue(appearance.localDone)
      XCTAssertFalse(appearance.globalDone)
    }
    let after = try await readEstimateResetSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(after.item.fieldHashes, before.item.fieldHashes)
    XCTAssertEqual(after.lunch.fieldHashes, before.lunch.fieldHashes)
    XCTAssertEqual(after.list.content, before.list.content)
    XCTAssertEqual(after.itinerary.fieldHashes, before.itinerary.fieldHashes)
    XCTAssertEqual(after.itinerary.progress.doneCount, before.itinerary.progress.doneCount)
    XCTAssertEqual(after.itinerary.progress.totalCount, 5)
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}
