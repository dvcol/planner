from pathlib import Path
from PIL import Image
import gzip,hashlib,json
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=root/'native-item-row-paint-validation'
packet.mkdir(exist_ok=True)
files={
 'original':'tablet-native-every-item-final/A303F52E-D8EE-480A-ACEF-D27F0C34845E.png',
 'pointer':'tablet-native-item-row-paint-pointer-down/C9F622EA-3AA5-428D-807F-15E0A9BB2EC0.png',
 'touch':'tablet-native-item-row-paint-touch-cycle/6FF49014-0E93-454E-AE5F-76ECF2B50A33.png'}
records={}
for label,name in files.items():
 path=root/name
 with Image.open(path) as picture:
  assert picture.format=='PNG' and picture.size==(1640,2360)
  decoded=picture.convert('RGB')
  regions=[]
  for index in range(14):
   rectangle=(136,278+index*148,408,357+index*148)
   region=decoded.crop(rectangle)
   bright=sum(1 for red,green,blue in region.get_flattened_data() if min(red,green,blue)>230)
   assert bright>20,(label,index,bright)
   regions.append({'sourceTitle':f'Scale Item {4987+index:05d}','pixelRectangle':rectangle,'brightPixels':bright,'totalPixels':region.width*region.height,'rgbSHA256':hashlib.sha256(region.tobytes()).hexdigest()})
  records[label]={'file':name,'originalFileSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'format':picture.format,'mode':picture.mode,'size':picture.size,'regions':regions}
expected=[entry['rgbSHA256'] for entry in records['original']['regions']]
assert all([entry['rgbSHA256'] for entry in record['regions']]==expected for record in records.values())
record={'result':'Original row pixels are painted and identical across all three captures.','visibleRegionsCompared':14,'regionBasis':'The native sample frame for Item 04994 is (68,657,136,39.5) points at 2x capture scale. Adjacent fixed-height rows are 74 points apart. Regions cover the title/metadata area, away from the scrollbar and detail pane.','allRegionBytesIdentical':True,'originalPreviewInterpretationCorrected':True,'scope':'Decoded original-file RGB evidence plus sampled native paint checks. Not an all-row/all-scene contrast, semantic OCR or physical-performance claim. No original image is edited.','captures':records}
(packet/'original-pixel-verification.json').write_text(json.dumps(record,indent=2)+'\n')
(packet/'pixel-verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('All 14 original visible row regions contain bright glyph pixels and are byte-identical to both passing native captures.')
