import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryItemIntentTests: XCTestCase {
  func testGetRetainsExactRepeatedDirectAppearanceAndReturnsLiveLocalState() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Hotel", notes: "Shared notes")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    let firstEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    let secondEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let firstIdentifier, _, _)? = firstEntry.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondEntry.generatedReferences.first
    else { return XCTFail("Repeated Item stops must have distinct saved entry identities.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .directItineraryItem(itineraryId: itinerary.id, entryId: secondIdentifier)),
        done: true))
    let firstIdentity = "v1/direct/\(itinerary.id)/\(firstIdentifier)/\(item.id)"
    let secondIdentity = "v1/direct/\(itinerary.id)/\(secondIdentifier)/\(item.id)"
    let reading = GetPlannerItineraryItemIntent()
    reading.itinerary = .init(id: itinerary.id, title: "Cached route", archived: true)
    reading.item = .init(
      id: secondIdentity, title: "Cached Hotel", context: "Cached position", globallyDone: true,
      locallyDone: false, done: false, archived: true)
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, secondIdentity)
    XCTAssertEqual(current.title, "Hotel")
    XCTAssertEqual(current.context, "Tokyo Weekend · Stop 2")
    XCTAssertFalse(current.globallyDone)
    XCTAssertTrue(current.locallyDone)
    XCTAssertTrue(current.done)
    XCTAssertFalse(current.archived)
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [secondIdentity, firstIdentity, secondIdentity])
    XCTAssertEqual(resolved.map(\.id), [secondIdentity, firstIdentity])
    XCTAssertEqual(resolved.map(\.context), ["Tokyo Weekend · Stop 2", "Tokyo Weekend · Stop 1"])
    XCTAssertEqual(resolved.map(\.locallyDone), [true, false])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testExpandedRepeatsKeepTheirIdentityWhileNamesAndSavedPositionsChange() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdMuseum = try await save(.createItem(content: .init(title: "Museum")))
    let museum = try XCTUnwrap(createdMuseum.generated.first)
    let createdLunch = try await save(.createItem(content: .init(title: "Lunch")))
    let lunch = try XCTUnwrap(createdLunch.generated.first)
    let createdList = try await save(.createList(content: .init(name: "Food")))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdEmptyList = try await save(.createList(content: .init(name: "Empty stop")))
    let emptyList = try XCTUnwrap(createdEmptyList.generated.first)
    let museumMembership = try await save(
      .addMembership(itemId: museum.id, listId: list.id, placement: .last))
    let lunchMembership = try await save(
      .addMembership(itemId: lunch.id, listId: list.id, placement: .last))
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    let direct = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: museum, placement: .last))
    let firstBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
    _ = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: emptyList, placement: .last))
    let secondBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
    guard
      case .membership(let museumIdentifier, _, _)? = museumMembership.generatedReferences.first,
      case .membership(let lunchIdentifier, _, _)? = lunchMembership.generatedReferences.first,
      case .itineraryEntry(let directIdentifier, _, _)? = direct.generatedReferences.first,
      case .itineraryEntry(let firstIdentifier, _, _)? = firstBranch.generatedReferences.first,
      case .itineraryEntry(let secondIdentifier, _, _)? = secondBranch.generatedReferences.first,
      case .source(.item(let originalMuseum)) = await planner.read(
        session: session, request: .source(museum)),
      case .source(.list(let originalList)) = await planner.read(
        session: session, request: .source(list)),
      case .source(.itinerary(let originalItinerary)) = await planner.read(
        session: session, request: .source(itinerary))
    else { return XCTFail("Repeated List entries need their own complete saved identities.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .expandedListItem(
            itineraryId: itinerary.id, listEntryId: secondIdentifier, membershipId: museumIdentifier
          )),
        done: true))
    _ = try await save(.setArchive(source: museum, archived: true))
    _ = try await save(
      .editItem(
        sourceId: museum.id, changes: .init(title: .set("Nezu Museum")),
        expectedFieldHashes: originalMuseum.fieldHashes))
    _ = try await save(
      .editList(
        sourceId: list.id, changes: .init(name: .set("Tokyo Food")),
        expectedFieldHashes: originalList.fieldHashes))
    _ = try await save(
      .editItinerary(
        sourceId: itinerary.id, changes: .init(title: .set("Tokyo Weekend")),
        expectedFieldHashes: originalItinerary.fieldHashes))
    _ = try await save(
      .reorderItineraryEntry(
        itineraryId: itinerary.id, entryId: directIdentifier,
        placement: .before(associationId: secondIdentifier)))
    _ = try await save(
      .reorderMembership(listId: list.id, membershipId: lunchIdentifier, placement: .first))
    let secondMuseum =
      "v1/list/\(itinerary.id)/\(secondIdentifier)/\(museumIdentifier)/\(museum.id)"
    let firstLunch = "v1/list/\(itinerary.id)/\(firstIdentifier)/\(lunchIdentifier)/\(lunch.id)"
    let directMuseum = "v1/direct/\(itinerary.id)/\(directIdentifier)/\(museum.id)"
    let firstMuseum = "v1/list/\(itinerary.id)/\(firstIdentifier)/\(museumIdentifier)/\(museum.id)"
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [
      secondMuseum, firstLunch, directMuseum, firstMuseum,
    ])
    XCTAssertEqual(resolved.map(\.id), [secondMuseum, firstLunch, directMuseum, firstMuseum])
    XCTAssertEqual(resolved.map(\.title), ["Nezu Museum", "Lunch", "Nezu Museum", "Nezu Museum"])
    XCTAssertEqual(
      resolved.map(\.context),
      [
        "Tokyo Weekend · Stop 4 · Tokyo Food · Item 2",
        "Tokyo Weekend · Stop 1 · Tokyo Food · Item 1",
        "Tokyo Weekend · Stop 3", "Tokyo Weekend · Stop 1 · Tokyo Food · Item 2",
      ])
    XCTAssertEqual(resolved.map(\.globallyDone), [false, false, false, false])
    XCTAssertEqual(resolved.map(\.locallyDone), [true, false, false, false])
    XCTAssertEqual(resolved.map(\.done), [true, false, false, false])
    XCTAssertEqual(resolved.map(\.archived), [true, false, true, true])
  }

  func testIdentityReadsCrossPagesNormalizeUUIDCaseAndNeverInventUnscopedChoices() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let createdItem = try await save(.createItem(content: .init(title: "Hotel")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdItinerary = try await save(.createItinerary(content: .init(title: "Long route")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    var identifiers: [String] = []
    for _ in 0..<65 {
      let created = try await save(
        .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
      guard case .itineraryEntry(let entry, _, _)? = created.generatedReferences.first else {
        return XCTFail("Every repeated stop needs its own saved identity.")
      }
      identifiers.append("v1/direct/\(itinerary.id)/\(entry)/\(item.id)")
    }
    let query = PlannerItineraryItemEntityQuery()
    query.plannerStore = store
    let reversedIdentifiers = Array(identifiers.reversed())
    let resolved = try await query.entities(
      for: reversedIdentifiers + [
        identifiers[0].lowercased(), "", "v2/direct/\(itinerary.id)/\(UUID())/\(item.id)",
        "v1/direct/invalid", "v1/list/\(itinerary.id)/\(UUID())/\(UUID())/\(item.id)",
      ])
    XCTAssertEqual(resolved.map(\.id), reversedIdentifiers)
    XCTAssertEqual(Set(resolved.map(\.id)).count, 65)
    XCTAssertEqual(resolved.first?.context, "Long route · Stop 65")
    XCTAssertEqual(resolved.last?.context, "Long route · Stop 1")
    XCTAssertTrue(resolved.allSatisfy { $0.title == "Hotel" && !$0.done })
    let suggestions = try await query.suggestedEntities()
    let search = try await query.entities(matching: "Hotel")
    XCTAssertTrue(suggestions.isEmpty)
    XCTAssertTrue(search.isEmpty)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
