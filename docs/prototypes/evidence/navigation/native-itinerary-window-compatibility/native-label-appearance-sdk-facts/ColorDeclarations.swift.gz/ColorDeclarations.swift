import SwiftUI
import CoreGraphics

func checkColorResolution(_ color: Color, environment: EnvironmentValues) -> [Double] {
  let resolvedColor = color.resolve(in: environment)
  return [Double(resolvedColor.red), Double(resolvedColor.green),
    Double(resolvedColor.blue), Double(resolvedColor.opacity)]
}

func checkSRGBConversion(_ color: Color, environment: EnvironmentValues) -> [Double]? {
  guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
    let convertedColor = color.resolve(in: environment).cgColor.converted(
      to: colorSpace, intent: .relativeColorimetric, options: nil),
    let components = convertedColor.components,
    components.count == 4, components.allSatisfy({ $0.isFinite })
  else { return nil }
  return components.map(Double.init)
}

func checkColorPicker(_ selection: Binding<Color>) -> some View {
  ColorPicker("Color", selection: selection, supportsOpacity: true)
}
