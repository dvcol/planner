from pathlib import Path
import gzip,hashlib,json,os,plistlib,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
evidence=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=evidence/phase
assert json.loads((packet/'exit.json').read_text())['exitCode']==0
prior=json.loads((evidence/'app-intent-label-association-final-qualification/extracted-intent-identifiers.json').read_text())
paths={
'mac':'/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
'mobile':'/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
'device':'/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata'}
metadata_bytes=Path(paths[platform]).read_bytes()
metadata=json.loads(metadata_bytes)
for key in ['actions','entities','queries']:
 assert sorted(metadata[key])==prior[key]
enum_cases={entry['identifier']:{case['identifier']:case['displayRepresentation']['title']['key'] for case in entry['cases']} for entry in metadata['enums']}
assert enum_cases==prior['enumCases']
parameter_contracts={}
for identifier in ['CreatePlannerItemIntent','EditPlannerItemIntent']:
 parameters={parameter['name']:parameter for parameter in metadata['actions'][identifier]['parameters']}
 expected={'title','subtitle','notes'}
 if identifier=='EditPlannerItemIntent':expected.add('item')
 assert set(parameters)==expected
 assert parameters['subtitle']['isOptional'] is True
 assert parameters['subtitle']['valueType']==parameters['notes']['valueType']
 assert parameters['subtitle']['valueType']=={'primitive':{'wrapper':{'typeIdentifier':0}}}
 assert parameters['title']['isOptional']==(identifier=='EditPlannerItemIntent')
 assert parameters['notes']['isOptional'] is True
 parameter_contracts[identifier]={name:{'optional':parameter['isOptional'],'valueType':parameter['valueType']} for name,parameter in parameters.items()}
result={'actions':sorted(metadata['actions']),'entities':sorted(metadata['entities']),'queries':sorted(metadata['queries']),'enumCases':enum_cases,'parameterContracts':parameter_contracts,'metadataSha256':hashlib.sha256(metadata_bytes).hexdigest(),'priorCatalogPreserved':True,'systemInvocationCredit':False,'metadataRuntimeCredit':False}
(packet/'extracted-intent-identifiers.json').write_text(json.dumps(result,indent=2)+'\n')
hashes=json.loads((packet/'source-sha256.json').read_text())
prior_hashes=json.loads((evidence/'app-intent-label-association-final-qualification/source-sha256.json').read_text())
changed=sorted(path for path,digest in prior_hashes.items() if hashes[path]!=digest)
assert changed==['Planner/AppIntents/PlannerItemIntents.swift','PlannerMCPTests/PlannerItemIntentTests.swift']
added=sorted(set(hashes)-set(prior_hashes))
assert added==['PlannerMCPTests/PlannerItemSubtitleIntentTests.swift']
for path,digest in hashes.items():
 assert hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256((Path('/private/tmp/PlannerNativeItemWindowSource')/path).read_bytes()).hexdigest()==digest,path
(packet/'current-source-verification.json').write_text(json.dumps({'success':True,'verifiedInputCount':len(hashes),'unchangedPriorInputCount':len(prior_hashes)-len(changed),'changedInputs':changed,'addedInputs':added},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
if platform=='mac':
 bundle=json.loads((packet/'exit.json').read_text())['bundle']
 summary_bytes=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',bundle,'--compact'],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 summary=json.loads(summary_bytes)
 assert summary['passedTests']==22 and summary['failedTests']==0 and summary['skippedTests']==0
 (packet/'test-results-summary.json').write_bytes(summary_bytes.rstrip()+b'\n')
 log=Path('/private/tmp/PlannerItemWindow-'+phase+'.log').read_text()
 diagnostics=[line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
 (packet/'compiler-diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
 print('tests',summary['passedTests'],'failures',summary['failedTests'],'skipped',summary['skippedTests'],'compiler diagnostics',len(diagnostics))
if platform=='device':
 app=Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
 extensions=list((app/'PlugIns').glob('*.appex'))
 assert len(extensions)==1
 products=[]
 for product in [app,*extensions]:
  values=plistlib.loads((product/'Info.plist').read_bytes())
  executable=product/values['CFBundleExecutable']
  architectures=subprocess.check_output(['lipo','-archs',str(executable)],text=True).split()
  assert architectures==['arm64']
  products.append({'bundleIdentifier':values['CFBundleIdentifier'],'executable':str(executable),'architectures':architectures,'sha256':hashlib.sha256(executable.read_bytes()).hexdigest()})
 (packet/'embedded-products-verification.json').write_text(json.dumps({'products':products,'embeddedMobileShareCount':1,'signingAllowed':False,'installedOrLaunched':False},indent=2)+'\n')
print(platform,'metadata',len(metadata['actions']),len(metadata['entities']),len(metadata['queries']),'verified inputs',len(hashes))
