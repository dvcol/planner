import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerTagIntentTests: XCTestCase {
  func testCreateTagReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerTagIntent()
    creation.name = "rainy-day"
    let tag = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(tag.name, "rainy-day")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.tag(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .tag, id: tag.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .tag, archive: .all))))
    else { return XCTFail("The returned Tag must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, tag.id)
    XCTAssertEqual(current.content.name, "rainy-day")
    XCTAssertNil(current.content.color)
    XCTAssertNil(current.content.iconName)
    XCTAssertNil(current.state.archived)
    XCTAssertNil(current.state.globalDone)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .tag, id: tag.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testIdentityAndGetReturnLiveNamesWithoutConfusingSameNameCategories() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerTagIntent()
    creation.name = "rainy-day"
    let cached = try await creation.callAsFunction(donate: false)
    creation.name = "Second tag"
    let second = try await creation.callAsFunction(donate: false)
    let categoryCreation = CreatePlannerCategoryIntent()
    categoryCreation.name = "Second tag"
    let category = try await categoryCreation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.tag(let original)) = await planner.read(
        session: session, request: .source(.init(kind: .tag, id: cached.id))),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editTag(
            sourceId: cached.id, changes: .init(name: .set("Renamed tag")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome
    else {
      return XCTFail("The canonical shared Tag must change before resolving its cached entity.")
    }
    let query = PlannerTagEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(
      for: [second.id, UUID(), cached.id, second.id, category.id, cached.id])
    XCTAssertEqual(resolved.map(\.id), [second.id, cached.id])
    XCTAssertEqual(resolved.map(\.name), ["Second tag", "Renamed tag"])
    let reading = GetPlannerTagIntent()
    reading.tag = cached
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, cached.id)
    XCTAssertEqual(current.name, "Renamed tag")
    reading.tag = .init(id: category.id, name: "Second tag")
    do {
      _ = try await reading.callAsFunction(donate: false)
      XCTFail("A Category cannot substitute for a Tag with the same name.")
    } catch { XCTAssertTrue(error.localizedDescription.contains("no longer available")) }
    reading.tag = .init(id: UUID(), name: "Missing")
    do {
      _ = try await reading.callAsFunction(donate: false)
      XCTFail("Get Tag cannot invent a missing source.")
    } catch { XCTAssertTrue(error.localizedDescription.contains("no longer available")) }
    let categoryReading = GetPlannerCategoryIntent()
    categoryReading.category = category
    let retainedCategory = try await categoryReading.callAsFunction(donate: false)
    XCTAssertEqual(retainedCategory.name, "Second tag")
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
