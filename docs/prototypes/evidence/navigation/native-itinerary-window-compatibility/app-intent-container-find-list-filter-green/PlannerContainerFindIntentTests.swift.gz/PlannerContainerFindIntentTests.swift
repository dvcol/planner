import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerContainerFindIntentTests: XCTestCase {
  func testListFindingCombinesTextAndArchiveWithoutChangingSavedData() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let create = CreatePlannerListIntent()
    var lists: [PlannerListEntity] = []
    for name in ["Café Tokyo", "Market Tokyo", "Cafe Osaka"] {
      create.name = name
      create.notes = "Saved notes"
      lists.append(try await create.callAsFunction(donate: false))
    }
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: .init(kind: .list, id: lists[1].id), archived: true))
      )
      .outcome,
      case .exported(let before) = await planner.exportData(session: session)
    else { return XCTFail("Seed and record the real Lists before native finding.") }
    let find = FindPlannerListsIntent()
    let all: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(all.map(\.id), [2, 0, 1].map { lists[$0].id })
    find.text = "TOKYO"
    let tokyo: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(tokyo.map(\.id), [0, 1].map { lists[$0].id })
    find.archive = .active
    let active: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(active.map(\.id), [lists[0].id])
    find.archive = .archived
    let archived: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(archived.map(\.id), [lists[1].id])
    XCTAssertEqual(archived.first?.archived, true)
    find.archive = .all
    find.text = "cAfE"
    let folded: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(folded.map(\.id), [2, 0].map { lists[$0].id })
    find.text = "No matching List"
    let empty: [PlannerListEntity] = try await find.callAsFunction(donate: false)
    XCTAssertTrue(empty.isEmpty)
    guard case .exported(let after) = await planner.exportData(session: session) else {
      return XCTFail("Finding cannot change saved Lists or their references.")
    }
    XCTAssertEqual(after, before)
    XCTAssertFalse(store.isSaving)
  }
}
