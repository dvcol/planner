#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  enum PlannerCatalogFindArchive: String, AppEnum, CaseIterable {
    case all, active, archived
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Plan archive filter")
    static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
      .all: .init(title: "All"), .active: .init(title: "Active"),
      .archived: .init(title: "Archived"),
    ]

    var queryValue: PlannerItemQuery.Archive {
      switch self {
      case .all: .all
      case .active: .active
      case .archived: .archived
      }
    }
  }

  struct FindPlannerListsIntent: AppIntent {
    static let title: LocalizedStringResource = "Find Planner Lists"
    static let description = IntentDescription("Find Lists by text and archive state.")
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Search text", default: "") var text: String
    @Parameter(title: "Archive", default: .all) var archive: PlannerCatalogFindArchive
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<[PlannerListEntity], Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      let query = PlannerListEntityQuery()
      query.plannerStore = plannerStore
      let lists = try await query.loadLists(
        query: .init(sourceKind: .list, text: text, archive: archive.queryValue))
      return .result(value: lists)
    }
  }
#endif
