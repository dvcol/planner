from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
epoch=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/phase
result=json.loads((epoch/'exit.json').read_text())
output=Path('/private/tmp/PlannerItineraryCompatibilityAttachments-'+phase)
if not (output/'manifest.json').is_file():
 completed=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',result['bundle'],'--output-path',str(output)],capture_output=True,text=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 assert completed.returncode==0,completed.stderr
redactions=[]
def scoped_text_attachment(original,filename):
 text=original.decode('utf-8')
 lines=text.splitlines(keepends=True)
 kept=[]
 apple_menu_indent=None
 for line in lines:
  indentation=len(line)-len(line.lstrip())
  if apple_menu_indent is not None:
   if line.strip() and indentation>apple_menu_indent:continue
   apple_menu_indent=None
  if line.lstrip().startswith('MenuBarItem,') and "title: 'Apple'" in line:
   apple_menu_indent=indentation
   continue
  kept.append(line)
 scoped=''.join(kept).encode('utf-8')
 if scoped!=original:
  redactions.append({'file':filename+'.gz','originalSHA256':hashlib.sha256(original).hexdigest(),'scopedSHA256':hashlib.sha256(scoped).hexdigest(),'omitted':'Unrelated system Apple menu, including global recent applications and documents.','originalRetainedAt':str(output/filename)})
 return scoped
omitted_capture_files = {
 '108DA805-ECCD-4A86-98C3-3FF8905330DB.png',
 '1BE36574-D87F-472E-853A-36EDA0FAD0A6.png',
 '30A02479-A7FE-4627-9A4D-8D1F5E00BDE0.png',
}
captures=[]
for group in json.loads((output/'manifest.json').read_text()):
 for attachment in group['attachments']:
  filename=attachment['exportedFileName']
  title=attachment['suggestedHumanReadableName']
  selected_caller = group['testIdentifier'].startswith(('ShareCaptureJourneyTests/', 'SavedCaptureJourneyTests/', 'SavedAppIntentJourneyTests/', 'CatalogTitleLayoutJourneyTests/')) or any(name in group['testIdentifier'] for name in ['testFilteredManualDragRetainsHiddenMembershipCompletionAndOrderAfterRelaunch', 'testListDraftCancellationAndCreationRemainDistinctAfterNativeRelaunch', 'testListNewItemLabelsRemainDraftUntilSaveAndRetainItsAppearanceAfterRelaunch', 'testItemEditorUndoRestoresItsLinkAndLabelGroupWithoutRevertingSavedNotes', 'testItineraryEditorUndoRestoresItsLinkAndLabelGroupWithoutRevertingSavedNotes', 'testNativeUndoMoveRestoresOriginalDoneAppearanceAndRemovesItsCreatedDestination', 'testNativeTextUndoPreservesTheSeparateRemovedMembershipAction', 'testGlobalUnknownEstimateKeepsManualBudgetsAndRevealsRetainedLocalStatesAfterReopening', 'testArchivedUnknownEstimateKeepsItsManualBranchBudgetAndRestoresLocalStateAfterRelaunch', 'testMissingFinishedEstimateShowsUpperBoundThenResolvesAndFinishesWithoutClearingManualTotal', 'testItineraryCompositionAndFilteredCountsPassNativeContrastAudit', 'testNativeUndoPreservesFiltersAndAnotherSelectedListAppearance', 'testMaximumDurationPreservesListProgressOrderAndIndependentCompletionAfterRelaunch', 'testMaximumDurationFiltersItemsAndInboxInclusivelyWithoutChangingSavedEstimates', 'testRestoredOriginatingListRequiresFreshReviewBeforeSavingItsRetainedItemDraft', 'testNewItemDraftRetainsFieldsAndRejectsSaveAfterOriginatingListDeletion', 'testNewItemDraftRetainsFieldsAndDestinationAcrossOriginatingListArchive', 'testNativeUndoRejectsNewerMembershipWithoutReplacingItsIdentityOrCompletion', 'testNativeInboxRetainsUnlistedItemsAndIndependentFiltersSortAndSourceStateAfterRelaunch', 'testNativeListSearchKeepsArchivedCompletionProgressAndValidDetailAcrossCumulativeFilters', 'testSearchKeepsMatchingHeadersOrChildrenAndPreservesFullRepeatedProgressAfterRelaunch', 'testOrderedItemAndListEntriesKeepIndependentChecksAndDetailsAfterRelaunch', 'testNativeUndoRestoresRemovedMembershipIdentityAndLocalCompletion', 'testNativeUndoRestoresOneRepeatedItineraryEntry', 'testArchivedListCreationActionsRemainDisabledInNativeOverflow', 'testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList', 'testListDestinationsRemainIndependentFromGlobalCaptureAndArchivedChoicesFallBack', 'testRealBackupSkipAndOverwriteKeepTagIdentityAfterRelaunch', 'testDeletingSelectedListChoosesTheFirstVisibleListAndItsFirstItemOnRegularLayouts'])
  if not selected_caller and not title.startswith(("Windowed ", "Windowed Lists", "Windowed Itineraries", "Windowed container", "New Item", "Returning from New Item", "List-origin New Item", "Windowed itinerary", "Itinerary boundary", "Itinerary fixture", "First repeated", "Selected itinerary", "Repeated itinerary", "App Screenshot", "Element Screenshot", "Itinerary Item picker", "Item picker", "Windowed List", "Selected Item", "Selected List", "Collapsed itinerary", "Reopened itinerary", "Filtered itinerary")):continue
  if filename.endswith('.png'):
   if filename in omitted_capture_files:
    original=output/filename
    redactions.append({'file':filename,'originalSHA256':hashlib.sha256(original.read_bytes()).hexdigest(),'omitted':'Whole-display capture includes unrelated system menu-bar content. A later window-only capture replaces this public evidence.','originalRetainedAt':str(original)})
    (epoch/filename).unlink(missing_ok=True)
    continue
   shutil.copy2(output/filename,epoch/filename)
  elif filename.endswith('.txt'):
   (epoch/(filename+'.gz')).write_bytes(gzip.compress(scoped_text_attachment((output/filename).read_bytes(),filename),mtime=0))
  else:continue
  captures.append({**attachment,'testIdentifier':group['testIdentifier']})
(epoch/'selected-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
(epoch/'artifact-redactions.json').write_text(json.dumps(redactions,indent=2)+'\n')
(epoch/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
for capture in captures:print(capture['exportedFileName'],capture['suggestedHumanReadableName'])
