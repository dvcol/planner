import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerLinkIntentTests: XCTestCase {
  func testItemLinkReadReturnsSavedOrderExactURLsAndDistinctDuplicateIdentitiesAfterReopen()
    async throws
  {
    let fixture = try await makeLinkIntentFixture()
    guard
      case .source(.item(let before)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    let reading = GetPlannerItemLinksIntent()
    reading.item = .init(id: fixture.item.id, title: "Cached title", done: true, archived: true)
    let links = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(links.count, 3)
    XCTAssertEqual(
      links.map(\.originalURL),
      [
        "https://maps.apple.com/?q=Nezu%20Museum&place-id=fixture-nezu",
        "https://example.com/Guide?Ref=%2f&Ref=A#Room",
        "https://maps.apple.com/?q=Nezu%20Museum&place-id=fixture-nezu",
      ])
    XCTAssertEqual(links.map(\.label), ["Visit", nil, "Visit"])
    XCTAssertEqual(links.map(\.ownerTitle), ["Museum", "Museum", "Museum"])
    XCTAssertEqual(links.map(\.position), [1, 2, 3])
    XCTAssertEqual(links[1].url.absoluteString, "https://example.com/Guide?Ref=%2f&Ref=A#Room")
    XCTAssertEqual(Set(links.map(\.id)).count, 3)
    XCTAssertEqual(
      links.map(\.id),
      before.content.links.map {
        "item:\(fixture.item.id.uuidString):\($0.linkId.uuidString)"
      })
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let after)) = await reopened.read(
        session: session, request: .source(fixture.item))
    else { return XCTFail("An ordinary Link read must preserve its owner after reopening.") }
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.updatedAt, before.updatedAt)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(after.content.links, before.content.links)
    let query = PlannerLinkEntityQuery()
    query.plannerStore = fixture.store
    let resolved = try await query.entities(for: [links[2].id, links[0].id, links[2].id])
    XCTAssertEqual(resolved.map(\.id), [links[2].id, links[0].id])
    XCTAssertEqual(resolved.map(\.position), [3, 1])
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}

private struct LinkIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let itinerary: PlannerEntityReference
}

@MainActor
private func makeLinkIntentFixture() async throws -> LinkIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  let links: [PlannerLinkInput] = [
    .init(
      originalUrl: "https://maps.apple.com/?q=Nezu%20Museum&place-id=fixture-nezu", label: "Visit"),
    .init(originalUrl: "https://example.com/Guide?Ref=%2f&Ref=A#Room", label: nil),
    .init(
      originalUrl: "https://maps.apple.com/?q=Nezu%20Museum&place-id=fixture-nezu", label: "Visit"),
  ]
  let commands: [PlannerCommand] = [
    .createItem(
      content: .init(
        title: "Museum", subtitle: "Booking", notes: "Keep notes",
        location: .init(
          displayName: "Saved place", formattedAddress: "Tokyo",
          coordinate: .init(latitude: 35.6622, longitude: 139.7171)),
        estimate: .init(minutes: 125, displayUnit: .hour), links: links)),
    .createItinerary(
      content: .init(
        title: "Weekend", notes: "Keep route notes",
        links: [.init(originalUrl: "https://example.com/route", label: "Route")],
        manualEstimate: .init(minutes: 480, displayUnit: .hour))),
  ]
  var sources: [PlannerEntityReference] = []
  for command in commands {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: command)
      ).outcome,
      let source = result.generated.first
    else { throw CancellationError() }
    sources.append(source)
  }
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    item: sources[0], itinerary: sources[1])
}
