import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleReadIntentTests: XCTestCase {
  func testCalendarWindowReturnsExactTimedAndInclusiveAllDayFormsWithoutChangingData()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The native Calendar read must start from saved Schedule forms.") }
    let zones = try await PlannerTimeZoneEntityQuery().entities(for: ["Asia/Tokyo"])
    let reading = FindPlannerSchedulesIntent()
    reading.startDay = .init(year: 2026, month: 10, day: 9)
    reading.endDay = .init(year: 2026, month: 10, day: 11)
    reading.displayTimeZone = try XCTUnwrap(zones.first)
    let schedules = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(schedules.map(\.id)), [fixture.timed.id, fixture.allDay.id])
    let timed = try XCTUnwrap(schedules.first { $0.id == fixture.timed.id })
    XCTAssertEqual(timed.title, "Museum")
    XCTAssertEqual(timed.sourceType, "Item")
    XCTAssertFalse(timed.allDay)
    XCTAssertEqual(timed.start, fixture.instant)
    XCTAssertNil(timed.end)
    XCTAssertNil(timed.startDay)
    XCTAssertNil(timed.endDay)
    XCTAssertEqual(timed.planningTimeZone?.id, "Asia/Tokyo")
    let allDay = try XCTUnwrap(schedules.first { $0.id == fixture.allDay.id })
    XCTAssertEqual(allDay.title, "Tokyo Weekend")
    XCTAssertEqual(allDay.sourceType, "Itinerary")
    XCTAssertTrue(allDay.allDay)
    XCTAssertNil(allDay.start)
    XCTAssertNil(allDay.end)
    XCTAssertNil(allDay.planningTimeZone)
    XCTAssertEqual(allDay.startDay?.year, 2026)
    XCTAssertEqual(allDay.startDay?.month, 10)
    XCTAssertEqual(allDay.startDay?.day, 9)
    XCTAssertEqual(allDay.endDay?.day, 11)
    XCTAssertNil(allDay.startDay?.hour)
    XCTAssertNil(allDay.startDay?.timeZone)
    XCTAssertNil(allDay.endDay?.hour)
    XCTAssertNil(allDay.endDay?.timeZone)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .exported(let after) = await reopened.exportData(session: session)
    else { return XCTFail("Native Calendar reads must preserve the reopened planner.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}

private struct ScheduleReadIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let timed: PlannerEntityReference
  let allDay: PlannerEntityReference
  let outside: PlannerEntityReference
  let instant: Date
}

@MainActor
private func makeScheduleReadIntentFixture() async throws -> ScheduleReadIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerEntityReference {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome,
      let source = result.generated.first
    else { throw CancellationError() }
    return source
  }
  let item = try await save(
    .createItem(content: .init(title: "Museum", estimate: .init(minutes: 90, displayUnit: .hour))))
  let itinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
  guard
    case .applied(_, .complete) = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    ).outcome
  else { throw CancellationError() }
  let instant = try Date.ISO8601FormatStyle().parse("2026-10-09T01:00:00Z")
    .addingTimeInterval(0.125)
  let timed = try await save(
    .createSchedule(
      source: item, form: .timed(start: instant, end: nil, planningTimeZone: "Asia/Tokyo")))
  let allDay = try await save(
    .createSchedule(
      source: itinerary,
      form: .allDay(
        start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11))))
  let outside = try await save(
    .createSchedule(
      source: item, form: .allDay(start: .init(year: 2026, month: 10, day: 12), end: nil)))
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    item: item, itinerary: itinerary, timed: timed, allDay: allDay, outside: outside,
    instant: instant)
}
