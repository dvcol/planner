#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerItemEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Item")
    static var defaultQuery: PlannerItemEntityQuery { PlannerItemEntityQuery() }
    let id: UUID
    @Property(title: "Title") var title: String
    @Property(title: "Completed everywhere") var done: Bool
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(title)") }

    init(id: UUID, title: String, done: Bool, archived: Bool) {
      self.id = id
      self.title = title
      self.done = done
      self.archived = archived
    }
  }

  struct PlannerItemEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore
    func entities(for identifiers: [UUID]) async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
    func entities(matching string: String) async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
    func suggestedEntities() async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
  }

  struct CreatePlannerItemIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Item"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Title") var title: String
    @Parameter(title: "Notes") var notes: String?
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerItemEntity, Never, Never, IntentDialog>
    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(
        .createItem(content: .init(title: title, notes: notes)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .item }) else {
          throw PlannerIntentFailure(
            message:
              "Planner applied this change without returning its Item. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(title)."
        case .incomplete:
          dialog =
            "The Item was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(
          value: PlannerItemEntity(id: source.id, title: title, done: false, archived: false),
          dialog: dialog)
      }
    }
  }

  private struct PlannerIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }

#endif
