from pathlib import Path
import gzip, hashlib, json, os, signal, subprocess, sys, time
workspace=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==workspace
phase,selected=sys.argv[1:3]
base=workspace/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
build=base/'native-share-migration-final-mac-build'
packet=base/phase
packet.mkdir(exist_ok=False)
root=Path('/private/tmp/PlannerNativeItemWindowSource')
manifest=json.loads((build/'source-sha256.json').read_text())
products=json.loads((build/'product-sha256.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
for name in ['source-sha256.json','source-root.json','product-sha256.json']:(packet/name).write_bytes((build/name).read_bytes())
plans=list(Path('/private/tmp/PlannerShareMigrationMacDerivedData/Build/Products').glob('PlannerFixtures_*.xctestrun'))
assert len(plans)==1,plans
result=Path('/private/tmp/PlannerShareMigration-'+phase+'.xcresult')
command=['xcodebuild','test-without-building','-xctestrun',str(plans[0]),'-destination','platform=macOS,arch=arm64','-parallel-testing-enabled','NO','-jobs','1','-test-timeouts-enabled','YES','-default-test-execution-time-allowance','600','-maximum-test-execution-time-allowance','600','-only-testing:PlannerFixtureUITests/'+selected,'-resultBundlePath',str(result)]
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
log=Path('/private/tmp/PlannerShareMigration-'+phase+'.log')
started=time.monotonic()
timed_out=False
with log.open('wb') as output:
 process=subprocess.Popen(command,cwd=root,env=environment,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=720)
 except subprocess.TimeoutExpired:
  timed_out=True
  os.killpg(process.pid,signal.SIGINT)
  try:process.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  code=124
unchanged=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
products_unchanged=all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in products.items())
(packet/'exit.json').write_text(json.dumps({'exitCode':code,'runnerTimedOut':timed_out,'elapsedSeconds':round(time.monotonic()-started,3),'inputsUnchanged':unchanged,'productsUnchanged':products_unchanged,'runtimeCredit':False},indent=2)+'\n')
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
extractions=[]
for kind in ['summary','tests']:
 command=['xcrun','xcresulttool','get','test-results',kind,'--path',str(result)]
 completed=subprocess.run(command,env=environment,capture_output=True)
 extractions.append({'command':command,'exitCode':completed.returncode})
 if completed.returncode==0:
  if kind=='summary':(packet/'test-summary.json').write_bytes(completed.stdout)
  else:(packet/'test-results-tests.json.gz').write_bytes(gzip.compress(completed.stdout,mtime=0))
(packet/'evidence-commands.json').write_text(json.dumps(extractions,indent=2)+'\n')
print('Mac runtime exit',code,'inputs unchanged',unchanged,'products unchanged',products_unchanged)
for line in log.read_text(errors='replace').splitlines():
 if line.startswith(('Test Case ','** TEST','error:')) or ('.swift:' in line and ': error:' in line):print(line[:700])
raise SystemExit(code)
