from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
packet = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility' / phase
outcome = json.loads((packet / 'exit.json').read_text())
bundle = outcome['bundle']
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
summary_command = ['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', bundle, '--compact']
summary = json.loads(subprocess.check_output(summary_command, env=environment))
(packet / 'test-results-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
output = Path('/private/tmp/PlannerBackupVersionAttachments-' + phase)
export_command = ['xcrun', 'xcresulttool', 'export', 'attachments', '--path', bundle, '--output-path', str(output)]
subprocess.run(export_command, check=True, env=environment, stdout=subprocess.DEVNULL)
selected = []
for test in json.loads((output / 'manifest.json').read_text()):
    for attachment in test['attachments']:
        source = output / attachment['exportedFileName']
        name = attachment['suggestedHumanReadableName']
        if source.suffix == '.png' and name.startswith(('Unsupported backup', 'Valid backup')):
            shutil.copy2(source, packet / source.name)
            selected.append(dict(attachment, testIdentifier=test['testIdentifier'], originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
        elif source.suffix == '.txt' and 'saved.list.' in name:
            destination = packet / (source.name + '.gz')
            destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
            selected.append(dict(attachment, testIdentifier=test['testIdentifier'], retainedFileName=destination.name, originalSha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(packet / 'selected-attachments.json').write_text(json.dumps({'bundle':bundle, 'attachments':selected, 'videoPublished':False}, indent=2) + '\n')
manifest = json.loads((packet / 'source-sha256.json').read_text())
differences = []
for relative, digest in manifest.items():
    source = repository / relative
    if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != digest:
        differences.append(relative)
(packet / 'current-source-comparison.json').write_text(json.dumps({'inputCount':len(manifest), 'differences':differences}, indent=2) + '\n')
(packet / 'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'phase':phase, 'exit':outcome['exitCode'], 'passed':summary['passedTests'], 'failed':summary['failedTests'], 'skipped':summary['skippedTests'], 'sourceDifferences':differences, 'captures':[entry['exportedFileName'] for entry in selected if entry['exportedFileName'].endswith('.png')]}))
