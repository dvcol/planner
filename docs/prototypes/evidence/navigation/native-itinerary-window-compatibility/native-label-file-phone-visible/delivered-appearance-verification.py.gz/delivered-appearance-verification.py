from pathlib import Path
import copy,gzip,hashlib,json,math,sys

def typed_value(value):
    if value is None:return ('null',)
    if isinstance(value,bool):return ('boolean',value)
    if isinstance(value,(int,float)):return ('number',*value.as_integer_ratio())
    if isinstance(value,str):return ('string',value)
    if isinstance(value,list):return ('array',tuple(typed_value(entry) for entry in value))
    assert isinstance(value,dict)
    return ('object',tuple(sorted((key,typed_value(entry)) for key,entry in value.items())))

repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=root/phase
provenance=json.loads((root/'native-label-appearance-inputs-valid/fixture-provenance.json').read_text())
source=repository/provenance['source'];assert hashlib.sha256(source.read_bytes()).hexdigest()==provenance['sha256']
original=json.loads(source.read_text())
original['formatVersion']=2
for entry in original['sources']:
    if entry['kind'] in ['list','itinerary']:entry['content']['manualEstimate']=None
summary=json.loads((packet/'test-results-summary.json').read_text())
assert summary['failedTests']==0 and summary['passedTests']>0
attachments=json.loads((packet/'selected-attachments.json').read_text())['attachments']
results=[]
renamed_timestamps={}
for stage,prefix in [('name-only','Label appearance name-only delivered backup filename'),('cleared','Label appearance cleared delivered backup filename')]:
    names=[entry for entry in attachments if entry['suggestedHumanReadableName'].startswith(prefix)]
    assert len(names)==1
    filename=gzip.decompress((packet/names[0]['retainedFileName']).read_bytes()).decode().strip()
    if platform=='mac':
        delivered=Path(filename)
        assert delivered.parent.name.startswith('PlannerNativeLabelExports-')
        assert delivered.name=='Planner label appearance export.json'
    else:
        assert Path(filename).name==filename and filename.endswith('.json')
        delivered=Path(provenance['destinations'][platform]).parent/filename
    assert delivered.stat().st_mtime>=summary['startTime']-2
    content=delivered.read_bytes();actual=json.loads(content);expected=copy.deepcopy(original)
    for label_kind,new_name in [('category','Dining custom'),('tag','Weather custom')]:
        expected_label=next(entry for entry in expected['sources'] if entry['kind']==label_kind)
        actual_labels=[entry for entry in actual['sources'] if entry['kind']==label_kind]
        assert len(actual_labels)==1
        actual_label=actual_labels[0]
        timestamp=actual_label['updatedAt']
        assert isinstance(timestamp,(int,float)) and not isinstance(timestamp,bool) and math.isfinite(timestamp)
        assert summary['startTime']-978307200-2<=timestamp<=delivered.stat().st_mtime-978307200+2
        if stage=='name-only':renamed_timestamps[label_kind]=timestamp
        elif label_kind=='tag':assert timestamp==renamed_timestamps[label_kind]
        else:assert timestamp>renamed_timestamps[label_kind]
        expected_label['content']['name']=new_name
        expected_label['updatedAt']=timestamp
        if stage=='cleared' and label_kind=='category':
            expected_label['content']['color']=None;expected_label['content']['iconName']=None
        assert typed_value(actual_label)==typed_value(expected_label),(stage,label_kind)
    assert set(actual)==set(expected)
    for key,expected_value in expected.items():
        actual_value=actual[key]
        if isinstance(expected_value,list):
            assert sorted((typed_value(entry) for entry in actual_value),key=repr)==sorted((typed_value(entry) for entry in expected_value),key=repr),(stage,key)
        else:assert typed_value(actual_value)==typed_value(expected_value),(stage,key)
    retained=stage+'-delivered-backup.json.gz'
    (packet/retained).write_bytes(gzip.compress(content,mtime=0))
    results.append({'stage':stage,'path':str(delivered),'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'retainedFileName':retained,'allRecordCollectionsAndValuesMatch':True,'onlyAllowedChanges':'Declared label names and their validated edit timestamps; explicit Category color/icon clearing in second export.'})
report={'source':{key:provenance[key] for key in ['source','bytes','sha256']},'platform':platform,'typedComparison':'Booleans distinct from native numbers; exact binary rational values for every color component; record-table order alone is representation. Nested arrays, identities, lifetimes, ranks, completion, content and history remain exact.','formatMigration':'Version 1 to 2 plus null manualEstimate on Lists/Itineraries.','nameOnlyColorAndCustomSymbolPreservationExact':True,'onlyExplicitCategoryAppearanceCleared':True,'unrelatedTagAppearanceAndOwnerRecordsPreserved':True,'delivered':results}
(packet/'delivered-appearance-verification.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'delivered-appearance-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(platform,'both actual exports exactly match the full expected graphs, including every color bit')
