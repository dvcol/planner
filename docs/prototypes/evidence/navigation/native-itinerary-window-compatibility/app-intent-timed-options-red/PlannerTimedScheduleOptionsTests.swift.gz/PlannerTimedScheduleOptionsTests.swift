import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerTimedScheduleOptionsTests: XCTestCase {
  func testTimedChoicesExcludeAllDayAndKeepArchivedOwnersWithLiveTitles() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    guard case .source(.item(let current)) = await fixture.planner.read(
      session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    for command in [
      PlannerCommand.editItem(
        sourceId: fixture.item.id, changes: .init(title: "Renamed museum"),
        expectedFieldHashes: current.fieldHashes),
      .setArchive(source: fixture.item, archived: true),
    ] {
      guard case .applied(_, .complete) = await fixture.planner.execute(
        .init(operationId: UUID(), session: fixture.session, command: command)).outcome
      else { throw CancellationError() }
    }
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { throw CancellationError() }
    let choices = try await PlannerTimedScheduleOptionsProvider().results()
    XCTAssertEqual(choices.map(\.id), [fixture.timed.id])
    XCTAssertEqual(choices.first?.title, "Renamed museum")
    XCTAssertEqual(choices.first?.allDay, false)
    XCTAssertEqual(choices.first?.start, fixture.instant)
    XCTAssertEqual(choices.first?.planningTimeZone?.id, "Asia/Tokyo")
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { throw CancellationError() }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.isSaving)
  }
}
