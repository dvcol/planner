#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation

  struct PlannerItemEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Item")
    static var defaultQuery: PlannerItemEntityQuery { PlannerItemEntityQuery() }
    let id: UUID
    @Property(title: "Title") var title: String
    @Property(title: "Completed everywhere") var done: Bool
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(title)") }

    init(id: UUID, title: String, done: Bool, archived: Bool) {
      self.id = id
      self.title = title
      self.done = done
      self.archived = archived
    }
  }

  struct PlannerItemEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    func entities(for identifiers: [UUID]) async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
    func entities(matching string: String) async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
    func suggestedEntities() async throws -> [PlannerItemEntity] {
      throw CocoaError(.featureUnsupported)
    }
  }

  struct CreatePlannerItemIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Item"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Title") var title: String
    @Parameter(title: "Notes") var notes: String?
    typealias PerformResult = IntentResultContainer<PlannerItemEntity, Never, Never, IntentDialog>
    func perform() async throws -> PerformResult { throw CocoaError(.featureUnsupported) }
  }

#endif
