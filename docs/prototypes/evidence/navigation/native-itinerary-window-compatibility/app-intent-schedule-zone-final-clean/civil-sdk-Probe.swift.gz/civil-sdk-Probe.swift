import AppIntents
import Foundation

enum ProbeScheduleForm: String, AppEnum {
  case timed, allDay
  static let typeDisplayRepresentation: TypeDisplayRepresentation = "Schedule form"
  static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [.timed: "Timed", .allDay: "All day"]
}
struct ProbeZone: AppEntity {
  static let typeDisplayRepresentation: TypeDisplayRepresentation = "Planning timezone"
  static var defaultQuery: ProbeZoneQuery { .init() }
  let id: String
  var displayRepresentation: DisplayRepresentation { .init(title: "\(id)") }
}
struct ProbeZoneQuery: EntityStringQuery {
  func entities(for identifiers: [String]) async throws -> [ProbeZone] { [] }
  func entities(matching string: String) async throws -> [ProbeZone] { [] }
}
struct ProbeSchedule: AppEntity {
  static let typeDisplayRepresentation: TypeDisplayRepresentation = "Schedule"
  static var defaultQuery: ProbeScheduleQuery { .init() }
  let id: UUID
  let isTimed: Bool
  var displayRepresentation: DisplayRepresentation { .init(title: "Schedule") }
}
struct ProbeScheduleQuery: EntityQuery {
  func entities(for identifiers: [UUID]) async throws -> [ProbeSchedule] { [] }
  func suggestedEntities() async throws -> [ProbeSchedule] { [] }
}
struct TimedScheduleOptions: DynamicOptionsProvider {
  func results() async throws -> [ProbeSchedule] {
    try await ProbeScheduleQuery().suggestedEntities().filter(\.isTimed)
  }
}
struct ProbeScheduleCreation: AppIntent {
  static let title: LocalizedStringResource = "Schedule creation probe"
  @Parameter(title: "Form", default: .timed) var form: ProbeScheduleForm
  @Parameter(title: "Local start", kind: .dateTime) var localStart: DateComponents?
  @Parameter(title: "Local end", kind: .dateTime) var localEnd: DateComponents?
  @Parameter(title: "All-day start", kind: .date) var startDay: DateComponents?
  @Parameter(title: "All-day end", kind: .date) var endDay: DateComponents?
  @Parameter(title: "Clock only", kind: .time) var clockOnly: DateComponents?
  @Parameter(title: "Instant comparison", kind: .dateTime) var instant: Date?
  @Parameter(title: "Planning timezone") var timeZone: ProbeZone?
  @Parameter(title: "Timed schedule", optionsProvider: TimedScheduleOptions()) var schedule: ProbeSchedule?
  static var parameterSummary: some ParameterSummary {
    Switch(\.$form) {
      Case(.timed) {
        Summary("Create \(\.$form) at \(\.$localStart) in \(\.$timeZone)") { \.$localEnd }
      }
      DefaultCase {
        Summary("Create \(\.$form) from \(\.$startDay)") { \.$endDay }
      }
    }
  }
  func perform() async throws -> some IntentResult { .result() }
}
