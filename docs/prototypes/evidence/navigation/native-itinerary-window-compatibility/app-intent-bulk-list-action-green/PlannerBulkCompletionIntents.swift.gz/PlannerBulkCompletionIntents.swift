#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct SetPlannerListChildCompletionIntent: AppIntent {
    static let title: LocalizedStringResource = "Set List child completion"
    static let description = IntentDescription(
      "Review and confirm completion for all Item appearances in this List, including hidden and archived children. Done everywhere stays unchanged."
    )
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "List") var list: PlannerListEntity
    @Parameter(title: "Completed") var completed: Bool
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<Never, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      let dialog = try await performPlannerBulkCompletion(
        self, scope: .list(listId: list.id), done: completed, store: plannerStore)
      return .result(dialog: dialog)
    }
  }

  @MainActor
  private func performPlannerBulkCompletion<Intent: AppIntent>(
    _ intent: Intent, scope: PlannerBulkScope, done: Bool, store: SavedPlannerStore
  ) async throws -> IntentDialog {
    while true {
      let name = try await plannerBulkScopeName(scope, store: store)
      let review = try await store.prepareAppIntentBulkCompletion(scope: scope, done: done)
      try Task.checkCancellation()
      let acceptLabel: LocalizedStringResource = done ? "Mark done" : "Mark undone"
      let confirmation: IntentDialog =
        "Set completion in \(name) for all \(review.targetCount) Item appearances, including hidden and archived children? Done everywhere stays unchanged."
      try await intent.requestConfirmation(
        actionName: .custom(
          acceptLabel: acceptLabel, acceptAlternatives: [],
          denyLabel: "Cancel", denyAlternatives: [], destructive: false),
        dialog: confirmation)
      try Task.checkCancellation()
      let result = try await store.executeAppIntent(review.command, reviewToken: review.reviewToken)
      switch result.outcome {
      case .rejected(let reason) where reason.code == "staleReview": continue
      case .rejected(let reason): throw PlannerBulkIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerBulkIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(_, .incomplete):
        return
          "Completion changed on this device, but its recovery copy is incomplete. Open Planner before making more changes."
      case .applied(_, .complete):
        if review.targetCount == 0 { return "No items. No completion flags changed." }
        return
          "Updated completion for \(review.targetCount) Item appearances in \(name). Done everywhere is unchanged."
      }
    }
  }

  @MainActor
  private func plannerBulkScopeName(_ scope: PlannerBulkScope, store: SavedPlannerStore)
    async throws -> String
  {
    let (planner, session) = try await store.appIntentContext()
    switch scope {
    case .list(let identifier):
      switch await planner.read(
        session: session, request: .source(.init(kind: .list, id: identifier)))
      {
      case .source(.list(let source)): return source.content.name
      case .failed(let reason): throw PlannerBulkIntentFailure(message: reason.message)
      default: throw PlannerBulkIntentFailure(message: "Planner could not read this List.")
      }
    default: throw PlannerBulkIntentFailure(message: "Choose a supported completion scope.")
    }
  }

  private struct PlannerBulkIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
