from pathlib import Path
import gzip, hashlib, json, plistlib, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = evidence / phase
baseline = evidence / 'app-intent-item-find-criteria-final-clean'
assert json.loads((packet / 'exit.json').read_text())['exitCode'] == 0
prior = json.loads(gzip.decompress((baseline / 'extract.actionsdata.gz').read_bytes()))
paths = {
    'mac': '/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
    'mobile': '/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
    'device': '/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata',
}
metadata_bytes = Path(paths[platform]).read_bytes()
metadata = json.loads(metadata_bytes)
def parameter(value_type, optional=False):
    return {'valueType': value_type, 'optional': optional}
def enumeration(identifier):
    return {'linkEnumeration': {'wrapper': {'identifier': identifier}}}
def entity_array(identifier):
    return {'array': {'wrapper': {'capabilities': 3, 'memberValueType': {'entity': {'wrapper': {'typeName': identifier}}}}}}
def action_contract(action):
    return {value['name']: parameter(value['valueType'], value['isOptional']) for value in action['parameters']}
assert len(metadata['actions']) == 67 and len(metadata['enums']) == 11
assert set(metadata['actions']) == set(prior['actions'])
for identifier, action in prior['actions'].items():
    assert action_contract(metadata['actions'][identifier]) == action_contract(action), identifier
    assert metadata['actions'][identifier].get('outputType') == action.get('outputType'), identifier
for kind in ['entities', 'queries', 'enums']:
    assert metadata[kind] == prior[kind], kind
result = {'actions': sorted(metadata['actions']), 'entities': sorted(metadata['entities']), 'queries': sorted(metadata['queries']), 'enumCount': len(metadata['enums']), 'priorActionParametersAndOutputsUnchanged': True, 'priorEntitiesQueriesEnumsUnchanged': True, 'metadataSha256': hashlib.sha256(metadata_bytes).hexdigest(), 'systemInvocationQualified': False}
(packet / 'extracted-intent-identifiers.json').write_text(json.dumps(result, indent=2) + '\n')
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes, mtime=0))
source_hashes = json.loads((packet / 'source-sha256.json').read_text())
prior_hashes = json.loads((baseline / 'source-sha256.json').read_text())
changed = sorted(relative for relative, digest in prior_hashes.items() if source_hashes.get(relative) != digest)
added = sorted(set(source_hashes) - set(prior_hashes))
assert changed == ['Planner/Scenes/SavedPlannerStore.swift', 'PlannerMCPTests/PlannerItemFindIntentTests.swift'], changed
assert added == [] and len(source_hashes) == 1038
assert all(hashlib.sha256((repository / relative).read_bytes()).hexdigest() == digest for relative, digest in source_hashes.items())
(packet / 'baseline-source-comparison.json').write_text(json.dumps({'baselinePacket': baseline.name, 'priorInputs': len(prior_hashes), 'currentInputs': len(source_hashes), 'changedInputs': changed, 'addedInputs': added, 'otherPriorInputsUnchanged': True}, indent=2) + '\n')
if platform == 'mac':
    command = ['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', '/private/tmp/PlannerItemWindow-' + phase + '.xcresult', '--format', 'json']
    summary = json.loads(subprocess.check_output(command, text=True))
    (packet / 'test-results-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert summary['passedTests'] == 82 and summary['failedTests'] == 0 and summary['skippedTests'] == 0
    lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] is True and len(lifecycle['removedDirectories']) == lifecycle['fixtureCount'] and lifecycle['fixtureCount'] > 0
else:
    final_mac = evidence / 'app-intent-related-empty-cancellation-final-clean'
    assert source_hashes == json.loads((final_mac / 'source-sha256.json').read_text())
    mac_metadata = json.loads(gzip.decompress((final_mac / 'extract.actionsdata.gz').read_bytes()))
    for kind in ['entities', 'queries', 'enums']:
        assert metadata[kind] == mac_metadata[kind], kind
    for identifier, action in mac_metadata['actions'].items():
        assert action_contract(metadata['actions'][identifier]) == action_contract(action)
        assert metadata['actions'][identifier].get('outputType') == action.get('outputType')
log_path = packet / 'build.log.gz'
if not log_path.exists():
    log_path = packet / 'test.log.gz'
log = gzip.decompress(log_path.read_bytes()).decode(errors='replace')
diagnostics = [line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet / 'compiler-diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
baseline_log = gzip.decompress((evidence / 'app-intent-schedule-removal-http-base/test.log.gz').read_bytes()).decode(errors='replace')
baseline_diagnostics = [line[:1000] for line in baseline_log.splitlines() if ': warning:' in line]
introduced = [line for line in diagnostics if line not in baseline_diagnostics]
(packet / 'baseline-compiler-diagnostics.json').write_text(json.dumps({'baselinePacket': 'app-intent-schedule-removal-http-base', 'baselineWarnings': baseline_diagnostics, 'currentDiagnostics': diagnostics, 'introducedDiagnostics': introduced}, indent=2) + '\n')
assert not introduced, introduced
assert not any(phrase in log for phrase in ['vnode unlinked while in use', 'database integrity compromised', 'invalidated open fd'])
if platform == 'device':
    app = Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
    extensions = list((app / 'PlugIns').glob('*.appex'))
    assert len(extensions) == 1
    products = []
    for product in [app, *extensions]:
        values = plistlib.loads((product / 'Info.plist').read_bytes())
        executable = product / values['CFBundleExecutable']
        architectures = subprocess.check_output(['lipo', '-archs', str(executable)], text=True).split()
        assert architectures == ['arm64']
        products.append({'bundleIdentifier': values['CFBundleIdentifier'], 'architectures': architectures, 'sha256': hashlib.sha256(executable.read_bytes()).hexdigest()})
    (packet / 'embedded-products-verification.json').write_text(json.dumps({'products': products, 'embeddedMobileShareCount': 1, 'signingAllowed': False, 'installedOrLaunched': False}, indent=2) + '\n')
(packet / 'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(platform, 'verified: 67 actions, unchanged 10 entities/queries, 11 enums;', len(source_hashes), 'matching inputs; compiler diagnostics', len(diagnostics))
