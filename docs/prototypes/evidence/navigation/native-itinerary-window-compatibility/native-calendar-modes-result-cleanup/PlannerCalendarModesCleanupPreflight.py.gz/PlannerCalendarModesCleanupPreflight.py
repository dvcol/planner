from pathlib import Path
import json, hashlib, subprocess, os
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd() == repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
root = repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
archive = Path('/private/tmp/PlannerHeaderUnpublishedDiagnostics/native-calendar-modes-iterations')
phases = ['native-calendar-day-week-mac','native-calendar-overlap-overflow-mac','native-calendar-modes-mac-lookup','native-calendar-modes-mac-readback','native-calendar-schedule-accessibility-mac','native-calendar-schedule-static-text-mac','native-calendar-modes-qualified-mac','native-calendar-modes-qualified-phone','native-calendar-modes-qualified-tablet','native-calendar-modes-qualified-tablet-retry']
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
records = []
for phase in phases:
    packet = root/phase
    if not packet.is_dir(): packet = archive/phase
    assert packet.is_dir(), phase
    status = json.loads((packet/'exit.json').read_text())
    assert status['exitCode'] in [0,65] and not status.get('runnerTimedOut',False)
    bundle = Path('/private/tmp/PlannerItemWindow-'+phase+'.xcresult')
    assert bundle.is_dir() and not bundle.is_symlink()
    summary_path = packet/'test-results-summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['totalTestCount'] >= 1
    command = ['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle)]
    result = subprocess.run(command,capture_output=True,text=True,env=environment,check=True)
    assert json.loads(result.stdout) == summary, phase
    manifest = json.loads((packet/'selected-attachments.json').read_text())
    attachments = manifest['attachments'] + manifest.get('excludedAttachments',[])
    for attachment in attachments:
        path = Path('/private/tmp/PlannerLabelAttachments-'+phase)/attachment['exportedFileName']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == attachment['sha256'], path
    handles = subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(bundle)],capture_output=True,text=True)
    assert handles.returncode == 1 and not handles.stdout.strip() and not handles.stderr.strip(), bundle
    records.append({'phase':phase,'path':str(bundle),'summaryPath':str(summary_path),'summarySha256':hashlib.sha256(summary_path.read_bytes()).hexdigest(),'rawSummaryExactlyMatches':True,'rawSummaryCommand':command,'verifiedSelectedOriginalAttachments':len(attachments),'nominalBytes':sum(path.stat().st_size for path in bundle.rglob('*') if path.is_file()),'openHandles':False,'result':{key:summary[key] for key in ['passedTests','failedTests','skippedTests']}})
report = {'evidenceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Only these ten completed Calendar-mode raw xcresults. Original extracted attachments, retained private packets, source, current products, package caches, Simulator state, fixture/export JSON and Planner datasets are excluded.','bundles':records,'bundleNominalBytes':sum(record['nominalBytes'] for record in records),'deleted':False}
Path('/private/tmp/PlannerCalendarModesCleanupCandidates.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'eligibleRawBundles':len(records),'nominalBytes':report['bundleNominalBytes'],'verifiedOriginalAttachments':sum(record['verifiedSelectedOriginalAttachments'] for record in records),'deleted':False}))
