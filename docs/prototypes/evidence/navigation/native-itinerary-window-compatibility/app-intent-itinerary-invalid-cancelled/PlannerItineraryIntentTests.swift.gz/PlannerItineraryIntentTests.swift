import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryIntentTests: XCTestCase {
  func testCreateItineraryReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItineraryIntent()
    creation.title = "Tokyo Weekend"
    creation.notes = "Museum, lunch and a return to the Hotel"
    let itinerary = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(itinerary.title, "Tokyo Weekend")
    XCTAssertFalse(itinerary.archived)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.itinerary(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .itinerary, id: itinerary.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .itinerary, archive: .all))))
    else { return XCTFail("The returned Itinerary must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, itinerary.id)
    XCTAssertEqual(current.content.title, "Tokyo Weekend")
    XCTAssertEqual(current.content.notes, "Museum, lunch and a return to the Hotel")
    XCTAssertEqual(current.state.archived, false)
    XCTAssertNil(current.state.globalDone)
    XCTAssertEqual(current.progress.state, .empty)
    XCTAssertEqual(current.progress.totalCount, 0)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertTrue(current.listEntrySummaries.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .itinerary, id: itinerary.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testIdentityLookupDeduplicatesRequestsAndReturnsLiveValuesInRequestedOrder() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItineraryIntent()
    creation.title = "Original itinerary"
    let first = try await creation.callAsFunction(donate: false)
    creation.title = "Second itinerary"
    let second = try await creation.callAsFunction(donate: false)
    let itemCreation = CreatePlannerItemIntent()
    itemCreation.title = "This is an Item, not an Itinerary"
    let item = try await itemCreation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .itinerary, id: first.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.itinerary(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editItinerary(
            sourceId: first.id, changes: .init(title: .set("Renamed itinerary")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: source, archived: true))
      ).outcome
    else { return XCTFail("Canonical commands must change the source before entity lookup.") }
    let query = PlannerItineraryEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(
      for: [second.id, UUID(), first.id, second.id, item.id, first.id])
    XCTAssertEqual(resolved.map(\.id), [second.id, first.id])
    XCTAssertEqual(resolved.map(\.title), ["Second itinerary", "Renamed itinerary"])
    XCTAssertEqual(resolved.map(\.archived), [false, true])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testGetItineraryReturnsLiveValuesAndRejectsMissingIdentity() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItineraryIntent()
    creation.title = "Original itinerary"
    let cached = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .itinerary, id: cached.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.itinerary(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editItinerary(
            sourceId: cached.id, changes: .init(title: .set("Renamed itinerary")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome
    else { return XCTFail("The canonical source must change before resolving a cached entity.") }
    let reading = GetPlannerItineraryIntent()
    reading.itinerary = cached
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, cached.id)
    XCTAssertEqual(current.title, "Renamed itinerary")
    XCTAssertFalse(current.archived)
    reading.itinerary = .init(id: UUID(), title: "Missing", archived: false)
    do {
      _ = try await reading.callAsFunction(donate: false)
      XCTFail("Get Itinerary must reject a missing identity rather than inventing a source.")
    } catch {
      XCTAssertTrue(error.localizedDescription.contains("no longer available"))
    }
  }

  func testItineraryChoicesPreserveCanonicalSearchOrderArchivedSourcesAndEveryPage() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    var identifiers: [UUID] = []
    for index in 0..<65 {
      guard
        case .applied(let created, .complete) = await planner.execute(
          .init(
            operationId: UUID(), session: session,
            command: .createItinerary(content: .init(title: String(format: "Route %02d", index))))
        ).outcome, let source = created.generated.first
      else { return XCTFail("Every canonical Itinerary must save before querying choices.") }
      identifiers.append(source.id)
    }
    guard
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: .init(kind: .itinerary, id: identifiers[0]), archived: true))
      ).outcome
    else { return XCTFail("The archived Itinerary must remain discoverable by identity.") }
    let query = PlannerItineraryEntityQuery()
    query.plannerStore = store
    let matches = try await query.entities(matching: "ROUTE")
    XCTAssertEqual(matches.map(\.id), identifiers)
    XCTAssertEqual(matches.first?.title, "Route 00")
    XCTAssertEqual(matches.first?.archived, true)
    XCTAssertEqual(matches.last?.title, "Route 64")
    XCTAssertEqual(Set(matches.map(\.id)).count, 65)
    let suggestions = try await query.suggestedEntities()
    XCTAssertEqual(suggestions.map(\.id), identifiers)
    let absent = try await query.entities(matching: "No such itinerary")
    XCTAssertTrue(absent.isEmpty)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testInvalidAndPrecancelledCreationLeaveNoSavedItineraries() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItineraryIntent()
    creation.title = "   "
    do {
      _ = try await creation.callAsFunction(donate: false)
      XCTFail("A blank Itinerary title cannot acknowledge creation.")
    } catch {
      XCTAssertFalse(error.localizedDescription.isEmpty)
    }
    creation.title = "Cancelled before invocation"
    let request = Task { try await creation.callAsFunction(donate: false) }
    request.cancel()
    do {
      _ = try await request.value
      XCTFail("A cancelled invocation must not start an Itinerary creation.")
    } catch {
      XCTAssertFalse(error.localizedDescription.isEmpty)
    }
    let query = PlannerItineraryEntityQuery()
    query.plannerStore = store
    let choices = try await query.suggestedEntities()
    XCTAssertTrue(choices.isEmpty)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .itinerary, archive: .all))))
    else {
      return XCTFail("The actual empty dataset must remain readable after rejected creation.")
    }
    XCTAssertTrue(catalog.rows.isEmpty)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(
        path: "PlannerItineraryIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
