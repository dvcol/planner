import Foundation
import PlannerCore
import Testing

struct AssociationUndoHistoryTests {
  @Test func issuanceEndsOnReopenButAppliedRestorationReplayPreservesLaterEdits() async throws {
    let fixture = try await AssociationUndoFixture()
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let removal = await fixture.remove()
    let snapshot = try #require(removal.associationUndoSnapshot)
    let replay = await fixture.remove()
    #expect(replay.associationUndoSnapshot?.closingOperationId == fixture.removalIdentifier)
    let reopened = Planner(configuration: fixture.configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap() else {
      throw CancellationError()
    }
    let removalReplay = await reopened.execute(
      .init(
        operationId: fixture.removalIdentifier, session: reopenedSession,
        command: fixture.removalCommand))
    #expect(removalReplay.associationUndoSnapshot == nil)
    let expired = await reopened.execute(
      .init(
        operationId: UUID(), session: reopenedSession,
        command: .restoreAssociation(snapshot: snapshot)))
    guard case .rejected(let expiration) = expired.outcome,
      case .source(.item(let item)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    #expect(expiration.code == "associationUndoUnavailable")
    _ = try await fixture.save(
      .editItem(
        sourceId: fixture.item.id, changes: .init(notes: .set("Edited after removal")),
        expectedFieldHashes: [.notes: try #require(item.fieldHashes[.notes])]))
    let restorationIdentifier = UUID()
    let restoration = await fixture.planner.execute(
      .init(
        operationId: restorationIdentifier, session: fixture.session,
        command: .restoreAssociation(snapshot: snapshot)))
    guard case .applied(let restored, .complete(let checkpoint)) = restoration.outcome,
      case .source(.item(let edited)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item))
    else { throw CancellationError() }
    #expect(edited.content.notes == "Edited after removal")
    _ = try await fixture.save(
      .editItem(
        sourceId: fixture.item.id, changes: .init(notes: .set("Edited after restoration")),
        expectedFieldHashes: [.notes: try #require(edited.fieldHashes[.notes])]))
    let beforeReplay = try await fixture.export()
    let restorationReplay = await reopened.execute(
      .init(
        operationId: restorationIdentifier, session: reopenedSession,
        command: .restoreAssociation(snapshot: snapshot)))
    guard case .applied(let replayed, .complete(let replayCheckpoint)) = restorationReplay.outcome
    else { throw CancellationError() }
    #expect(replayed == restored && replayCheckpoint == checkpoint)
    let consumed = await fixture.planner.execute(
      .init(
        operationId: UUID(), session: fixture.session,
        command: .restoreAssociation(snapshot: snapshot)))
    guard case .rejected(let consumedFailure) = consumed.outcome else {
      throw CancellationError()
    }
    #expect(consumedFailure.code == "associationUndoUnavailable")
    #expect(try await fixture.export() == beforeReplay)
  }

  @Test func newerMembershipRejectsOldUndoWithoutReplacingLocalState() async throws {
    let fixture = try await AssociationUndoFixture()
    defer { try? FileManager.default.removeItem(at: fixture.directory) }
    let removal = await fixture.remove()
    let snapshot = try #require(removal.associationUndoSnapshot)
    let replacement = try await fixture.save(
      .addMembership(itemId: fixture.item.id, listId: fixture.list.id, placement: .last))
    guard case .membership(let replacementIdentifier, _, _)? = replacement.generatedReferences.first
    else { throw CancellationError() }
    let before = try await fixture.export()
    let response = await fixture.planner.execute(
      .init(
        operationId: UUID(), session: fixture.session,
        command: .restoreAssociation(snapshot: snapshot)))
    guard case .rejected(let failure) = response.outcome,
      case .appearance(let retained) = await fixture.planner.read(
        session: fixture.session,
        request: .appearance(
          .listMembership(listId: fixture.list.id, membershipId: replacementIdentifier)))
    else { throw CancellationError() }
    #expect(failure.code == "associationUndoUnavailable")
    #expect(response.associationUndoSnapshot == nil)
    #expect(replacementIdentifier != fixture.membershipIdentifier)
    #expect(!retained.localDone && !retained.effectiveDone)
    #expect(try await fixture.export() == before)
  }
}

struct AssociationUndoFixture {
  let directory: URL
  let configuration: PlannerStorageConfiguration
  let planner: Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let list: PlannerEntityReference
  let membershipIdentifier: UUID
  let removalIdentifier = UUID()

  init() async throws {
    directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    configuration = .init(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    planner = Planner(configuration: configuration)
    guard case .ready(let ready) = await planner.bootstrap() else { throw CancellationError() }
    session = ready
    guard
      case .applied(let itemCreation, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: ready,
          command: .createItem(content: .init(title: "Museum", notes: "Original notes")))
      ).outcome,
      let createdItem = itemCreation.generated.first,
      case .applied(let listCreation, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: ready,
          command: .createList(content: .init(name: "Tokyo")))
      ).outcome,
      let createdList = listCreation.generated.first,
      case .applied(let membershipCreation, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: ready,
          command: .addMembership(
            itemId: createdItem.id, listId: createdList.id, placement: .last))
      ).outcome,
      case .membership(let identifier, _, _)? = membershipCreation.generatedReferences.first,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: ready,
          command: .setCompletion(
            scope: .appearance(
              .listMembership(listId: createdList.id, membershipId: identifier)), done: true))
      ).outcome
    else { throw CancellationError() }
    item = createdItem
    list = createdList
    membershipIdentifier = identifier
  }

  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }

  func remove() async -> PlannerOperationResult {
    await planner.execute(
      .init(operationId: removalIdentifier, session: session, command: removalCommand))
  }

  var removalCommand: PlannerCommand {
    .removeMembership(listId: list.id, membershipId: membershipIdentifier)
  }

  func export() async throws -> Data {
    guard case .exported(let data) = await planner.exportData(session: session) else {
      throw CancellationError()
    }
    return data
  }
}
