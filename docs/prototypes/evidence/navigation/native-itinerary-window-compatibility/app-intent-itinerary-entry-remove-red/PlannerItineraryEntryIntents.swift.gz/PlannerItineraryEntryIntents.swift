#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  enum PlannerItineraryEntryKind: String, AppEnum, CaseIterable {
    case item, list
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Itinerary entry type")
    static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
      .item: .init(title: "Item"), .list: .init(title: "List"),
    ]
  }

  struct PlannerItineraryEntryEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Itinerary Entry")
    static var defaultQuery: PlannerItineraryEntryEntityQuery { PlannerItineraryEntryEntityQuery() }
    let id: String
    @Property(title: "Title") var title: String
    @Property(title: "Context") var context: String
    @Property(title: "Type") var kind: PlannerItineraryEntryKind
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation {
      DisplayRepresentation(title: "\(title)", subtitle: "\(context)")
    }

    init(
      id: String, title: String, context: String, kind: PlannerItineraryEntryKind, archived: Bool
    ) {
      self.id = id
      self.title = title
      self.context = context
      self.kind = kind
      self.archived = archived
    }
  }

  struct PlannerItineraryEntryEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore
    @IntentParameterDependency<RemovePlannerItineraryEntryIntent>(\.$itinerary) var removalIntent

    @MainActor func entities(for identifiers: [String]) async throws
      -> [PlannerItineraryEntryEntity]
    {
      throw PlannerItineraryEntryIntentFailure(
        message: "Itinerary entry lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerItineraryEntryEntity]
    {
      throw PlannerItineraryEntryIntentFailure(
        message: "Itinerary entry search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerItineraryEntryEntity] {
      throw PlannerItineraryEntryIntentFailure(
        message: "Itinerary entry suggestions are not implemented.")
    }
  }

  struct RemovePlannerItineraryEntryIntent: AppIntent {
    static let title: LocalizedStringResource = "Remove Entry from Itinerary"
    static let description = IntentDescription(
      "Remove one route stop while retaining its shared Item or List and all other stops.")
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Itinerary") var itinerary: PlannerItineraryEntity
    @Parameter(title: "Entry", query: PlannerItineraryEntryEntityQuery())
    var entry: PlannerItineraryEntryEntity
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<Never, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerItineraryEntryIntentFailure(
        message: "Itinerary entry removal is not implemented.")
    }
  }

  private struct PlannerItineraryEntryIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
