import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerItemDestinationIntentTests: XCTestCase {
  func testCreationAppendsOneTodoAppearanceToTheSelectedListAfterReopen() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let listCreation = CreatePlannerListIntent()
    listCreation.name = "Tokyo"
    let destination = try await listCreation.callAsFunction(donate: false)
    let other = try await listCreation.callAsFunction(donate: false)
    let creation = CreatePlannerItemIntent()
    creation.title = "Existing museum"
    let existing = try await creation.callAsFunction(donate: false)
    let adding = AddPlannerItemToListIntent()
    adding.item = existing
    adding.list = destination
    let _: Void = try await adding.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.list(let before)) = await planner.read(
        session: session, request: .source(.init(kind: .list, id: destination.id))),
      case .membership(let existingMembership, _, _)? = before.references.first
    else { return XCTFail("The destination must contain the original saved appearance.") }
    let existingAppearance = PlannerAppearance.listMembership(
      listId: destination.id, membershipId: existingMembership)
    guard
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setCompletion(scope: .appearance(existingAppearance), done: true))
      ).outcome
    else { return XCTFail("The existing appearance must have its independent Done state.") }
    creation.title = "New museum"
    creation.subtitle = "  Réservation · 金曜日  "
    creation.notes = "Tickets booked\nKeep the original text"
    creation.list = .init(id: destination.id, name: "Obsolete cached name", archived: true)
    let item = try await creation.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(.init(kind: .item, id: item.id))),
      case .source(.list(let populated)) = await reopened.read(
        session: reopenedSession, request: .source(.init(kind: .list, id: destination.id))),
      case .source(.list(let untouched)) = await reopened.read(
        session: reopenedSession, request: .source(.init(kind: .list, id: other.id))),
      case .membership(let membership, let owner, let source)? = saved.references.first,
      case .appearance(let appearance) = await reopened.read(
        session: reopenedSession,
        request: .appearance(.listMembership(listId: destination.id, membershipId: membership))),
      case .appearance(let retained) = await reopened.read(
        session: reopenedSession, request: .appearance(existingAppearance)),
      case .snapshot(let ordered) = await reopened.query(
        .init(
          session: reopenedSession,
          request: .items(
            .init(
              scope: .list(destination.id), completion: .all, archive: .all,
              sort: .init(mode: .manual)))))
    else { return XCTFail("Creation must save the Item and its List appearance together.") }
    XCTAssertEqual(saved.content.title, "New museum")
    XCTAssertEqual(saved.content.subtitle, "  Réservation · 金曜日  ")
    XCTAssertEqual(saved.content.notes, "Tickets booked\nKeep the original text")
    XCTAssertEqual(owner, .init(kind: .list, id: destination.id))
    XCTAssertEqual(source, saved.source)
    XCTAssertEqual(saved.references.count, 1)
    XCTAssertEqual(populated.references.count, 2)
    XCTAssertEqual(populated.content.name, "Tokyo")
    XCTAssertTrue(untouched.references.isEmpty)
    XCTAssertFalse(appearance.globalDone)
    XCTAssertFalse(appearance.localDone)
    XCTAssertFalse(appearance.effectiveDone)
    XCTAssertTrue(retained.localDone)
    XCTAssertEqual(
      ordered.rows,
      [
        .appearance(source: .init(kind: .item, id: existing.id), appearance: existingAppearance),
        .appearance(
          source: saved.source,
          appearance: .listMembership(listId: destination.id, membershipId: membership)),
      ])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
