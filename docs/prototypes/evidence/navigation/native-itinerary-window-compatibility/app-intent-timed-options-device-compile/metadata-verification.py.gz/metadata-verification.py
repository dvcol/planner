from pathlib import Path
import gzip, hashlib, json, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={
'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),
'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),
'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
baseline_phase='app-intent-estimate-setting-final' if platform=='mac' else 'app-intent-estimate-setting-'+platform+'-compile'
baseline=json.loads(gzip.decompress((root/baseline_phase/'extract.actionsdata.gz').read_bytes()))
raw=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes()
current=json.loads(raw)
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
expected=json.loads(json.dumps(baseline))
field=expected['actions']['SetPlannerScheduleTimeZoneIntent']['parameters'][0]
field['capabilities']=8
field['dynamicOptionsSupport']=1
assert field.pop('queryIdentifier')=='Planner.PlannerScheduleEntityQuery'
for section in ['actions','entities','queries','enums','autoShortcuts']:
    assert normalize(current[section])==normalize(expected[section]),section
(root/phase/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(root/phase/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
report={'platform':platform,'actions':len(current['actions']),'entities':len(current['entities']),'queries':len(current['queries']),'onlyContractChange':'SetPlannerScheduleTimeZoneIntent.schedule uses native dynamic options instead of its explicit general query binding','scheduleEntityTypeAndRequirednessUnchanged':True,'defaultScheduleQueryPreserved':True,'comparisonNormalization':'resolvableInputTypes alternatives only','metadataSha256':hashlib.sha256(raw).hexdigest(),'systemPickerCredit':False}
(root/phase/'metadata-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(platform, report['onlyContractChange'])
