import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerListIntentTests: XCTestCase {
  func testCreateListIntentReturnsTheSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    creation.notes = "Keep these places together"
    let list = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(list.name, "Tokyo Food")
    XCTAssertFalse(list.archived)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.list(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .list, id: list.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .list, archive: .all))))
    else { return XCTFail("The returned List must remain readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, list.id)
    XCTAssertEqual(current.content.name, "Tokyo Food")
    XCTAssertEqual(current.content.notes, "Keep these places together")
    XCTAssertEqual(current.state.archived, false)
    XCTAssertEqual(current.progress.state, .empty)
    XCTAssertEqual(current.progress.totalCount, 0)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .list, id: list.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerListIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
