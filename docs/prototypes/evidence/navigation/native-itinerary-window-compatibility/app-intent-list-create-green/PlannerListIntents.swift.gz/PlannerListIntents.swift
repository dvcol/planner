#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerListEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "List")
    static var defaultQuery: PlannerListEntityQuery { PlannerListEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String, archived: Bool) {
      self.id = id
      self.name = name
      self.archived = archived
    }
  }

  struct PlannerListEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List resolution is not implemented yet.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List search is not implemented yet.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerListEntity] {
      throw PlannerListIntentFailure(message: "List choices are not implemented yet.")
    }
  }

  struct CreatePlannerListIntent: AppIntent {
    static let title: LocalizedStringResource = "Create List"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Parameter(title: "Notes") var notes: String?
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerListEntity, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(
        .createList(content: .init(name: name, notes: notes)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerListIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerListIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .list }) else {
          throw PlannerListIntentFailure(
            message:
              "Planner applied this change without returning its List. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(name)."
        case .incomplete:
          dialog =
            "The List was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(
          value: PlannerListEntity(id: source.id, name: name, archived: false), dialog: dialog)
      }
    }
  }

  private struct PlannerListIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
