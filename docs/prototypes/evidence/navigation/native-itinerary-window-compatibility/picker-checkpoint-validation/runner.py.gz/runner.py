from pathlib import Path
import gzip, hashlib, json, os, re, subprocess
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
packet = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
validation = packet / 'picker-checkpoint-validation'
validation.mkdir(exist_ok=False)
(validation / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
source_paths = [
 'Planner/Scenes/SavedContainerWindowRows.swift', 'Planner/Scenes/SavedAddToListForm.swift',
 'Planner/Scenes/SavedMoveItemForm.swift', 'Planner/Scenes/SavedCaptureForm.swift',
 'Planner/Scenes/SavedItemFilters.swift', 'Planner/Scenes/SavedItineraryContentViews.swift',
 'Planner/Scenes/SavedPlannerStore.swift', 'Planner/Scenes/SavedPlannerView.swift',
 'Planner/Scenes/SavedItineraryViews.swift', 'Planner/Scenes/SavedBackupImportForm.swift',
 'PlannerFixtureUITests/ContainerCatalogSortJourneyTests.swift',
 'PlannerNavigationUITests/NativeNavigationElements.swift',
 'PlannerNavigationUITests/SavedListCaptureJourneyTests.swift']
document_paths = [
 'docs/native-container-window-contract-review.md', 'docs/native-association-undo-contract-review.md',
 'docs/prototypes/native-itinerary-window-compatibility.md',
 'docs/prototypes/native-container-catalog-windows.md', 'docs/offline-conflicts-and-recovery.md']
source_hashes = {path: hashlib.sha256((repository / path).read_bytes()).hexdigest() for path in source_paths + document_paths}
(validation / 'source-sha256.json').write_text(json.dumps(source_hashes, indent=2)+'\n')
commands = [
 ('swift-lint', ['xcrun','swift-format','lint','--strict',*source_paths]),
 ('markdown-lint', ['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json',*document_paths]),
 ('diff-check', ['git','diff','--check'])]
for name, command in commands:
 result = subprocess.run(command, cwd=repository, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), capture_output=True)
 (validation / (name+'.json')).write_text(json.dumps({'command':command,'exitCode':result.returncode},indent=2)+'\n')
 (validation / (name+'.log.gz')).write_bytes(gzip.compress(result.stdout+result.stderr,mtime=0))
 print(name, 'exit', result.returncode)
 assert result.returncode == 0
assert source_hashes == {path:hashlib.sha256((repository/path).read_bytes()).hexdigest() for path in source_hashes}
executions = [{'epoch':str(path.parent.relative_to(packet)), **json.loads(path.read_text())} for path in sorted(packet.glob('*/exit.json'))]
(packet / 'execution-index.json').write_text(json.dumps(executions,indent=2)+'\n')
credential_pattern = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})')
paths = [path for path in sorted(packet.rglob('*')) if path.is_file() and path.name != 'packet-sha256.json']
for path in paths:
 content = path.read_bytes()
 if path.suffix == '.gz': content = gzip.decompress(content)
 assert not credential_pattern.search(content), 'Credential-like value in '+str(path.relative_to(packet))
(packet / 'packet-sha256.json').write_text(json.dumps({str(path.relative_to(packet)):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}, indent=2)+'\n')
print('Indexed and credential-scanned',len(paths),'packet files')
