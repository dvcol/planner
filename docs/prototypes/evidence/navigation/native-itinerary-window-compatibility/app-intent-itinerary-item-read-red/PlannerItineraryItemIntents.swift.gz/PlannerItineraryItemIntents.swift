#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerItineraryItemEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Itinerary Item")
    static var defaultQuery: PlannerItineraryItemEntityQuery { PlannerItineraryItemEntityQuery() }
    let id: String
    @Property(title: "Title") var title: String
    @Property(title: "Context") var context: String
    @Property(title: "Globally completed") var globallyDone: Bool
    @Property(title: "Completed here") var locallyDone: Bool
    @Property(title: "Completed") var done: Bool
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation {
      DisplayRepresentation(title: "\(title)", subtitle: "\(context)")
    }

    init(
      id: String, title: String, context: String, globallyDone: Bool, locallyDone: Bool,
      done: Bool, archived: Bool
    ) {
      self.id = id
      self.title = title
      self.context = context
      self.globallyDone = globallyDone
      self.locallyDone = locallyDone
      self.done = done
      self.archived = archived
    }
  }

  struct PlannerItineraryItemEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore
    @IntentParameterDependency<GetPlannerItineraryItemIntent>(\.$itinerary) var getIntent

    @MainActor func entities(for identifiers: [String]) async throws -> [PlannerItineraryItemEntity]
    {
      throw PlannerItineraryItemIntentFailure(message: "Itinerary Item lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerItineraryItemEntity] {
      throw PlannerItineraryItemIntentFailure(message: "Itinerary Item search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerItineraryItemEntity] {
      throw PlannerItineraryItemIntentFailure(
        message: "Itinerary Item suggestions are not implemented.")
    }
  }

  struct GetPlannerItineraryItemIntent: AppIntent {
    static let title: LocalizedStringResource = "Get Item in Itinerary"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Itinerary") var itinerary: PlannerItineraryEntity
    @Parameter(title: "Item in Itinerary", query: PlannerItineraryItemEntityQuery())
    var item: PlannerItineraryItemEntity
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerItineraryItemEntity, Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerItineraryItemIntentFailure(message: "Get Item in Itinerary is not implemented.")
    }
  }

  private struct PlannerItineraryItemIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
