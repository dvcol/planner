from pathlib import Path
import gzip,hashlib,json,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
baseline_phase='app-intent-deferred-content-final' if platform=='mac' else 'app-intent-deferred-content-'+platform+'-compile'
baseline=json.loads(gzip.decompress((root/baseline_phase/'extract.actionsdata.gz').read_bytes()))
raw=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes();current=json.loads(raw)
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
for section in ['entities','queries','enums','autoShortcuts']:
    assert normalize(current[section])==normalize(baseline[section]),section
for name,action in baseline['actions'].items():assert normalize(current['actions'][name])==normalize(action),name
expected={
'SetPlannerListChildCompletionIntent':[('list','PlannerListEntity'),('completed','boolean')],
'SetPlannerItineraryChildCompletionIntent':[('itinerary','PlannerItineraryEntity'),('completed','boolean')],
'SetPlannerItineraryListChildCompletionIntent':[('itinerary','PlannerItineraryEntity'),('entry','PlannerItineraryEntryEntity'),('completed','boolean')]}
assert set(current['actions'])-set(baseline['actions'])==set(expected)
assert len(current['actions'])==75
for name,fields in expected.items():
    action=current['actions'][name]
    assert action['allowedTargets']==[{'type':1}] and action['supportedModes']==1 and action['authenticationPolicy']==0,name
    assert [field['name'] for field in action['parameters']]==[field[0] for field in fields],name
    for parameter,(_,kind) in zip(action['parameters'],fields):
        assert not parameter['isOptional'] and 'defaultValue' not in parameter,parameter
        if kind=='boolean':assert parameter['valueType']=={'primitive':{'wrapper':{'typeIdentifier':1}}}
        else:assert parameter['valueType']=={'entity':{'wrapper':{'typeName':kind}}}
        if parameter['name']=='entry':assert parameter['queryIdentifier']=='Planner.PlannerItineraryEntryEntityQuery'
packet=root/phase
(packet/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(packet/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(packet/'metadata-verification.json').write_text(json.dumps({'platform':platform,'addedActions':expected,'actionCount':75,'previous72ActionsAndAllEntitiesQueriesEnumsAndFourShortcutsPreserved':True,'comparisonNormalization':'resolvableInputTypes alternatives only','metadataSha256':hashlib.sha256(raw).hexdigest(),'actualSystemConfirmationAndPickerCredit':False},indent=2)+'\n')
print(platform,'three typed bulk actions; all previous native contracts retained')
