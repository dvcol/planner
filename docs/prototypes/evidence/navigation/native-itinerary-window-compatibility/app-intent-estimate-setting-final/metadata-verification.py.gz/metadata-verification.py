from pathlib import Path
import gzip, hashlib, json, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase=sys.argv[1]
platform=sys.argv[2]
roots={
'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),
'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),
'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/phase
raw=(roots[platform]/'Metadata.appintents/extract.actionsdata').read_bytes()
current=json.loads(raw)
baseline_path=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/('app-intent-container-find-final-clean' if platform=='mac' else 'app-intent-container-find-'+platform+'-compile')/'extract.actionsdata.gz'
baseline=json.loads(gzip.decompress(baseline_path.read_bytes()))
new_names={'SetPlannerItemEstimateIntent','SetPlannerListEstimateIntent','SetPlannerItineraryEstimateIntent'}
assert set(current['actions'])==set(baseline['actions'])|new_names
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
for name, action in baseline['actions'].items():
    assert normalize(current['actions'][name])==normalize(action), name
assert current['entities']==baseline['entities']
assert current['queries']==baseline['queries']
old_enums={value['identifier']:value for value in baseline['enums']}
new_enums={value['identifier']:value for value in current['enums']}
assert set(new_enums)==set(old_enums)|{'PlannerEstimateUnitChoice'}
for name,value in old_enums.items(): assert new_enums[name]==value,name
assert [value['identifier'] for value in new_enums['PlannerEstimateUnitChoice']['cases']]==['minute','hour','day','week','month','year']
for name, owner in [('SetPlannerItemEstimateIntent','item'),('SetPlannerListEstimateIntent','list'),('SetPlannerItineraryEstimateIntent','itinerary')]:
    action=current['actions'][name]
    fields=action['parameters']
    assert [value['name'] for value in fields]==[owner,'quantity','unit','additionalMinutes']
    assert all(not value['isOptional'] for value in fields)
    assert fields[1]['valueType']=={'primitive':{'wrapper':{'typeIdentifier':2}}}
    assert fields[3]['valueType']==fields[1]['valueType']
    assert fields[2]['valueType']=={'linkEnumeration':{'wrapper':{'identifier':'PlannerEstimateUnitChoice'}}}
    assert fields[2]['typeSpecificMetadata']==['LNValueTypeSpecificMetadataKeyDefaultValue',{'string':{'wrapper':'minute'}}]
    assert fields[3]['typeSpecificMetadata']==['LNValueTypeSpecificMetadataKeyDefaultValue',{'int':{'wrapper':0}}]
    assert action['authenticationPolicy']==0 and action['supportedModes']==1
(packet/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(packet/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
report={'platform':platform,'metadataSha256':hashlib.sha256(raw).hexdigest(),'baseline':str(baseline_path.relative_to(repository)),'retainedActions':len(baseline['actions']),'addedActions':sorted(new_names),'retainedEntities':len(current['entities']),'retainedQueries':len(current['queries']),'retainedEnums':len(old_enums),'units':['minute','hour','day','week','month','year'],'allPriorContractsEqual':True,'comparisonNormalization':'Only resolvableInputTypes alternatives are treated as an unordered set; parameter and enum case order remain exact','requiredFields':[ 'owner','quantity','unit','additionalMinutes'],'quantityAndAdditionalMinutesType':'native Int','defaultUnit':'minute','defaultAdditionalMinutes':0,'systemInvocationCredit':False}
(packet/'metadata-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(platform, '72 actions; 69 previous action contracts, entities, queries and enums preserved')
