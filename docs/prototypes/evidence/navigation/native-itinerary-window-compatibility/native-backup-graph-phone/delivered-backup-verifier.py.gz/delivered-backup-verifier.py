from pathlib import Path
import gzip
import hashlib
import json
import sys


def typed_value(value):
    """Keep booleans distinct from numbers and preserve nested sequence order."""
    if value is None:
        return ("null",)
    if isinstance(value, bool):
        return ("boolean", value)
    if isinstance(value, (int, float)):
        return ("number", *value.as_integer_ratio())
    if isinstance(value, str):
        return ("string", value)
    if isinstance(value, list):
        return ("array", tuple(typed_value(element) for element in value))
    assert isinstance(value, dict)
    return ("object", tuple(sorted((key, typed_value(element)) for key, element in value.items())))


repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
assert platform in ['phone', 'tablet']
root = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = root / phase
attachments = json.loads((packet / 'selected-attachments.json').read_text())['attachments']
filenames = [entry for entry in attachments if entry['suggestedHumanReadableName'].startswith('Full graph delivered backup filename')]
assert len(filenames) == 1
filename = gzip.decompress((packet / filenames[0]['retainedFileName']).read_bytes()).decode().strip()
assert Path(filename).name == filename and filename.endswith('.json')
provenance = json.loads((root / 'native-backup-graph-inputs/fixture-provenance.json').read_text())
delivered = Path(provenance['destinations'][platform]).parent / filename
assert delivered.is_file(), delivered
summary = json.loads((packet / 'test-results-summary.json').read_text())
assert delivered.stat().st_mtime >= summary['startTime'] - 2
actual_data = delivered.read_bytes()
actual = json.loads(actual_data)
expected = json.loads((repository / provenance['source']).read_bytes())
assert expected['formatVersion'] == 1
expected['formatVersion'] = 2
for source in expected['sources']:
    if source['kind'] in ['list', 'itinerary']:
        source['content']['manualEstimate'] = None
assert set(actual) == set(expected)
differences = []
for key, expected_value in expected.items():
    actual_value = actual[key]
    if isinstance(expected_value, list):
        expected_signature = sorted((typed_value(record) for record in expected_value), key=repr)
        actual_signature = sorted((typed_value(record) for record in actual_value), key=repr)
    else:
        expected_signature = typed_value(expected_value)
        actual_signature = typed_value(actual_value)
    if actual_signature != expected_signature:
        differences.append(key)
assert not differences, differences
(packet / 'delivered-backup.json.gz').write_bytes(gzip.compress(actual_data, mtime=0))
result = {
    'path': str(delivered),
    'bytes': len(actual_data),
    'sha256': hashlib.sha256(actual_data).hexdigest(),
    'modifiedAfterTestStarted': True,
    'sourceFixture': provenance['source'],
    'sourceFixtureSha256': provenance['sha256'],
    'allowedMigration': 'formatVersion 1 to 2, adding null manualEstimate to List/Itinerary content',
    'comparison': 'Every typed field in every complete record table; top-level table order ignored, ranks and nested sequence order exact',
    'recordCounts': {key: len(value) for key, value in actual.items() if isinstance(value, list)},
    'differences': differences,
    'uiInvocationPassed': summary['failedTests'] == 0 and summary['passedTests'] > 0,
}
(packet / 'delivered-backup-verification.json').write_text(json.dumps(result, indent=2) + '\n')
(packet / 'delivered-backup-verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps(result, indent=2))
