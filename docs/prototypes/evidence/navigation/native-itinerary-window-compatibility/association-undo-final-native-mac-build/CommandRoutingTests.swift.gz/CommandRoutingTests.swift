import Foundation
import PlannerCore
import Testing

@testable import Planner

struct CommandRoutingTests {
  @Test func categoryFieldGuardsOverHTTPKeepConflictsAtomicAndReplayOriginalReceipts() async throws
  {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let datasetSession) = await planner.bootstrap(),
      case .applied(let created, .complete) = await planner.execute(
        PlannerOperation(
          operationId: UUID(), session: datasetSession,
          command: .createCategory(
            content: PlannerCategoryContentInput(
              name: "Food", color: PlannerColor(red: 0, green: 0, blue: 1, alpha: 1),
              iconName: "fork.knife")))
      ).outcome,
      let category = created.generated.first
    else {
      Issue.record("A durable Category must exist before its HTTP edit journey.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    var readRequest = try executionRequest(
      endpoint: endpoint, operationIdentifier: UUID(), command: [:])
    readRequest.httpBody = try JSONSerialization.data(withJSONObject: [
      "jsonrpc": "2.0", "id": 2, "method": "tools/call",
      "params": [
        "name": "planner_read",
        "arguments": [
          "formatVersion": 1,
          "request": [
            "kind": "source", "source": ["kind": "category", "id": category.id.uuidString],
          ],
        ],
      ],
    ])
    do {
      let original = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      let originalValue = try #require(original["value"] as? [String: Any])
      let originalHashes = try #require(originalValue["fieldHashes"] as? [String: String])
      let renameRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: [
          "type": "editCategory", "sourceId": category.id.uuidString,
          "changes": ["name": " Dining "], "expectedFieldHashes": originalHashes,
        ])
      let renamed = try operationValue(
        try await httpSession.data(for: renameRequest), isError: false)
      try #require(renamed["state"] as? String == "applied")
      #expect((renamed["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "2")
      let iconCleared = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editCategory", "sourceId": category.id.uuidString,
              "changes": ["iconName": NSNull()], "expectedFieldHashes": originalHashes,
            ])), isError: false)
      #expect(iconCleared["state"] as? String == "applied")
      #expect(
        (iconCleared["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "3")
      let beforeConflict = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      let beforeValue = try #require(beforeConflict["value"] as? [String: Any])
      let beforeHashes = try #require(beforeValue["fieldHashes"] as? [String: String])
      let stale = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editCategory", "sourceId": category.id.uuidString,
              "changes": [
                "name": "Must not save", "color": ["red": 1, "green": 0, "blue": 0, "alpha": 1],
              ], "expectedFieldHashes": originalHashes,
            ])), isError: true)
      #expect(stale["state"] as? String == "rejected")
      let reason = try #require(stale["reason"] as? [String: Any])
      #expect(reason["code"] as? String == "staleEdit")
      let details = try #require(reason["details"] as? [String: Any])
      #expect(details["kind"] as? String == "staleEdit")
      #expect(details["conflictingFields"] as? [String] == ["name"])
      #expect(details["currentValues"] as? [String: String] == ["name": " Dining "])
      let currentNameHash = try #require(beforeHashes["name"])
      #expect(details["currentFieldHashes"] as? [String: String] == ["name": currentNameHash])
      let afterConflict = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      #expect(NSDictionary(dictionary: afterConflict).isEqual(to: beforeConflict))
      let colorCleared = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editCategory", "sourceId": category.id.uuidString,
              "changes": ["color": NSNull()], "expectedFieldHashes": originalHashes,
            ])), isError: false)
      #expect(colorCleared["state"] as? String == "applied")
      #expect(
        (colorCleared["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "4")
      let staleNull = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editCategory", "sourceId": category.id.uuidString,
              "changes": ["color": ["red": 0, "green": 0, "blue": 1, "alpha": 1]],
              "expectedFieldHashes": originalHashes,
            ])), isError: true)
      let nullReason = try #require(staleNull["reason"] as? [String: Any])
      #expect(nullReason["code"] as? String == "staleEdit")
      let nullDetails = try #require(nullReason["details"] as? [String: Any])
      #expect(nullDetails["conflictingFields"] as? [String] == ["color"])
      #expect((nullDetails["currentValues"] as? [String: Any])?["color"] is NSNull)
      let replayed = try operationValue(
        try await httpSession.data(for: renameRequest), isError: false)
      #expect(NSDictionary(dictionary: replayed).isEqual(to: renamed))
      let latest = try operationValue(try await httpSession.data(for: readRequest), isError: false)
      let latestValue = try #require(latest["value"] as? [String: Any])
      let latestContent = try #require(latestValue["content"] as? [String: Any])
      #expect(latestContent["name"] as? String == " Dining ")
      #expect(latestContent["color"] is NSNull)
      #expect(latestContent["iconName"] is NSNull)
      #expect(latestValue["createdAt"] as? Double == originalValue["createdAt"] as? Double)
      let reopened = PlannerCore.Planner(configuration: configuration)
      guard case .ready(let reopenedSession) = await reopened.bootstrap(),
        case .source(.category(let saved)) = await reopened.read(
          session: reopenedSession, request: .source(category))
      else {
        Issue.record("HTTP Category edits must remain readable after reopening.")
        await listener.stop()
        return
      }
      #expect(saved.content.name == " Dining ")
      #expect(saved.content.color == nil)
      #expect(saved.content.iconName == nil)
      #expect(saved.updatedAt.timeIntervalSinceReferenceDate == latestValue["updatedAt"] as? Double)
      #expect(
        latestValue["fieldHashes"] as? [String: String]
          == Dictionary(
            uniqueKeysWithValues: saved.fieldHashes.map { ($0.key.rawValue, $0.value.value) }))
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func tagFieldGuardsOverHTTPKeepConflictsAtomicAndReplayOriginalReceipts() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let datasetSession) = await planner.bootstrap(),
      case .applied(let created, .complete) = await planner.execute(
        PlannerOperation(
          operationId: UUID(), session: datasetSession,
          command: .createTag(
            content: PlannerTagContentInput(
              name: "Food", color: PlannerColor(red: 0, green: 0, blue: 1, alpha: 1),
              iconName: "fork.knife")))
      ).outcome,
      let tag = created.generated.first
    else {
      Issue.record("A durable Tag must exist before its HTTP edit journey.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    var readRequest = try executionRequest(
      endpoint: endpoint, operationIdentifier: UUID(), command: [:])
    readRequest.httpBody = try JSONSerialization.data(withJSONObject: [
      "jsonrpc": "2.0", "id": 2, "method": "tools/call",
      "params": [
        "name": "planner_read",
        "arguments": [
          "formatVersion": 1,
          "request": [
            "kind": "source", "source": ["kind": "tag", "id": tag.id.uuidString],
          ],
        ],
      ],
    ])
    do {
      let original = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      let originalValue = try #require(original["value"] as? [String: Any])
      let originalHashes = try #require(originalValue["fieldHashes"] as? [String: String])
      let renameRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: [
          "type": "editTag", "sourceId": tag.id.uuidString,
          "changes": ["name": " Dining "], "expectedFieldHashes": originalHashes,
        ])
      let renamed = try operationValue(
        try await httpSession.data(for: renameRequest), isError: false)
      try #require(renamed["state"] as? String == "applied")
      #expect((renamed["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "2")
      let iconCleared = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editTag", "sourceId": tag.id.uuidString,
              "changes": ["iconName": NSNull()], "expectedFieldHashes": originalHashes,
            ])), isError: false)
      #expect(iconCleared["state"] as? String == "applied")
      #expect(
        (iconCleared["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "3")
      let beforeConflict = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      let beforeValue = try #require(beforeConflict["value"] as? [String: Any])
      let beforeHashes = try #require(beforeValue["fieldHashes"] as? [String: String])
      let stale = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editTag", "sourceId": tag.id.uuidString,
              "changes": [
                "name": "Must not save", "color": ["red": 1, "green": 0, "blue": 0, "alpha": 1],
              ], "expectedFieldHashes": originalHashes,
            ])), isError: true)
      #expect(stale["state"] as? String == "rejected")
      let reason = try #require(stale["reason"] as? [String: Any])
      #expect(reason["code"] as? String == "staleEdit")
      let details = try #require(reason["details"] as? [String: Any])
      #expect(details["kind"] as? String == "staleEdit")
      #expect(details["conflictingFields"] as? [String] == ["name"])
      #expect(details["currentValues"] as? [String: String] == ["name": " Dining "])
      let currentNameHash = try #require(beforeHashes["name"])
      #expect(details["currentFieldHashes"] as? [String: String] == ["name": currentNameHash])
      let afterConflict = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      #expect(NSDictionary(dictionary: afterConflict).isEqual(to: beforeConflict))
      let colorCleared = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editTag", "sourceId": tag.id.uuidString,
              "changes": ["color": NSNull()], "expectedFieldHashes": originalHashes,
            ])), isError: false)
      #expect(colorCleared["state"] as? String == "applied")
      #expect(
        (colorCleared["recovery"] as? [String: Any])?["checkpointGeneration"] as? String == "4")
      let staleNull = try operationValue(
        try await httpSession.data(
          for: executionRequest(
            endpoint: endpoint, operationIdentifier: UUID(),
            command: [
              "type": "editTag", "sourceId": tag.id.uuidString,
              "changes": ["color": ["red": 0, "green": 0, "blue": 1, "alpha": 1]],
              "expectedFieldHashes": originalHashes,
            ])), isError: true)
      let nullReason = try #require(staleNull["reason"] as? [String: Any])
      #expect(nullReason["code"] as? String == "staleEdit")
      let nullDetails = try #require(nullReason["details"] as? [String: Any])
      #expect(nullDetails["conflictingFields"] as? [String] == ["color"])
      #expect((nullDetails["currentValues"] as? [String: Any])?["color"] is NSNull)
      let replayed = try operationValue(
        try await httpSession.data(for: renameRequest), isError: false)
      #expect(NSDictionary(dictionary: replayed).isEqual(to: renamed))
      let latest = try operationValue(try await httpSession.data(for: readRequest), isError: false)
      let latestValue = try #require(latest["value"] as? [String: Any])
      let latestContent = try #require(latestValue["content"] as? [String: Any])
      #expect(latestContent["name"] as? String == " Dining ")
      #expect(latestContent["color"] is NSNull)
      #expect(latestContent["iconName"] is NSNull)
      #expect(latestValue["createdAt"] as? Double == originalValue["createdAt"] as? Double)
      let reopened = PlannerCore.Planner(configuration: configuration)
      guard case .ready(let reopenedSession) = await reopened.bootstrap(),
        case .source(.tag(let saved)) = await reopened.read(
          session: reopenedSession, request: .source(tag))
      else {
        Issue.record("HTTP Tag edits must remain readable after reopening.")
        await listener.stop()
        return
      }
      #expect(saved.content.name == " Dining ")
      #expect(saved.content.color == nil)
      #expect(saved.content.iconName == nil)
      #expect(saved.updatedAt.timeIntervalSinceReferenceDate == latestValue["updatedAt"] as? Double)
      #expect(
        latestValue["fieldHashes"] as? [String: String]
          == Dictionary(
            uniqueKeysWithValues: saved.fieldHashes.map { ($0.key.rawValue, $0.value.value) }))
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func categoryEditAdvertisementAndInvalidPatchesPreserveSavedDataOverHTTP() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap(),
      case .applied(let created, .complete) = await planner.execute(
        PlannerOperation(
          operationId: UUID(), session: datasetSession,
          command: .createCategory(content: PlannerCategoryContentInput(name: "Food")))
      ).outcome,
      let category = created.generated.first,
      case .source(.category(let original)) = await planner.read(
        session: datasetSession, request: .source(category))
    else {
      Issue.record("A saved Category must exist before edit admission qualification.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let hashes = Dictionary(
      uniqueKeysWithValues: original.fieldHashes.map { ($0.key.rawValue, $0.value.value) })
    let valid: [String: Any] = [
      "type": "editCategory", "sourceId": category.id.uuidString,
      "changes": ["name": "Dining"], "expectedFieldHashes": hashes,
    ]
    do {
      var advertisementRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(), command: valid)
      advertisementRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 3, "method": "tools/list", "params": [:],
      ])
      let advertisement = try await httpSession.data(for: advertisementRequest)
      #expect((advertisement.1 as? HTTPURLResponse)?.statusCode == 200)
      let envelope = try #require(
        JSONSerialization.jsonObject(with: advertisement.0) as? [String: Any])
      let tools = try #require((envelope["result"] as? [String: Any])?["tools"] as? [[String: Any]])
      let executeTool = try #require(tools.first { $0["name"] as? String == "planner_execute" })
      let properties = try #require(
        (executeTool["inputSchema"] as? [String: Any])?["properties"] as? [String: Any])
      let variants = try #require(
        (properties["command"] as? [String: Any])?["oneOf"] as? [[String: Any]])
      let categoryVariant = try #require(
        variants.first { variant in
          let fields = variant["properties"] as? [String: Any]
          return (fields?["type"] as? [String: Any])?["const"] as? String == "editCategory"
        })
      #expect(categoryVariant["additionalProperties"] as? Bool == false)
      #expect(
        Set(categoryVariant["required"] as? [String] ?? []) == [
          "type", "sourceId", "changes", "expectedFieldHashes",
        ])
      let fields = try #require(categoryVariant["properties"] as? [String: Any])
      let changes = try #require(fields["changes"] as? [String: Any])
      #expect(changes["additionalProperties"] as? Bool == false)
      #expect(changes["minProperties"] as? Int == 1)
      #expect(
        Set(try #require(changes["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      let guards = try #require(fields["expectedFieldHashes"] as? [String: Any])
      #expect(guards["additionalProperties"] as? Bool == false)
      #expect(
        Set(try #require(guards["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      let invalidOverrides: [([String: Any], String, String)] = [
        (["sourceId": "invalid"], "invalidInput", "/command/sourceId"),
        (["changes": [:]], "invalidInput", "/command/changes"),
        (["changes": ["name": NSNull()]], "invalidInput", "/command/changes/name"),
        (["changes": ["name": " \n\t"]], "invalidInput", "/command/changes/name"),
        (["changes": ["notes": "Forbidden"]], "unknownField", "/command/changes/notes"),
        (["changes": ["color": "blue"]], "invalidInput", "/command/changes/color"),
        (
          ["changes": ["color": ["red": 2, "green": 0, "blue": 0, "alpha": 1]]],
          "invalidInput", "/command/changes/color/red"
        ),
        (["expectedFieldHashes": [:]], "invalidInput", "/command/expectedFieldHashes/name"),
        (["expectedFieldHashes": ["name": 1]], "invalidInput", "/command/expectedFieldHashes/name"),
        (
          ["expectedFieldHashes": ["name": "invalid"]], "invalidInput",
          "/command/expectedFieldHashes/name"
        ),
        (
          ["expectedFieldHashes": ["notes": "invalid"]], "unknownField",
          "/command/expectedFieldHashes/notes"
        ),
      ]
      for (overrides, code, propertyPath) in invalidOverrides {
        let operationIdentifier = UUID()
        let rejected = try operationValue(
          try await httpSession.data(
            for: executionRequest(
              endpoint: endpoint, operationIdentifier: operationIdentifier,
              command: valid.merging(overrides) { _, incoming in incoming })), isError: true)
        #expect(rejected["state"] as? String == "rejected")
        let reason = try #require(rejected["reason"] as? [String: Any])
        #expect(reason["code"] as? String == code)
        #expect(reason["propertyPath"] as? String == propertyPath)
        guard
          case .source(.category(let unchanged)) = await planner.read(
            session: datasetSession, request: .source(category)),
          case .noReliableEvidence = await planner.operationStatus(
            session: datasetSession, operationId: operationIdentifier)
        else {
          Issue.record("Invalid edits must retain the saved Category without applied evidence.")
          await listener.stop()
          return
        }
        #expect(unchanged.content == original.content)
        #expect(unchanged.sourceLifetimeId == original.sourceLifetimeId)
        #expect(unchanged.createdAt == original.createdAt)
        #expect(unchanged.updatedAt == original.updatedAt)
        #expect(unchanged.fieldHashes == original.fieldHashes)
      }
      guard
        case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces)
      else {
        Issue.record("Invalid requests must leave recovery readable.")
        await listener.stop()
        return
      }
      #expect(namespaces.first?.acknowledgedSnapshot?.checkpointGeneration == 1)
      #expect(namespaces.first?.preparedProposals.isEmpty == true)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func tagEditAdvertisementAndInvalidPatchesPreserveSavedDataOverHTTP() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap(),
      case .applied(let created, .complete) = await planner.execute(
        PlannerOperation(
          operationId: UUID(), session: datasetSession,
          command: .createTag(content: PlannerTagContentInput(name: "Food")))
      ).outcome,
      let tag = created.generated.first,
      case .source(.tag(let original)) = await planner.read(
        session: datasetSession, request: .source(tag))
    else {
      Issue.record("A saved Tag must exist before edit admission qualification.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let hashes = Dictionary(
      uniqueKeysWithValues: original.fieldHashes.map { ($0.key.rawValue, $0.value.value) })
    let valid: [String: Any] = [
      "type": "editTag", "sourceId": tag.id.uuidString,
      "changes": ["name": "Dining"], "expectedFieldHashes": hashes,
    ]
    do {
      var advertisementRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(), command: valid)
      advertisementRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 3, "method": "tools/list", "params": [:],
      ])
      let advertisement = try await httpSession.data(for: advertisementRequest)
      #expect((advertisement.1 as? HTTPURLResponse)?.statusCode == 200)
      let envelope = try #require(
        JSONSerialization.jsonObject(with: advertisement.0) as? [String: Any])
      let tools = try #require((envelope["result"] as? [String: Any])?["tools"] as? [[String: Any]])
      let executeTool = try #require(tools.first { $0["name"] as? String == "planner_execute" })
      let properties = try #require(
        (executeTool["inputSchema"] as? [String: Any])?["properties"] as? [String: Any])
      let variants = try #require(
        (properties["command"] as? [String: Any])?["oneOf"] as? [[String: Any]])
      let tagVariant = try #require(
        variants.first { variant in
          let fields = variant["properties"] as? [String: Any]
          return (fields?["type"] as? [String: Any])?["const"] as? String == "editTag"
        })
      #expect(tagVariant["additionalProperties"] as? Bool == false)
      #expect(
        Set(tagVariant["required"] as? [String] ?? []) == [
          "type", "sourceId", "changes", "expectedFieldHashes",
        ])
      let fields = try #require(tagVariant["properties"] as? [String: Any])
      let changes = try #require(fields["changes"] as? [String: Any])
      #expect(changes["additionalProperties"] as? Bool == false)
      #expect(changes["minProperties"] as? Int == 1)
      #expect(
        Set(try #require(changes["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      let guards = try #require(fields["expectedFieldHashes"] as? [String: Any])
      #expect(guards["additionalProperties"] as? Bool == false)
      #expect(
        Set(try #require(guards["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      let invalidOverrides: [([String: Any], String, String)] = [
        (["sourceId": "invalid"], "invalidInput", "/command/sourceId"),
        (["changes": [:]], "invalidInput", "/command/changes"),
        (["changes": ["name": NSNull()]], "invalidInput", "/command/changes/name"),
        (["changes": ["name": " \n\t"]], "invalidInput", "/command/changes/name"),
        (["changes": ["notes": "Forbidden"]], "unknownField", "/command/changes/notes"),
        (["changes": ["color": "blue"]], "invalidInput", "/command/changes/color"),
        (
          ["changes": ["color": ["red": 2, "green": 0, "blue": 0, "alpha": 1]]],
          "invalidInput", "/command/changes/color/red"
        ),
        (["expectedFieldHashes": [:]], "invalidInput", "/command/expectedFieldHashes/name"),
        (["expectedFieldHashes": ["name": 1]], "invalidInput", "/command/expectedFieldHashes/name"),
        (
          ["expectedFieldHashes": ["name": "invalid"]], "invalidInput",
          "/command/expectedFieldHashes/name"
        ),
        (
          ["expectedFieldHashes": ["notes": "invalid"]], "unknownField",
          "/command/expectedFieldHashes/notes"
        ),
      ]
      for (overrides, code, propertyPath) in invalidOverrides {
        let operationIdentifier = UUID()
        let rejected = try operationValue(
          try await httpSession.data(
            for: executionRequest(
              endpoint: endpoint, operationIdentifier: operationIdentifier,
              command: valid.merging(overrides) { _, incoming in incoming })), isError: true)
        #expect(rejected["state"] as? String == "rejected")
        let reason = try #require(rejected["reason"] as? [String: Any])
        #expect(reason["code"] as? String == code)
        #expect(reason["propertyPath"] as? String == propertyPath)
        guard
          case .source(.tag(let unchanged)) = await planner.read(
            session: datasetSession, request: .source(tag)),
          case .noReliableEvidence = await planner.operationStatus(
            session: datasetSession, operationId: operationIdentifier)
        else {
          Issue.record("Invalid edits must retain the saved Tag without applied evidence.")
          await listener.stop()
          return
        }
        #expect(unchanged.content == original.content)
        #expect(unchanged.sourceLifetimeId == original.sourceLifetimeId)
        #expect(unchanged.createdAt == original.createdAt)
        #expect(unchanged.updatedAt == original.updatedAt)
        #expect(unchanged.fieldHashes == original.fieldHashes)
      }
      guard
        case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces)
      else {
        Issue.record("Invalid requests must leave recovery readable.")
        await listener.stop()
        return
      }
      #expect(namespaces.first?.acknowledgedSnapshot?.checkpointGeneration == 1)
      #expect(namespaces.first?.preparedProposals.isEmpty == true)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func categoryWireAdvertisementAndValidationKeepRejectedDataUnapplied() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else {
      Issue.record("Initialize the local dataset before validating agent input.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: session)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    do {
      var advertisementRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: ["type": "createCategory", "content": ["name": "Food"]])
      advertisementRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": [:],
      ])
      let advertisement = try await httpSession.data(for: advertisementRequest)
      #expect((advertisement.1 as? HTTPURLResponse)?.statusCode == 200)
      let envelope = try #require(
        JSONSerialization.jsonObject(with: advertisement.0) as? [String: Any])
      let advertised = try #require(envelope["result"] as? [String: Any])
      let tools = try #require(advertised["tools"] as? [[String: Any]])
      let executeTool = try #require(tools.first { $0["name"] as? String == "planner_execute" })
      let inputSchema = try #require(executeTool["inputSchema"] as? [String: Any])
      let properties = try #require(inputSchema["properties"] as? [String: Any])
      let commandSchema = try #require(properties["command"] as? [String: Any])
      let commandVariants = try #require(commandSchema["oneOf"] as? [[String: Any]])
      let categoryVariant = try #require(
        commandVariants.first { variant in
          let variantProperties = variant["properties"] as? [String: Any]
          return (variantProperties?["type"] as? [String: Any])?["const"] as? String
            == "createCategory"
        })
      let categoryProperties = try #require(categoryVariant["properties"] as? [String: Any])
      let categoryContent = try #require(categoryProperties["content"] as? [String: Any])
      #expect(
        Set(try #require(categoryContent["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      #expect(categoryContent["required"] as? [String] == ["name"])
      let readTool = try #require(tools.first { $0["name"] as? String == "planner_read" })
      let readSchema = try #require(readTool["inputSchema"] as? [String: Any])
      let readProperties = try #require(readSchema["properties"] as? [String: Any])
      let readRequestSchema = try #require(readProperties["request"] as? [String: Any])
      let readVariants = try #require(readRequestSchema["oneOf"] as? [[String: Any]])
      let sourceVariant = try #require(
        readVariants.first { variant in
          let variantProperties = variant["properties"] as? [String: Any]
          return (variantProperties?["kind"] as? [String: Any])?["const"] as? String == "source"
        })
      let sourceProperties = try #require(sourceVariant["properties"] as? [String: Any])
      let sourceSchema = try #require(sourceProperties["source"] as? [String: Any])
      let sourceFields = try #require(sourceSchema["properties"] as? [String: Any])
      let kindSchema = try #require(sourceFields["kind"] as? [String: Any])
      #expect((kindSchema["enum"] as? [String])?.contains("category") == true)
      let invalidContents: [([String: Any], String, String)] = [
        ([:], "invalidInput", "/command/content/name"),
        (["name": NSNull()], "invalidInput", "/command/content/name"),
        (["name": " \n\t"], "invalidInput", "/command/content/name"),
        (["name": "Food", "notes": "Forbidden"], "unknownField", "/command/content/notes"),
        (["name": "Food", "color": "blue"], "invalidInput", "/command/content/color"),
        (
          ["name": "Food", "color": ["red": 2, "green": 0, "blue": 0, "alpha": 1]],
          "invalidInput", "/command/content/color/red"
        ),
      ]
      for (content, code, propertyPath) in invalidContents {
        let operationIdentifier = UUID()
        let request = try executionRequest(
          endpoint: endpoint, operationIdentifier: operationIdentifier,
          command: ["type": "createCategory", "content": content])
        let rejected = try operationValue(try await httpSession.data(for: request), isError: true)
        #expect(rejected["state"] as? String == "rejected")
        let reason = try #require(rejected["reason"] as? [String: Any])
        #expect(reason["code"] as? String == code)
        #expect(reason["propertyPath"] as? String == propertyPath)
        guard
          case .noReliableEvidence = await planner.operationStatus(
            session: session,
            operationId: operationIdentifier)
        else {
          Issue.record("Rejected input must not fabricate applied operation evidence.")
          await listener.stop()
          return
        }
      }
      guard
        case .snapshot(let empty) = await planner.query(
          PlannerQuery(
            session: session,
            request: .catalog(PlannerCatalogQuery(sourceKind: .category, archive: .all)))),
        case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces)
      else {
        Issue.record("Validation must leave the initial dataset and recovery namespace readable.")
        await listener.stop()
        return
      }
      #expect(empty.matchingCount == 0)
      #expect(namespaces.first?.acknowledgedSnapshot == nil)
      #expect(namespaces.first?.preparedProposals.isEmpty == true)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func tagWireAdvertisementAndValidationKeepRejectedDataUnapplied() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else {
      Issue.record("Initialize the local dataset before validating agent input.")
      return
    }
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: session)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    do {
      var advertisementRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: ["type": "createTag", "content": ["name": "Food"]])
      advertisementRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": [:],
      ])
      let advertisement = try await httpSession.data(for: advertisementRequest)
      #expect((advertisement.1 as? HTTPURLResponse)?.statusCode == 200)
      let envelope = try #require(
        JSONSerialization.jsonObject(with: advertisement.0) as? [String: Any])
      let advertised = try #require(envelope["result"] as? [String: Any])
      let tools = try #require(advertised["tools"] as? [[String: Any]])
      let executeTool = try #require(tools.first { $0["name"] as? String == "planner_execute" })
      let inputSchema = try #require(executeTool["inputSchema"] as? [String: Any])
      let properties = try #require(inputSchema["properties"] as? [String: Any])
      let commandSchema = try #require(properties["command"] as? [String: Any])
      let commandVariants = try #require(commandSchema["oneOf"] as? [[String: Any]])
      let tagVariant = try #require(
        commandVariants.first { variant in
          let variantProperties = variant["properties"] as? [String: Any]
          return (variantProperties?["type"] as? [String: Any])?["const"] as? String
            == "createTag"
        })
      let tagProperties = try #require(tagVariant["properties"] as? [String: Any])
      let tagContent = try #require(tagProperties["content"] as? [String: Any])
      #expect(
        Set(try #require(tagContent["properties"] as? [String: Any]).keys) == [
          "name", "color", "iconName",
        ])
      #expect(tagContent["required"] as? [String] == ["name"])
      let readTool = try #require(tools.first { $0["name"] as? String == "planner_read" })
      let readSchema = try #require(readTool["inputSchema"] as? [String: Any])
      let readProperties = try #require(readSchema["properties"] as? [String: Any])
      let readRequestSchema = try #require(readProperties["request"] as? [String: Any])
      let readVariants = try #require(readRequestSchema["oneOf"] as? [[String: Any]])
      let sourceVariant = try #require(
        readVariants.first { variant in
          let variantProperties = variant["properties"] as? [String: Any]
          return (variantProperties?["kind"] as? [String: Any])?["const"] as? String == "source"
        })
      let sourceProperties = try #require(sourceVariant["properties"] as? [String: Any])
      let sourceSchema = try #require(sourceProperties["source"] as? [String: Any])
      let sourceFields = try #require(sourceSchema["properties"] as? [String: Any])
      let kindSchema = try #require(sourceFields["kind"] as? [String: Any])
      #expect((kindSchema["enum"] as? [String])?.contains("tag") == true)
      let queryTool = try #require(tools.first { $0["name"] as? String == "planner_query" })
      let queryInput = try #require(queryTool["inputSchema"] as? [String: Any])
      let queryProperties = try #require(queryInput["properties"] as? [String: Any])
      let querySchema = try #require(queryProperties["query"] as? [String: Any])
      let queryVariants = try #require(querySchema["oneOf"] as? [[String: Any]])
      let labelCatalog = try #require(
        queryVariants.first { variant in
          let variantProperties = variant["properties"] as? [String: Any]
          let kinds = (variantProperties?["sourceKind"] as? [String: Any])?["enum"] as? [String]
          return kinds?.contains("tag") == true
        })
      let labelProperties = try #require(labelCatalog["properties"] as? [String: Any])
      #expect(
        Set(try #require(labelCatalog["required"] as? [String])) == [
          "kind", "sourceKind", "archive",
        ])
      #expect((labelProperties["archive"] as? [String: Any])?["const"] as? String == "all")
      #expect(
        Set(try #require((labelProperties["sourceKind"] as? [String: Any])?["enum"] as? [String]))
          == ["category", "tag"])
      let invalidContents: [([String: Any], String, String)] = [
        ([:], "invalidInput", "/command/content/name"),
        (["name": NSNull()], "invalidInput", "/command/content/name"),
        (["name": " \n\t"], "invalidInput", "/command/content/name"),
        (["name": "Food", "notes": "Forbidden"], "unknownField", "/command/content/notes"),
        (["name": "Food", "color": "blue"], "invalidInput", "/command/content/color"),
        (
          ["name": "Food", "color": ["red": 2, "green": 0, "blue": 0, "alpha": 1]],
          "invalidInput", "/command/content/color/red"
        ),
      ]
      for (content, code, propertyPath) in invalidContents {
        let operationIdentifier = UUID()
        let request = try executionRequest(
          endpoint: endpoint, operationIdentifier: operationIdentifier,
          command: ["type": "createTag", "content": content])
        let rejected = try operationValue(try await httpSession.data(for: request), isError: true)
        #expect(rejected["state"] as? String == "rejected")
        let reason = try #require(rejected["reason"] as? [String: Any])
        #expect(reason["code"] as? String == code)
        #expect(reason["propertyPath"] as? String == propertyPath)
        guard
          case .noReliableEvidence = await planner.operationStatus(
            session: session,
            operationId: operationIdentifier)
        else {
          Issue.record("Rejected input must not fabricate applied operation evidence.")
          await listener.stop()
          return
        }
      }
      guard
        case .snapshot(let empty) = await planner.query(
          PlannerQuery(
            session: session,
            request: .catalog(PlannerCatalogQuery(sourceKind: .tag, archive: .all)))),
        case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces)
      else {
        Issue.record("Validation must leave the initial dataset and recovery namespace readable.")
        await listener.stop()
        return
      }
      #expect(empty.matchingCount == 0)
      #expect(namespaces.first?.acknowledgedSnapshot == nil)
      #expect(namespaces.first?.preparedProposals.isEmpty == true)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func tagCreationOverHTTPReplaysAndReadsTheSameDurableSource() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("Initialize the real local dataset before agent creation.")
      return
    }
    let operationIdentifier = UUID()
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let createRequest = try executionRequest(
      endpoint: endpoint, operationIdentifier: operationIdentifier,
      command: [
        "type": "createTag",
        "content": [
          "name": " Café food ", "color": ["red": 0.125, "green": 0.5, "blue": 0.75, "alpha": 1],
          "iconName": "fork.knife",
        ],
      ])
    do {
      let created = try operationValue(
        try await httpSession.data(for: createRequest), isError: false)
      #expect(created["state"] as? String == "applied")
      let result = try #require(created["result"] as? [String: Any])
      let generated = try #require(result["generated"] as? [[String: Any]])
      #expect(generated.count == 1)
      let source = try #require(generated.first)
      #expect(source["kind"] as? String == "tag")
      let identifierSpelling = try #require(source["id"] as? String)
      let identifier = try #require(UUID(uuidString: identifierSpelling))
      let replay = try operationValue(
        try await httpSession.data(for: createRequest), isError: false)
      #expect(NSDictionary(dictionary: replay).isEqual(to: created))
      var readRequest = createRequest
      readRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 2, "method": "tools/call",
        "params": [
          "name": "planner_read",
          "arguments": [
            "formatVersion": 1, "request": ["kind": "source", "source": source],
          ],
        ],
      ])
      let wireRead = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      #expect(wireRead["kind"] as? String == "source")
      let value = try #require(wireRead["value"] as? [String: Any])
      let content = try #require(value["content"] as? [String: Any])
      #expect(Set(content.keys) == ["name", "color", "iconName"])
      #expect(content["name"] as? String == " Café food ")
      #expect(content["iconName"] as? String == "fork.knife")
      #expect(
        NSDictionary(dictionary: try #require(content["color"] as? [String: Any])).isEqual(to: [
          "red": 0.125, "green": 0.5, "blue": 0.75, "alpha": 1,
        ]))
      let state = try #require(value["state"] as? [String: Any])
      #expect(state["globalDone"] is NSNull)
      #expect(state["archived"] is NSNull)
      #expect(value["progress"] is NSNull)
      let reopened = PlannerCore.Planner(configuration: configuration)
      guard case .ready(let reopenedSession) = await reopened.bootstrap(),
        case .source(.tag(let read)) = await reopened.read(
          session: reopenedSession,
          request: .source(PlannerEntityReference(kind: .tag, id: identifier))),
        case .appliedRecoveryComplete(let saved, let checkpoint) = await reopened.operationStatus(
          session: reopenedSession, operationId: operationIdentifier)
      else {
        Issue.record("Agent-created Tag must reopen with the original receipt and recovery.")
        await listener.stop()
        return
      }
      #expect(value["createdAt"] as? Double == read.createdAt.timeIntervalSinceReferenceDate)
      #expect(value["updatedAt"] as? Double == read.updatedAt.timeIntervalSinceReferenceDate)
      #expect(
        value["fieldHashes"] as? [String: String]
          == Dictionary(
            uniqueKeysWithValues:
              read.fieldHashes.map { ($0.key.rawValue, $0.value.value) }))
      #expect(saved.generated == [read.source])
      #expect(checkpoint == 1)
      var queryRequest = createRequest
      queryRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 3, "method": "tools/call",
        "params": [
          "name": "planner_query",
          "arguments": [
            "formatVersion": 1,
            "query": [
              "kind": "catalog", "sourceKind": "tag", "archive": "all", "text": "FOOD cafe",
            ],
          ],
        ],
      ])
      let catalog = try operationValue(
        try await httpSession.data(for: queryRequest), isError: false)
      #expect(catalog["matchingCount"] as? String == "1")
      let rows = try #require(catalog["rows"] as? [[String: Any]])
      #expect(rows.count == 1)
      #expect((rows.first?["source"] as? [String: Any])?["id"] as? String == identifier.uuidString)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func categoryCreationOverHTTPReplaysAndReadsTheSameDurableSource() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("Initialize the real local dataset before agent creation.")
      return
    }
    let operationIdentifier = UUID()
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let createRequest = try executionRequest(
      endpoint: endpoint, operationIdentifier: operationIdentifier,
      command: [
        "type": "createCategory",
        "content": [
          "name": " Café food ", "color": ["red": 0.125, "green": 0.5, "blue": 0.75, "alpha": 1],
          "iconName": "fork.knife",
        ],
      ])
    do {
      let created = try operationValue(
        try await httpSession.data(for: createRequest), isError: false)
      #expect(created["state"] as? String == "applied")
      let result = try #require(created["result"] as? [String: Any])
      let generated = try #require(result["generated"] as? [[String: Any]])
      #expect(generated.count == 1)
      let source = try #require(generated.first)
      #expect(source["kind"] as? String == "category")
      let identifierSpelling = try #require(source["id"] as? String)
      let identifier = try #require(UUID(uuidString: identifierSpelling))
      let replay = try operationValue(
        try await httpSession.data(for: createRequest), isError: false)
      #expect(NSDictionary(dictionary: replay).isEqual(to: created))
      var readRequest = createRequest
      readRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 2, "method": "tools/call",
        "params": [
          "name": "planner_read",
          "arguments": [
            "formatVersion": 1, "request": ["kind": "source", "source": source],
          ],
        ],
      ])
      let wireRead = try operationValue(
        try await httpSession.data(for: readRequest), isError: false)
      #expect(wireRead["kind"] as? String == "source")
      let value = try #require(wireRead["value"] as? [String: Any])
      let content = try #require(value["content"] as? [String: Any])
      #expect(Set(content.keys) == ["name", "color", "iconName"])
      #expect(content["name"] as? String == " Café food ")
      #expect(content["iconName"] as? String == "fork.knife")
      #expect(
        NSDictionary(dictionary: try #require(content["color"] as? [String: Any])).isEqual(to: [
          "red": 0.125, "green": 0.5, "blue": 0.75, "alpha": 1,
        ]))
      let state = try #require(value["state"] as? [String: Any])
      #expect(state["globalDone"] is NSNull)
      #expect(state["archived"] is NSNull)
      #expect(value["progress"] is NSNull)
      let reopened = PlannerCore.Planner(configuration: configuration)
      guard case .ready(let reopenedSession) = await reopened.bootstrap(),
        case .source(.category(let read)) = await reopened.read(
          session: reopenedSession,
          request: .source(PlannerEntityReference(kind: .category, id: identifier))),
        case .appliedRecoveryComplete(let saved, let checkpoint) = await reopened.operationStatus(
          session: reopenedSession, operationId: operationIdentifier)
      else {
        Issue.record("Agent-created Category must reopen with the original receipt and recovery.")
        await listener.stop()
        return
      }
      #expect(value["createdAt"] as? Double == read.createdAt.timeIntervalSinceReferenceDate)
      #expect(value["updatedAt"] as? Double == read.updatedAt.timeIntervalSinceReferenceDate)
      #expect(
        value["fieldHashes"] as? [String: String]
          == Dictionary(
            uniqueKeysWithValues:
              read.fieldHashes.map { ($0.key.rawValue, $0.value.value) }))
      #expect(saved.generated == [read.source])
      #expect(checkpoint == 1)
      var queryRequest = createRequest
      queryRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 3, "method": "tools/call",
        "params": [
          "name": "planner_query",
          "arguments": [
            "formatVersion": 1,
            "query": [
              "kind": "catalog", "sourceKind": "category", "archive": "all", "text": "FOOD cafe",
            ],
          ],
        ],
      ])
      let catalog = try operationValue(
        try await httpSession.data(for: queryRequest), isError: false)
      #expect(catalog["matchingCount"] as? String == "1")
      let rows = try #require(catalog["rows"] as? [[String: Any]])
      #expect(rows.count == 1)
      #expect((rows.first?["source"] as? [String: Any])?["id"] as? String == identifier.uuidString)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func subtitleEditOverHTTPPreservesNotesAndRejectsStaleChangesBeforeClearing() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("The real Planner dataset must initialize.")
      return
    }
    let created = await planner.execute(
      PlannerOperation(
        operationId: UUID(), session: datasetSession,
        command: .createItem(
          content: PlannerItemContentInput(
            title: "Hotel", subtitle: "Stay near station", notes: "Original notes"))))
    guard case .applied(let result, .complete) = created.outcome else {
      Issue.record("Hotel must be independently saved before editing.")
      return
    }
    let source = try #require(result.generated.first)
    guard
      case .source(.item(let original)) = await planner.read(
        session: datasetSession, request: .source(source))
    else {
      Issue.record("The original subtitle hash must come from a public read.")
      return
    }
    let originalHash = try #require(original.fieldHashes[.subtitle])
    let operationIdentifier = UUID()
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    do {
      let edit = try executionRequest(
        endpoint: endpoint, operationIdentifier: operationIdentifier,
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": "Museum and garden"],
          "expectedFieldHashes": ["subtitle": originalHash.value],
        ])
      let edited = try operationValue(try await httpSession.data(for: edit), isError: false)
      #expect(edited["state"] as? String == "applied")
      let recovery = try #require(edited["recovery"] as? [String: Any])
      #expect(recovery["state"] as? String == "complete")
      #expect(recovery["checkpointGeneration"] as? String == "2")
      guard
        case .source(.item(let friday)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("HTTP must update the shared native Item.")
        await listener.stop()
        return
      }
      #expect(friday.content.title == "Hotel")
      #expect(friday.content.notes == "Original notes")
      #expect(friday.content.subtitle == "Museum and garden")
      #expect(friday.state.globalDone == false)
      #expect(friday.state.archived == false)
      let staleRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": "Old subtitle proposal"],
          "expectedFieldHashes": ["subtitle": originalHash.value],
        ])
      let stale = try operationValue(try await httpSession.data(for: staleRequest), isError: true)
      #expect(stale["state"] as? String == "rejected")
      let reason = try #require(stale["reason"] as? [String: Any])
      #expect(reason["code"] as? String == "staleEdit")
      let details = try #require(reason["details"] as? [String: Any])
      #expect(details["kind"] as? String == "staleEdit")
      #expect(details["conflictingFields"] as? [String] == ["subtitle"])
      let currentValues = try #require(details["currentValues"] as? [String: Any])
      #expect(currentValues["subtitle"] as? String == "Museum and garden")
      let hashes = try #require(details["currentFieldHashes"] as? [String: String])
      #expect(hashes["subtitle"] == friday.fieldHashes[.subtitle]?.value)
      guard
        case .source(.item(let current)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("A stale agent edit must retain the current Item.")
        await listener.stop()
        return
      }
      #expect(current.content.subtitle == "Museum and garden")
      #expect(current.updatedAt == friday.updatedAt)
      #expect(current.fieldHashes == friday.fieldHashes)
      guard
        case .appliedRecoveryComplete(let saved, let checkpoint) = await planner.operationStatus(
          session: datasetSession, operationId: operationIdentifier)
      else {
        Issue.record("The successful edit must retain its original evidence.")
        await listener.stop()
        return
      }
      #expect(saved.affected == [source])
      #expect(checkpoint == 2)
      let currentSubtitleHash = try #require(current.fieldHashes[.subtitle])
      let clear = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": NSNull()],
          "expectedFieldHashes": ["subtitle": currentSubtitleHash.value],
        ])
      let cleared = try operationValue(try await httpSession.data(for: clear), isError: false)
      #expect(cleared["state"] as? String == "applied")
      guard
        case .source(.item(let afterClear)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("The cleared subtitle must remain publicly readable.")
        await listener.stop()
        return
      }
      #expect(afterClear.content.subtitle == nil)
      #expect(afterClear.content.title == "Hotel")
      #expect(afterClear.content.notes == "Original notes")
      #expect(afterClear.state.globalDone == false)
      #expect(afterClear.state.archived == false)
      let replay = try operationValue(try await httpSession.data(for: edit), isError: false)
      #expect(NSDictionary(dictionary: replay).isEqual(to: edited))
      let changedReplay = try executionRequest(
        endpoint: endpoint, operationIdentifier: operationIdentifier,
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": "Different proposal"],
          "expectedFieldHashes": ["subtitle": originalHash.value],
        ])
      let mismatch = try operationValue(
        try await httpSession.data(for: changedReplay), isError: true)
      #expect(
        (mismatch["reason"] as? [String: Any])?["code"] as? String == "operationPayloadMismatch")
      let invalidCommands: [[String: Any]] = [
        [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": true, "title": "Must not apply"],
          "expectedFieldHashes": ["subtitle": currentSubtitleHash.value],
        ],
        [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["subtitle": "Missing guard"], "expectedFieldHashes": [:],
        ],
      ]
      for invalidCommand in invalidCommands {
        let invalidOperationIdentifier = UUID()
        let invalidRequest = try executionRequest(
          endpoint: endpoint, operationIdentifier: invalidOperationIdentifier,
          command: invalidCommand)
        let rejected = try operationValue(
          try await httpSession.data(for: invalidRequest), isError: true)
        #expect(rejected["state"] as? String == "rejected")
        #expect((rejected["reason"] as? [String: Any])?["code"] as? String == "invalidInput")
        guard
          case .noReliableEvidence = await planner.operationStatus(
            session: datasetSession, operationId: invalidOperationIdentifier)
        else {
          Issue.record("Invalid subtitle edits must not create an applied receipt.")
          await listener.stop()
          return
        }
      }
      guard
        case .source(.item(let retained)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("Replay and invalid requests must retain the cleared Item.")
        await listener.stop()
        return
      }
      #expect(retained.content.subtitle == nil)
      #expect(retained.content.title == "Hotel")
      #expect(retained.content.notes == "Original notes")
      #expect(retained.updatedAt == afterClear.updatedAt)
      #expect(retained.fieldHashes == afterClear.fieldHashes)
      var catalogRequest = edit
      catalogRequest.httpBody = try JSONSerialization.data(withJSONObject: [
        "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": [:],
      ])
      let (catalogData, catalogResponse) = try await httpSession.data(for: catalogRequest)
      #expect((catalogResponse as? HTTPURLResponse)?.statusCode == 200)
      let catalog = try #require(JSONSerialization.jsonObject(with: catalogData) as? [String: Any])
      let tools = try #require((catalog["result"] as? [String: Any])?["tools"] as? [[String: Any]])
      let execution = try #require(tools.first { $0["name"] as? String == "planner_execute" })
      let properties = try #require(
        (execution["inputSchema"] as? [String: Any])?["properties"] as? [String: Any])
      let variants = try #require(
        (properties["command"] as? [String: Any])?["oneOf"] as? [[String: Any]])
      let itemEdit = try #require(
        variants.first {
          let fields = $0["properties"] as? [String: Any]
          return (fields?["type"] as? [String: Any])?["const"] as? String == "editItem"
        })
      let itemEditProperties = try #require(itemEdit["properties"] as? [String: Any])
      let changeSchema = try #require(itemEditProperties["changes"] as? [String: Any])
      let changeProperties = try #require(changeSchema["properties"] as? [String: Any])
      let subtitleSchema = try #require(changeProperties["subtitle"] as? [String: Any])
      #expect(subtitleSchema["type"] as? [String] == ["string", "null"])
      #expect(changeSchema["additionalProperties"] as? Bool == false)
      await listener.stop()
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func notesEditOverHTTPRejectsStaleHashAndRetainsFridayBooking() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("The real Planner dataset must initialize.")
      return
    }
    let created = await planner.execute(
      PlannerOperation(
        operationId: UUID(), session: datasetSession,
        command: .createItem(
          content: PlannerItemContentInput(title: "Hotel", notes: "Original notes"))))
    guard case .applied(let result, .complete) = created.outcome else {
      Issue.record("Hotel must be independently saved before editing.")
      return
    }
    let source = try #require(result.generated.first)
    guard
      case .source(.item(let original)) = await planner.read(
        session: datasetSession, request: .source(source))
    else {
      Issue.record("The original notes hash must come from a public read.")
      return
    }
    let originalHash = try #require(original.fieldHashes[.notes])
    let operationIdentifier = UUID()
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    do {
      let edit = try executionRequest(
        endpoint: endpoint, operationIdentifier: operationIdentifier,
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["notes": "Friday booking"],
          "expectedFieldHashes": ["notes": originalHash.value],
        ])
      let edited = try operationValue(try await httpSession.data(for: edit), isError: false)
      #expect(edited["state"] as? String == "applied")
      let recovery = try #require(edited["recovery"] as? [String: Any])
      #expect(recovery["state"] as? String == "complete")
      #expect(recovery["checkpointGeneration"] as? String == "2")
      guard
        case .source(.item(let friday)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("HTTP must update the shared native Item.")
        return
      }
      #expect(friday.content.title == "Hotel")
      #expect(friday.content.notes == "Friday booking")
      #expect(friday.state.globalDone == false)
      #expect(friday.state.archived == false)
      let staleRequest = try executionRequest(
        endpoint: endpoint, operationIdentifier: UUID(),
        command: [
          "type": "editItem", "sourceId": source.id.uuidString,
          "changes": ["notes": "Monday booking"],
          "expectedFieldHashes": ["notes": originalHash.value],
        ])
      let stale = try operationValue(try await httpSession.data(for: staleRequest), isError: true)
      await listener.stop()
      #expect(stale["state"] as? String == "rejected")
      let reason = try #require(stale["reason"] as? [String: Any])
      #expect(reason["code"] as? String == "staleEdit")
      let details = try #require(reason["details"] as? [String: Any])
      #expect(details["kind"] as? String == "staleEdit")
      #expect(details["conflictingFields"] as? [String] == ["notes"])
      let currentValues = try #require(details["currentValues"] as? [String: Any])
      #expect(currentValues["notes"] as? String == "Friday booking")
      let hashes = try #require(details["currentFieldHashes"] as? [String: String])
      #expect(hashes["notes"] == friday.fieldHashes[.notes]?.value)
      guard
        case .source(.item(let current)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("A stale agent edit must retain the current Item.")
        return
      }
      #expect(current.content.notes == "Friday booking")
      #expect(current.updatedAt == friday.updatedAt)
      #expect(current.fieldHashes == friday.fieldHashes)
      guard
        case .appliedRecoveryComplete(let saved, let checkpoint) = await planner.operationStatus(
          session: datasetSession, operationId: operationIdentifier)
      else {
        Issue.record("The successful edit must retain its original evidence.")
        return
      }
      #expect(saved.affected == [source])
      #expect(checkpoint == 2)
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test(arguments: [
    "deleteSource", "applyImport", "restoreRecovery", "restoreAssociation", "retryRecovery",
    "exportData", "decodeImport",
  ])
  func nativeAdministrationIsForbiddenWithoutChangingHotel(_ commandType: String) async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = PlannerCore.Planner(
      configuration: PlannerStorageConfiguration(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("The real Planner dataset must initialize.")
      return
    }
    let created = await planner.execute(
      PlannerOperation(
        operationId: UUID(), session: datasetSession,
        command: .createItem(
          content: PlannerItemContentInput(title: "Hotel", notes: "Original notes"))))
    guard case .applied(let originalResult, .complete(let checkpoint)) = created.outcome else {
      Issue.record("Hotel must be independently saved before rejected agent work.")
      return
    }
    let source = try #require(originalResult.generated.first)
    let operationIdentifier = UUID()
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let request = try executionRequest(
      endpoint: endpoint, operationIdentifier: operationIdentifier, command: ["type": commandType])
    do {
      let exchange = try await httpSession.data(for: request)
      await listener.stop()
      let response = try #require(exchange.1 as? HTTPURLResponse)
      #expect(response.statusCode == 200)
      let envelope = try #require(JSONSerialization.jsonObject(with: exchange.0) as? [String: Any])
      #expect(envelope["error"] == nil)
      let tool = try #require(envelope["result"] as? [String: Any])
      #expect(tool["isError"] as? Bool == true)
      let structured = try #require(tool["structuredContent"] as? [String: Any])
      #expect(structured["state"] as? String == "rejected")
      #expect(structured["operationId"] as? String == operationIdentifier.uuidString)
      let reason = try #require(structured["reason"] as? [String: Any])
      let expectedCode: String
      if ["retryRecovery", "exportData", "decodeImport"].contains(commandType) {
        expectedCode = "unavailable"
      } else {
        expectedCode = "forbiddenOperation"
      }
      #expect(reason["code"] as? String == expectedCode)
      #expect(reason["propertyPath"] as? String == "/command/type")
      guard
        case .source(.item(let current)) = await planner.read(
          session: datasetSession, request: .source(source))
      else {
        Issue.record("Rejected administration must retain Hotel.")
        return
      }
      #expect(current.content.title == "Hotel")
      #expect(current.content.notes == "Original notes")
      #expect(current.state.globalDone == false)
      #expect(current.state.archived == false)
      guard
        case .snapshot(let snapshot) = await planner.query(
          PlannerQuery(session: datasetSession, request: .items(PlannerItemQuery())))
      else {
        Issue.record("Rejected administration must preserve the public query.")
        return
      }
      #expect(snapshot.matchingCount == 1)
      #expect(snapshot.rows == [.source(source)])
      guard
        case .noReliableEvidence = await planner.operationStatus(
          session: datasetSession, operationId: operationIdentifier)
      else {
        Issue.record("Adapter admission must not create a domain receipt.")
        return
      }
      guard
        case .listedNamespaces(let namespaces) = await planner.inspectRecovery(request: .namespaces)
      else {
        Issue.record("The existing independent checkpoint must remain available.")
        return
      }
      #expect(namespaces.count == 1)
      #expect(namespaces.first?.preparedProposals.isEmpty == true)
      #expect(namespaces.first?.acknowledgedSnapshot?.checkpointGeneration == checkpoint)
    } catch {
      await listener.stop()
      throw error
    }
  }

  @Test func createOverHTTPPersistsHotelAndReplaysWithoutAnotherItem() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let datasetSession) = await planner.bootstrap() else {
      Issue.record("The real Planner dataset must initialize.")
      return
    }
    let operationIdentifier = try #require(
      UUID(uuidString: "00000000-0000-4000-8000-000000000901"))
    let handler = PlannerMCPRequestHandler(
      credential: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", accessWindowIdentifier: UUID(),
      planner: planner, datasetSession: datasetSession)
    let listener = PlannerMCPLoopbackListener(requestHandler: handler)
    let endpoint = try await listener.start(port: 0)
    let httpSession = URLSession(configuration: .ephemeral)
    defer { httpSession.invalidateAndCancel() }
    let request = try executionRequest(
      endpoint: endpoint, operationIdentifier: operationIdentifier,
      command: ["type": "createItem", "content": ["title": "Hotel", "notes": "Original notes"]])
    do {
      let firstExchange = try await httpSession.data(for: request)
      let first = try appliedCreation(firstExchange, operationIdentifier: operationIdentifier)
      let replayExchange = try await httpSession.data(for: request)
      let replay = try appliedCreation(replayExchange, operationIdentifier: operationIdentifier)
      await listener.stop()
      #expect(replay.itemIdentifier == first.itemIdentifier)
      #expect(replay.checkpoint == first.checkpoint)
      #expect(first.checkpoint == "1")
      let reopened = PlannerCore.Planner(configuration: configuration)
      guard case .ready(let reopenedSession) = await reopened.bootstrap() else {
        Issue.record("HTTP-created data must reopen through the public Core.")
        return
      }
      let item = PlannerEntityReference(kind: .item, id: first.itemIdentifier)
      guard
        case .source(.item(let read)) = await reopened.read(
          session: reopenedSession, request: .source(item))
      else {
        Issue.record("HTTP-created Hotel must remain readable after reopening.")
        return
      }
      #expect(read.content.title == "Hotel")
      #expect(read.content.notes == "Original notes")
      #expect(read.state.globalDone == false)
      #expect(read.state.archived == false)
      guard
        case .snapshot(let snapshot) = await reopened.query(
          PlannerQuery(session: reopenedSession, request: .items(PlannerItemQuery())))
      else {
        Issue.record("The resulting Items must be discoverable through Core.")
        return
      }
      #expect(snapshot.matchingCount == 1)
      #expect(snapshot.rows == [.source(item)])
      guard
        case .appliedRecoveryComplete(let result, let checkpoint) = await reopened.operationStatus(
          session: reopenedSession, operationId: operationIdentifier)
      else {
        Issue.record("The original operation must retain complete recovery evidence.")
        return
      }
      #expect(result.generated == [item])
      #expect(checkpoint == 1)
    } catch {
      await listener.stop()
      throw error
    }
  }

  private func executionRequest(
    endpoint: URL, operationIdentifier: UUID, command: [String: Any]
  ) throws -> URLRequest {
    var request = URLRequest(url: endpoint)
    request.httpMethod = "POST"
    request.httpBody = try JSONSerialization.data(withJSONObject: [
      "jsonrpc": "2.0", "id": 1, "method": "tools/call",
      "params": [
        "name": "planner_execute",
        "arguments": [
          "formatVersion": 1, "operationId": operationIdentifier.uuidString, "command": command,
        ],
      ],
    ])
    request.setValue(
      "Bearer AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("application/json, text/event-stream", forHTTPHeaderField: "Accept")
    request.setValue("2025-11-25", forHTTPHeaderField: "MCP-Protocol-Version")
    request.timeoutInterval = 5
    return request
  }

  private func operationValue(_ exchange: (Data, URLResponse), isError: Bool) throws -> [String:
    Any]
  {
    let response = try #require(exchange.1 as? HTTPURLResponse)
    #expect(response.statusCode == 200)
    let envelope = try #require(JSONSerialization.jsonObject(with: exchange.0) as? [String: Any])
    #expect(envelope["error"] == nil)
    let tool = try #require(envelope["result"] as? [String: Any])
    #expect(tool["isError"] as? Bool == isError)
    let value = try #require(tool["structuredContent"] as? [String: Any])
    let content = try #require(tool["content"] as? [[String: Any]])
    let text = try #require(content.first?["text"] as? String)
    let textResult = try #require(
      JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any])
    #expect(NSDictionary(dictionary: textResult).isEqual(to: value))
    return value
  }

  private func appliedCreation(
    _ exchange: (Data, URLResponse), operationIdentifier: UUID
  ) throws -> (itemIdentifier: UUID, checkpoint: String) {
    let response = try #require(exchange.1 as? HTTPURLResponse)
    #expect(response.statusCode == 200)
    let envelope = try #require(JSONSerialization.jsonObject(with: exchange.0) as? [String: Any])
    #expect(envelope["error"] == nil)
    let tool = try #require(envelope["result"] as? [String: Any])
    #expect(tool["isError"] as? Bool == false)
    let structured = try #require(tool["structuredContent"] as? [String: Any])
    #expect(structured["formatVersion"] as? Int == 1)
    #expect(structured["operationId"] as? String == operationIdentifier.uuidString)
    #expect(structured["state"] as? String == "applied")
    let result = try #require(structured["result"] as? [String: Any])
    let generated = try #require(result["generated"] as? [[String: Any]])
    #expect(generated.count == 1)
    let source = try #require(generated.first)
    #expect(source["kind"] as? String == "item")
    let spelling = try #require(source["id"] as? String)
    let itemIdentifier = try #require(UUID(uuidString: spelling))
    let affected = try #require(result["affected"] as? [[String: Any]])
    #expect(affected.count == 1)
    #expect(affected.first?["id"] as? String == spelling)
    #expect((result["progress"] as? [Any])?.isEmpty == true)
    #expect(result["importSummary"] is NSNull)
    let recovery = try #require(structured["recovery"] as? [String: Any])
    #expect(recovery["state"] as? String == "complete")
    let checkpoint = try #require(recovery["checkpointGeneration"] as? String)
    let content = try #require(tool["content"] as? [[String: Any]])
    let text = try #require(content.first?["text"] as? String)
    let textResult = try #require(
      JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any])
    #expect(NSDictionary(dictionary: textResult).isEqual(to: structured))
    return (itemIdentifier, checkpoint)
  }
}
