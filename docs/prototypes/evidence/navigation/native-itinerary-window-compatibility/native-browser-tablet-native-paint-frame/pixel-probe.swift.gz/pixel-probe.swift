import Foundation
import CoreGraphics
import ImageIO
let entries = [("7C3FE94B-9432-4380-A02E-D4BCC3B378D6.png", 341), ("1B8CE516-7972-4FD0-BB3A-A96F949DD642.png", 371)]
for (name, start) in entries {
  let file = URL(fileURLWithPath: "/private/tmp/PlannerBrowserFinalTabletAttachments/" + name)
  let source = CGImageSourceCreateWithURL(file as CFURL, nil)!
  let image = CGImageSourceCreateImageAtIndex(source, 0, nil)!
  let readingImage = image.cropping(to: CGRect(x: start * 2, y: 94 * 2, width: (820 - start) * 2, height: 200 * 2))!
  var pixels = [UInt8](repeating: 0, count: 32 * 32 * 4)
  pixels.withUnsafeMutableBytes { buffer in
    let context = CGContext(data: buffer.baseAddress, width: 32, height: 32, bitsPerComponent: 8, bytesPerRow: 32 * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue)!
    context.draw(readingImage, in: CGRect(x: 0, y: 0, width: 32, height: 32))
  }
  let levels = stride(from: 0, to: pixels.count, by: 4).map { (Int(pixels[$0]) + Int(pixels[$0 + 1]) + Int(pixels[$0 + 2])) / 3 }
  let background = levels.sorted()[levels.count / 2]
  print(name, "range", levels.min()!, levels.max()!, "contrastPixels", levels.filter { abs($0 - background) > 40 }.count)
}
