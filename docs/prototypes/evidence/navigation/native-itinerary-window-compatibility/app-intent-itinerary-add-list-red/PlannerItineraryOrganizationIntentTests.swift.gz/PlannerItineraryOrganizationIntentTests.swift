import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryOrganizationIntentTests: XCTestCase {
  func testRepeatedItemAddsKeepLiveContentGlobalPrecedenceAndIndependentLocalStatesAfterReopen()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Hotel"
    creation.notes = "Original notes"
    let item = try await creation.callAsFunction(donate: false)
    let planCreation = CreatePlannerItineraryIntent()
    planCreation.title = "Tokyo Weekend"
    let itinerary = try await planCreation.callAsFunction(donate: false)
    let completion = SetPlannerItemCompletionIntent()
    completion.item = item
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    let adding = AddPlannerItemToItineraryIntent()
    adding.item = item
    adding.itinerary = itinerary
    let _: Void = try await adding.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let itinerarySource = PlannerEntityReference(kind: .itinerary, id: itinerary.id)
    let itemSource = PlannerEntityReference(kind: .item, id: item.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.itinerary(let first)) = await planner.read(
        session: session, request: .source(itinerarySource)),
      case .itineraryEntry(let firstIdentifier, let owner, let source)? = first.references.first
    else { return XCTFail("Adding must save a live route reference.") }
    XCTAssertEqual(owner, itinerarySource)
    XCTAssertEqual(source, itemSource)
    XCTAssertEqual(first.references.count, 1)
    let firstAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: firstIdentifier)
    guard
      case .appearance(let initial) = await planner.read(
        session: session, request: .appearance(firstAppearance))
    else { return XCTFail("The first appearance must be readable.") }
    XCTAssertTrue(initial.globalDone)
    XCTAssertFalse(initial.localDone)
    XCTAssertTrue(initial.effectiveDone)
    guard
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setCompletion(scope: .appearance(firstAppearance), done: true))
      ).outcome
    else { return XCTFail("The first appearance can be completed locally.") }
    let _: Void = try await adding.callAsFunction(donate: false)
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    let editing = EditPlannerItemIntent()
    editing.item = item
    editing.notes = "Live Hotel notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.itinerary(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(itinerarySource)),
      saved.references.count == 2,
      case .itineraryEntry(let secondIdentifier, let secondOwner, let secondSource) =
        saved.references[1],
      case .source(.item(let savedItem)) = await reopened.read(
        session: reopenedSession, request: .source(itemSource)),
      case .snapshot(let itemCatalog) = await reopened.query(
        .init(session: reopenedSession, request: .items(.init(completion: .all, archive: .all))))
    else { return XCTFail("Both entries and their single source must survive reopening.") }
    XCTAssertEqual(saved.references.first, first.references.first)
    XCTAssertNotEqual(secondIdentifier, firstIdentifier)
    XCTAssertEqual(secondOwner, itinerarySource)
    XCTAssertEqual(secondSource, itemSource)
    XCTAssertEqual(saved.progress.totalCount, 2)
    XCTAssertEqual(saved.progress.doneCount, 1)
    XCTAssertEqual(savedItem.content.notes, "Live Hotel notes")
    XCTAssertEqual(savedItem.state.globalDone, false)
    XCTAssertEqual(itemCatalog.rows, [.source(itemSource)])
    let secondAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: secondIdentifier)
    for (appearance, expectedLocalDone) in [(firstAppearance, true), (secondAppearance, false)] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(appearance))
      else { return XCTFail("Both original appearances must remain readable.") }
      XCTAssertEqual(current.content.notes, "Live Hotel notes")
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocalDone)
      XCTAssertEqual(current.effectiveDone, expectedLocalDone)
    }
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testRepeatedListAddsPreserveRouteOrderAndLiveChildrenWithoutInheritingStandaloneCompletion()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let itemCreation = CreatePlannerItemIntent()
    itemCreation.title = "Museum"
    let museum = try await itemCreation.callAsFunction(donate: false)
    let listCreation = CreatePlannerListIntent()
    listCreation.name = "Tokyo Food"
    let list = try await listCreation.callAsFunction(donate: false)
    let membershipAddition = AddPlannerItemToListIntent()
    membershipAddition.item = museum
    membershipAddition.list = list
    let _: Void = try await membershipAddition.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let listSource = PlannerEntityReference(kind: .list, id: list.id)
    let museumSource = PlannerEntityReference(kind: .item, id: museum.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.list(let originalList)) = await planner.read(
        session: session, request: .source(listSource)),
      case .membership(let membershipIdentifier, _, _)? = originalList.references.first
    else { return XCTFail("The standalone membership must exist first.") }
    func save(_ command: PlannerCommand) async throws {
      guard
        case .applied(_, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
    }
    let standalone = PlannerAppearance.listMembership(
      listId: list.id, membershipId: membershipIdentifier)
    try await save(.setCompletion(scope: .appearance(standalone), done: true))
    let planCreation = CreatePlannerItineraryIntent()
    planCreation.title = "Tokyo Weekend"
    let itinerary = try await planCreation.callAsFunction(donate: false)
    let itinerarySource = PlannerEntityReference(kind: .itinerary, id: itinerary.id)
    let addingList = AddPlannerListToItineraryIntent()
    addingList.list = list
    addingList.itinerary = itinerary
    let _: Void = try await addingList.callAsFunction(donate: false)
    guard
      case .source(.itinerary(let first)) = await planner.read(
        session: session, request: .source(itinerarySource)),
      case .itineraryEntry(let firstIdentifier, _, let firstSource)? = first.references.first
    else { return XCTFail("Adding the List must save a live branch.") }
    XCTAssertEqual(firstSource, listSource)
    let firstAppearance = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: firstIdentifier, membershipId: membershipIdentifier)
    guard
      case .appearance(let initial) = await planner.read(
        session: session, request: .appearance(firstAppearance))
    else { return XCTFail("The branch child must start independently from standalone completion.") }
    XCTAssertFalse(initial.localDone)
    XCTAssertFalse(initial.effectiveDone)
    try await save(.setCompletion(scope: .appearance(firstAppearance), done: true))
    let addingItem = AddPlannerItemToItineraryIntent()
    addingItem.item = museum
    addingItem.itinerary = itinerary
    let _: Void = try await addingItem.callAsFunction(donate: false)
    let _: Void = try await addingList.callAsFunction(donate: false)
    itemCreation.title = "Lunch"
    let lunch = try await itemCreation.callAsFunction(donate: false)
    membershipAddition.item = lunch
    let _: Void = try await membershipAddition.callAsFunction(donate: false)
    let editing = EditPlannerItemIntent()
    editing.item = museum
    editing.notes = "Updated shared Museum notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    let completion = SetPlannerItemCompletionIntent()
    completion.item = museum
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    guard
      case .source(.itinerary(let globallyDone)) = await planner.read(
        session: session, request: .source(itinerarySource))
    else { return XCTFail("Global completion must apply to every live Museum appearance.") }
    XCTAssertEqual(globallyDone.progress.doneCount, 3)
    XCTAssertEqual(globallyDone.progress.totalCount, 5)
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.itinerary(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(itinerarySource)),
      case .source(.list(let savedList)) = await reopened.read(
        session: reopenedSession, request: .source(listSource))
    else { return XCTFail("The route and source List must survive reopening.") }
    let entries = saved.references.compactMap { reference -> (UUID, PlannerEntityReference)? in
      guard case .itineraryEntry(let identifier, let owner, let source) = reference,
        owner == itinerarySource
      else { return nil }
      return (identifier, source)
    }
    XCTAssertEqual(entries.map(\.1), [listSource, museumSource, listSource])
    guard entries.count == 3 else { return XCTFail("Repeated Lists must retain distinct entries.") }
    XCTAssertEqual(entries[0].0, firstIdentifier)
    XCTAssertEqual(Set(entries.map(\.0)).count, 3)
    XCTAssertEqual(saved.progress.totalCount, 5)
    XCTAssertEqual(saved.progress.doneCount, 1)
    XCTAssertEqual(saved.listEntrySummaries.count, 2)
    XCTAssertEqual(savedList.progress.totalCount, 2)
    XCTAssertEqual(savedList.progress.doneCount, 1)
    let secondAppearance = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: entries[2].0, membershipId: membershipIdentifier)
    let directAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: entries[1].0)
    for (appearance, expectedLocalDone) in [
      (standalone, true), (firstAppearance, true), (directAppearance, false),
      (secondAppearance, false),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(appearance))
      else { return XCTFail("Each Museum appearance must keep its own completion context.") }
      XCTAssertEqual(current.source, museumSource)
      XCTAssertEqual(current.content.notes, "Updated shared Museum notes")
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocalDone)
      XCTAssertEqual(current.effectiveDone, expectedLocalDone)
    }
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory.appending(
      path: "PlannerItineraryOrganizationIntentTests/\(UUID().uuidString)",
      directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
