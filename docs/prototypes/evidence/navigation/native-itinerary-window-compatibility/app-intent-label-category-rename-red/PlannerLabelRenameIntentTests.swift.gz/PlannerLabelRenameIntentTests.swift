import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerLabelRenameIntentTests: XCTestCase {
  func testCategoryRenameUpdatesLiveOwnerAndRowLabelsWithoutRewritingTheirData() async throws {
    let fixture = try await makeLabelRenameIntentFixture()
    guard
      case .source(.category(let original)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.category)),
      case .source(.item(let beforeItem)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item)),
      case .source(.itinerary(let beforeItinerary)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.itinerary)),
      case .source(.list(let beforeList)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.list))
    else { return XCTFail("The shared label and its owners must be readable before renaming.") }
    let rename = RenamePlannerCategoryIntent()
    rename.category = .init(id: fixture.category.id, name: "Cached Category")
    rename.name = "Art and museums"
    let _: Void = try await rename.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.category(let current)) = await reopened.read(
        session: session, request: .source(fixture.category)),
      case .source(.tag(let retainedTag)) = await reopened.read(
        session: session, request: .source(fixture.tag)),
      case .source(.item(let item)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.itinerary(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.itinerary)),
      case .source(.list(let list)) = await reopened.read(
        session: session, request: .source(fixture.list)),
      case .source(.schedule(let booking)) = await reopened.read(
        session: session, request: .source(fixture.schedule)),
      case .snapshot(let snapshot) = await reopened.query(
        .init(
          session: session,
          request: .items(
            .init(completion: .all, archive: .all, categories: .init(ids: [fixture.category.id]))))),
      case .rows(let rows) = await reopened.read(
        session: session, request: .rows(generation: snapshot.generation, offset: 0, limit: 64))
    else { return XCTFail("Live label changes and unchanged owners must survive reopening.") }
    XCTAssertEqual(current.source, original.source)
    XCTAssertEqual(current.sourceLifetimeId, original.sourceLifetimeId)
    XCTAssertEqual(current.createdAt, original.createdAt)
    XCTAssertEqual(current.content.name, "Art and museums")
    XCTAssertEqual(current.content.color, original.content.color)
    XCTAssertEqual(current.content.iconName, original.content.iconName)
    XCTAssertEqual(current.references, original.references)
    XCTAssertEqual(retainedTag.content.name, "rainy-day")
    XCTAssertEqual(item.fieldHashes, beforeItem.fieldHashes)
    XCTAssertEqual(item.updatedAt, beforeItem.updatedAt)
    XCTAssertEqual(item.references, beforeItem.references)
    XCTAssertEqual(item.state.globalDone, false)
    XCTAssertEqual(item.state.archived, false)
    XCTAssertEqual(itinerary.content, beforeItinerary.content)
    XCTAssertEqual(itinerary.fieldHashes, beforeItinerary.fieldHashes)
    XCTAssertEqual(itinerary.updatedAt, beforeItinerary.updatedAt)
    XCTAssertEqual(itinerary.references, beforeItinerary.references)
    XCTAssertEqual(list.updatedAt, beforeList.updatedAt)
    XCTAssertEqual(list.references, beforeList.references)
    XCTAssertEqual(booking.content.form, fixture.form)
    XCTAssertEqual(item.labels.first { $0.reference == fixture.category }?.name, "Art and museums")
    XCTAssertEqual(
      itinerary.labels.first { $0.reference == fixture.category }?.name, "Art and museums")
    XCTAssertEqual(rows.rows.map(\.identity), [.source(fixture.item)])
    XCTAssertEqual(
      rows.rows.first?.labels.first { $0.reference == fixture.category }?.name, "Art and museums")
    for (appearance, expectedLocal) in [
      (
        PlannerAppearance.listMembership(
          listId: fixture.list.id, membershipId: fixture.membershipIdentifier), true
      ),
      (
        .directItineraryItem(itineraryId: fixture.itinerary.id, entryId: fixture.entryIdentifier),
        false
      ),
    ] {
      guard
        case .appearance(let saved) = await reopened.read(
          session: session, request: .appearance(appearance))
      else { return XCTFail("Label renaming cannot replace completion contexts.") }
      XCTAssertFalse(saved.globalDone)
      XCTAssertEqual(saved.localDone, expectedLocal)
    }
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}

private struct LabelRenameIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let category: PlannerEntityReference
  let tag: PlannerEntityReference
  let item: PlannerEntityReference
  let list: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let schedule: PlannerEntityReference
  let membershipIdentifier: UUID
  let entryIdentifier: UUID
  let form: PlannerScheduleForm
}

@MainActor
private func makeLabelRenameIntentFixture() async throws -> LabelRenameIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }
  let createdCategory = try await save(
    .createCategory(
      content: .init(
        name: "Museums", color: .init(red: 1, green: 0.5, blue: 0, alpha: 1),
        iconName: "building.columns")))
  let category = try XCTUnwrap(createdCategory.generated.first)
  let createdTag = try await save(
    .createTag(
      content: .init(
        name: "rainy-day", color: .init(red: 0, green: 0.5, blue: 1, alpha: 1),
        iconName: "cloud.rain")))
  let tag = try XCTUnwrap(createdTag.generated.first)
  let createdItem = try await save(
    .createItem(
      content: .init(
        title: "Museum", notes: "Keep booking", categoryIds: [category.id], tagIds: [tag.id])))
  let item = try XCTUnwrap(createdItem.generated.first)
  let createdList = try await save(.createList(content: .init(name: "Tokyo Food")))
  let list = try XCTUnwrap(createdList.generated.first)
  let createdMembership = try await save(
    .addMembership(itemId: item.id, listId: list.id, placement: .last))
  guard case .membership(let membership, _, _)? = createdMembership.generatedReferences.first else {
    throw CancellationError()
  }
  _ = try await save(
    .setCompletion(
      scope: .appearance(.listMembership(listId: list.id, membershipId: membership)), done: true))
  let createdItinerary = try await save(
    .createItinerary(
      content: .init(
        title: "Tokyo Weekend", notes: "Keep route", categoryIds: [category.id], tagIds: [tag.id])))
  let itinerary = try XCTUnwrap(createdItinerary.generated.first)
  let added = try await save(
    .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
  guard case .itineraryEntry(let entry, _, _)? = added.generatedReferences.first else {
    throw CancellationError()
  }
  let form = PlannerScheduleForm.allDay(
    start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
  let createdSchedule = try await save(.createSchedule(source: itinerary, form: form))
  let schedule = try XCTUnwrap(createdSchedule.generated.first)
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    category: category, tag: tag, item: item, list: list, itinerary: itinerary, schedule: schedule,
    membershipIdentifier: membership, entryIdentifier: entry, form: form)
}
