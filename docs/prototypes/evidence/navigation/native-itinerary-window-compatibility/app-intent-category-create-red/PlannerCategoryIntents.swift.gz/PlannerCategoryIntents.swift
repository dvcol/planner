#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerCategoryEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Category")
    static var defaultQuery: PlannerCategoryEntityQuery { PlannerCategoryEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String) {
      self.id = id
      self.name = name
    }
  }

  struct PlannerCategoryEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category identity lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category suggestions are not implemented.")
    }
  }

  struct CreatePlannerCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Category"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<
      PlannerCategoryEntity, Never, Never, IntentDialog
    >

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerCategoryIntentFailure(message: "Category creation is not implemented.")
    }
  }

  private struct PlannerCategoryIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
