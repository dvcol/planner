import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryEntryIntentTests: XCTestCase {
  func testRemovingOneRepeatedListEntryPreservesSourcesOtherContextsEmptyStopAndBooking()
    async throws
  {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Museum", notes: "Keep booking")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let createdList = try await save(.createList(content: .init(name: "Tokyo Food")))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdEmpty = try await save(.createList(content: .init(name: "Empty stop")))
    let emptyList = try XCTUnwrap(createdEmpty.generated.first)
    let createdMembership = try await save(
      .addMembership(itemId: item.id, listId: list.id, placement: .last))
    guard case .membership(let membership, _, _)? = createdMembership.generatedReferences.first
    else {
      return XCTFail("The shared List needs its own saved membership.")
    }
    _ = try await save(
      .setCompletion(
        scope: .appearance(.listMembership(listId: list.id, membershipId: membership)), done: true))
    let createdItinerary = try await save(
      .createItinerary(content: .init(title: "Tokyo Weekend", notes: "Keep route notes")))
    let itinerary = try XCTUnwrap(createdItinerary.generated.first)
    var entries: [UUID] = []
    for source in [item, list, emptyList, list] {
      let created = try await save(
        .addItineraryEntry(itineraryId: itinerary.id, source: source, placement: .last))
      guard case .itineraryEntry(let identifier, _, _)? = created.generatedReferences.first else {
        return XCTFail("Every top-level stop needs a distinct saved entry.")
      }
      entries.append(identifier)
    }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .expandedListItem(
            itineraryId: itinerary.id, listEntryId: entries[3], membershipId: membership)),
        done: true))
    let form = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let createdSchedule = try await save(.createSchedule(source: itinerary, form: form))
    let schedule = try XCTUnwrap(createdSchedule.generated.first)
    guard
      case .source(.item(let beforeItem)) = await planner.read(
        session: session, request: .source(item)),
      case .source(.list(let beforeList)) = await planner.read(
        session: session, request: .source(list))
    else { return XCTFail("Shared sources must be readable before removing one reference.") }
    let removal = RemovePlannerItineraryEntryIntent()
    removal.itinerary = .init(id: itinerary.id, title: "Cached route", archived: true)
    removal.entry = .init(
      id: "v1/entry/\(itinerary.id)/\(entries[1])/list/\(list.id)", title: "Cached",
      context: "Cached", kind: .item, archived: true)
    let _: Void = try await removal.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let savedItem)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let savedList)) = await reopened.read(
        session: reopenedSession, request: .source(list)),
      case .source(.list(let savedEmpty)) = await reopened.read(
        session: reopenedSession, request: .source(emptyList)),
      case .source(.itinerary(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let booking)) = await reopened.read(
        session: reopenedSession, request: .source(schedule))
    else {
      return XCTFail("Removing a reference must preserve its sources and other planning data.")
    }
    let route = saved.references.compactMap { reference -> UUID? in
      guard case .itineraryEntry(let identifier, _, _) = reference else { return nil }
      return identifier
    }
    XCTAssertEqual(route, [entries[0], entries[2], entries[3]])
    XCTAssertEqual(savedItem.fieldHashes, beforeItem.fieldHashes)
    XCTAssertEqual(savedItem.updatedAt, beforeItem.updatedAt)
    XCTAssertEqual(savedItem.state.globalDone, false)
    XCTAssertEqual(savedList.fieldHashes, beforeList.fieldHashes)
    XCTAssertEqual(savedList.updatedAt, beforeList.updatedAt)
    let survivingReferences = beforeList.references.filter { reference in
      guard case .itineraryEntry(let identifier, _, _) = reference else { return true }
      return identifier != entries[1]
    }
    XCTAssertEqual(savedList.references, survivingReferences)
    XCTAssertEqual(savedList.progress.doneCount, 1)
    XCTAssertEqual(savedEmpty.content.name, "Empty stop")
    XCTAssertEqual(saved.content.notes, "Keep route notes")
    XCTAssertEqual(saved.progress.totalCount, 2)
    XCTAssertEqual(saved.progress.doneCount, 1)
    XCTAssertEqual(booking.content.form, form)
    for (appearance, expectedLocal) in [
      (
        PlannerAppearance.directItineraryItem(itineraryId: itinerary.id, entryId: entries[0]), false
      ),
      (
        .expandedListItem(
          itineraryId: itinerary.id, listEntryId: entries[3], membershipId: membership), true
      ),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(appearance))
      else { return XCTFail("Surviving local contexts must remain readable.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocal)
    }
    let query = PlannerItineraryEntryEntityQuery()
    query.plannerStore = store
    let emptyIdentity = "v1/entry/\(itinerary.id)/\(entries[2])/list/\(emptyList.id)"
    let secondIdentity = "v1/entry/\(itinerary.id)/\(entries[3])/list/\(list.id)"
    let directIdentity = "v1/entry/\(itinerary.id)/\(entries[0])/item/\(item.id)"
    let resolved = try await query.entities(for: [
      emptyIdentity, removal.entry.id, secondIdentity, directIdentity,
    ])
    XCTAssertEqual(resolved.map(\.id), [emptyIdentity, secondIdentity, directIdentity])
    XCTAssertEqual(resolved.map(\.title), ["Empty stop", "Tokyo Food", "Museum"])
    XCTAssertEqual(
      resolved.map(\.context),
      [
        "Tokyo Weekend · Stop 2 · List", "Tokyo Weekend · Stop 3 · List",
        "Tokyo Weekend · Stop 1 · Item",
      ])
    XCTAssertEqual(resolved.map(\.kind), [.list, .list, .item])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
  func testBeforeReorderKeepsRepeatedItemIdentityCompletionEmptyStopAndBooking() async throws {
    let fixture = try await makeItineraryEntryIntentFixture()
    let form = PlannerScheduleForm.allDay(start: .init(year: 2026, month: 10, day: 20), end: nil)
    guard
      case .applied(let created, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .createSchedule(
            source: .init(kind: .itinerary, id: fixture.itinerary.id), form: form))
      ).outcome,
      let schedule = created.generated.first,
      case .source(.item(let beforeItem)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.item)),
      case .source(.list(let beforeList)) = await fixture.planner.read(
        session: fixture.session, request: .source(fixture.list))
    else { return XCTFail("The saved route needs real source and booking observations.") }
    let reorder = ReorderPlannerItineraryEntryIntent()
    reorder.itinerary = fixture.itinerary
    reorder.entry = fixture.entries[2]
    reorder.position = .before
    reorder.relativeEntry = fixture.entries[0]
    let _: Void = try await reorder.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.itinerary(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .itinerary, id: fixture.itinerary.id))),
      case .source(.item(let afterItem)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.list(let afterList)) = await reopened.read(
        session: session, request: .source(fixture.list)),
      case .source(.schedule(let booking)) = await reopened.read(
        session: session, request: .source(schedule)),
      case .snapshot(let manual) = await reopened.query(
        .init(
          session: session,
          request: .items(
            .init(
              scope: .itinerary(fixture.itinerary.id), completion: .all, archive: .all,
              sort: .init(mode: .manual)))))
    else { return XCTFail("Reordering must retain the entire graph after reopening.") }
    let route = saved.references.compactMap { reference -> UUID? in
      guard case .itineraryEntry(let identifier, _, _) = reference else { return nil }
      return identifier
    }
    XCTAssertEqual(
      route,
      [fixture.entryIdentifiers[2], fixture.entryIdentifiers[0], fixture.entryIdentifiers[1]])
    XCTAssertEqual(
      manual.rows,
      [
        .appearance(
          source: fixture.item,
          appearance: .directItineraryItem(
            itineraryId: fixture.itinerary.id, entryId: fixture.entryIdentifiers[2])),
        .appearance(
          source: fixture.item,
          appearance: .directItineraryItem(
            itineraryId: fixture.itinerary.id, entryId: fixture.entryIdentifiers[0])),
      ])
    XCTAssertEqual(afterItem.fieldHashes, beforeItem.fieldHashes)
    XCTAssertEqual(afterItem.updatedAt, beforeItem.updatedAt)
    XCTAssertEqual(afterList.fieldHashes, beforeList.fieldHashes)
    XCTAssertEqual(afterList.updatedAt, beforeList.updatedAt)
    XCTAssertEqual(afterList.references, beforeList.references)
    XCTAssertEqual(saved.progress.totalCount, 2)
    XCTAssertEqual(saved.progress.doneCount, 1)
    XCTAssertEqual(booking.content.form, form)
    for (entry, expectedLocal) in [
      (fixture.entryIdentifiers[0], true), (fixture.entryIdentifiers[2], false),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: session,
          request: .appearance(
            .directItineraryItem(itineraryId: fixture.itinerary.id, entryId: entry)))
      else { return XCTFail("Repeated stops must retain independent completion.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocal)
    }
  }
}

private struct ItineraryEntryIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let list: PlannerEntityReference
  let itinerary: PlannerItineraryEntity
  let entries: [PlannerItineraryEntryEntity]
  let entryIdentifiers: [UUID]
}

@MainActor
private func makeItineraryEntryIntentFixture() async throws -> ItineraryEntryIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }
  let createdItem = try await save(.createItem(content: .init(title: "Hotel", notes: "Keep notes")))
  let item = try XCTUnwrap(createdItem.generated.first)
  let createdList = try await save(.createList(content: .init(name: "Empty stop")))
  let list = try XCTUnwrap(createdList.generated.first)
  let createdItinerary = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
  let owner = try XCTUnwrap(createdItinerary.generated.first)
  var entries: [PlannerItineraryEntryEntity] = []
  var identifiers: [UUID] = []
  for source in [item, list, item] {
    let created = try await save(
      .addItineraryEntry(itineraryId: owner.id, source: source, placement: .last))
    guard case .itineraryEntry(let identifier, _, _)? = created.generatedReferences.first else {
      throw CancellationError()
    }
    identifiers.append(identifier)
    entries.append(
      .init(
        id: "v1/entry/\(owner.id)/\(identifier)/\(source.kind.rawValue)/\(source.id)",
        title: "Cached", context: "Cached", kind: source.kind == .list ? .list : .item,
        archived: false))
  }
  _ = try await save(
    .setCompletion(
      scope: .appearance(.directItineraryItem(itineraryId: owner.id, entryId: identifiers[0])),
      done: true))
  return .init(
    configuration: configuration, store: store, planner: planner, session: session, item: item,
    list: list, itinerary: .init(id: owner.id, title: "Cached route", archived: false),
    entries: entries, entryIdentifiers: identifiers)
}
