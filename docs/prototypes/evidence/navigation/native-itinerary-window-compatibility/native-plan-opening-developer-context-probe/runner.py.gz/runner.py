from pathlib import Path
import gzip,json,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
evidence=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=evidence/'native-plan-opening-developer-context-probe'
packet.mkdir(exist_ok=False)
before=subprocess.run(['launchctl','getenv','DEVELOPER_DIR'],capture_output=True,text=True,check=True).stdout.rstrip('\n')
report={'before':before,'probe':'/Applications/Xcode.app/Contents/Developer','temporaryUserContextOnly':True,'protectedBrokerRestarted':False,'restored':False}
(packet/'environment.json').write_text(json.dumps(report,indent=2)+'\n')
result=None
try:
    changed=subprocess.run(['launchctl','setenv','DEVELOPER_DIR',report['probe']],capture_output=True,text=True)
    report['setenvExitCode']=changed.returncode;report['setenvStderr']=changed.stderr
    if changed.returncode!=0:raise SystemExit(changed.returncode)
    current=subprocess.run(['launchctl','getenv','DEVELOPER_DIR'],capture_output=True,text=True,check=True).stdout.rstrip('\n')
    assert current==report['probe']
    result=subprocess.run([sys.executable,'/private/tmp/PlannerOpeningUIQualification.py','native-plan-opening-phone-developer-context','SavedAppearanceJourneyTests/testCreatingFirstListInLandscapeLoadsItsContents','phone'],cwd=repository,timeout=720)
    report['testRunnerExitCode']=result.returncode
finally:
    command=['launchctl','setenv','DEVELOPER_DIR',before] if before else ['launchctl','unsetenv','DEVELOPER_DIR']
    restored=subprocess.run(command,capture_output=True,text=True)
    after=subprocess.run(['launchctl','getenv','DEVELOPER_DIR'],capture_output=True,text=True).stdout.rstrip('\n')
    report['restoreExitCode']=restored.returncode;report['after']=after;report['restored']=restored.returncode==0 and after==before
    (packet/'environment.json').write_text(json.dumps(report,indent=2)+'\n')
    (packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
    assert report['restored'],report
print('Developer context restored; test exit',None if result is None else result.returncode,flush=True)
if result is not None:raise SystemExit(result.returncode)
