import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerCategoryIntentTests: XCTestCase {
  func testCreateCategoryReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerCategoryIntent()
    creation.name = "Museums"
    let category = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(category.name, "Museums")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.category(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .category, id: category.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .category, archive: .all))))
    else { return XCTFail("The returned Category must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, category.id)
    XCTAssertEqual(current.content.name, "Museums")
    XCTAssertNil(current.content.color)
    XCTAssertNil(current.content.iconName)
    XCTAssertNil(current.state.archived)
    XCTAssertNil(current.state.globalDone)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .category, id: category.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
