from pathlib import Path
import json, os, subprocess, gzip, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd() == repository
phase = sys.argv[1]
packet = repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'/phase
packet.mkdir(exist_ok=False)
environment = dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
identifier = 'FBD72DAB-1D40-4E64-912D-7F9763E00446'
prior = json.loads((repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-calendar-modes-qualified-tablet-retry/test-results-summary.json').read_text())
assert prior['devicesAndConfigurations'][0]['device']['deviceId'] == identifier
inventory = subprocess.run(['xcrun','simctl','list','devices','available','--json'],capture_output=True,text=True,env=environment,check=True)
devices = [device for group in json.loads(inventory.stdout)['devices'].values() for device in group if device['udid'] == identifier]
assert len(devices) == 1
observed = {'udid':identifier,'name':devices[0]['name'],'beforeState':devices[0]['state'],'commands':[]}
assert observed['beforeState'] in ['Booted','Shutdown']
commands = []
if observed['beforeState'] == 'Booted': commands.append(['xcrun','simctl','shutdown',identifier])
commands += [['xcrun','simctl','boot',identifier],['xcrun','simctl','bootstatus',identifier,'-b']]
for command in commands:
    result = subprocess.run(command,capture_output=True,text=True,env=environment,timeout=180)
    observed['commands'].append({'command':command,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    (packet/'boot.json').write_text(json.dumps(observed,indent=2)+'\n')
    assert result.returncode == 0, command
observed['completed'] = True
(packet/'boot.json').write_text(json.dumps(observed,indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'device':observed['name'],'beforeState':observed['beforeState'],'completed':True,'commands':len(commands)}))
