from pathlib import Path
import gzip,hashlib,json,os,plistlib,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
evidence=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=evidence/phase
assert json.loads((packet/'exit.json').read_text())['exitCode']==0
prior=json.loads((evidence/'app-intent-item-subtitle-final-qualification/extracted-intent-identifiers.json').read_text())
paths={
'mac':'/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
'mobile':'/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
'device':'/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata'}
metadata_bytes=Path(paths[platform]).read_bytes()
metadata=json.loads(metadata_bytes)
expected_actions={
'ClearPlannerItemEstimateIntent':('item','PlannerItemEntity'),
'UsePlannerListCalculatedEstimateIntent':('list','PlannerListEntity'),
'UsePlannerItineraryCalculatedEstimateIntent':('itinerary','PlannerItineraryEntity')}
assert set(metadata['actions'])==set(prior['actions'])|set(expected_actions)
assert sorted(metadata['entities'])==prior['entities']
assert sorted(metadata['queries'])==prior['queries']
enum_cases={entry['identifier']:{case['identifier']:case['displayRepresentation']['title']['key'] for case in entry['cases']} for entry in metadata['enums']}
assert enum_cases==prior['enumCases']
retained_parameter_contracts={}
for identifier,previous in prior['parameterContracts'].items():
 parameters={parameter['name']:{'optional':parameter['isOptional'],'valueType':parameter['valueType']} for parameter in metadata['actions'][identifier]['parameters']}
 assert parameters==previous
 retained_parameter_contracts[identifier]=parameters
parameter_contracts={}
for identifier,(name,type_name) in expected_actions.items():
 action=metadata['actions'][identifier]
 parameters={parameter['name']:parameter for parameter in action['parameters']}
 assert set(parameters)=={name}
 assert parameters[name]['isOptional'] is False
 assert parameters[name]['valueType']=={'entity':{'wrapper':{'typeName':type_name}}}
 assert action['isDiscoverable'] is True
 parameter_contracts[identifier]={'parameter':name,'entityType':type_name,'optional':False}
result={'actions':sorted(metadata['actions']),'entities':sorted(metadata['entities']),'queries':sorted(metadata['queries']),'enumCases':enum_cases,'parameterContracts':parameter_contracts,'retainedParameterContracts':retained_parameter_contracts,'metadataSha256':hashlib.sha256(metadata_bytes).hexdigest(),'catalogExtensionVerified':True,'systemInvocationCredit':False,'metadataRuntimeCredit':False}
(packet/'extracted-intent-identifiers.json').write_text(json.dumps(result,indent=2)+'\n')
hashes=json.loads((packet/'source-sha256.json').read_text())
prior_hashes=json.loads((evidence/'app-intent-item-subtitle-final-qualification/source-sha256.json').read_text())
assert all(hashes[path]==digest for path,digest in prior_hashes.items())
added=sorted(set(hashes)-set(prior_hashes))
assert added==['Planner/AppIntents/PlannerEstimateResetIntents.swift','PlannerMCPTests/PlannerEstimateResetIntentTests.swift']
for path,digest in hashes.items():
 assert hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256((Path('/private/tmp/PlannerNativeItemWindowSource')/path).read_bytes()).hexdigest()==digest,path
(packet/'current-source-verification.json').write_text(json.dumps({'success':True,'verifiedInputCount':len(hashes),'unchangedPriorInputCount':len(prior_hashes),'addedInputs':added},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
if platform=='mac':
 bundle=json.loads((packet/'exit.json').read_text())['bundle']
 summary_bytes=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',bundle,'--compact'],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 summary=json.loads(summary_bytes)
 assert summary['passedTests']==41 and summary['failedTests']==0 and summary['skippedTests']==0
 (packet/'test-results-summary.json').write_bytes(summary_bytes.rstrip()+b'\n')
 log=Path('/private/tmp/PlannerItemWindow-'+phase+'.log').read_text()
 diagnostics=[line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
 (packet/'compiler-diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
 print('tests',summary['passedTests'],'failures',summary['failedTests'],'skipped',summary['skippedTests'],'compiler diagnostics',len(diagnostics))
if platform=='device':
 app=Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
 extensions=list((app/'PlugIns').glob('*.appex'))
 assert len(extensions)==1
 products=[]
 for product in [app,*extensions]:
  values=plistlib.loads((product/'Info.plist').read_bytes())
  executable=product/values['CFBundleExecutable']
  architectures=subprocess.check_output(['lipo','-archs',str(executable)],text=True).split()
  assert architectures==['arm64']
  products.append({'bundleIdentifier':values['CFBundleIdentifier'],'executable':str(executable),'architectures':architectures,'sha256':hashlib.sha256(executable.read_bytes()).hexdigest()})
 (packet/'embedded-products-verification.json').write_text(json.dumps({'products':products,'embeddedMobileShareCount':1,'signingAllowed':False,'installedOrLaunched':False},indent=2)+'\n')
print(platform,'metadata',len(metadata['actions']),len(metadata['entities']),len(metadata['queries']),'verified inputs',len(hashes))
