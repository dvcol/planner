from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=Path('/private/tmp/PlannerNativeItemWindowSource')
derived=Path('/private/tmp/PlannerShareMigrationMacDerivedData')
base=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
preparation=base/'native-share-migration-archive-build'
packet=base/'native-share-migration-final-mac-build'
packet.mkdir(exist_ok=False)
manifest=json.loads((preparation/'source-sha256.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
for name in ['source-sha256.json','source-root.json']:
 (packet/name).write_bytes((preparation/name).read_bytes())
(packet/'workspace-revision.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
command=['xcodebuild','build-for-testing','-project','Planner.xcodeproj','-scheme','PlannerFixtures','-destination','platform=macOS,arch=arm64','-derivedDataPath',str(derived),'-clonedSourcePackagesDirPath','/private/tmp/PlannerCalendarMonthSourcePackages','-disableAutomaticPackageResolution','-parallel-testing-enabled','NO','-jobs','1','-only-testing:PlannerFixtureUITests','CODE_SIGNING_ALLOWED=YES','CODE_SIGN_IDENTITY=-','CODE_SIGN_STYLE=Manual','DEVELOPMENT_TEAM=','ARCHS=arm64','ONLY_ACTIVE_ARCH=YES']
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
log=Path('/private/tmp/PlannerShareMigrationFinalMacBuild.log')
with log.open('wb') as output:
 result=subprocess.run(command,cwd=root,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
unchanged=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items())
(packet/'build.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'inputsUnchanged':unchanged,'runtimeCredit':False},indent=2)+'\n')
assert unchanged
if result.returncode==0:
 products={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in (derived/'Build/Products').rglob('*') if path.is_file() and (path.name in ['PlannerFixtures','PlannerFixtures.debug.dylib','PlannerFixtureUITests-Runner','PlannerFixtureUITests'] or path.name.endswith('.xctestrun'))}
 assert products
 (packet/'product-sha256.json').write_text(json.dumps(products,indent=2)+'\n')
 resources=root/'Packages/PlannerCore/Tests/PlannerCoreStoreTests/Fixtures/SchemaV1'
 bundle=derived/'Build/Products/Debug/PlannerFixtures.app/Contents/Resources/SchemaV1'
 checks={str(path.relative_to(resources)):{'source':hashlib.sha256(path.read_bytes()).hexdigest(),'bundled':hashlib.sha256((bundle/path.relative_to(resources)).read_bytes()).hexdigest()} for path in resources.rglob('*') if path.is_file()}
 assert len(checks)==14 and all(value['source']==value['bundled'] for value in checks.values())
 (packet/'schema-resource-sha256.json').write_text(json.dumps(checks,indent=2)+'\n')
print('Mac fixture compiler exit',result.returncode,'frozen inputs unchanged',unchanged)
for line in log.read_text(errors='replace').splitlines():
 if line.startswith(('** TEST','** BUILD','error:')) or ('.swift:' in line and ': error:' in line): print(line[:600])
raise SystemExit(result.returncode)
