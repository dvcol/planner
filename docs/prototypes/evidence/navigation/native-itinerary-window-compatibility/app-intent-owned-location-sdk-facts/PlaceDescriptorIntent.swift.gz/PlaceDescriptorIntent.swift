import AppIntents
import CoreLocation
import GeoToolbox
struct OwnedPinProbeIntent: AppIntent {
 static let title: LocalizedStringResource = "Owned Pin Probe"
 @Parameter(title: "Location") var location: PlaceDescriptor
 static var parameterSummary: some ParameterSummary { Summary("Use \(\.$location)") }
 func perform() async throws -> some IntentResult {
  guard let coordinate = location.coordinate,
   coordinate.latitude.isFinite, coordinate.longitude.isFinite,
   CLLocationCoordinate2DIsValid(coordinate) else { return .result() }
  return .result()
 }
}
func input() -> PlaceDescriptor {
 PlaceDescriptor(representations: [.coordinate(.init(latitude: 35.66, longitude: 139.72))], commonName: nil)
}
func addressOnlyInput() -> PlaceDescriptor {
 PlaceDescriptor(representations: [.address("Tokyo, Japan")], commonName: nil)
}
func deviceInput() -> PlaceDescriptor {
 PlaceDescriptor(representations: [.deviceLocation(CLLocation(latitude: 35.66, longitude: 139.72))], commonName: nil)
}

func explicitCoordinate(from descriptor: PlaceDescriptor) -> CLLocationCoordinate2D? {
 var selectedCoordinate: CLLocationCoordinate2D?
 for representation in descriptor.representations {
  let coordinate: CLLocationCoordinate2D
  switch representation {
  case .coordinate(let value): coordinate = value
  case .deviceLocation(let location): coordinate = location.coordinate
  case .address: continue
  @unknown default: return nil
  }
  guard coordinate.latitude.isFinite, coordinate.longitude.isFinite,
   CLLocationCoordinate2DIsValid(coordinate) else { return nil }
  if let previousCoordinate = selectedCoordinate {
   guard previousCoordinate.latitude == coordinate.latitude,
    previousCoordinate.longitude == coordinate.longitude else { return nil }
  }
  selectedCoordinate = coordinate
 }
 return selectedCoordinate
}
