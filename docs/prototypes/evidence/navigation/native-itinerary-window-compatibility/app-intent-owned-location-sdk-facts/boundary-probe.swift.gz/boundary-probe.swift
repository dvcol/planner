import CoreLocation
import GeoToolbox
let representations: [PlaceDescriptor.PlaceRepresentation]
switch CommandLine.arguments[1] {
case "empty": representations = []
case "address": representations = [.address("Tokyo, Japan")]
case "latitude": representations = [.coordinate(.init(latitude: 91, longitude: 0))]
case "longitude": representations = [.coordinate(.init(latitude: 0, longitude: -181))]
case "nan": representations = [.coordinate(.init(latitude: .nan, longitude: 0))]
case "infinity": representations = [.coordinate(.init(latitude: 0, longitude: .infinity))]
case "conflicting": representations = [.coordinate(.init(latitude: 1, longitude: 2)), .coordinate(.init(latitude: 3, longitude: 4))]
default: fatalError("Unknown probe case")
}
let location = PlaceDescriptor(representations: representations, commonName: "Probe")
print(location.representations.count)
