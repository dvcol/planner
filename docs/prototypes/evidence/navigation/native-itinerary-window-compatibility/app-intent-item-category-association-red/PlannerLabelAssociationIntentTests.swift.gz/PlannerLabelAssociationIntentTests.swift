import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerLabelAssociationIntentTests: XCTestCase {
  func testItemCategoryAssignmentPreservesSharedLabelsAndOtherOwnerDataAfterReopen() async throws {
    let fixture = try await makeLabelAssociationIntentFixture()
    let assign = SetPlannerItemCategoryIntent()
    assign.item = .init(id: fixture.item.id, title: "Cached Item", done: true, archived: false)
    assign.category = .init(id: fixture.extraCategory.id, name: "Cached Category")
    assign.assigned = true
    let _: Void = try await assign.callAsFunction(donate: false)
    let _: Void = try await assign.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let item)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.itinerary(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.itinerary)),
      case .source(.category(let category)) = await reopened.read(
        session: session, request: .source(fixture.extraCategory))
    else { return XCTFail("The assignment and its shared sources must survive reopening.") }
    XCTAssertEqual(item.content.categoryIds, [fixture.category.id, fixture.extraCategory.id])
    XCTAssertEqual(item.content.tagIds, [fixture.tag.id])
    XCTAssertEqual(item.content.title, "Museum")
    XCTAssertEqual(item.content.notes, "Keep booking")
    XCTAssertEqual(item.state.globalDone, true)
    XCTAssertEqual(item.state.archived, false)
    XCTAssertEqual(item.labels.first { $0.reference == fixture.extraCategory }?.name, "Outdoors")
    XCTAssertEqual(category.content.name, "Outdoors")
    XCTAssertEqual(itinerary.content.categoryIds, [fixture.category.id])
    assign.assigned = false
    let _: Void = try await assign.callAsFunction(donate: false)
    let _: Void = try await assign.callAsFunction(donate: false)
    guard
      case .source(.item(let detached)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.category(let retained)) = await reopened.read(
        session: session, request: .source(fixture.extraCategory))
    else { return XCTFail("Unassigning must retain both owner and shared label.") }
    XCTAssertEqual(detached.content.categoryIds, [fixture.category.id])
    XCTAssertEqual(detached.content.tagIds, [fixture.tag.id])
    XCTAssertEqual(retained.content, category.content)
    XCTAssertEqual(retained.updatedAt, category.updatedAt)
    try await assertAssociationFixtureContextPreserved(fixture, planner: reopened, session: session)
  }
}

private struct LabelAssociationIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let category: PlannerEntityReference
  let extraCategory: PlannerEntityReference
  let tag: PlannerEntityReference
  let extraTag: PlannerEntityReference
  let item: PlannerEntityReference
  let list: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let schedule: PlannerEntityReference
  let membershipIdentifier: UUID
  let entryIdentifier: UUID
}

@MainActor
private func makeLabelAssociationIntentFixture() async throws -> LabelAssociationIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }
  let createdCategory = try await save(.createCategory(content: .init(name: "Museums")))
  let category = try XCTUnwrap(createdCategory.generated.first)
  let createdExtraCategory = try await save(.createCategory(content: .init(name: "Outdoors")))
  let extraCategory = try XCTUnwrap(createdExtraCategory.generated.first)
  let createdTag = try await save(.createTag(content: .init(name: "rainy-day")))
  let tag = try XCTUnwrap(createdTag.generated.first)
  let createdExtraTag = try await save(.createTag(content: .init(name: "booked")))
  let extraTag = try XCTUnwrap(createdExtraTag.generated.first)
  let createdItem = try await save(
    .createItem(
      content: .init(
        title: "Museum", notes: "Keep booking", categoryIds: [category.id], tagIds: [tag.id])))
  let item = try XCTUnwrap(createdItem.generated.first)
  _ = try await save(.setCompletion(scope: .globalItem(itemId: item.id), done: true))
  let createdList = try await save(.createList(content: .init(name: "Tokyo Food")))
  let list = try XCTUnwrap(createdList.generated.first)
  let addedMembership = try await save(
    .addMembership(itemId: item.id, listId: list.id, placement: .last))
  guard
    case .membership(let membershipIdentifier, _, _)? = addedMembership.generatedReferences.first
  else { throw CancellationError() }
  let createdItinerary = try await save(
    .createItinerary(
      content: .init(
        title: "Tokyo Weekend", notes: "Keep route", categoryIds: [category.id], tagIds: [tag.id])))
  let itinerary = try XCTUnwrap(createdItinerary.generated.first)
  let addedEntry = try await save(
    .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
  guard case .itineraryEntry(let entryIdentifier, _, _)? = addedEntry.generatedReferences.first
  else { throw CancellationError() }
  _ = try await save(
    .setCompletion(
      scope: .appearance(
        .directItineraryItem(
          itineraryId: itinerary.id, entryId: entryIdentifier)), done: true))
  let createdSchedule = try await save(
    .createSchedule(
      source: itinerary,
      form: .allDay(
        start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))))
  let schedule = try XCTUnwrap(createdSchedule.generated.first)
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    category: category, extraCategory: extraCategory, tag: tag, extraTag: extraTag,
    item: item, list: list, itinerary: itinerary, schedule: schedule,
    membershipIdentifier: membershipIdentifier, entryIdentifier: entryIdentifier)
}

@MainActor
private func assertAssociationFixtureContextPreserved(
  _ fixture: LabelAssociationIntentFixture, planner: PlannerCore.Planner,
  session: PlannerDatasetSession
) async throws {
  guard
    case .source(.list(let list)) = await planner.read(
      session: session, request: .source(fixture.list)),
    case .source(.itinerary(let itinerary)) = await planner.read(
      session: session, request: .source(fixture.itinerary)),
    case .appearance(let membership) = await planner.read(
      session: session,
      request: .appearance(
        .listMembership(listId: fixture.list.id, membershipId: fixture.membershipIdentifier))),
    case .appearance(let entry) = await planner.read(
      session: session,
      request: .appearance(
        .directItineraryItem(itineraryId: fixture.itinerary.id, entryId: fixture.entryIdentifier))),
    case .source(.schedule(let schedule)) = await planner.read(
      session: session, request: .source(fixture.schedule))
  else { return XCTFail("Label edits must retain original organization, completion and bookings.") }
  XCTAssertEqual(list.content.name, "Tokyo Food")
  XCTAssertEqual(itinerary.content.title, "Tokyo Weekend")
  XCTAssertEqual(itinerary.content.notes, "Keep route")
  XCTAssertFalse(membership.localDone)
  XCTAssertTrue(membership.globalDone)
  XCTAssertTrue(entry.localDone)
  XCTAssertTrue(entry.globalDone)
  XCTAssertEqual(
    schedule.content.form,
    .allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21)))
  XCTAssertFalse(fixture.store.recoveryBlocked)
  XCTAssertFalse(fixture.store.isSaving)
}
