#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerCategoryEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Category")
    static var defaultQuery: PlannerCategoryEntityQuery { PlannerCategoryEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String) {
      self.id = id
      self.name = name
    }
  }

  struct PlannerCategoryEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category identity lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category suggestions are not implemented.")
    }
  }

  struct CreatePlannerCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Category"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<
      PlannerCategoryEntity, Never, Never, IntentDialog
    >

    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(.createCategory(content: .init(name: name)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerCategoryIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerCategoryIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .category }) else {
          throw PlannerCategoryIntentFailure(
            message:
              "Planner applied this change without returning its Category. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(name)."
        case .incomplete:
          dialog =
            "The Category was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(value: PlannerCategoryEntity(id: source.id, name: name), dialog: dialog)
      }
    }
  }

  struct GetPlannerCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Get Category"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Category") var category: PlannerCategoryEntity
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerCategoryEntity, Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerCategoryIntentFailure(message: "Get Category is not implemented.")
    }
  }

  private struct PlannerCategoryIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
