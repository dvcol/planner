#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerItemEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Item")
    static var defaultQuery: PlannerItemEntityQuery { PlannerItemEntityQuery() }
    let id: UUID
    @Property(title: "Title") var title: String
    @Property(title: "Completed everywhere") var done: Bool
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(title)") }

    init(id: UUID, title: String, done: Bool, archived: Bool) {
      self.id = id
      self.title = title
      self.done = done
      self.archived = archived
    }

    init(source: PlannerItemSourceRead) throws {
      guard let done = source.state.globalDone, let archived = source.state.archived else {
        throw PlannerIntentFailure(message: "Planner could not read this Item's state.")
      }
      self.init(id: source.source.id, title: source.content.title, done: done, archived: archived)
    }

    init(row: PlannerRowRead) throws {
      guard case .source(let source) = row.identity, source.kind == .item,
        let done = row.globalDone, let archived = row.archived
      else { throw PlannerIntentFailure(message: "Planner could not read its Item choices.") }
      self.init(id: source.id, title: row.title, done: done, archived: archived)
    }
  }

  struct PlannerItemEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore
    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerItemEntity] {
      let (planner, session) = try await plannerStore.appIntentContext()
      var seenIdentifiers: Set<UUID> = []
      var entities: [PlannerItemEntity] = []
      for identifier in identifiers where seenIdentifiers.insert(identifier).inserted {
        try Task.checkCancellation()
        switch await planner.read(
          session: session, request: .source(.init(kind: .item, id: identifier)))
        {
        case .source(.item(let source)): entities.append(try PlannerItemEntity(source: source))
        case .failed(let reason) where reason.code == "missingReference": continue
        case .failed(let reason): throw PlannerIntentFailure(message: reason.message)
        default: throw PlannerIntentFailure(message: "Planner could not resolve this Item.")
        }
      }
      return entities
    }
    @MainActor func entities(matching string: String) async throws -> [PlannerItemEntity] {
      try await loadItems(matching: string)
    }
    @MainActor func suggestedEntities() async throws -> [PlannerItemEntity] {
      try await loadItems(matching: "")
    }

    @MainActor private func loadItems(matching text: String) async throws -> [PlannerItemEntity] {
      let (planner, session) = try await plannerStore.appIntentContext()
      let snapshot: PlannerQuerySnapshot
      switch await planner.query(
        .init(
          session: session,
          request: .items(.init(text: text, completion: .all, archive: .all))))
      {
      case .snapshot(let current): snapshot = current
      case .failed(let reason): throw PlannerIntentFailure(message: reason.message)
      }
      var entities: [PlannerItemEntity] = []
      var offset: Int64 = 0
      while offset < snapshot.matchingCount {
        try Task.checkCancellation()
        switch await planner.read(
          session: session,
          request: .rows(generation: snapshot.generation, offset: offset, limit: 64))
        {
        case .rows(let window):
          guard !window.rows.isEmpty else {
            throw PlannerIntentFailure(message: "Planner could not load all matching Item choices.")
          }
          entities.append(contentsOf: try window.rows.map(PlannerItemEntity.init(row:)))
          offset += Int64(window.rows.count)
        case .failed(let reason): throw PlannerIntentFailure(message: reason.message)
        default: throw PlannerIntentFailure(message: "Planner could not read its Item choices.")
        }
      }
      return entities
    }
  }

  struct CreatePlannerItemIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Item"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Title") var title: String
    @Parameter(title: "Notes") var notes: String?
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerItemEntity, Never, Never, IntentDialog>
    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(
        .createItem(content: .init(title: title, notes: notes)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .item }) else {
          throw PlannerIntentFailure(
            message:
              "Planner applied this change without returning its Item. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(title)."
        case .incomplete:
          dialog =
            "The Item was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(
          value: PlannerItemEntity(id: source.id, title: title, done: false, archived: false),
          dialog: dialog)
      }
    }
  }

  struct GetPlannerItemIntent: AppIntent {
    static let title: LocalizedStringResource = "Get Item"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Item") var item: PlannerItemEntity
    typealias PerformResult = IntentResultContainer<PlannerItemEntity, Never, Never, Never>

    func perform() async throws -> PerformResult {
      throw NSError(
        domain: "PlannerIntentImplementation", code: 2,
        userInfo: [NSLocalizedDescriptionKey: "Planner Item reading is not implemented."])
    }
  }

  private struct PlannerIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }

#endif
