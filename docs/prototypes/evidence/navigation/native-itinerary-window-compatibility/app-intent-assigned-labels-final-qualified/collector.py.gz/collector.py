from pathlib import Path
import gzip, hashlib, json, os, plistlib, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = evidence / phase
assert json.loads((packet / 'exit.json').read_text())['exitCode'] == 0
baseline = evidence / 'app-intent-item-destination-final-clean'
prior = json.loads((baseline / 'extracted-intent-identifiers.json').read_text())
prior_metadata = json.loads(gzip.decompress((baseline / 'extract.actionsdata.gz').read_bytes()))
paths = {
    'mac': '/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
    'mobile': '/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
    'device': '/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata',
}
metadata_bytes = Path(paths[platform]).read_bytes()
metadata = json.loads(metadata_bytes)
new_actions = {'GetPlannerItemCategoriesIntent': ('item', 'PlannerItemEntity', 'PlannerCategoryEntity'), 'GetPlannerItemTagsIntent': ('item', 'PlannerItemEntity', 'PlannerTagEntity'), 'GetPlannerItineraryCategoriesIntent': ('itinerary', 'PlannerItineraryEntity', 'PlannerCategoryEntity'), 'GetPlannerItineraryTagsIntent': ('itinerary', 'PlannerItineraryEntity', 'PlannerTagEntity')}
assert set(metadata['actions']) == set(prior['actions']) | set(new_actions) and len(metadata['actions']) == 57
assert sorted(metadata['entities']) == prior['entities'] and sorted(metadata['queries']) == prior['queries']
contracts = {identifier: {parameter['name']: {'optional': parameter['isOptional'], 'valueType': parameter['valueType']} for parameter in action['parameters']} for identifier, action in metadata['actions'].items()}
expected = dict(prior['parameterContracts'])
for identifier, (owner, owner_type, result_type) in new_actions.items():
    expected[identifier] = {owner: {'optional': False, 'valueType': {'entity': {'wrapper': {'typeName': owner_type}}}}}
assert contracts == expected
outputs = {identifier: action.get('outputType') for identifier, action in metadata['actions'].items()}
expected_outputs = {identifier: action.get('outputType') for identifier, action in prior_metadata['actions'].items()}
for identifier, (owner, owner_type, result_type) in new_actions.items():
    expected_outputs[identifier] = {'array': {'wrapper': {'capabilities': 3, 'memberValueType': {'entity': {'wrapper': {'typeName': result_type}}}}}}
    assert metadata['actions'][identifier]['isDiscoverable'] is True
assert outputs == expected_outputs
assert metadata['queries'] == prior_metadata['queries']
assert metadata['entities'] == prior_metadata['entities']
assert metadata['enums'] == prior_metadata['enums']
result = dict(prior, actions=sorted(metadata['actions']), parameterContracts=contracts, outputContracts=outputs, metadataSha256=hashlib.sha256(metadata_bytes).hexdigest(), entityContractsUnchanged=True, queryContractsUnchanged=True, enumContractsUnchanged=True, systemInvocationQualified=False, systemDependencyInjectionQualified=False)
(packet / 'extracted-intent-identifiers.json').write_text(json.dumps(result, indent=2) + '\n')
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes, mtime=0))
source_hashes = json.loads((packet / 'source-sha256.json').read_text())
prior_hashes = json.loads((baseline / 'source-sha256.json').read_text())
changed = sorted(relative for relative, digest in prior_hashes.items() if source_hashes.get(relative) != digest)
added = sorted(set(source_hashes) - set(prior_hashes))
assert changed == ['Planner/AppIntents/PlannerLabelAssociationIntents.swift', 'PlannerMCPTests/PlannerLabelAssociationIntentTests.swift'], changed
assert added == ['PlannerMCPTests/PlannerAssignedLabelIntentTests.swift'] and len(source_hashes) == 1029
assert all(hashlib.sha256((repository / relative).read_bytes()).hexdigest() == digest for relative, digest in source_hashes.items())
(packet / 'baseline-source-comparison.json').write_text(json.dumps({'priorInputs': len(prior_hashes), 'currentInputs': len(source_hashes), 'changedInputs': changed, 'addedInputs': added, 'otherPriorInputsUnchanged': True}, indent=2) + '\n')
if platform == 'mac':
    summary = json.loads((packet / 'test-results-summary.json').read_text())
    assert summary['passedTests'] == 41 and summary['failedTests'] == 0 and summary['skippedTests'] == 0
    lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] is True and len(lifecycle['removedDirectories']) == 46
else:
    assert source_hashes == json.loads((evidence / 'app-intent-assigned-labels-final-qualified/source-sha256.json').read_text())
log_path = packet / 'build.log.gz'
if not log_path.exists():
    log_path = packet / 'test.log.gz'
log = gzip.decompress(log_path.read_bytes()).decode(errors='replace')
diagnostics = [line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet / 'compiler-diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
assert not diagnostics, diagnostics
assert not any(phrase in log for phrase in ['vnode unlinked while in use', 'database integrity compromised', 'file descriptor is invalidated'])
if platform == 'device':
    app = Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
    extensions = list((app / 'PlugIns').glob('*.appex'))
    assert len(extensions) == 1
    products = []
    for product in [app, *extensions]:
        values = plistlib.loads((product / 'Info.plist').read_bytes())
        executable = product / values['CFBundleExecutable']
        architectures = subprocess.check_output(['lipo', '-archs', str(executable)], text=True).split()
        assert architectures == ['arm64']
        products.append({'bundleIdentifier': values['CFBundleIdentifier'], 'architectures': architectures, 'sha256': hashlib.sha256(executable.read_bytes()).hexdigest()})
    (packet / 'embedded-products-verification.json').write_text(json.dumps({'products': products, 'embeddedMobileShareCount': 1, 'signingAllowed': False, 'installedOrLaunched': False}, indent=2) + '\n')
(packet / 'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(platform, 'verified: 57 actions including four typed label-array reads, prior entity/query/enum/result contracts preserved;', len(source_hashes), 'matching inputs; compiler diagnostics', len(diagnostics))
