import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class SavedPlanOpeningTests: XCTestCase {
  func testColdRequestWaitsForOneReadyWindowAndResolvesOnlyItsExactPlan() async throws {
    let (_, _, store) = try makePlannerIntentStorage()
    let result = try await store.executeAppIntent(.createList(content: .init(name: "Tokyo Food")))
    let source = try XCTUnwrap(result.generated.first { $0.kind == .list })
    let opening = SavedPlanOpeningCoordinator()
    let request = try await opening.submit(source: source, store: store)
    XCTAssertEqual(opening.pending?.identifier, request.identifier)
    XCTAssertNil(opening.pending?.windowIdentifier)
    let recipient = UUID()
    let otherWindow = UUID()
    opening.register(windowIdentifier: recipient, isActive: true, isReady: true)
    opening.register(windowIdentifier: otherWindow, isActive: false, isReady: true)
    let otherClaim = try await opening.claim(windowIdentifier: otherWindow, store: store)
    XCTAssertNil(otherClaim)
    let claim = try await opening.claim(windowIdentifier: recipient, store: store)
    XCTAssertEqual(claim?.identifier, request.identifier)
    let repeatedClaim = try await opening.claim(windowIdentifier: recipient, store: store)
    XCTAssertNil(repeatedClaim)
    XCTAssertNotNil(opening.pending)
    let target = try await opening.resolveNavigation(
      requestIdentifier: request.identifier, windowIdentifier: recipient, store: store)
    XCTAssertEqual(target, source)
    XCTAssertNil(opening.pending)
  }
}
