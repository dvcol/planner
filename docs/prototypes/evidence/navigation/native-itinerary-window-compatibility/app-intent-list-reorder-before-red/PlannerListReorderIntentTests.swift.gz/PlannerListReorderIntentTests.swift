import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerListReorderIntentTests: XCTestCase {
  func testBeforePlacementPreservesIdentitiesContextsContentEstimatesAndScheduleAfterReopen()
    async throws
  {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let createdAlpha = try await save(
      .createItem(
        content: .init(title: "Alpha", estimate: .init(minutes: 15, displayUnit: .minute))))
    let alpha = try XCTUnwrap(createdAlpha.generated.first)
    let createdMiddle = try await save(
      .createItem(
        content: .init(title: "Middle", estimate: .init(minutes: 30, displayUnit: .minute))))
    let middle = try XCTUnwrap(createdMiddle.generated.first)
    let createdZulu = try await save(
      .createItem(
        content: .init(
          title: "Zulu", notes: "Shared notes", estimate: .init(minutes: 45, displayUnit: .minute)))
    )
    let zulu = try XCTUnwrap(createdZulu.generated.first)
    let createdList = try await save(.createList(content: .init(name: "Tokyo Food")))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdOther = try await save(.createList(content: .init(name: "Wishlist")))
    let otherList = try XCTUnwrap(createdOther.generated.first)
    let alphaMembership = try await save(
      .addMembership(itemId: alpha.id, listId: list.id, placement: .last))
    let middleMembership = try await save(
      .addMembership(itemId: middle.id, listId: list.id, placement: .last))
    let zuluMembership = try await save(
      .addMembership(itemId: zulu.id, listId: list.id, placement: .last))
    let otherMembership = try await save(
      .addMembership(itemId: zulu.id, listId: otherList.id, placement: .last))
    guard case .membership(let alphaIdentifier, _, _)? = alphaMembership.generatedReferences.first,
      case .membership(let middleIdentifier, _, _)? = middleMembership.generatedReferences.first,
      case .membership(let zuluIdentifier, _, _)? = zuluMembership.generatedReferences.first,
      case .membership(let otherIdentifier, _, _)? = otherMembership.generatedReferences.first
    else { return XCTFail("Each source membership must retain its own identity.") }
    let appearance = PlannerAppearance.listMembership(listId: list.id, membershipId: zuluIdentifier)
    let otherAppearance = PlannerAppearance.listMembership(
      listId: otherList.id, membershipId: otherIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(appearance), done: true))
    _ = try await save(.setArchive(source: alpha, archived: true))
    let createdPlan = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    let listEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
    let directEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: zulu, placement: .last))
    guard
      case .itineraryEntry(let listEntryIdentifier, _, _)? = listEntry.generatedReferences.first,
      case .itineraryEntry(let directIdentifier, _, _)? = directEntry.generatedReferences.first
    else { return XCTFail("The route must retain direct and expanded references.") }
    let expanded = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: listEntryIdentifier, membershipId: zuluIdentifier)
    let direct = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: directIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(direct), done: true))
    let form = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let booking = try await save(.createSchedule(source: zulu, form: form))
    let schedule = try XCTUnwrap(booking.generated.first)
    guard
      case .source(.item(let beforeItem)) = await planner.read(
        session: session, request: .source(zulu)),
      case .source(.list(let beforeList)) = await planner.read(
        session: session, request: .source(list)),
      case .source(.itinerary(let beforePlan)) = await planner.read(
        session: session, request: .source(itinerary))
    else { return XCTFail("The rich graph must be readable before reordering.") }
    let reordering = ReorderPlannerItemInListIntent()
    reordering.item = .init(
      id: zulu.id, title: "Obsolete selected title", done: true, archived: true)
    reordering.list = .init(id: list.id, name: "Obsolete List name", archived: true)
    reordering.position = .before
    reordering.relativeItem = .init(
      id: middle.id, title: "Obsolete anchor title", done: true, archived: true)
    let _: Void = try await reordering.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let afterItem)) = await reopened.read(
        session: reopenedSession, request: .source(zulu)),
      case .source(.list(let afterList)) = await reopened.read(
        session: reopenedSession, request: .source(list)),
      case .source(.list(let afterOther)) = await reopened.read(
        session: reopenedSession, request: .source(otherList)),
      case .source(.itinerary(let afterPlan)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let afterSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule)),
      case .snapshot(let manual) = await reopened.query(
        .init(
          session: reopenedSession,
          request: .items(
            .init(
              scope: .list(list.id), completion: .all, archive: .all, sort: .init(mode: .manual))))),
      case .snapshot(let alphabetical) = await reopened.query(
        .init(
          session: reopenedSession,
          request: .items(.init(scope: .list(list.id), completion: .all, archive: .all))))
    else { return XCTFail("The saved order and unchanged graph must survive reopening.") }
    XCTAssertEqual(
      afterList.references,
      alphaMembership.generatedReferences + zuluMembership.generatedReferences
        + middleMembership.generatedReferences + listEntry.generatedReferences)
    XCTAssertEqual(afterList.content, beforeList.content)
    XCTAssertEqual(afterList.progress.doneCount, beforeList.progress.doneCount)
    XCTAssertEqual(afterList.progress.archivedCount, beforeList.progress.archivedCount)
    XCTAssertEqual(afterList.estimates.fullEstimate, beforeList.estimates.fullEstimate)
    XCTAssertEqual(afterList.estimates.remainingEstimate, beforeList.estimates.remainingEstimate)
    XCTAssertEqual(afterList.state.archived, false)
    XCTAssertEqual(afterOther.references, otherMembership.generatedReferences)
    XCTAssertEqual(afterPlan.references, beforePlan.references)
    XCTAssertEqual(afterPlan.progress.doneCount, beforePlan.progress.doneCount)
    XCTAssertEqual(afterPlan.estimates.fullEstimate, beforePlan.estimates.fullEstimate)
    XCTAssertEqual(afterPlan.estimates.remainingEstimate, beforePlan.estimates.remainingEstimate)
    XCTAssertEqual(afterItem.content.title, "Zulu")
    XCTAssertEqual(afterItem.content.notes, "Shared notes")
    XCTAssertEqual(afterItem.fieldHashes, beforeItem.fieldHashes)
    XCTAssertEqual(afterItem.updatedAt, beforeItem.updatedAt)
    XCTAssertEqual(afterItem.state.globalDone, false)
    XCTAssertEqual(afterItem.state.archived, false)
    XCTAssertEqual(afterSchedule.content.form, form)
    XCTAssertEqual(
      manual.rows,
      [alphaIdentifier, zuluIdentifier, middleIdentifier].map {
        .appearance(.listMembership(listId: list.id, membershipId: $0))
      })
    XCTAssertEqual(
      alphabetical.rows,
      [alphaIdentifier, middleIdentifier, zuluIdentifier].map {
        .appearance(.listMembership(listId: list.id, membershipId: $0))
      })
    for (context, expectedDone) in [
      (appearance, true), (otherAppearance, false), (expanded, false), (direct, true),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(context))
      else { return XCTFail("Reordering must preserve each completion context.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedDone)
      XCTAssertEqual(current.effectiveDone, expectedDone)
    }
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
