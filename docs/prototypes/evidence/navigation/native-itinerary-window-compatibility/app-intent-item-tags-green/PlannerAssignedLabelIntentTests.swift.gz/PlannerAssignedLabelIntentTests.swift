import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerAssignedLabelIntentTests: XCTestCase {
  func testItemCategoriesReturnOnlyCurrentSharedAssignmentsWithDistinctIdentities() async throws {
    let fixture = try await makeLabelAssociationIntentFixture()
    let assignment = SetPlannerItemCategoryIntent()
    assignment.item = .init(id: fixture.item.id, title: "Cached Item", done: false, archived: true)
    assignment.category = .init(id: fixture.extraCategory.id, name: "Cached Category")
    let _: Void = try await assignment.callAsFunction(donate: false)
    let rename = RenamePlannerCategoryIntent()
    rename.category = assignment.category
    rename.name = "Museums"
    let _: Void = try await rename.callAsFunction(donate: false)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The read fixture must have current saved shared-label names.") }
    let reading = GetPlannerItemCategoriesIntent()
    reading.item = assignment.item
    let categories = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(categories.map(\.id)), [fixture.category.id, fixture.extraCategory.id])
    XCTAssertEqual(categories.map(\.name), ["Museums", "Museums"])
    XCTAssertEqual(categories.count, 2)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .exported(let after) = await reopened.exportData(session: session)
    else { return XCTFail("Reading label assignments must preserve the saved planner.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }

  func testItemTagsReadArchivedOwnersAndReturnEmptyAfterOnlyTheirAssignmentsAreRemoved()
    async throws
  {
    let fixture = try await makeLabelAssociationIntentFixture()
    let assignment = SetPlannerItemTagIntent()
    assignment.item = .init(id: fixture.item.id, title: "Cached Item", done: false, archived: false)
    assignment.tag = .init(id: fixture.extraTag.id, name: "Cached Tag")
    let _: Void = try await assignment.callAsFunction(donate: false)
    let rename = RenamePlannerTagIntent()
    rename.tag = assignment.tag
    rename.name = "rainy-day"
    let _: Void = try await rename.callAsFunction(donate: false)
    let archive = SetPlannerItemArchiveIntent()
    archive.item = assignment.item
    archive.archived = true
    let _: Void = try await archive.callAsFunction(donate: false)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The archived owner and its assigned Tags must be saved.") }
    let reading = GetPlannerItemTagsIntent()
    reading.item = assignment.item
    let tags = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(tags.map(\.id)), [fixture.tag.id, fixture.extraTag.id])
    XCTAssertEqual(tags.map(\.name), ["rainy-day", "rainy-day"])
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("An archived owner's labels must remain readable without mutation.") }
    XCTAssertEqual(after, before)
    assignment.assigned = false
    let _: Void = try await assignment.callAsFunction(donate: false)
    assignment.tag = .init(id: fixture.tag.id, name: "Cached original Tag")
    let _: Void = try await assignment.callAsFunction(donate: false)
    let empty = try await reading.callAsFunction(donate: false)
    XCTAssertTrue(empty.isEmpty)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let item)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.itinerary(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.itinerary))
    else { return XCTFail("The empty Item assignment set must retain the shared sources.") }
    XCTAssertTrue(item.content.tagIds.isEmpty)
    XCTAssertEqual(item.content.categoryIds, [fixture.category.id])
    XCTAssertEqual(item.state.archived, true)
    XCTAssertEqual(item.state.globalDone, true)
    XCTAssertEqual(itinerary.content.tagIds, [fixture.tag.id])
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}
