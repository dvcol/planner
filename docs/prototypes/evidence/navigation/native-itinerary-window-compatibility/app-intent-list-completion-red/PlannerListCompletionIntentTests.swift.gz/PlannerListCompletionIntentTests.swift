import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerListCompletionIntentTests: XCTestCase {
  func testListCompletionRetainsIndependentContextsAndGlobalPrecedenceThroughReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let createdItem = try await save(
      .createItem(content: .init(title: "Museum", notes: "Shared notes")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let first = try await save(.createList(content: .init(name: "Tokyo Food")))
    let sourceList = try XCTUnwrap(first.generated.first)
    let second = try await save(.createList(content: .init(name: "Wishlist")))
    let otherList = try XCTUnwrap(second.generated.first)
    let membership = try await save(
      .addMembership(itemId: item.id, listId: sourceList.id, placement: .last))
    let otherMembership = try await save(
      .addMembership(itemId: item.id, listId: otherList.id, placement: .last))
    guard case .membership(let identifier, _, _)? = membership.generatedReferences.first,
      case .membership(let otherIdentifier, _, _)? = otherMembership.generatedReferences.first
    else { return XCTFail("The two Lists must have independent membership identities.") }
    let appearance = PlannerAppearance.listMembership(
      listId: sourceList.id, membershipId: identifier)
    let otherAppearance = PlannerAppearance.listMembership(
      listId: otherList.id, membershipId: otherIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(otherAppearance), done: true))
    let createdPlan = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    let direct = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    let branch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: sourceList, placement: .last))
    guard case .itineraryEntry(let directIdentifier, _, _)? = direct.generatedReferences.first,
      case .itineraryEntry(let branchIdentifier, _, _)? = branch.generatedReferences.first
    else { return XCTFail("The direct and expanded itinerary contexts must exist.") }
    let directAppearance = PlannerAppearance.directItineraryItem(
      itineraryId: itinerary.id, entryId: directIdentifier)
    let expandedAppearance = PlannerAppearance.expandedListItem(
      itineraryId: itinerary.id, listEntryId: branchIdentifier, membershipId: identifier)
    _ = try await save(.setCompletion(scope: .appearance(expandedAppearance), done: true))
    let form = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let booking = try await save(.createSchedule(source: item, form: form))
    let schedule = try XCTUnwrap(booking.generated.first)
    guard
      case .source(.item(let before)) = await planner.read(session: session, request: .source(item))
    else { return XCTFail("Shared content must be readable before local completion.") }
    let completion = SetPlannerItemListCompletionIntent()
    completion.item = .init(id: item.id, title: "Obsolete title", done: true, archived: true)
    completion.list = .init(id: sourceList.id, name: "Obsolete name", archived: true)
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    guard
      case .source(.item(let afterLocal)) = await planner.read(
        session: session, request: .source(item)),
      case .appearance(let locallyDone) = await planner.read(
        session: session, request: .appearance(appearance))
    else { return XCTFail("Only the selected local flag may change.") }
    XCTAssertEqual(afterLocal.fieldHashes, before.fieldHashes)
    XCTAssertEqual(afterLocal.updatedAt, before.updatedAt)
    XCTAssertEqual(afterLocal.state.globalDone, false)
    XCTAssertEqual(afterLocal.state.archived, false)
    XCTAssertTrue(locallyDone.localDone)
    XCTAssertTrue(locallyDone.effectiveDone)
    let globalCompletion = SetPlannerItemCompletionIntent()
    globalCompletion.item = completion.item
    globalCompletion.done = true
    let _: Void = try await globalCompletion.callAsFunction(donate: false)
    guard
      case .source(.item(let globallyDone)) = await planner.read(
        session: session, request: .source(item))
    else { return XCTFail("The explicit Item action must set global completion first.") }
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    guard
      case .source(.item(let afterLocalReopen)) = await planner.read(
        session: session, request: .source(item)),
      case .appearance(let masked) = await planner.read(
        session: session, request: .appearance(appearance))
    else { return XCTFail("Clearing local completion must retain global Done precedence.") }
    XCTAssertEqual(afterLocalReopen.updatedAt, globallyDone.updatedAt)
    XCTAssertTrue(masked.globalDone)
    XCTAssertFalse(masked.localDone)
    XCTAssertTrue(masked.effectiveDone)
    globalCompletion.done = false
    let _: Void = try await globalCompletion.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let savedItem)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let savedList)) = await reopened.read(
        session: reopenedSession, request: .source(sourceList)),
      case .source(.itinerary(let savedPlan)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let savedSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule))
    else { return XCTFail("The full graph must survive reopening after global Reopen.") }
    for (context, expectedLocalDone) in [
      (appearance, false), (otherAppearance, true), (directAppearance, false),
      (expandedAppearance, true),
    ] {
      guard
        case .appearance(let current) = await reopened.read(
          session: reopenedSession, request: .appearance(context))
      else { return XCTFail("Every original completion context must remain readable.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, expectedLocalDone)
      XCTAssertEqual(current.effectiveDone, expectedLocalDone)
      XCTAssertEqual(current.content.notes, "Shared notes")
    }
    XCTAssertEqual(savedItem.content.title, "Museum")
    XCTAssertEqual(savedItem.state.globalDone, false)
    XCTAssertEqual(savedItem.state.archived, false)
    XCTAssertEqual(savedList.content.name, "Tokyo Food")
    XCTAssertEqual(savedList.state.archived, false)
    XCTAssertEqual(savedList.progress.doneCount, 0)
    XCTAssertEqual(savedPlan.progress.totalCount, 2)
    XCTAssertEqual(savedPlan.progress.doneCount, 1)
    XCTAssertEqual(savedSchedule.content.form, form)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory.appending(
      path: "PlannerListCompletionIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"), processRole: .mainApplication,
      storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
