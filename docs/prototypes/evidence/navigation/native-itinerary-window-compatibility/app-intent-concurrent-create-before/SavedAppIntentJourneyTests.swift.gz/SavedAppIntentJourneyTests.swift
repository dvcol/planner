import AppIntentsTesting
import XCTest

@MainActor
final class SavedAppIntentJourneyTests: XCTestCase {
  func testCreateIntentReturnsTheSameSavedItemReadByNativeDetailsAfterRelaunch() async throws {
    continueAfterFailure = false
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    let definitions = IntentDefinitions(bundleIdentifier: "org.example.PlannerMCPPrototype")
    let creation = definitions.intents["CreatePlannerItemIntent"].makeIntent(
      title: "Train tickets", notes: "Collect at the station")
    let response = try await creation.run()
    let item: AnyAppEntity = try response.value
    let title: String = try item.title
    let done: Bool = try item.done
    XCTAssertEqual(title, "Train tickets")
    XCTAssertFalse(done)
    let identifier = try XCTUnwrap(UUID(uuidString: item.identifier.instanceIdentifier))
    application.openPlannerSection("Items")
    let row = application.plannerElement("saved.item.\(identifier.uuidString)")
    XCTAssertTrue(row.waitForExistence(timeout: 10))
    row.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["Collect at the station"].waitForExistence(timeout: 10))
    application.terminate()
    application.launchSavedPlannerJourney()
    let read = definitions.intents["GetPlannerItemIntent"].makeIntent(item: item)
    let restoredResponse = try await read.run()
    let restored: AnyAppEntity = try restoredResponse.value
    let restoredTitle: String = try restored.title
    XCTAssertEqual(restored.identifier, item.identifier)
    XCTAssertEqual(restoredTitle, "Train tickets")
  }
}
