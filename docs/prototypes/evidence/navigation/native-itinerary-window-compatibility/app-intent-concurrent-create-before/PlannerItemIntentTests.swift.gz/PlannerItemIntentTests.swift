import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItemIntentTests: XCTestCase {
  func testConcurrentCreateIntentsKeepBothRequestsAndAwaitTheSameStoreOpening() async throws {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerItemIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let store = SavedPlannerStore(configuration: configuration)
    AppDependencyManager.shared.add(dependency: store)
    var firstCreation = CreatePlannerItemIntent()
    firstCreation.title = "Train tickets"
    var secondCreation = CreatePlannerItemIntent()
    secondCreation.title = "Hotel check-in"
    async let firstResult = firstCreation.callAsFunction(donate: false)
    async let secondResult = secondCreation.callAsFunction(donate: false)
    let (firstItem, secondItem) = try await (firstResult, secondResult)
    XCTAssertEqual(firstItem.title, "Train tickets")
    XCTAssertEqual(secondItem.title, "Hotel check-in")
    XCTAssertNotEqual(firstItem.id, secondItem.id)
    XCTAssertTrue(store.isReady)
    XCTAssertFalse(store.isSaving)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .snapshot(let snapshot) = await planner.query(
        .init(session: session, request: .items(.init(completion: .all, archive: .all))))
    else { return XCTFail("Both real operations must remain readable after reopening.") }
    XCTAssertEqual(
      snapshot.rows,
      [
        .source(.init(kind: .item, id: secondItem.id)),
        .source(.init(kind: .item, id: firstItem.id)),
      ])
  }

  func testGlobalCompletionIntentPreservesIndependentListFlagsWhenTheItemIsReopened()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerItemIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let store = SavedPlannerStore(configuration: configuration)
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerItemIntent()
    creation.title = "Museum"
    creation.notes = "Keep the shared notes"
    let item = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else {
      return XCTFail("The Item's current real dataset must be ready.")
    }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      let operation = await planner.execute(
        .init(operationId: UUID(), session: session, command: command))
      guard case .applied(let result, .complete) = operation.outcome else {
        throw CancellationError()
      }
      return result
    }
    var appearances: [PlannerAppearance] = []
    for name in ["Tokyo", "Wishlist"] {
      let listCreation = try await save(.createList(content: .init(name: name)))
      let list = try XCTUnwrap(listCreation.generated.first)
      let membership = try await save(
        .addMembership(itemId: item.id, listId: list.id, placement: .last))
      guard case .membership(let membershipIdentifier, _, _)? = membership.generatedReferences.first
      else { return XCTFail("The original List association must have its own identity.") }
      appearances.append(.listMembership(listId: list.id, membershipId: membershipIdentifier))
    }
    _ = try await save(.setCompletion(scope: .appearance(appearances[0]), done: true))
    var completion = SetPlannerItemCompletionIntent()
    completion.item = item
    completion.done = true
    let _: Void = try await completion.callAsFunction(donate: false)
    for (index, appearance) in appearances.enumerated() {
      guard
        case .appearance(let current) = await planner.read(
          session: session, request: .appearance(appearance))
      else { return XCTFail("The original appearance must remain readable.") }
      XCTAssertTrue(current.globalDone)
      XCTAssertTrue(current.effectiveDone)
      XCTAssertEqual(current.localDone, index == 0)
      XCTAssertEqual(current.content.notes, "Keep the shared notes")
    }
    completion.done = false
    let _: Void = try await completion.callAsFunction(donate: false)
    for (index, appearance) in appearances.enumerated() {
      guard
        case .appearance(let current) = await planner.read(
          session: session, request: .appearance(appearance))
      else { return XCTFail("Reopening cannot remove either original association.") }
      XCTAssertFalse(current.globalDone)
      XCTAssertEqual(current.localDone, index == 0)
      XCTAssertEqual(current.effectiveDone, index == 0)
      XCTAssertFalse(current.archived)
    }
  }

  func testEntityQueriesResolveCurrentValuesAndCanonicalSearchWithoutInventingMissingItems()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerItemIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let store = SavedPlannerStore(configuration: configuration)
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerItemIntent()
    creation.title = "Train tickets"
    creation.notes = "Collect at the station"
    let cached = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.item(let current)) = await planner.read(
        session: session, request: .source(.init(kind: .item, id: cached.id))),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editItem(
            sourceId: cached.id, changes: .init(title: .set("Revised tickets")),
            expectedFieldHashes: current.fieldHashes))
      )
      .outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setCompletion(scope: .globalItem(itemId: cached.id), done: true))
      )
      .outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: .init(kind: .item, id: cached.id), archived: true))
      )
      .outcome
    else { return XCTFail("Real Core edits must prepare the changed source.") }
    var query = PlannerItemEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(for: [cached.id, UUID()])
    XCTAssertEqual(resolved.map(\.id), [cached.id])
    XCTAssertEqual(resolved.first?.title, "Revised tickets")
    XCTAssertEqual(resolved.first?.done, true)
    XCTAssertEqual(resolved.first?.archived, true)
    let matches = try await query.entities(matching: "STATION")
    XCTAssertEqual(matches.map(\.id), [cached.id])
    let missing = try await query.entities(matching: "No such visit")
    XCTAssertTrue(missing.isEmpty)
    let suggestions = try await query.suggestedEntities()
    XCTAssertEqual(suggestions.map(\.id), [cached.id])
    var reading = GetPlannerItemIntent()
    reading.item = cached
    let refreshed = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(refreshed.id, cached.id)
    XCTAssertEqual(refreshed.title, "Revised tickets")
    XCTAssertTrue(refreshed.done)
    XCTAssertTrue(refreshed.archived)
  }

  func testCreateIntentReturnsTheSingleSavedIdentityAndPreservesContentAndRecoveryAfterReopen()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerItemIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let store = SavedPlannerStore(configuration: configuration)
    AppDependencyManager.shared.add(dependency: store)
    var intent = CreatePlannerItemIntent()
    intent.title = "Train tickets"
    intent.notes = "Collect at the station"
    let created = try await intent.callAsFunction(donate: false)
    XCTAssertEqual(created.title, "Train tickets")
    XCTAssertFalse(created.done)
    XCTAssertFalse(created.archived)
    XCTAssertTrue(store.isReady)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: created.id))),
      case .snapshot(let items) = await reopened.query(
        .init(session: session, request: .items(.init(completion: .all, archive: .all)))),
      case .status(let status) = await reopened.read(session: session, request: .status)
    else { return XCTFail("The returned Item must be readable from reopened real storage.") }
    XCTAssertEqual(items.rows, [.source(saved.source)])
    XCTAssertEqual(saved.source.id, created.id)
    XCTAssertEqual(saved.content.title, "Train tickets")
    XCTAssertEqual(saved.content.notes, "Collect at the station")
    guard case .known(let checkpoint, let incomplete, let blocked) = status.recovery else {
      return XCTFail("The actual recovery status must remain available.")
    }
    XCTAssertNotNil(checkpoint)
    XCTAssertTrue(incomplete.isEmpty)
    XCTAssertFalse(blocked)
  }
}
