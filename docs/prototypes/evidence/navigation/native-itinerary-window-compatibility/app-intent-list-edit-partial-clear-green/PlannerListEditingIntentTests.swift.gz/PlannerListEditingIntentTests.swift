import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerListEditingIntentTests: XCTestCase {
  func testListPartialEditsKeepOmittedFieldsAndExplicitlyClearNotes() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Original List"
    creation.notes = "Keep the notes"
    let list = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    var editing = EditPlannerListIntent()
    editing.list = list
    editing.name = "Renamed List"
    let _: Void = try await editing.callAsFunction(donate: false)
    guard
      case .source(.list(let renamed)) = await planner.read(
        session: session, request: .source(.init(kind: .list, id: list.id)))
    else { return XCTFail("The same List must remain readable after a name-only edit.") }
    XCTAssertEqual(renamed.content.name, "Renamed List")
    XCTAssertEqual(renamed.content.notes, "Keep the notes")
    editing.name = nil
    editing.notes = "Updated notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    guard
      case .source(.list(let updated)) = await planner.read(
        session: session, request: .source(.init(kind: .list, id: list.id)))
    else { return XCTFail("A notes-only edit must retain the live renamed List.") }
    XCTAssertEqual(updated.content.name, "Renamed List")
    XCTAssertEqual(updated.content.notes, "Updated notes")
    editing.notes = ""
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.list(let cleared)) = await reopened.read(
        session: reopenedSession, request: .source(.init(kind: .list, id: list.id)))
    else { return XCTFail("The renamed List must survive explicit notes clearing and reopening.") }
    XCTAssertEqual(cleared.source.id, list.id)
    XCTAssertEqual(cleared.content.name, "Renamed List")
    XCTAssertNil(cleared.content.notes)
  }

  func testListEditPreservesIdentityMetadataArchiveAndMembershipCompletionAfterReopen()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    let color = PlannerColor(red: 0.1, green: 0.3, blue: 0.7, alpha: 1)
    let estimate = PlannerEstimate(minutes: 210, displayUnit: .hour)
    let createdList = try await save(
      .createList(
        content: .init(
          name: "Tokyo Food", notes: "Original List notes", color: color,
          iconName: "fork.knife", manualEstimate: estimate)))
    let list = try XCTUnwrap(createdList.generated.first)
    let createdItem = try await save(
      .createItem(content: .init(title: "Museum", notes: "Museum notes")))
    let item = try XCTUnwrap(createdItem.generated.first)
    let added = try await save(.addMembership(itemId: item.id, listId: list.id, placement: .last))
    guard case .membership(let identifier, _, _)? = added.generatedReferences.first else {
      return XCTFail("The fixture must retain the original membership identity.")
    }
    let appearance = PlannerAppearance.listMembership(listId: list.id, membershipId: identifier)
    _ = try await save(.setCompletion(scope: .appearance(appearance), done: true))
    _ = try await save(.setArchive(source: list, archived: true))
    guard
      case .source(.list(let before)) = await planner.read(
        session: session, request: .source(list))
    else { return XCTFail("The rich archived List must be readable before its edit.") }
    var editing = EditPlannerListIntent()
    editing.list = .init(id: list.id, name: "Obsolete cached name", archived: false)
    editing.name = "Reviewed Tokyo Food"
    editing.notes = "Reviewed List notes"
    let _: Void = try await editing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.list(let after)) = await reopened.read(
        session: reopenedSession, request: .source(list)),
      case .appearance(let retained) = await reopened.read(
        session: reopenedSession, request: .appearance(appearance))
    else { return XCTFail("The same List and membership must survive editing and reopening.") }
    XCTAssertEqual(after.source, list)
    XCTAssertEqual(after.content.name, "Reviewed Tokyo Food")
    XCTAssertEqual(after.content.notes, "Reviewed List notes")
    XCTAssertEqual(after.content.color, color)
    XCTAssertEqual(after.content.iconName, "fork.knife")
    XCTAssertEqual(after.content.manualEstimate, estimate)
    XCTAssertEqual(after.state.archived, true)
    XCTAssertEqual(after.references, before.references)
    XCTAssertEqual(after.progress.doneCount, before.progress.doneCount)
    XCTAssertEqual(after.estimates, before.estimates)
    XCTAssertEqual(retained.content.title, "Museum")
    XCTAssertEqual(retained.content.notes, "Museum notes")
    XCTAssertFalse(retained.globalDone)
    XCTAssertTrue(retained.localDone)
    XCTAssertTrue(retained.effectiveDone)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(
        path: "PlannerListEditingIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
