import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerItemFindIntentTests: XCTestCase {
  func testFindItemsCombinesTextCompletionAndArchiveWithoutChangingSavedData() async throws {
    let fixture = try await makeItemFindIntentFixture()
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Record the saved data before finding Items.") }
    let find = FindPlannerItemsIntent()
    let all: [PlannerItemEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(all.map(\.id), fixture.items.map(\.id))
    XCTAssertEqual(all.map(\.title), ["A Museum", "B Museum", "C Museum", "D Osaka"])
    find.text = "TOKYO"
    find.completion = .todo
    find.archive = .active
    let narrowed: [PlannerItemEntity] = try await find.callAsFunction(donate: false)
    XCTAssertEqual(narrowed.map(\.id), [fixture.items[0].id])
    XCTAssertEqual(narrowed.first?.done, false)
    XCTAssertEqual(narrowed.first?.archived, false)
    find.text = "No matching notes"
    let empty = try await find.callAsFunction(donate: false)
    XCTAssertTrue(empty.isEmpty)
    guard case .exported(let after) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("Finding Items must leave the saved graph readable and unchanged.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.isSaving)
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}

private struct ItemFindIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let items: [PlannerEntityReference]
}

@MainActor
private func makeItemFindIntentFixture() async throws -> ItemFindIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  var items: [PlannerEntityReference] = []
  for title in ["A Museum", "B Museum", "C Museum", "D Osaka"] {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .createItem(
            content: .init(title: title, notes: title == "D Osaka" ? "Osaka" : "Tokyo"))))
      .outcome,
      let item = result.generated.first(where: { $0.kind == .item })
    else { throw CancellationError() }
    items.append(item)
  }
  guard
    case .applied(_, .complete) = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .setCompletion(scope: .globalItem(itemId: items[1].id), done: true))
    ).outcome,
    case .applied(_, .complete) = await planner.execute(
      .init(
        operationId: UUID(), session: session,
        command: .setArchive(source: items[2], archived: true))
    ).outcome
  else { throw CancellationError() }
  return .init(
    configuration: configuration, store: store, planner: planner, session: session, items: items)
}
