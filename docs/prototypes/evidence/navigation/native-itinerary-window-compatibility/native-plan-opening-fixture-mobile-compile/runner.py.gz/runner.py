from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:3]
assert platform in ['mac', 'mobile']
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
compilation = evidence / 'native-plan-opening-mac-compile'
packet = evidence / phase
packet.mkdir(exist_ok=False)
root = Path('/private/tmp/PlannerNativeItemWindowSource')
hashes = json.loads((compilation / 'source-sha256.json').read_text())
for relative, digest in hashes.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest, relative
(packet / 'source-sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
(packet / 'source-root.json').write_bytes((compilation / 'source-root.json').read_bytes())
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
derived = '/private/tmp/PlannerNativeItemWindowDerivedData' if platform == 'mac' else '/private/tmp/PlannerItemWindowsNativemobileDerivedData'
destination = 'platform=macOS,arch=arm64' if platform == 'mac' else 'generic/platform=iOS Simulator'
command = ['xcodebuild', 'build-for-testing', '-project', 'Planner.xcodeproj', '-scheme', 'PlannerFixtures', '-destination', destination, '-derivedDataPath', derived, '-clonedSourcePackagesDirPath', '/private/tmp/PlannerCalendarMonthSourcePackages', '-disableAutomaticPackageResolution', '-parallel-testing-enabled', 'NO', '-jobs', '1', '-only-testing:PlannerFixtureUITests', 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES']
command += ['CODE_SIGNING_ALLOWED=YES', 'CODE_SIGN_IDENTITY=-', 'CODE_SIGN_STYLE=Manual', 'DEVELOPMENT_TEAM='] if platform == 'mac' else ['CODE_SIGNING_ALLOWED=NO']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerOpeningFixture-' + phase + '.log')
with log.open('wb') as output:
    result = subprocess.run(command, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT)
(packet / 'build.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode': result.returncode, 'runtimeCredit': False}, indent=2) + '\n')
for relative, digest in hashes.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest, relative
print(phase, 'exit', result.returncode, 'compiler credit only')
for line in log.read_text().splitlines():
    if '** TEST' in line or ': error:' in line:
        print(line[:600])
raise SystemExit(result.returncode)
