#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerItineraryEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Itinerary")
    static var defaultQuery: PlannerItineraryEntityQuery { PlannerItineraryEntityQuery() }
    let id: UUID
    @Property(title: "Title") var title: String
    @Property(title: "Archived") var archived: Bool
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(title)") }

    init(id: UUID, title: String, archived: Bool) {
      self.id = id
      self.title = title
      self.archived = archived
    }
  }

  struct PlannerItineraryEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerItineraryEntity] {
      throw PlannerItineraryIntentFailure(message: "Itinerary identity lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerItineraryEntity] {
      throw PlannerItineraryIntentFailure(message: "Itinerary search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerItineraryEntity] {
      throw PlannerItineraryIntentFailure(message: "Itinerary choices are not implemented.")
    }
  }

  struct CreatePlannerItineraryIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Itinerary"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Title") var title: String
    @Parameter(title: "Notes") var notes: String?
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<
      PlannerItineraryEntity, Never, Never, IntentDialog
    >

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerItineraryIntentFailure(message: "Itinerary creation is not implemented.")
    }
  }

  private struct PlannerItineraryIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
