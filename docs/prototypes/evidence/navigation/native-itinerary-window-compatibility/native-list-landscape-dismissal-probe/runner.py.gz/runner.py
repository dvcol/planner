from pathlib import Path
import gzip, hashlib, io, json, os, shutil, subprocess, sys, tarfile
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
selected = sys.argv[2]
platform = sys.argv[3] if len(sys.argv) > 3 else 'phone'
assert platform in ['phone', 'tablet']
packet = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility' / phase
packet.mkdir(parents=True, exist_ok=False)
root = Path('/private/tmp/PlannerNativeItemWindowSource')
root.mkdir(exist_ok=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
archive = subprocess.check_output(['git', 'archive', base, 'Configuration', 'Packages', 'Planner.xcodeproj', 'Planner', 'PlannerMCPTests', 'PlannerFixtures', 'PlannerFixtureUITests', 'PlannerNavigationUITests', 'PlannerShareMobile', 'PlannerShareMac', 'docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for member in source.getmembers():
        if not member.isfile(): continue
        destination = root / member.name
        content = source.extractfile(member).read()
        if destination.is_file() and destination.read_bytes() == content: continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
changed = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
overlays = sorted({path for path in changed + new if (path.endswith('.swift') and path.startswith(('Packages/', 'Planner/', 'PlannerMCPTests/', 'PlannerNavigationUITests/', 'PlannerFixtureUITests/', 'PlannerFixtures/'))) or path.startswith(('Configuration/', 'Planner.xcodeproj/', 'docs/fixtures/'))})
if os.environ.get('PLANNER_OPENING_BASELINE') == '1':
    overlays = [path for path in overlays if path == 'PlannerNavigationUITests/SavedAppearanceJourneyTests.swift']
    for relative in ['Planner/Scenes/SavedPlanOpeningCoordinator.swift', 'Planner/Scenes/SavedPlannerMainWindow.swift', 'Planner/AppIntents/PlannerOpenPlanIntents.swift', 'PlannerMCPTests/SavedPlanOpeningTests.swift']:
        (root / relative).unlink(missing_ok=True)
for path in overlays:
    (root / path).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repository / path, root / path)
if os.environ.get('PLANNER_LIST_DISMISSAL_PROBE'):
    probe = Path(os.environ['PLANNER_LIST_DISMISSAL_PROBE'])
    subprocess.run(['git', 'apply', str(probe)], cwd=root, check=True)
    (packet / 'baseline-fix.patch.gz').write_bytes(gzip.compress(probe.read_bytes(), mtime=0))
    (packet / 'baseline-fixed-view.swift.gz').write_bytes(gzip.compress((root / 'Planner/Scenes/SavedPlannerView.swift').read_bytes(), mtime=0))
    (packet / 'diagnostic-probe.json').write_text(json.dumps({'committedBaseline': base, 'onlyProductionChange': 'defer new List selection until native sheet onDismiss', 'patchSha256': hashlib.sha256(probe.read_bytes()).hexdigest()}, indent=2) + '\n')
inputs = sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet / 'source-sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root': str(root), 'base':base, 'overlays':overlays}, indent=2) + '\n')
for path in overlays:
    (packet / (Path(path).name + '.gz')).write_bytes(gzip.compress((root / path).read_bytes(), mtime=0))
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
bundle = '/private/tmp/PlannerItemWindow-' + phase + '.xcresult'
command = ['xcodebuild', 'test', '-project', 'Planner.xcodeproj', '-scheme', 'PlannerNavigation', '-destination', 'platform=iOS Simulator,id=' + ('2A49C66C-C8A4-435F-B98A-9A90706780DE' if platform == 'phone' else 'FBD72DAB-1D40-4E64-912D-7F9763E00446'), '-derivedDataPath', '/private/tmp/PlannerItemWindowsNativemobileDerivedData', '-clonedSourcePackagesDirPath', '/private/tmp/PlannerCalendarMonthSourcePackages', '-disableAutomaticPackageResolution', '-parallel-testing-enabled', 'NO', '-jobs', '1', '-test-timeouts-enabled', 'YES', '-default-test-execution-time-allowance', '120', '-maximum-test-execution-time-allowance', '120', *['-only-testing:PlannerNavigationUITests/' + name for name in selected.split(',')], '-resultBundlePath', bundle, 'CODE_SIGNING_ALLOWED=NO', 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerItemWindow-' + phase + '.log')
with log.open('wb') as output:
    result = subprocess.run(command, timeout=600, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT)
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode':result.returncode, 'bundle':bundle}, indent=2) + '\n')
assert all(hashlib.sha256((root / path).read_bytes()).hexdigest() == digest for path, digest in hashes.items())
assert all((root / path).read_bytes() == (repository / path).read_bytes() for path in overlays)
print(phase, 'exit', result.returncode)
for line in log.read_text().splitlines():
    if line.startswith(('Test Case ', '** TEST', 'error:')) or ('Test ' in line and ('passed' in line or 'failed' in line)) or ': error:' in line or 'recorded an issue' in line:
        print(line[:1500])
raise SystemExit(result.returncode)
