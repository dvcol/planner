import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleZoneIntentTests: XCTestCase {
  func testChangingPlanningZonePreservesTheExactStartOnlyInstantAndOtherBookings() async throws {
    let fixture = try await makeScheduleReadIntentFixture()
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let choices = try await query.entities(for: [fixture.timed.id])
    let change = SetPlannerScheduleTimeZoneIntent()
    change.schedule = try XCTUnwrap(choices.first)
    change.planningTimeZone = try XCTUnwrap(PlannerTimeZoneEntity(identifier: "Europe/Paris"))
    let _: Void = try await change.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let current)) = await reopened.read(session: session, request: .source(fixture.timed)),
      case .source(.schedule(let outside)) = await reopened.read(session: session, request: .source(fixture.outside)),
      case .source(.schedule(let itinerary)) = await reopened.read(session: session, request: .source(fixture.allDay)),
      case .source(.item(let item)) = await reopened.read(session: session, request: .source(fixture.item))
    else { return XCTFail("A zone-only edit must retain every saved source and booking identity.") }
    XCTAssertEqual(current.source, fixture.timed)
    XCTAssertEqual(current.content.source, fixture.item)
    XCTAssertEqual(current.content.form,
      .timed(start: fixture.instant, end: nil, planningTimeZone: "Europe/Paris"))
    XCTAssertEqual(outside.content.form,
      .allDay(start: .init(year: 2026, month: 10, day: 12), end: nil))
    XCTAssertEqual(itinerary.content.form,
      .allDay(start: .init(year: 2026, month: 10, day: 9), end: .init(year: 2026, month: 10, day: 11)))
    XCTAssertEqual(item.content.estimate?.minutes, 90)
    XCTAssertEqual(item.state.globalDone, false)
    XCTAssertEqual(item.state.archived, false)
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}
