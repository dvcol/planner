import gzip,hashlib,json
from pathlib import Path
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
phases={'mac':'native-label-appearance-mac-compile','mobile':'native-label-system-picker-rgb','device':'native-label-appearance-device-compile'}
baselines={'mac':'app-intent-schedule-form-final','mobile':'app-intent-schedule-form-mobile-compile','device':'app-intent-schedule-form-device-compile'}
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(item) for item in content),key=lambda item:json.dumps(item,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(item) for item in value]
    return value
for platform,phase in phases.items():
    current=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes()
    baseline=gzip.decompress((root/baselines[platform]/'extract.actionsdata.gz').read_bytes())
    assert normalize(json.loads(current))==normalize(json.loads(baseline)),platform
    (root/phase/'extract.actionsdata.gz').write_bytes(gzip.compress(current,mtime=0))
    (root/phase/'metadata-verification.json').write_text(json.dumps({'all81ActionsEntitiesQueriesEnumsAndFourShortcutsUnchanged':True,'comparisonNormalization':'resolvableInputTypes alternatives only','sha256':hashlib.sha256(current).hexdigest()},indent=2)+'\n')
source_phases=[*phases.values(),'native-label-appearance-hosted','native-label-appearance-phone-valid','native-label-appearance-tablet-dark']
source_maps={phase:json.loads((root/phase/'source-sha256.json').read_text()) for phase in source_phases}
production_inputs={name:digest for name,digest in source_maps[phases['mac']].items() if name.startswith(('Planner/','Packages/','Configuration/','Planner.xcodeproj/'))}
for phase,mapping in source_maps.items():
    for name,digest in production_inputs.items():
        assert mapping[name]==digest,(phase,name)
        assert hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest,name
report={'phases':source_phases,'identicalProductionAndConfigurationInputCount':len(production_inputs),'testSourcesMayDifferBetweenEarlierNativeAndFinalSystemPickerRuns':True,'all81ActionContractsPreservedOnAllPlatforms':True,'actualMacUIOrSignedDeviceRuntimeCredit':False}
packet=root/phases['device']
(packet/'source-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(report)
