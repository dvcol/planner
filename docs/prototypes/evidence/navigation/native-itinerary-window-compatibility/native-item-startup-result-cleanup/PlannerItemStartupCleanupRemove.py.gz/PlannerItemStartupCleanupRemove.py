from pathlib import Path
import json, hashlib, subprocess, shutil, gzip
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd() == repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
report = json.loads(Path('/private/tmp/PlannerItemStartupCleanupCandidates.json').read_text())
assert report['evidenceCommit'] == subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert len(report['bundles']) == 5
for record in report['bundles']:
    path = Path(record['path'])
    assert path.parent.resolve() == Path('/private/tmp').resolve()
    assert record['phase'] in ['native-schedule-actions-mac','native-item-cold-start-tablet','native-item-cold-start-phone','native-item-cold-start-phone-controls','native-item-cold-start-tablet-controls']
    assert path == Path('/private/tmp')/('PlannerItemWindow-'+record['phase']+'.xcresult') and path.suffix == '.xcresult'
    assert path.is_dir() and not path.is_symlink()
    assert hashlib.sha256(Path(record['summaryPath']).read_bytes()).hexdigest() == record['summarySha256']
    handles = subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(path)],capture_output=True,text=True)
    assert handles.returncode == 1 and not handles.stdout.strip() and not handles.stderr.strip(), path
for record in report['bundles']:
    path = Path(record['path']); shutil.rmtree(path); assert not path.exists(); record['removed'] = True
report['deleted'] = True
report['actualCleanupScope'] = 'Five completed raw startup-diagnostic xcresult directories only. Original extracted attachments, private diagnostic packets, source, current build products, package caches, Simulator state, fixture/export JSON and Planner datasets remain intact.'
packet = repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-item-startup-result-cleanup'
packet.mkdir(exist_ok=False)
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
for filename in ['/private/tmp/PlannerItemStartupCleanupPreflight.py','/private/tmp/PlannerItemStartupCleanupRemove.py']:
    source = Path(filename); (packet/(source.name+'.gz')).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
print(json.dumps({'removedRawBundles':len(report['bundles']),'removedNominalBytes':report['bundleNominalBytes']}))
