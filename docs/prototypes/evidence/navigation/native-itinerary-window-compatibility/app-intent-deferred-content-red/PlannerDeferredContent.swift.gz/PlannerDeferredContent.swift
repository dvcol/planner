#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  @MainActor
  func readPlannerDeferredItemSource(identifier: UUID) async throws -> PlannerItemSourceRead {
    @AppDependency var plannerStore: SavedPlannerStore
    try Task.checkCancellation()
    let (planner, session) = try await plannerStore.appIntentContext()
    try Task.checkCancellation()
    switch await planner.read(
      session: session, request: .source(.init(kind: .item, id: identifier)))
    {
    case .source(.item(let current)): return current
    case .failed(let reason): throw PlannerDeferredContentFailure(message: reason.message)
    default:
      throw PlannerDeferredContentFailure(message: "Planner could not read this Item's content.")
    }
  }

  private struct PlannerDeferredContentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
