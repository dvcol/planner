import AppIntents
import Foundation
import GeoToolbox
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerDeferredContentTests: XCTestCase {
  func testLightweightQueriesReadOwnedContentAndDatesWithoutChangingThePlanner() async throws {
    let fixture = try await makeEstimateResetIntentFixture()
    let sources = try await readEstimateResetSources(fixture)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { throw CancellationError() }
    let itemQuery = PlannerItemEntityQuery()
    itemQuery.plannerStore = fixture.store
    let listQuery = PlannerListEntityQuery()
    listQuery.plannerStore = fixture.store
    let itineraryQuery = PlannerItineraryEntityQuery()
    itineraryQuery.plannerStore = fixture.store
    let itemChoices = try await itemQuery.entities(matching: "Museum")
    let listChoices = try await listQuery.suggestedEntities()
    let itineraryChoices = try await itineraryQuery.entities(for: [fixture.itinerary.id])
    let item = try XCTUnwrap(itemChoices.first)
    let list = try XCTUnwrap(listChoices.first)
    let itinerary = try XCTUnwrap(itineraryChoices.first)
    let itemValues = try await (
      item.subtitle, item.notes, item.locationName, item.address, item.pin,
      item.created, item.lastUpdated)
    XCTAssertEqual(item.id, fixture.item.id)
    XCTAssertEqual(itemValues.0, "Opening hours vary")
    XCTAssertEqual(itemValues.1, "Keep booking")
    XCTAssertEqual(itemValues.2, "Museum")
    XCTAssertEqual(itemValues.3, "Tokyo")
    let pin = try XCTUnwrap(itemValues.4)
    XCTAssertNil(pin.commonName)
    XCTAssertEqual(pin.representations.count, 1)
    guard case .coordinate(let coordinate) = pin.representations[0] else {
      return XCTFail("Only the saved coordinate belongs in the Pin.")
    }
    XCTAssertEqual(coordinate.latitude, 35.6622)
    XCTAssertEqual(coordinate.longitude, 139.7171)
    XCTAssertEqual(itemValues.5, sources.item.createdAt)
    XCTAssertEqual(itemValues.6, sources.item.updatedAt)
    let listValues = try await (list.notes, list.created, list.lastUpdated)
    XCTAssertEqual(listValues.0, "Keep List")
    XCTAssertEqual(listValues.1, sources.list.createdAt)
    XCTAssertEqual(listValues.2, sources.list.updatedAt)
    let itineraryValues = try await (
      itinerary.notes, itinerary.locationName, itinerary.address, itinerary.pin,
      itinerary.created, itinerary.lastUpdated)
    XCTAssertEqual(itineraryValues.0, "Keep route")
    XCTAssertNil(itineraryValues.1)
    XCTAssertNil(itineraryValues.2)
    XCTAssertNil(itineraryValues.3)
    XCTAssertEqual(itineraryValues.4, sources.itinerary.createdAt)
    XCTAssertEqual(itineraryValues.5, sources.itinerary.updatedAt)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .exported(let after) = await reopened.exportData(session: session)
    else { throw CancellationError() }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.isSaving)
  }

  func testItemNotesReadCurrentSavedTextWithoutChangingTheReturnedEntityIdentity() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Museum"
    creation.notes = "Original notes\n東京 🏛️"
    let item = try await creation.callAsFunction(donate: false)
    let initialNotes = try await item.notes
    XCTAssertEqual(initialNotes, "Original notes\n東京 🏛️")
    let edit = EditPlannerItemIntent()
    edit.item = item
    edit.notes = "Changed notes\nCafé"
    let _: Void = try await edit.callAsFunction(donate: false)
    let currentNotes = try await item.notes
    XCTAssertEqual(currentNotes, "Changed notes\nCafé")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: item.id)))
    else { return XCTFail("The getter must retain the original saved Item.") }
    XCTAssertEqual(saved.content.notes, "Changed notes\nCafé")
    XCTAssertEqual(saved.source.id, item.id)
    XCTAssertFalse(store.isSaving)
  }
}
