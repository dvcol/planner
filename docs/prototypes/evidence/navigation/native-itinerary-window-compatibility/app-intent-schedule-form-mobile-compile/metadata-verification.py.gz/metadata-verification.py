from pathlib import Path
import gzip,hashlib,json,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
phase,platform=sys.argv[1:3]
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
products={'mac':Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources'),'mobile':Path('/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app'),'device':Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')}
baseline_phase='app-intent-bulk-qualified' if platform=='mac' else 'app-intent-bulk-'+platform+'-compile'
baseline=json.loads(gzip.decompress((root/baseline_phase/'extract.actionsdata.gz').read_bytes()))
raw=(products[platform]/'Metadata.appintents/extract.actionsdata').read_bytes();current=json.loads(raw)
def normalize(value):
    if isinstance(value,dict):
        return {key:sorted((normalize(entry) for entry in content),key=lambda entry:json.dumps(entry,sort_keys=True)) if key=='resolvableInputTypes' else normalize(content) for key,content in value.items()}
    if isinstance(value,list):return [normalize(entry) for entry in value]
    return value
for section in ['entities','queries','autoShortcuts']:
    assert normalize(current[section])==normalize(baseline[section]),section
for name,action in baseline['actions'].items():assert normalize(current['actions'][name])==normalize(action),name
assert normalize([entry for entry in current['enums'] if entry['identifier']!='PlannerScheduleOccurrence'])==normalize(baseline['enums'])
occurrences=[entry for entry in current['enums'] if entry['identifier']=='PlannerScheduleOccurrence']
assert len(occurrences)==1
assert [(entry['identifier'],entry['displayRepresentation']['title']['key']) for entry in occurrences[0]['cases']]==[('earlier','Earlier'),('later','Later')]
expected={
'CreatePlannerTimedItemScheduleIntent':('item','PlannerItemEntity','timed'),
'CreatePlannerTimedItineraryScheduleIntent':('itinerary','PlannerItineraryEntity','timed'),
'CreatePlannerAllDayItemScheduleIntent':('item','PlannerItemEntity','allDay'),
'CreatePlannerAllDayItineraryScheduleIntent':('itinerary','PlannerItineraryEntity','allDay'),
'SetPlannerScheduleTimedFormIntent':('schedule','PlannerScheduleEntity','timed'),
'SetPlannerScheduleAllDayFormIntent':('schedule','PlannerScheduleEntity','allDay')}
assert set(current['actions'])-set(baseline['actions'])==set(expected)
assert len(current['actions'])==81
for name,(owner,owner_type,form) in expected.items():
    action=current['actions'][name]
    assert action['allowedTargets']==[{'type':1}] and action['supportedModes']==1 and action['authenticationPolicy']==0,name
    assert action['outputType']=={'entity':{'wrapper':{'typeName':'PlannerScheduleEntity'}}},name
    fields=action['parameters']
    names=[owner,'start','planningTimeZone','end','startOccurrence','endOccurrence'] if form=='timed' else [owner,'startDay','endDay']
    assert [field['name'] for field in fields]==names,name
    assert fields[0]['valueType']=={'entity':{'wrapper':{'typeName':owner_type}}}
    for field in fields:
        field_name=field['name']
        assert field['isOptional']==(field_name in ['end','endDay','startOccurrence','endOccurrence']),field
        assert 'defaultValue' not in field,field
        if field_name in ['start','end','startDay','endDay']:
            assert field['valueType']=={'primitive':{'wrapper':{'typeIdentifier':9}}},field
            assert field['typeSpecificMetadata']==['LNValueTypeMetadataKeyDateFormat',{'int':{'wrapper':2 if form=='timed' else 0}}],field
        if field_name in ['startOccurrence','endOccurrence']:
            assert field['valueType']=={'linkEnumeration':{'wrapper':{'identifier':'PlannerScheduleOccurrence'}}},field
        if field_name=='planningTimeZone':assert field['queryIdentifier']=='Planner.PlannerTimeZoneEntityQuery'
        if field_name=='schedule':assert field['queryIdentifier']=='Planner.PlannerScheduleEntityQuery'
packet=root/phase
(packet/'extract.actionsdata.gz').write_bytes(gzip.compress(raw,mtime=0))
(packet/'metadata-verification.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(packet/'metadata-verification.json').write_text(json.dumps({'platform':platform,'addedActions':expected,'actionCount':81,'earlierLaterOccurrenceEnumAdded':True,'allPrevious75ActionContractsAndEntitiesQueriesEnumsAndFourShortcutsPreserved':True,'civilDateAndDateTimeKindsVerified':True,'requiredAndOptionalFieldsAndNoOccurrenceDefaultsVerified':True,'allSixActionsReturnExactScheduleEntities':True,'comparisonNormalization':'resolvableInputTypes alternatives only','metadataSha256':hashlib.sha256(raw).hexdigest(),'actualSystemPickerSerializationAndInvocationCredit':False},indent=2)+'\n')
print(platform,'six typed Schedule actions; native civil kinds and no occurrence defaults; previous contracts retained')
