#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct SetPlannerItemCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Set Item Category"
    static let description = IntentDescription(
      "Assign or unassign this shared Category. Other labels and Item data stay unchanged.")
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Item") var item: PlannerItemEntity
    @Parameter(title: "Category") var category: PlannerCategoryEntity
    @Parameter(title: "Assigned", default: true) var assigned: Bool
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<Never, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      let dialog = try await setPlannerItemCategoryAssignment(
        itemId: item.id, categoryId: category.id, assigned: assigned, store: plannerStore)
      return .result(dialog: dialog)
    }
  }

  @MainActor
  private func setPlannerItemCategoryAssignment(
    itemId: UUID, categoryId: UUID, assigned: Bool, store: SavedPlannerStore
  ) async throws -> IntentDialog {
    let (planner, session) = try await store.appIntentContext()
    try Task.checkCancellation()
    switch await planner.read(
      session: session, request: .source(.init(kind: .category, id: categoryId)))
    {
    case .source(.category): break
    case .failed(let reason): throw PlannerLabelAssociationIntentFailure(message: reason.message)
    default:
      throw PlannerLabelAssociationIntentFailure(message: "Planner could not read this Category.")
    }
    let source: PlannerItemSourceRead
    switch await planner.read(session: session, request: .source(.init(kind: .item, id: itemId))) {
    case .source(.item(let current)): source = current
    case .failed(let reason): throw PlannerLabelAssociationIntentFailure(message: reason.message)
    default:
      throw PlannerLabelAssociationIntentFailure(message: "Planner could not read this Item.")
    }
    var identifiers = source.content.categoryIds
    if assigned {
      identifiers.insert(categoryId)
    } else {
      identifiers.remove(categoryId)
    }
    let result = try await store.executeAppIntent(
      .editItem(
        sourceId: source.source.id, changes: .init(categoryIds: .set(identifiers)),
        expectedFieldHashes: source.fieldHashes))
    switch result.outcome {
    case .rejected(let reason): throw PlannerLabelAssociationIntentFailure(message: reason.message)
    case .unverified:
      throw PlannerLabelAssociationIntentFailure(
        message:
          "Planner could not verify this change. Open Planner to review recovery before making another change."
      )
    case .applied(_, let recovery):
      switch recovery {
      case .complete:
        if assigned { return "Assigned the shared label. Other labels are preserved." }
        return "Unassigned the label. The shared label and its other uses are preserved."
      case .incomplete:
        return
          "The label assignment changed on this device, but its recovery copy is incomplete. Open Planner before making more changes."
      }
    }
  }

  private struct PlannerLabelAssociationIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
