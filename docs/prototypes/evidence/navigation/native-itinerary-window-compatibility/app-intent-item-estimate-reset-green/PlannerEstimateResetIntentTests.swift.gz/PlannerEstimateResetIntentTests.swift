import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerEstimateResetIntentTests: XCTestCase {
  func testClearingItemEstimatePreservesContextsBookingsAndManualContainerBudgets() async throws {
    let fixture = try await makeEstimateResetIntentFixture()
    let before = try await readEstimateResetSources(fixture)
    let clearing = ClearPlannerItemEstimateIntent()
    clearing.item = .init(id: fixture.item.id, title: "Cached Item", done: true, archived: true)
    let _: Void = try await clearing.callAsFunction(donate: false)
    let _: Void = try await clearing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap() else { throw CancellationError() }
    let after = try await readEstimateResetSources(fixture, planner: reopened, session: session)
    XCTAssertNil(after.item.content.estimate)
    XCTAssertEqual(after.lunch.content.estimate, .init(minutes: 30, displayUnit: .minute))
    XCTAssertEqual(after.list.content.manualEstimate, .init(minutes: 240, displayUnit: .hour))
    XCTAssertEqual(after.itinerary.content.manualEstimate, .init(minutes: 480, displayUnit: .hour))
    XCTAssertEqual(
      after.list.estimates.calculatedEstimate, .lowerBound(minutes: 30, missingEstimateCount: 1))
    XCTAssertEqual(after.list.estimates.fullEstimate, .exact(minutes: 240))
    XCTAssertEqual(
      after.list.estimates.remainingEstimate,
      .upperBound(minutes: 240, missingFinishedEstimateCount: 1))
    XCTAssertEqual(
      after.itinerary.estimates.calculatedEstimate,
      .lowerBound(minutes: 480, missingEstimateCount: 1))
    assertEstimateResetPreservesOtherFields(before, after, changedKind: .item)
    try await assertEstimateResetContextsAndBookings(fixture, planner: reopened, session: session)
  }
}

private struct EstimateResetIntentFixture {
  let configuration: PlannerStorageConfiguration
  let store: SavedPlannerStore
  let planner: PlannerCore.Planner
  let session: PlannerDatasetSession
  let item: PlannerEntityReference
  let lunch: PlannerEntityReference
  let list: PlannerEntityReference
  let itinerary: PlannerEntityReference
  let membershipIdentifier: UUID
  let lunchMembershipIdentifier: UUID
  let firstBranchIdentifier: UUID
  let secondBranchIdentifier: UUID
  let directEntryIdentifier: UUID
  let itemSchedule: PlannerEntityReference
  let itinerarySchedule: PlannerEntityReference
}

private struct EstimateResetSourceObservations {
  let item: PlannerItemSourceRead
  let lunch: PlannerItemSourceRead
  let list: PlannerListSourceRead
  let itinerary: PlannerItinerarySourceRead
}

@MainActor
private func makeEstimateResetIntentFixture() async throws -> EstimateResetIntentFixture {
  let (_, configuration, store) = try makePlannerIntentStorage()
  AppDependencyManager.shared.add(dependency: store)
  let planner = PlannerCore.Planner(configuration: configuration)
  guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
  func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
    guard
      case .applied(let result, .complete) = await planner.execute(
        .init(operationId: UUID(), session: session, command: command)
      ).outcome
    else { throw CancellationError() }
    return result
  }
  let createdCategory = try await save(.createCategory(content: .init(name: "Museums")))
  let category = try XCTUnwrap(createdCategory.generated.first)
  let createdTag = try await save(.createTag(content: .init(name: "booked")))
  let tag = try XCTUnwrap(createdTag.generated.first)
  let createdItem = try await save(
    .createItem(
      content: .init(
        title: "Museum", subtitle: "Opening hours vary", notes: "Keep booking",
        location: .init(
          displayName: "Museum", formattedAddress: "Tokyo",
          coordinate: .init(latitude: 35.6622, longitude: 139.7171)),
        estimate: .init(minutes: 90, displayUnit: .hour),
        links: [.init(originalUrl: "https://example.com/museum", label: "Visit guide")],
        categoryIds: [category.id], tagIds: [tag.id])))
  let item = try XCTUnwrap(createdItem.generated.first)
  let createdLunch = try await save(
    .createItem(
      content: .init(
        title: "Lunch", notes: "Keep lunch", estimate: .init(minutes: 30, displayUnit: .minute))))
  let lunch = try XCTUnwrap(createdLunch.generated.first)
  let createdList = try await save(
    .createList(
      content: .init(
        name: "Tokyo Food", notes: "Keep List",
        manualEstimate: .init(minutes: 240, displayUnit: .hour))))
  let list = try XCTUnwrap(createdList.generated.first)
  let addedItem = try await save(.addMembership(itemId: item.id, listId: list.id, placement: .last))
  let addedLunch = try await save(
    .addMembership(itemId: lunch.id, listId: list.id, placement: .last))
  guard case .membership(let membershipIdentifier, _, _)? = addedItem.generatedReferences.first,
    case .membership(let lunchMembershipIdentifier, _, _)? = addedLunch.generatedReferences.first
  else { throw CancellationError() }
  _ = try await save(
    .setCompletion(
      scope: .appearance(
        .listMembership(
          listId: list.id, membershipId: membershipIdentifier)), done: true))
  let createdItinerary = try await save(
    .createItinerary(
      content: .init(
        title: "Tokyo Weekend", notes: "Keep route", categoryIds: [category.id], tagIds: [tag.id],
        manualEstimate: .init(minutes: 480, displayUnit: .hour))))
  let itinerary = try XCTUnwrap(createdItinerary.generated.first)
  let firstBranch = try await save(
    .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
  let secondBranch = try await save(
    .addItineraryEntry(itineraryId: itinerary.id, source: list, placement: .last))
  let directEntry = try await save(
    .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
  guard
    case .itineraryEntry(let firstBranchIdentifier, _, _)? = firstBranch.generatedReferences.first,
    case .itineraryEntry(let secondBranchIdentifier, _, _)? = secondBranch.generatedReferences.first,
    case .itineraryEntry(let directEntryIdentifier, _, _)? = directEntry.generatedReferences.first
  else { throw CancellationError() }
  _ = try await save(
    .setCompletion(
      scope: .appearance(
        .expandedListItem(
          itineraryId: itinerary.id, listEntryId: firstBranchIdentifier,
          membershipId: membershipIdentifier)), done: true))
  let createdItemSchedule = try await save(
    .createSchedule(
      source: item,
      form: .timed(
        start: Date(timeIntervalSinceReferenceDate: 814_000_000),
        end: Date(timeIntervalSinceReferenceDate: 814_007_200), planningTimeZone: "Asia/Tokyo")))
  let itemSchedule = try XCTUnwrap(createdItemSchedule.generated.first)
  let createdItinerarySchedule = try await save(
    .createSchedule(
      source: itinerary,
      form: .allDay(
        start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))))
  let itinerarySchedule = try XCTUnwrap(createdItinerarySchedule.generated.first)
  return .init(
    configuration: configuration, store: store, planner: planner, session: session,
    item: item, lunch: lunch, list: list, itinerary: itinerary,
    membershipIdentifier: membershipIdentifier,
    lunchMembershipIdentifier: lunchMembershipIdentifier,
    firstBranchIdentifier: firstBranchIdentifier, secondBranchIdentifier: secondBranchIdentifier,
    directEntryIdentifier: directEntryIdentifier, itemSchedule: itemSchedule,
    itinerarySchedule: itinerarySchedule)
}

@MainActor
private func readEstimateResetSources(
  _ fixture: EstimateResetIntentFixture, planner: PlannerCore.Planner? = nil,
  session: PlannerDatasetSession? = nil
) async throws -> EstimateResetSourceObservations {
  let planner = planner ?? fixture.planner
  let session = session ?? fixture.session
  guard
    case .source(.item(let item)) = await planner.read(
      session: session, request: .source(fixture.item)),
    case .source(.item(let lunch)) = await planner.read(
      session: session, request: .source(fixture.lunch)),
    case .source(.list(let list)) = await planner.read(
      session: session, request: .source(fixture.list)),
    case .source(.itinerary(let itinerary)) = await planner.read(
      session: session, request: .source(fixture.itinerary))
  else { throw CancellationError() }
  return .init(item: item, lunch: lunch, list: list, itinerary: itinerary)
}

@MainActor
private func assertEstimateResetPreservesOtherFields(
  _ before: EstimateResetSourceObservations, _ after: EstimateResetSourceObservations,
  changedKind: PlannerEntityKind?
) {
  var ignoredItemFields: Set<PlannerItemField> = []
  var ignoredListFields: Set<PlannerListField> = []
  var ignoredItineraryFields: Set<PlannerItineraryField> = []
  if changedKind == .item { ignoredItemFields = [.estimate] }
  if changedKind == .list { ignoredListFields = [.manualEstimate] }
  if changedKind == .itinerary { ignoredItineraryFields = [.manualEstimate] }
  XCTAssertEqual(
    after.item.fieldHashes.filter { !ignoredItemFields.contains($0.key) },
    before.item.fieldHashes.filter { !ignoredItemFields.contains($0.key) })
  XCTAssertEqual(
    after.list.fieldHashes.filter { !ignoredListFields.contains($0.key) },
    before.list.fieldHashes.filter { !ignoredListFields.contains($0.key) })
  XCTAssertEqual(
    after.itinerary.fieldHashes.filter { !ignoredItineraryFields.contains($0.key) },
    before.itinerary.fieldHashes.filter { !ignoredItineraryFields.contains($0.key) })
  XCTAssertEqual(after.lunch.fieldHashes, before.lunch.fieldHashes)
  XCTAssertEqual(after.lunch.updatedAt, before.lunch.updatedAt)
  XCTAssertEqual(after.item.sourceLifetimeId, before.item.sourceLifetimeId)
  XCTAssertEqual(after.itinerary.sourceLifetimeId, before.itinerary.sourceLifetimeId)
  XCTAssertEqual(after.item.source, before.item.source)
  XCTAssertEqual(after.list.source, before.list.source)
  XCTAssertEqual(after.itinerary.source, before.itinerary.source)
  XCTAssertEqual(after.item.createdAt, before.item.createdAt)
  XCTAssertEqual(after.list.createdAt, before.list.createdAt)
  XCTAssertEqual(after.itinerary.createdAt, before.itinerary.createdAt)
  XCTAssertEqual(after.item.state.globalDone, before.item.state.globalDone)
  XCTAssertEqual(after.item.state.archived, before.item.state.archived)
  XCTAssertEqual(after.list.state.archived, before.list.state.archived)
  XCTAssertEqual(after.itinerary.state.archived, before.itinerary.state.archived)
  XCTAssertEqual(after.item.references, before.item.references)
  XCTAssertEqual(after.list.references, before.list.references)
  XCTAssertEqual(after.itinerary.references, before.itinerary.references)
  if changedKind != .item { XCTAssertEqual(after.item.updatedAt, before.item.updatedAt) }
  if changedKind != .list { XCTAssertEqual(after.list.updatedAt, before.list.updatedAt) }
  if changedKind != .itinerary {
    XCTAssertEqual(after.itinerary.updatedAt, before.itinerary.updatedAt)
  }
}

@MainActor
private func assertEstimateResetContextsAndBookings(
  _ fixture: EstimateResetIntentFixture, planner: PlannerCore.Planner,
  session: PlannerDatasetSession
) async throws {
  let expectedAppearances: [(PlannerAppearance, Bool)] = [
    (.listMembership(listId: fixture.list.id, membershipId: fixture.membershipIdentifier), true),
    (
      .listMembership(listId: fixture.list.id, membershipId: fixture.lunchMembershipIdentifier),
      false
    ),
    (
      .expandedListItem(
        itineraryId: fixture.itinerary.id, listEntryId: fixture.firstBranchIdentifier,
        membershipId: fixture.membershipIdentifier), true
    ),
    (
      .expandedListItem(
        itineraryId: fixture.itinerary.id, listEntryId: fixture.secondBranchIdentifier,
        membershipId: fixture.membershipIdentifier), false
    ),
    (
      .directItineraryItem(
        itineraryId: fixture.itinerary.id, entryId: fixture.directEntryIdentifier), false
    ),
  ]
  for (appearance, expectedLocal) in expectedAppearances {
    guard
      case .appearance(let saved) = await planner.read(
        session: session, request: .appearance(appearance))
    else { return XCTFail("Estimate reset must retain every independent appearance.") }
    XCTAssertFalse(saved.globalDone)
    XCTAssertEqual(saved.localDone, expectedLocal)
  }
  guard
    case .source(.schedule(let itemSchedule)) = await planner.read(
      session: session, request: .source(fixture.itemSchedule)),
    case .source(.schedule(let itinerarySchedule)) = await planner.read(
      session: session, request: .source(fixture.itinerarySchedule))
  else { return XCTFail("Activity estimates and manual budgets must not remove booked Schedules.") }
  XCTAssertEqual(
    itemSchedule.content.form,
    .timed(
      start: Date(timeIntervalSinceReferenceDate: 814_000_000),
      end: Date(timeIntervalSinceReferenceDate: 814_007_200), planningTimeZone: "Asia/Tokyo"))
  XCTAssertEqual(
    itinerarySchedule.content.form,
    .allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21)))
  XCTAssertFalse(fixture.store.recoveryBlocked)
  XCTAssertFalse(fixture.store.isSaving)
}
