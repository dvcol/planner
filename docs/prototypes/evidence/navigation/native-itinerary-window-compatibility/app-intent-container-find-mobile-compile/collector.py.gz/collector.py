from pathlib import Path
import gzip, hashlib, json, plistlib, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = evidence / phase
baseline = evidence / 'app-intent-related-empty-cancellation-final-clean'
assert json.loads((packet / 'exit.json').read_text())['exitCode'] == 0
prior = json.loads(gzip.decompress((baseline / 'extract.actionsdata.gz').read_bytes()))
paths = {
    'mac': '/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
    'mobile': '/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
    'device': '/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata',
}
metadata_bytes = Path(paths[platform]).read_bytes()
metadata = json.loads(metadata_bytes)
def parameter(value_type, optional=False):
    return {'valueType': value_type, 'optional': optional}
def enumeration(identifier):
    return {'linkEnumeration': {'wrapper': {'identifier': identifier}}}
def entity_array(identifier):
    return {'array': {'wrapper': {'capabilities': 3, 'memberValueType': {'entity': {'wrapper': {'typeName': identifier}}}}}}
def action_contract(action):
    return {value['name']: parameter(value['valueType'], value['isOptional']) for value in action['parameters']}
expected_parameters = {
    'text': parameter({'primitive': {'wrapper': {'typeIdentifier': 0}}}),
    'archive': parameter(enumeration('PlannerCatalogFindArchive')),
    'sort': parameter(enumeration('PlannerCatalogFindSort')),
    'direction': parameter(enumeration('PlannerCatalogFindDirection')),
}
outputs = {'FindPlannerListsIntent': entity_array('PlannerListEntity'), 'FindPlannerItinerariesIntent': entity_array('PlannerItineraryEntity')}
assert len(metadata['actions']) == 69
assert set(metadata['actions']) == set(prior['actions']) | set(outputs)
for identifier, action in prior['actions'].items():
    assert action_contract(metadata['actions'][identifier]) == action_contract(action), identifier
    assert metadata['actions'][identifier].get('outputType') == action.get('outputType'), identifier
for identifier, output in outputs.items():
    assert action_contract(metadata['actions'][identifier]) == expected_parameters, identifier
    assert metadata['actions'][identifier]['outputType'] == output, identifier
    assert metadata['actions'][identifier]['isDiscoverable'] is True
for kind in ['entities', 'queries']:
    assert metadata[kind] == prior[kind], kind
prior_enums = {value['identifier']: value for value in prior['enums']}
current_enums = {value['identifier']: value for value in metadata['enums']}
expected_cases = {'PlannerCatalogFindArchive': {'all', 'active', 'archived'}, 'PlannerCatalogFindSort': {'title', 'created', 'lastUpdated', 'fullEstimate'}, 'PlannerCatalogFindDirection': {'ascending', 'descending'}}
assert len(current_enums) == 14
assert set(current_enums) == set(prior_enums) | set(expected_cases)
for identifier, value in prior_enums.items():
    assert current_enums[identifier] == value, identifier
for identifier, cases in expected_cases.items():
    assert {value['identifier'] for value in current_enums[identifier]['cases']} == cases
result = {'actions': sorted(metadata['actions']), 'entities': sorted(metadata['entities']), 'queries': sorted(metadata['queries']), 'enumCount': len(current_enums), 'newActionParameters': expected_parameters, 'newActionOutputs': outputs, 'newEnumCases': {key: sorted(value) for key, value in expected_cases.items()}, 'priorActionParametersAndOutputsUnchanged': True, 'priorEntitiesQueriesEnumsUnchanged': True, 'metadataSha256': hashlib.sha256(metadata_bytes).hexdigest(), 'systemInvocationQualified': False}
(packet / 'extracted-intent-identifiers.json').write_text(json.dumps(result, indent=2) + '\n')
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes, mtime=0))
source_hashes = json.loads((packet / 'source-sha256.json').read_text())
prior_hashes = json.loads((baseline / 'source-sha256.json').read_text())
changed = sorted(relative for relative, digest in prior_hashes.items() if source_hashes.get(relative) != digest)
added = sorted(set(source_hashes) - set(prior_hashes))
assert changed == ['Planner/AppIntents/PlannerItineraryIntents.swift', 'Planner/AppIntents/PlannerListIntents.swift'], changed
assert added == ['Planner/AppIntents/PlannerContainerFindIntents.swift', 'PlannerMCPTests/PlannerContainerFindIntentTests.swift'] and len(source_hashes) == 1040
assert all(hashlib.sha256((repository / relative).read_bytes()).hexdigest() == digest for relative, digest in source_hashes.items())
(packet / 'baseline-source-comparison.json').write_text(json.dumps({'baselinePacket': baseline.name, 'priorInputs': len(prior_hashes), 'currentInputs': len(source_hashes), 'changedInputs': changed, 'addedInputs': added, 'otherPriorInputsUnchanged': True}, indent=2) + '\n')
if platform == 'mac':
    command = ['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', '/private/tmp/PlannerItemWindow-' + phase + '.xcresult', '--format', 'json']
    summary = json.loads(subprocess.check_output(command, text=True))
    (packet / 'test-results-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert summary['passedTests'] > 0 and summary['failedTests'] == 0 and summary['skippedTests'] == 0
    lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] is True and len(lifecycle['removedDirectories']) == lifecycle['fixtureCount'] and lifecycle['fixtureCount'] > 0
else:
    final_mac = evidence / 'app-intent-container-find-final-clean'
    assert source_hashes == json.loads((final_mac / 'source-sha256.json').read_text())
    mac_metadata = json.loads(gzip.decompress((final_mac / 'extract.actionsdata.gz').read_bytes()))
    for kind in ['entities', 'queries', 'enums']:
        assert metadata[kind] == mac_metadata[kind], kind
    for identifier, action in mac_metadata['actions'].items():
        assert action_contract(metadata['actions'][identifier]) == action_contract(action)
        assert metadata['actions'][identifier].get('outputType') == action.get('outputType')
log_path = packet / 'build.log.gz'
if not log_path.exists():
    log_path = packet / 'test.log.gz'
log = gzip.decompress(log_path.read_bytes()).decode(errors='replace')
diagnostics = [line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet / 'compiler-diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
baseline_log = gzip.decompress((evidence / 'app-intent-schedule-removal-http-base/test.log.gz').read_bytes()).decode(errors='replace')
baseline_diagnostics = [line[:1000] for line in baseline_log.splitlines() if ': warning:' in line]
introduced = [line for line in diagnostics if line not in baseline_diagnostics]
(packet / 'baseline-compiler-diagnostics.json').write_text(json.dumps({'baselinePacket': 'app-intent-schedule-removal-http-base', 'baselineWarnings': baseline_diagnostics, 'currentDiagnostics': diagnostics, 'introducedDiagnostics': introduced}, indent=2) + '\n')
assert not introduced, introduced
assert not any(phrase in log for phrase in ['vnode unlinked while in use', 'database integrity compromised', 'invalidated open fd'])
if platform == 'mac':
    import re
    assert "Test Suite 'PlannerContainerFindIntentTests' passed" in log
    names = re.findall(r'func (test[A-Za-z0-9_]+)', (repository / 'PlannerMCPTests/PlannerContainerFindIntentTests.swift').read_text())
    assert names
    for name in names:
        assert " " + name + "]' passed" in log, name
    native_counts = re.findall(r'Executed ([0-9]+) tests, with 0 failures', log)
    http_counts = re.findall(r'Test run with ([0-9]+) tests in', log)
    assert native_counts and http_counts
    assert summary['passedTests'] == int(native_counts[-1]) + int(http_counts[-1])
    (packet / 'executed-test-reconciliation.json').write_text(json.dumps({'passedNativeCases': int(native_counts[-1]), 'passedHttpDeclarations': int(http_counts[-1]), 'actualSummaryPasses': summary['passedTests'], 'newContainerFindCases': names, 'markedFixtures': lifecycle['fixtureCount']}, indent=2) + '\n')

if platform == 'device':
    app = Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
    extensions = list((app / 'PlugIns').glob('*.appex'))
    assert len(extensions) == 1
    products = []
    for product in [app, *extensions]:
        values = plistlib.loads((product / 'Info.plist').read_bytes())
        executable = product / values['CFBundleExecutable']
        architectures = subprocess.check_output(['lipo', '-archs', str(executable)], text=True).split()
        assert architectures == ['arm64']
        products.append({'bundleIdentifier': values['CFBundleIdentifier'], 'architectures': architectures, 'sha256': hashlib.sha256(executable.read_bytes()).hexdigest()})
    (packet / 'embedded-products-verification.json').write_text(json.dumps({'products': products, 'embeddedMobileShareCount': 1, 'signingAllowed': False, 'installedOrLaunched': False}, indent=2) + '\n')
(packet / 'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(platform, 'verified: 69 actions, unchanged 10 entities/queries, 14 enums;', len(source_hashes), 'matching inputs; compiler diagnostics', len(diagnostics))
