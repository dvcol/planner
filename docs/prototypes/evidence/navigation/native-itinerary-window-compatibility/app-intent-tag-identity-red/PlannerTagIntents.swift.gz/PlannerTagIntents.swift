#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerTagEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Tag")
    static var defaultQuery: PlannerTagEntityQuery { PlannerTagEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String) {
      self.id = id
      self.name = name
    }
  }

  struct PlannerTagEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag identity lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag suggestions are not implemented.")
    }
  }

  struct CreatePlannerTagIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Tag"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerTagEntity, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(.createTag(content: .init(name: name)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerTagIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerTagIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .tag }) else {
          throw PlannerTagIntentFailure(
            message:
              "Planner applied this change without returning its Tag. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(name)."
        case .incomplete:
          dialog =
            "The Tag was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(value: PlannerTagEntity(id: source.id, name: name), dialog: dialog)
      }
    }
  }

  struct GetPlannerTagIntent: AppIntent {
    static let title: LocalizedStringResource = "Get Tag"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Tag") var tag: PlannerTagEntity
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerTagEntity, Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerTagIntentFailure(message: "Get Tag is not implemented.")
    }
  }

  private struct PlannerTagIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
