from pathlib import Path
import gzip, hashlib, json, re
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
root = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
phases = ['native-calendar-modes-qualified-mac', 'native-calendar-modes-qualified-phone', 'native-calendar-modes-qualified-tablet-retry']
expected_cases = {'testDenseAllDaySchedulesKeepTimedAppointmentsAndEveryScheduleAccessible', 'testSimultaneousStartOnlyAppointmentsRemainSeparateAndUsableInDayView', 'testDayAndWeekShowTheSavedStartOnlyEntryWithoutReschedulingIt'}
records = []; source_hashes = None; image_count = 0
for phase in phases:
    packet = root / phase
    hashes = json.loads((packet / 'source-sha256.json').read_text())
    assert len(hashes) == 1061
    for relative, digest in hashes.items():
        assert hashlib.sha256((repository / relative).read_bytes()).hexdigest() == digest, relative
    if source_hashes is None: source_hashes = hashes
    assert hashes == source_hashes
    summary = json.loads((packet / 'test-results-summary.json').read_text())
    assert {key:summary[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests','expectedFailures']} == {'totalTestCount':3,'passedTests':3,'failedTests':0,'skippedTests':0,'expectedFailures':0}
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    passing = re.findall(r"Test Case '-\[PlannerNavigationUITests.SavedCalendarModesJourneyTests (\w+)\]' passed \(([\d.]+) seconds\)", log)
    assert {case for case, duration in passing} == expected_cases and len(passing) == 3
    manifest = json.loads((packet / 'selected-attachments.json').read_text())
    assert not manifest.get('excludedAttachments')
    for attachment in manifest['attachments']:
        path = packet / attachment['retainedFileName']; content = path.read_bytes()
        if path.suffix == '.gz': content = gzip.decompress(content)
        assert hashlib.sha256(content).hexdigest() == attachment['sha256']
        if path.suffix == '.png': image_count += 1
    records.append({'phase':phase,'summary':{key:summary[key] for key in ['totalTestCount','passedTests','failedTests','skippedTests']},'cases':[{'name':case,'seconds':float(duration)} for case,duration in passing],'originalAttachments':len(manifest['attachments'])})
compilation = json.loads((root/'native-calendar-modes-qualified-mac-build/source-sha256.json').read_text())
assert compilation == source_hashes
assert json.loads((root/'native-calendar-modes-qualified-mac-build/exit.json').read_text())['exitCode']==0
visuals = json.loads((root/'native-calendar-modes-validation/visual-inspection.json').read_text())
assert len(visuals['captures']) == 12
for capture in visuals['captures']:
    assert hashlib.sha256((root/capture['phase']/capture['file']).read_bytes()).hexdigest() == capture['sha256']
earlier_tablet = json.loads((root/'native-calendar-modes-qualified-tablet/test-results-summary.json').read_text())
assert earlier_tablet['passedTests'] == 2 and earlier_tablet['failedTests'] == 1
assert json.loads((root/'native-calendar-modes-qualified-tablet/source-sha256.json').read_text()) == source_hashes
packet = root / 'native-calendar-modes-validation'; packet.mkdir(exist_ok=True)
report = {'sourceInputs':len(source_hashes),'allFinalInputsMatchWorkspace':True,'passingExecutions':9,'distinctCases':3,'compilerAndRuntimeEpochs':4,'originalImages':image_count,'visuallyInspectedImages':len(visuals['captures']),'runs':records,'earlierTabletInvocation':{'passed':2,'failed':1,'scope':'Initial Add-menu helper failure before any Schedule creation. Unchanged full-group retry is recorded separately. Cause remains unestablished; no startup workaround is applied.'},'remaining':'Mac all-day span/date-input journey, Q127 inspector resizing, full accessibility/keyboard/physical qualification and broader map gates remain open.'}
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
(packet/'verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'sourceInputs':len(source_hashes),'passingExecutions':9,'distinctCases':3,'originalImages':image_count}))
