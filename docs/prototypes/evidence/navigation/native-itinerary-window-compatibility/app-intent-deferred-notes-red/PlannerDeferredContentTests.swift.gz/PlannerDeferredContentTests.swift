import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerDeferredContentTests: XCTestCase {
  func testItemNotesReadCurrentSavedTextWithoutChangingTheReturnedEntityIdentity() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Museum"
    creation.notes = "Original notes\n東京 🏛️"
    let item = try await creation.callAsFunction(donate: false)
    let initialNotes = try await item.notes
    XCTAssertEqual(initialNotes, "Original notes\n東京 🏛️")
    let edit = EditPlannerItemIntent()
    edit.item = item
    edit.notes = "Changed notes\nCafé"
    let _: Void = try await edit.callAsFunction(donate: false)
    let currentNotes = try await item.notes
    XCTAssertEqual(currentNotes, "Changed notes\nCafé")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: item.id)))
    else { return XCTFail("The getter must retain the original saved Item.") }
    XCTAssertEqual(saved.content.notes, "Changed notes\nCafé")
    XCTAssertEqual(saved.source.id, item.id)
    XCTAssertFalse(store.isSaving)
  }
}
