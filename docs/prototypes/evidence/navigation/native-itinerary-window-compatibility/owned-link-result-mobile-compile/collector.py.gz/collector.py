from pathlib import Path
import gzip, hashlib, json, os, plistlib, subprocess, sys
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase, platform = sys.argv[1:]
evidence = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet = evidence / phase
assert json.loads((packet / 'exit.json').read_text())['exitCode'] == 0
baseline = evidence / 'app-intent-link-read-final-qualification'
prior = json.loads((baseline / 'extracted-intent-identifiers.json').read_text())
paths = {
 'mac':'/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata',
 'mobile':'/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata',
 'device':'/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata'}
metadata_bytes = Path(paths[platform]).read_bytes()
metadata = json.loads(metadata_bytes)
contracts = {identifier:{parameter['name']:{'optional':parameter['isOptional'],'valueType':parameter['valueType']} for parameter in action['parameters']} for identifier,action in metadata['actions'].items()}
enum_cases = {entry['identifier']:{case['identifier']:case['displayRepresentation']['title']['key'] for case in entry['cases']} for entry in metadata['enums']}
assert sorted(metadata['actions']) == prior['actions']
assert sorted(metadata['entities']) == prior['entities']
assert sorted(metadata['queries']) == prior['queries']
assert contracts == prior['parameterContracts'] and enum_cases == prior['enumCases']
assert {identifier:metadata['actions'][identifier]['outputType'] for identifier in prior['outputContracts']} == prior['outputContracts']
(packet / 'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes,mtime=0))
(packet / 'intent-catalog-verification.json').write_text(json.dumps({'actions':45,'entities':8,'queries':8,'parameterContractsUnchanged':True,'enumsUnchanged':True,'linkReadOutputContractsUnchanged':True,'metadataSha256':hashlib.sha256(metadata_bytes).hexdigest(),'systemInvocationQualified':False},indent=2)+'\n')
source_hashes = json.loads((packet / 'source-sha256.json').read_text())
prior_hashes = json.loads((baseline / 'source-sha256.json').read_text())
changed = [relative for relative,digest in prior_hashes.items() if source_hashes.get(relative) != digest]
added = sorted(set(source_hashes)-set(prior_hashes))
assert set(changed) == {'Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift','Packages/PlannerCore/Tests/PlannerCoreStoreTests/ItemLinkEditTests.swift','Packages/PlannerCore/Tests/PlannerCoreStoreTests/ItineraryEditTests.swift','PlannerMCPTests/ItineraryEditRoutingTests.swift'}
assert added == ['Packages/PlannerCore/Tests/PlannerCoreStoreTests/OwnedLinkEditResultTests.swift']
(packet / 'baseline-source-comparison.json').write_text(json.dumps({'priorInputs':len(prior_hashes),'currentInputs':len(source_hashes),'changedInputs':changed,'addedInputs':added,'otherPriorInputsUnchanged':True},indent=2)+'\n')
if platform == 'mac':
 bundle = json.loads((packet / 'exit.json').read_text())['bundle']
 summary_bytes = subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',bundle,'--compact'],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
 summary = json.loads(summary_bytes)
 assert summary['passedTests']==57 and summary['failedTests']==0 and summary['skippedTests']==0
 (packet / 'test-results-summary.json').write_bytes(summary_bytes.rstrip()+b'\n')
 lifecycle = json.loads((packet / 'fixture-lifecycle-report.json').read_text())
 assert lifecycle['success'] is True
 print('Tests',summary['passedTests'],'disposed fixtures',len(lifecycle['removedDirectories']))
else:
 final_hashes=json.loads((evidence / 'owned-link-result-final-qualified/source-sha256.json').read_text())
 production=[relative for relative in source_hashes if relative.startswith(('Planner/','Packages/PlannerCore/Sources/','Configuration/','Planner.xcodeproj/'))]
 assert all(source_hashes[relative] == final_hashes[relative] for relative in production)
 (packet / 'final-production-source-comparison.json').write_text(json.dumps({'allProductionInputsMatchFinalMacQualification':True,'productionInputCount':len(production),'sourceEpochDifferences':sorted(relative for relative in source_hashes if source_hashes[relative] != final_hashes[relative])},indent=2)+'\n')
log = gzip.decompress((packet / 'build.log.gz').read_bytes()).decode(errors='replace') if (packet / 'build.log.gz').exists() else gzip.decompress((packet / 'test.log.gz').read_bytes()).decode(errors='replace')
diagnostics = [line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet / 'compiler-diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
assert not diagnostics, diagnostics
if platform == 'device':
 app=Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
 extensions=list((app/'PlugIns').glob('*.appex'))
 assert len(extensions)==1
 products=[]
 for product in [app,*extensions]:
  values=plistlib.loads((product/'Info.plist').read_bytes())
  executable=product/values['CFBundleExecutable']
  architectures=subprocess.check_output(['lipo','-archs',str(executable)],text=True).split()
  assert architectures==['arm64']
  products.append({'bundleIdentifier':values['CFBundleIdentifier'],'architectures':architectures,'sha256':hashlib.sha256(executable.read_bytes()).hexdigest()})
 (packet/'embedded-products-verification.json').write_text(json.dumps({'products':products,'embeddedMobileShareCount':1,'signingAllowed':False,'installedOrLaunched':False},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(platform,'catalog unchanged; inputs',len(source_hashes),'compiler diagnostics',len(diagnostics))
