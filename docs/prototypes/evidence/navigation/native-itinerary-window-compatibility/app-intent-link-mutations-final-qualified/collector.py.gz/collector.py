from pathlib import Path
import gzip, hashlib, json, os, plistlib, subprocess, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase,platform=sys.argv[1:]
evidence=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packet=evidence/phase
assert json.loads((packet/'exit.json').read_text())['exitCode']==0
baseline=evidence/'app-intent-edit-links-final-qualified'
prior=json.loads((baseline/'extracted-intent-identifiers.json').read_text())
prior_metadata=json.loads(gzip.decompress((baseline/'extract.actionsdata.gz').read_bytes()))
paths={'mac':'/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products/Debug/Planner.app/Contents/Resources/Metadata.appintents/extract.actionsdata','mobile':'/private/tmp/PlannerItemWindowsNativemobileDerivedData/Build/Products/Debug-iphonesimulator/Planner.app/Metadata.appintents/extract.actionsdata','device':'/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app/Metadata.appintents/extract.actionsdata'}
metadata_bytes=Path(paths[platform]).read_bytes()
metadata=json.loads(metadata_bytes)
new_actions={'RemovePlannerItemLinkIntent':('item','PlannerItemEntity',False),'RemovePlannerItineraryLinkIntent':('itinerary','PlannerItineraryEntity',False),'ReorderPlannerItemLinkIntent':('item','PlannerItemEntity',True),'ReorderPlannerItineraryLinkIntent':('itinerary','PlannerItineraryEntity',True)}
assert set(metadata['actions'])==set(prior['actions'])|set(new_actions)
assert sorted(metadata['entities'])==prior['entities'] and sorted(metadata['queries'])==prior['queries']
contracts={identifier:{parameter['name']:{'optional':parameter['isOptional'],'valueType':parameter['valueType']} for parameter in action['parameters']} for identifier,action in metadata['actions'].items()}
for identifier,contract in prior['parameterContracts'].items(): assert contracts[identifier]==contract
for identifier in prior['actions']: assert metadata['actions'][identifier].get('outputType')==prior_metadata['actions'][identifier].get('outputType'),identifier
outputs=dict(prior['outputContracts'])
query_parameters={}
for identifier,(owner,entity,reorder) in new_actions.items():
    expected={owner:{'optional':False,'valueType':{'entity':{'wrapper':{'typeName':entity}}}},'link':{'optional':False,'valueType':{'entity':{'wrapper':{'typeName':'PlannerLinkEntity'}}}}}
    names=['link']
    if reorder:
        expected['position']={'optional':False,'valueType':{'linkEnumeration':{'wrapper':{'identifier':'PlannerLinkReorderPosition'}}}}
        expected['relativeLink']={'optional':True,'valueType':{'entity':{'wrapper':{'typeName':'PlannerLinkEntity'}}}}
        names.append('relativeLink')
    assert contracts[identifier]==expected
    assert metadata['actions'][identifier]['isDiscoverable'] is True and metadata['actions'][identifier].get('outputType') is None
    outputs[identifier]=None
    query_parameters[identifier]={}
    for name in names:
        parameter=next(parameter for parameter in metadata['actions'][identifier]['parameters'] if parameter['name']==name)
        assert parameter['queryIdentifier']=='Planner.PlannerLinkEntityQuery' and parameter['capabilities']==4
        query_parameters[identifier][name]={'queryIdentifier':parameter['queryIdentifier'],'capabilities':parameter['capabilities']}
properties={entry['identifier']:{'optional':entry['isOptional'],'valueType':entry['valueType']} for entry in metadata['entities']['PlannerLinkEntity']['properties']}
assert properties==prior['linkPropertyContracts']
enum_cases={entry['identifier']:{case['identifier']:case['displayRepresentation']['title']['key'] for case in entry['cases']} for entry in metadata['enums']}
assert enum_cases==dict(prior['enumCases'],PlannerLinkReorderPosition={'first':'Beginning','last':'End','before':'Before link','after':'After link'})
assert metadata['queries']==prior_metadata['queries']
result={'actions':sorted(metadata['actions']),'entities':sorted(metadata['entities']),'queries':sorted(metadata['queries']),'parameterContracts':contracts,'outputContracts':outputs,'enumCases':enum_cases,'linkPropertyContracts':properties,'explicitLinkQueryParameters':query_parameters,'queryContractsUnchanged':True,'metadataSha256':hashlib.sha256(metadata_bytes).hexdigest(),'systemInvocationQualified':False,'systemDependencyInjectionQualified':False}
(packet/'extracted-intent-identifiers.json').write_text(json.dumps(result,indent=2)+'\n')
(packet/'extract.actionsdata.gz').write_bytes(gzip.compress(metadata_bytes,mtime=0))
source_hashes=json.loads((packet/'source-sha256.json').read_text())
prior_hashes=json.loads((baseline/'source-sha256.json').read_text())
changed=sorted(relative for relative,digest in prior_hashes.items() if source_hashes.get(relative)!=digest)
added=sorted(set(source_hashes)-set(prior_hashes))
assert changed==['Planner/AppIntents/PlannerLinkIntents.swift'],changed
assert added==['PlannerMCPTests/PlannerLinkRemovalIntentTests.swift','PlannerMCPTests/PlannerLinkReorderIntentTests.swift'] and len(source_hashes)==1027
(packet/'baseline-source-comparison.json').write_text(json.dumps({'priorInputs':len(prior_hashes),'currentInputs':len(source_hashes),'changedInputs':changed,'addedInputs':added,'otherPriorInputsUnchanged':True},indent=2)+'\n')
if platform=='mac':
    bundle=json.loads((packet/'exit.json').read_text())['bundle']
    summary_bytes=subprocess.check_output(['xcrun','xcresulttool','get','test-results','summary','--path',bundle,'--compact'],env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
    summary=json.loads(summary_bytes)
    assert summary['passedTests']==79 and summary['failedTests']==0 and summary['skippedTests']==0
    (packet/'test-results-summary.json').write_bytes(summary_bytes.rstrip()+b'\n')
    lifecycle=json.loads((packet/'fixture-lifecycle-report.json').read_text())
    assert lifecycle['success'] is True and len(lifecycle['removedDirectories'])==88
    print('Tests',summary['passedTests'],'disposed fixtures',len(lifecycle['removedDirectories']))
else:
    final=json.loads((evidence/'app-intent-link-mutations-final-qualified/source-sha256.json').read_text())
    assert source_hashes==final
log_path=packet/'build.log.gz'
if not log_path.exists(): log_path=packet/'test.log.gz'
log=gzip.decompress(log_path.read_bytes()).decode(errors='replace')
diagnostics=[line[:1000] for line in log.splitlines() if ': warning:' in line or ': error:' in line]
(packet/'compiler-diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
assert not diagnostics,diagnostics
if platform=='device':
    app=Path('/private/tmp/PlannerShareProducts-device/Build/Products/Debug-iphoneos/Planner.app')
    extensions=list((app/'PlugIns').glob('*.appex'))
    assert len(extensions)==1
    products=[]
    for product in [app,*extensions]:
        values=plistlib.loads((product/'Info.plist').read_bytes())
        executable=product/values['CFBundleExecutable']
        architectures=subprocess.check_output(['lipo','-archs',str(executable)],text=True).split()
        assert architectures==['arm64']
        products.append({'bundleIdentifier':values['CFBundleIdentifier'],'architectures':architectures,'sha256':hashlib.sha256(executable.read_bytes()).hexdigest()})
    (packet/'embedded-products-verification.json').write_text(json.dumps({'products':products,'embeddedMobileShareCount':1,'signingAllowed':False,'installedOrLaunched':False},indent=2)+'\n')
(packet/'collector.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(platform,'verified catalog',len(metadata['actions']),'actions;',len(source_hashes),'inputs; compiler diagnostics',len(diagnostics))
