from pathlib import Path
import json,gzip,hashlib,subprocess,os
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd()==repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
compact=json.loads((root/'native-label-file-iterations/outcomes.json').read_text())
archive=Path('/private/tmp/PlannerHeaderUnpublishedDiagnostics/native-label-file-iterations')
packets=[root/name for name in ['native-label-file-visible-mac','native-label-file-phone-visible','native-label-file-tablet-visible-dark']]
packets += [archive/entry['phase'] for entry in compact['records'] if (archive/entry['phase']/'test-results-summary.json').is_file()]
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
bundles=[];files={}
for packet in packets:
    status=json.loads((packet/'exit.json').read_text());assert status['exitCode'] in [0,65]
    assert not status.get('runnerTimedOut',False)
    bundle=Path('/private/tmp/PlannerItemWindow-'+packet.name+'.xcresult')
    assert bundle.is_dir() and not bundle.is_symlink()
    summary_path=packet/'test-results-summary.json';summary=json.loads(summary_path.read_text())
    assert summary['totalTestCount']>=1
    command=['xcrun','xcresulttool','get','test-results','summary','--path',str(bundle)]
    result=subprocess.run(command,capture_output=True,text=True,env=environment,check=True)
    assert json.loads(result.stdout)==summary,packet
    manifest=json.loads((packet/'selected-attachments.json').read_text())
    attachments=manifest['attachments']+manifest.get('excludedAttachments',[])
    for item in attachments:
        path=Path('/private/tmp/PlannerLabelAttachments-'+packet.name)/item['exportedFileName']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],path
    check=subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(bundle)],capture_output=True,text=True)
    assert check.returncode==1 and not check.stdout.strip() and not check.stderr.strip(),bundle
    bundles.append({'phase':packet.name,'path':str(bundle),'summaryPath':str(summary_path),'summarySha256':hashlib.sha256(summary_path.read_bytes()).hexdigest(),'rawSummaryExactlyMatches':True,'rawSummaryCommand':command,'verifiedSelectedOriginalAttachments':len(attachments),'nominalBytes':sum(path.stat().st_size for path in bundle.rglob('*') if path.is_file()),'openHandles':False,'result':{key:summary[key] for key in ['passedTests','failedTests','skippedTests']}})
    report_path=packet/'delivered-appearance-verification.json'
    if report_path.exists():
        report=json.loads(report_path.read_text())
        for entry in report['delivered']:
            path=Path(entry['path']);content=path.read_bytes()
            assert hashlib.sha256(content).hexdigest()==entry['sha256']
            assert gzip.decompress((packet/entry['retainedFileName']).read_bytes())==content
            assert entry['allRecordCollectionsAndValuesMatch']
            assert path.name.endswith('.json') and path.parent.is_dir()
            if report['platform']=='mac':assert path.parent.name.startswith('PlannerNativeLabelExports-')
            files[str(path)]={'path':str(path),'sha256':entry['sha256'],'bytes':len(content),'ownership':'Native delivered export whose full expected seven-source graph was verified during this qualification.','retainedBytes':str(packet/entry['retainedFileName'])}
inputs=json.loads((root/'native-label-file-mobile-inputs/fixture-provenance.json').read_text())
for entry in inputs['destinations']:
    path=Path(entry['path']);content=path.read_bytes()
    assert entry['createdByThisQualification'] and not entry['replacedExistingFile']
    assert hashlib.sha256(content).hexdigest()==entry['sha256']
    files[str(path)]={'path':str(path),'sha256':entry['sha256'],'bytes':len(content),'ownership':'New Simulator-only fixture copy created by this qualification without replacing any existing file.','retainedBytes':str(repository/inputs['source'])}
for entry in files.values():
    check=subprocess.run(['/usr/sbin/lsof','-n','-P',entry['path']],capture_output=True,text=True)
    assert check.returncode==1 and not check.stdout.strip() and not check.stderr.strip(),entry['path']
    entry['openHandles']=False
report={'evidenceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Only completed label-file raw xcresults and hash-verified test-created inputs/delivered exports. Source, current products, package caches, Simulator state and Planner datasets are excluded.','bundles':bundles,'files':list(files.values()),'bundleNominalBytes':sum(entry['nominalBytes'] for entry in bundles),'fileBytes':sum(entry['bytes'] for entry in files.values()),'deleted':False}
Path('/private/tmp/PlannerLabelFileCleanupCandidates.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'eligibleRawBundles':len(bundles),'bundleNominalBytes':report['bundleNominalBytes'],'eligibleOwnedJSONFiles':len(files),'ownedJSONBytes':report['fileBytes'],'deleted':False}))
