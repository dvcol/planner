from pathlib import Path
import json,hashlib,subprocess,shutil,gzip
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd()==repository
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
report=json.loads(Path('/private/tmp/PlannerLabelFileCleanupCandidates.json').read_text())
assert report['evidenceCommit']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for record in report['bundles']:
    path=Path(record['path'])
    assert path.parent.resolve()==Path('/private/tmp').resolve()
    assert path.name.startswith('PlannerItemWindow-native-label-file-') and path.suffix=='.xcresult'
    assert path.is_dir() and not path.is_symlink()
    assert hashlib.sha256(Path(record['summaryPath']).read_bytes()).hexdigest()==record['summarySha256']
    check=subprocess.run(['/usr/sbin/lsof','-n','-P','+D',str(path)],capture_output=True,text=True)
    assert check.returncode==1 and not check.stdout.strip() and not check.stderr.strip(),path
for record in report['bundles']:
    path=Path(record['path']);shutil.rmtree(path);assert not path.exists();record['removed']=True
for record in report['files']:
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()==record['sha256']
    record['removed']=False
    record['preservedFor']='Small native fixture/delivered-file inputs retained for local reruns and review; these are not part of disk reclamation.'
report['deleted']=True
report['actualCleanupScope']='12 completed raw xcresult directories only. All 16 small JSON fixtures/exports, original extracted attachments, private diagnostic packets, source, products, caches, Simulator state and Planner datasets remain intact.'
packet=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility/native-label-file-result-cleanup'
packet.mkdir(exist_ok=False)
(packet/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
for filename in ['/private/tmp/PlannerLabelFileCleanupPreflight.py','/private/tmp/PlannerLabelFileCleanupRemove.py']:
    source=Path(filename);(packet/(source.name+'.gz')).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
print(json.dumps({'removedRawBundles':len(report['bundles']),'removedNominalBytes':report['bundleNominalBytes'],'preservedOwnedJSONFiles':len(report['files']),'preservedOwnedJSONBytes':report['fileBytes']}))
