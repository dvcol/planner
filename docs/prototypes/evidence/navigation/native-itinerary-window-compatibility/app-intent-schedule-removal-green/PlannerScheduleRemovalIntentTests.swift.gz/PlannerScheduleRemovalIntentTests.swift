import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleRemovalIntentTests: XCTestCase {
  func testRemovingOneItemBookingPreservesItsOwnerOtherBookingsAndItineraryReference()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    guard
      case .applied(_, .complete) = await fixture.planner.execute(
        .init(
          operationId: UUID(), session: fixture.session,
          command: .setCompletion(scope: .globalItem(itemId: fixture.item.id), done: true))
      ).outcome
    else { return XCTFail("The Item's independent state must be saved first.") }
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let choices = try await query.entities(for: [fixture.timed.id])
    let removal = RemovePlannerScheduleIntent()
    removal.schedule = try XCTUnwrap(choices.first)
    let _: Void = try await removal.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let item)) = await reopened.read(
        session: session, request: .source(fixture.item)),
      case .source(.itinerary(let itinerary)) = await reopened.read(
        session: session, request: .source(fixture.itinerary)),
      case .source(.schedule(let other)) = await reopened.read(
        session: session, request: .source(fixture.outside)),
      case .source(.schedule(let retained)) = await reopened.read(
        session: session, request: .source(fixture.allDay)),
      case .failed(let missing) = await reopened.read(
        session: session, request: .source(fixture.timed))
    else { return XCTFail("Only the selected booking should be absent after reopening.") }
    XCTAssertEqual(missing.code, "missingReference")
    XCTAssertEqual(item.content.title, "Museum")
    XCTAssertEqual(item.content.estimate?.minutes, 90)
    XCTAssertEqual(item.state.globalDone, true)
    XCTAssertEqual(item.state.archived, false)
    XCTAssertEqual(other.content.source, fixture.item)
    XCTAssertEqual(retained.content.source, fixture.itinerary)
    XCTAssertTrue(
      itinerary.references.contains {
        if case .itineraryEntry(_, _, let source) = $0 { return source == fixture.item }
        return false
      })
    let remaining = try await query.suggestedEntities()
    XCTAssertEqual(Set(remaining.map(\.id)), [fixture.outside.id, fixture.allDay.id])
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}
