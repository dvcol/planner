import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerAssignedLabelIntentTests: XCTestCase {
  func testItemCategoriesReturnOnlyCurrentSharedAssignmentsWithDistinctIdentities() async throws {
    let fixture = try await makeLabelAssociationIntentFixture()
    let assignment = SetPlannerItemCategoryIntent()
    assignment.item = .init(id: fixture.item.id, title: "Cached Item", done: false, archived: true)
    assignment.category = .init(id: fixture.extraCategory.id, name: "Cached Category")
    let _: Void = try await assignment.callAsFunction(donate: false)
    let rename = RenamePlannerCategoryIntent()
    rename.category = assignment.category
    rename.name = "Museums"
    let _: Void = try await rename.callAsFunction(donate: false)
    guard case .exported(let before) = await fixture.planner.exportData(session: fixture.session)
    else { return XCTFail("The read fixture must have current saved shared-label names.") }
    let reading = GetPlannerItemCategoriesIntent()
    reading.item = assignment.item
    let categories = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(Set(categories.map(\.id)), [fixture.category.id, fixture.extraCategory.id])
    XCTAssertEqual(categories.map(\.name), ["Museums", "Museums"])
    XCTAssertEqual(categories.count, 2)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .exported(let after) = await reopened.exportData(session: session)
    else { return XCTFail("Reading label assignments must preserve the saved planner.") }
    XCTAssertEqual(after, before)
    XCTAssertFalse(fixture.store.recoveryBlocked)
    XCTAssertFalse(fixture.store.isSaving)
  }
}
