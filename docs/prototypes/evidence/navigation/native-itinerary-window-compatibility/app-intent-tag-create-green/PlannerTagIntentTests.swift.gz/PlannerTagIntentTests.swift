import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerTagIntentTests: XCTestCase {
  func testCreateTagReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerTagIntent()
    creation.name = "rainy-day"
    let tag = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(tag.name, "rainy-day")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.tag(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .tag, id: tag.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .tag, archive: .all))))
    else { return XCTFail("The returned Tag must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, tag.id)
    XCTAssertEqual(current.content.name, "rainy-day")
    XCTAssertNil(current.content.color)
    XCTAssertNil(current.content.iconName)
    XCTAssertNil(current.state.archived)
    XCTAssertNil(current.state.globalDone)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .tag, id: tag.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
