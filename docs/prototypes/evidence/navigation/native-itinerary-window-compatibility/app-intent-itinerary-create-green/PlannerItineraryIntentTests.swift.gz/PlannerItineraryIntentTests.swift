import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerItineraryIntentTests: XCTestCase {
  func testCreateItineraryReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerItineraryIntent()
    creation.title = "Tokyo Weekend"
    creation.notes = "Museum, lunch and a return to the Hotel"
    let itinerary = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(itinerary.title, "Tokyo Weekend")
    XCTAssertFalse(itinerary.archived)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.itinerary(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .itinerary, id: itinerary.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .itinerary, archive: .all))))
    else { return XCTFail("The returned Itinerary must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, itinerary.id)
    XCTAssertEqual(current.content.title, "Tokyo Weekend")
    XCTAssertEqual(current.content.notes, "Museum, lunch and a return to the Hotel")
    XCTAssertEqual(current.state.archived, false)
    XCTAssertNil(current.state.globalDone)
    XCTAssertEqual(current.progress.state, .empty)
    XCTAssertEqual(current.progress.totalCount, 0)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertTrue(current.listEntrySummaries.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .itinerary, id: itinerary.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(
        path: "PlannerItineraryIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
