import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class SavedPlanOpeningTests: XCTestCase {
  func testOpenListIntentRequestsItsExactSavedIdentityWithoutClaimingNavigation() async throws {
    let (_, _, store) = try makePlannerIntentStorage()
    let creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    AppDependencyManager.shared.add(dependency: store)
    let list = try await creation.callAsFunction(donate: false)
    let opening = SavedPlanOpeningCoordinator()
    AppDependencyManager.shared.add(dependency: opening)
    let action = OpenPlannerListIntent()
    action.target = .init(id: list.id, name: "Stale title", archived: false)
    _ = try await action.perform()
    XCTAssertEqual(opening.pending?.source, .init(kind: .list, id: list.id))
    XCTAssertFalse(try XCTUnwrap(opening.pending).isClaimed)
    XCTAssertNil(opening.pending?.windowIdentifier)
  }

  func testClosingOrCancellingTheRecipientNeverRedirectsItsPendingDraftDecision() async throws {
    let (_, _, store) = try makePlannerIntentStorage()
    let creation = try await store.executeAppIntent(.createList(content: .init(name: "Origin")))
    guard case .applied(let applied, .complete) = creation.outcome else {
      return XCTFail("The source must be saved before testing its opening lifecycle.")
    }
    let source = try XCTUnwrap(applied.generated.first)
    let opening = SavedPlanOpeningCoordinator()
    let recipient = UUID()
    let other = UUID()
    opening.register(windowIdentifier: recipient, isActive: true, isReady: true)
    opening.register(windowIdentifier: other, isActive: false, isReady: true)
    let request = try await opening.submit(source: source, store: store)
    _ = try await opening.claim(windowIdentifier: recipient, store: store)
    opening.cancel(requestIdentifier: request.identifier, windowIdentifier: other)
    XCTAssertEqual(opening.pending?.identifier, request.identifier)
    opening.unregister(windowIdentifier: recipient)
    XCTAssertNil(opening.pending)
    let redirected = try await opening.claim(windowIdentifier: other, store: store)
    XCTAssertNil(redirected)
    do {
      _ = try await opening.resolveNavigation(
        requestIdentifier: request.identifier, windowIdentifier: recipient, store: store)
      XCTFail("A closed recipient cannot finish navigating later.")
    } catch { XCTAssertNil(opening.pending) }
    let next = try await opening.submit(source: source, store: store)
    XCTAssertEqual(next.windowIdentifier, other)
    _ = try await opening.claim(windowIdentifier: other, store: store)
    opening.cancel(requestIdentifier: next.identifier, windowIdentifier: other)
    XCTAssertNil(opening.pending)
    let retry = try await opening.submit(source: source, store: store)
    XCTAssertNotEqual(retry.identifier, next.identifier)
  }

  func testForegroundRecipientKeepsItsRequestWhenAnotherOpeningArrives() async throws {
    let (_, _, store) = try makePlannerIntentStorage()
    let creation = try await store.executeAppIntent(.createItinerary(content: .init(title: "Weekend")))
    guard case .applied(let applied, .complete) = creation.outcome else {
      return XCTFail("The Itinerary must be durably saved before opening.")
    }
    let source = try XCTUnwrap(applied.generated.first { $0.kind == .itinerary })
    let opening = SavedPlanOpeningCoordinator()
    let first = UUID()
    let second = UUID()
    opening.register(windowIdentifier: first, isActive: true, isReady: true)
    opening.register(windowIdentifier: second, isActive: false, isReady: true)
    opening.register(windowIdentifier: first, isActive: false, isReady: true)
    opening.register(windowIdentifier: second, isActive: true, isReady: true)
    let request = try await opening.submit(source: source, store: store)
    XCTAssertEqual(request.windowIdentifier, second)
    do {
      _ = try await opening.submit(source: source, store: store)
      XCTFail("A second external request must not replace a pending draft decision.")
    } catch {
      XCTAssertTrue(error.localizedDescription.contains("already"))
    }
    XCTAssertEqual(opening.pending?.identifier, request.identifier)
    let otherClaim = try await opening.claim(windowIdentifier: first, store: store)
    XCTAssertNil(otherClaim)
    let claim = try await opening.claim(windowIdentifier: second, store: store)
    XCTAssertEqual(claim?.identifier, request.identifier)
  }

  func testColdRequestWaitsForOneReadyWindowAndResolvesOnlyItsExactPlan() async throws {
    let (_, _, store) = try makePlannerIntentStorage()
    let result = try await store.executeAppIntent(.createList(content: .init(name: "Tokyo Food")))
    guard case .applied(let applied, .complete) = result.outcome else {
      return XCTFail("The exact saved List must exist before requesting navigation.")
    }
    let source = try XCTUnwrap(applied.generated.first { $0.kind == .list })
    let opening = SavedPlanOpeningCoordinator()
    let request = try await opening.submit(source: source, store: store)
    XCTAssertEqual(opening.pending?.identifier, request.identifier)
    XCTAssertNil(opening.pending?.windowIdentifier)
    let recipient = UUID()
    let otherWindow = UUID()
    opening.register(windowIdentifier: recipient, isActive: true, isReady: true)
    opening.register(windowIdentifier: otherWindow, isActive: false, isReady: true)
    let otherClaim = try await opening.claim(windowIdentifier: otherWindow, store: store)
    XCTAssertNil(otherClaim)
    let claim = try await opening.claim(windowIdentifier: recipient, store: store)
    XCTAssertEqual(claim?.identifier, request.identifier)
    let repeatedClaim = try await opening.claim(windowIdentifier: recipient, store: store)
    XCTAssertNil(repeatedClaim)
    XCTAssertNotNil(opening.pending)
    let target = try await opening.resolveNavigation(
      requestIdentifier: request.identifier, windowIdentifier: recipient, store: store)
    XCTAssertEqual(target, source)
    XCTAssertNil(opening.pending)
  }
}
