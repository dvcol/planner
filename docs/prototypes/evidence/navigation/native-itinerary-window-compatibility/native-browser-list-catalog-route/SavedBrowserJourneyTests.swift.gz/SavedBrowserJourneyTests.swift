import Network
import XCTest

@MainActor
final class SavedBrowserJourneyTests: XCTestCase {
  func testSavedWebsiteOpensInsidePlannerAndReturnsToTheSameItem() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    #if os(macOS)
      application.plannerElement("saved.section.items").activateForPlannerJourney()
    #else
      application.buttons["Items"].firstMatch.activateForPlannerJourney()
    #endif
    createLinkedItem(in: application, destination: destination)
    let savedLink = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.")
    ).firstMatch
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    for _ in 0..<6 where !savedLink.isHittable { application.swipeUp() }
    let originalLinkIdentity = savedLink.identifier
    XCTAssertEqual(savedLink.value as? String, destination.absoluteString)
    savedLink.activateForPlannerJourney()
    let returnToItem = application.buttons["saved.browser.return"]
    guard returnToItem.waitForExistence(timeout: 10) else {
      let hierarchy = XCTAttachment(string: application.debugDescription)
      hierarchy.name = "Unavailable browser own-app hierarchy, state \(application.state.rawValue)"
      hierarchy.lifetime = .keepAlways
      add(hierarchy)
      if application.windows.firstMatch.exists {
        let capture = XCTAttachment(screenshot: application.windows.firstMatch.screenshot())
        capture.name = "Unavailable browser own-app window"
        capture.lifetime = .keepAlways
        add(capture)
      }
      XCTFail("Opening the saved guide must present Planner's native browser return control.")
      return
    }
    XCTAssertEqual(application.state, .runningForeground)
    let page = application.webViews.firstMatch
    XCTAssertTrue(page.waitForExistence(timeout: 10))
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].waitForExistence(timeout: 10))
    XCTAssertTrue(server.requestLines.contains("GET /guide HTTP/1.1"))
    let capture = XCTAttachment(screenshot: application.windows.firstMatch.screenshot())
    capture.name = "Saved guide opens in native Planner webpage"
    capture.lifetime = .keepAlways
    add(capture)
    returnToItem.activateForPlannerJourney()
    let restoredLink = application.descendants(matching: .any)
      .matching(identifier: originalLinkIdentity).firstMatch
    XCTAssertTrue(restoredLink.waitForExistence(timeout: 10))
    XCTAssertEqual(restoredLink.value as? String, destination.absoluteString)
    let catalogBack = application.navigationBars.buttons["Items"].firstMatch
    if catalogBack.exists { catalogBack.activateForPlannerJourney() }
    XCTAssertTrue(
      application.savedPlannerItemRows("Museum reading").firstMatch.waitForExistence(timeout: 5))
    XCTAssertEqual(application.savedPlannerItemRows("Museum reading").count, 1)
  }

  func testNativeWebpageHistoryAndReloadKeepTheSavedBookmarkUnchanged() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    #if os(macOS)
      application.plannerElement("saved.section.items").activateForPlannerJourney()
    #else
      application.buttons["Items"].firstMatch.activateForPlannerJourney()
    #endif
    createLinkedItem(in: application, destination: destination)
    let savedLink = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.")
    ).firstMatch
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    let savedLinkIdentifier = savedLink.identifier
    savedLink.activateForPlannerJourney()
    let page = application.webViews.firstMatch
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].waitForExistence(timeout: 10))
    page.links["Garden guide"].activateForPlannerJourney()
    XCTAssertTrue(page.staticTexts["Garden guide fixture"].waitForExistence(timeout: 10))
    let back = application.buttons["saved.browser.back"]
    XCTAssertTrue(back.waitForExistence(timeout: 5))
    XCTAssertTrue(back.isEnabled)
    back.activateForPlannerJourney()
    XCTAssertTrue(page.staticTexts["Museum guide fixture"].waitForExistence(timeout: 10))
    let forward = application.buttons["saved.browser.forward"]
    XCTAssertTrue(forward.isEnabled)
    forward.activateForPlannerJourney()
    XCTAssertTrue(page.staticTexts["Garden guide fixture"].waitForExistence(timeout: 10))
    let previousRequests = server.requestLines.filter { $0 == "GET /garden HTTP/1.1" }.count
    application.buttons["saved.browser.reload"].activateForPlannerJourney()
    let deadline = ContinuousClock.now.advanced(by: .seconds(5))
    while ContinuousClock.now < deadline,
      server.requestLines.filter({ $0 == "GET /garden HTTP/1.1" }).count <= previousRequests
    {
      try await Task.sleep(for: .milliseconds(20))
    }
    XCTAssertGreaterThan(
      server.requestLines.filter { $0 == "GET /garden HTTP/1.1" }.count, previousRequests)
    XCTAssertTrue(page.staticTexts["Garden guide fixture"].waitForExistence(timeout: 10))
    application.buttons["saved.browser.return"].activateForPlannerJourney()
    let retainedLink = application.descendants(matching: .any)
      .matching(identifier: savedLinkIdentifier).firstMatch
    XCTAssertTrue(retainedLink.waitForExistence(timeout: 10))
    XCTAssertEqual(retainedLink.value as? String, destination.absoluteString)
  }

  func testCalendarSourceOpensItsGuideAndReturnsToTheSameScheduleDetails() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    createLinkedItem(in: application, destination: destination)
    let links = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link."))
    XCTAssertTrue(links.firstMatch.waitForExistence(timeout: 10))
    let savedLinkIdentifier = links.firstMatch.identifier
    let actions = application.plannerElement("saved.item.actions")
    XCTAssertTrue(actions.waitForExistence(timeout: 10))
    actions.activateForPlannerJourney()
    application.plannerElement("Schedule item").activateForPlannerJourney()
    application.plannerElement("saved.schedule.save").activateForPlannerJourney()
    let schedule = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.schedule.")
    ).firstMatch
    XCTAssertTrue(schedule.waitForExistence(timeout: 10))
    let scheduleIdentifier = schedule.identifier
      .replacingOccurrences(of: "saved.item.schedule.", with: "")
    application.openPlannerSection("Calendar")
    let booking = application.descendants(matching: .any)
      .matching(identifier: "saved.calendar.schedule.\(scheduleIdentifier)").firstMatch
    XCTAssertTrue(booking.waitForExistence(timeout: 10))
    booking.activateForPlannerJourney()
    let savedLink = application.descendants(matching: .any)
      .matching(identifier: savedLinkIdentifier).firstMatch
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    for _ in 0..<6 where !savedLink.isHittable { application.swipeUp() }
    savedLink.activateForPlannerJourney()
    let returnToPlanner = application.buttons["saved.browser.return"]
    XCTAssertTrue(returnToPlanner.waitForExistence(timeout: 10))
    XCTAssertTrue(
      application.webViews.firstMatch.staticTexts["Museum guide fixture"]
        .waitForExistence(timeout: 10))
    returnToPlanner.activateForPlannerJourney()
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    XCTAssertEqual(savedLink.value as? String, destination.absoluteString)
    XCTAssertTrue(schedule.waitForExistence(timeout: 10))
  }

  func testItineraryGuideReturnsToItsOwnPlanInsteadOfAnItemPlaceholder() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Itineraries")
    application.plannerElement("saved.itinerary.new").activateForPlannerJourney()
    let title = application.textFields["saved.itinerary.title"]
    XCTAssertTrue(title.waitForExistence(timeout: 5))
    title.activateForPlannerJourney()
    title.typeText("Museum route")
    let addLink = application.plannerElement("saved.itinerary.link.add")
    for _ in 0..<6 where !addLink.isHittable { application.swipeUp() }
    XCTAssertTrue(addLink.isHittable)
    addLink.activateForPlannerJourney()
    let linkInput = application.textFields.matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.itinerary.link.url.")
    ).firstMatch
    XCTAssertTrue(linkInput.waitForExistence(timeout: 5))
    linkInput.activateForPlannerJourney()
    linkInput.typeText(destination.absoluteString)
    application.plannerElement("saved.itinerary.save").activateForPlannerJourney()
    let savedLink = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.")
    ).firstMatch
    XCTAssertTrue(savedLink.waitForExistence(timeout: 10))
    let savedLinkIdentifier = savedLink.identifier
    for _ in 0..<6 where !savedLink.isHittable { application.swipeUp() }
    savedLink.activateForPlannerJourney()
    let returnToPlan = application.buttons["saved.browser.return"]
    XCTAssertTrue(returnToPlan.waitForExistence(timeout: 10))
    XCTAssertEqual(returnToPlan.label, "Return to itinerary")
    XCTAssertTrue(
      application.webViews.firstMatch.staticTexts["Museum guide fixture"]
        .waitForExistence(timeout: 10))
    returnToPlan.activateForPlannerJourney()
    let retainedLink = application.descendants(matching: .any)
      .matching(identifier: savedLinkIdentifier).firstMatch
    XCTAssertTrue(retainedLink.waitForExistence(timeout: 10))
    XCTAssertEqual(retainedLink.value as? String, destination.absoluteString)
    XCTAssertTrue(application.staticTexts["Museum route"].firstMatch.exists)
  }

  func testListGuideReturnsToTheSameLocallyCompletedAppearance() async throws {
    continueAfterFailure = false
    let server = try BrowserJourneyServer()
    let destination = try await server.start()
    defer { server.stop() }
    let application = XCUIApplication()
    application.launchArguments = ["--local-prototype-dataset", UUID().uuidString]
    application.launchSavedPlannerJourney()
    application.openPlannerSection("Items")
    createLinkedItem(in: application, destination: destination)
    XCTAssertTrue(application.plannerElement("saved.item.actions").waitForExistence(timeout: 10))
    application.openPlannerSection("Lists")
    let newList = application.plannerElement("saved.list.new")
    XCTAssertTrue(newList.waitForExistence(timeout: 10))
    newList.activateForPlannerJourney()
    let name = application.textFields["saved.list.name"]
    XCTAssertTrue(name.waitForExistence(timeout: 5))
    name.activateForPlannerJourney()
    name.typeText("Reading list")
    application.plannerElement("saved.list.save").activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["No items"].waitForExistence(timeout: 10))
    application.openSavedPlannerListAddMenu()
    application.plannerElement("saved.list.add").activateForPlannerJourney()
    let candidate = application.staticTexts["Museum reading"].firstMatch
    XCTAssertTrue(candidate.waitForExistence(timeout: 10))
    candidate.activateForPlannerJourney()
    application.plannerElement("saved.membership.add").activateForPlannerJourney()
    let markDone = application.buttons["Mark Museum reading done in this List"].firstMatch
    XCTAssertTrue(markDone.waitForExistence(timeout: 10))
    markDone.activateForPlannerJourney()
    let markUndone = application.buttons["Mark Museum reading undone in this List"].firstMatch
    XCTAssertTrue(markUndone.waitForExistence(timeout: 10))
    application.savedPlannerItemRows("Museum reading").firstMatch.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["In Reading list"].waitForExistence(timeout: 10))
    XCTAssertTrue(application.staticTexts["Completed"].firstMatch.exists)
    let links = application.descendants(matching: .any).matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link."))
    XCTAssertTrue(links.firstMatch.waitForExistence(timeout: 10))
    let linkIdentifier = links.firstMatch.identifier
    links.firstMatch.activateForPlannerJourney()
    let returnToItem = application.buttons["saved.browser.return"]
    XCTAssertTrue(returnToItem.waitForExistence(timeout: 10))
    XCTAssertTrue(
      application.webViews.firstMatch.staticTexts["Museum guide fixture"]
        .waitForExistence(timeout: 10))
    returnToItem.activateForPlannerJourney()
    XCTAssertTrue(application.staticTexts["In Reading list"].waitForExistence(timeout: 10))
    XCTAssertTrue(application.staticTexts["Completed"].firstMatch.exists)
    let retainedLink = application.descendants(matching: .any)
      .matching(identifier: linkIdentifier).firstMatch
    XCTAssertTrue(retainedLink.waitForExistence(timeout: 10))
    XCTAssertEqual(retainedLink.value as? String, destination.absoluteString)
    application.openPlannerSection("Items")
    let completion = application.descendants(matching: .any)
      .matching(identifier: "saved.item.completion").firstMatch
    if !completion.waitForExistence(timeout: 2) {
      let source = application.savedPlannerItemRows("Museum reading").firstMatch
      XCTAssertTrue(source.waitForExistence(timeout: 10))
      source.activateForPlannerJourney()
    }
    XCTAssertTrue(completion.waitForPlannerBooleanState(false))
  }

  private func createLinkedItem(in application: XCUIApplication, destination: URL) {
    application.openSavedPlannerNewItemEditor()
    let title = application.textFields["saved.item.title"]
    XCTAssertTrue(title.waitForExistence(timeout: 5))
    title.activateForPlannerJourney()
    title.typeText("Museum reading")
    let addLink = application.plannerElement("saved.item.link.add")
    for _ in 0..<6 where !addLink.isHittable { application.swipeUp() }
    XCTAssertTrue(addLink.isHittable)
    addLink.activateForPlannerJourney()
    let linkInput = application.textFields.matching(
      NSPredicate(format: "identifier BEGINSWITH %@", "saved.item.link.url.")
    ).firstMatch
    XCTAssertTrue(linkInput.waitForExistence(timeout: 5))
    linkInput.activateForPlannerJourney()
    linkInput.typeText(destination.absoluteString)
    application.plannerElement("saved.item.save").activateForPlannerJourney()
  }
}

private final class BrowserJourneyServer: @unchecked Sendable {
  private let listener: NWListener
  private let queue = DispatchQueue(label: "Planner.BrowserJourneyServer")
  private let lock = NSLock()
  private var port: NWEndpoint.Port?
  private var failure: NWError?
  private var observedRequestLines: [String] = []
  private var connections: [NWConnection] = []

  init() throws {
    let parameters = NWParameters.tcp
    parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
    listener = try NWListener(using: parameters)
  }

  var requestLines: [String] { lock.withLock { observedRequestLines } }

  func start() async throws -> URL {
    listener.stateUpdateHandler = { [weak self] state in
      guard let self else { return }
      lock.withLock {
        if case .ready = state { port = listener.port }
        if case .failed(let error) = state { failure = error }
      }
    }
    listener.newConnectionHandler = { [weak self] connection in
      guard let self else { return }
      connections.append(connection)
      connection.start(queue: queue)
      receive(connection, bytes: Data())
    }
    listener.start(queue: queue)
    let deadline = ContinuousClock.now.advanced(by: .seconds(5))
    while ContinuousClock.now < deadline {
      let observation = lock.withLock { (port, failure) }
      if let failure = observation.1 { throw failure }
      if let port = observation.0,
        let destination = URL(string: "http://localhost:\(port.rawValue)/guide")
      {
        return destination
      }
      try await Task.sleep(for: .milliseconds(10))
    }
    throw URLError(.timedOut)
  }

  func stop() {
    queue.async { [self] in
      listener.cancel()
      for connection in connections { connection.cancel() }
      connections.removeAll()
    }
  }

  private func receive(_ connection: NWConnection, bytes: Data) {
    connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) {
      [weak self] incoming, _, complete, error in
      guard let self else { return }
      let received = bytes + (incoming ?? Data())
      guard error == nil, received.count <= 8192 else {
        connection.cancel()
        return
      }
      guard let header = String(data: received, encoding: .utf8), header.contains("\r\n\r\n") else {
        if complete { connection.cancel() } else { receive(connection, bytes: received) }
        return
      }
      let requestLine = header.components(separatedBy: "\r\n").first ?? ""
      lock.withLock { observedRequestLines.append(requestLine) }
      let body: String
      if requestLine.contains(" /garden ") {
        body = """
          <!doctype html><html><head><title>Garden guide</title></head>
          <body><h1>Garden guide fixture</h1><p>Enter through the east gate.</p></body></html>
          """
      } else {
        body = """
          <!doctype html><html><head><title>Museum guide</title></head>
          <body><h1>Museum guide fixture</h1><p>Meet at the garden entrance.</p>
          <a href="/garden">Garden guide</a></body></html>
          """
      }
      let content = requestLine.hasPrefix("HEAD ") ? "" : body
      let response =
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(content)"
      connection.send(
        content: Data(response.utf8),
        completion: .contentProcessed { _ in connection.cancel() })
    }
  }
}
