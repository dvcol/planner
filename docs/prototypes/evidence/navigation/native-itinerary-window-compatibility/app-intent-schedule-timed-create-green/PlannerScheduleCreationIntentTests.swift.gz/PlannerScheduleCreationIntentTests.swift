import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleCreationIntentTests: XCTestCase {
  func
    testTimedItemCreationUsesPlanningCivilTimeAndReturnsItsExactSavedIdentityWithoutAnInferredEnd()
    async throws
  {
    let fixture = try await makeEstimateResetIntentFixture()
    let before = try await readEstimateResetSources(fixture)
    let action = CreatePlannerTimedItemScheduleIntent()
    action.item = .init(id: fixture.item.id, title: "Cached name", done: true, archived: true)
    action.start = DateComponents(
      calendar: Calendar(identifier: .gregorian), timeZone: TimeZone(identifier: "Europe/Paris"),
      year: 2026, month: 10, day: 9, hour: 10, minute: 0)
    action.planningTimeZone = try XCTUnwrap(PlannerTimeZoneEntity(identifier: "Asia/Tokyo"))
    let created = try await action.callAsFunction(donate: false)
    let expectedStart = try Date.ISO8601FormatStyle().parse("2026-10-09T01:00:00Z")
    XCTAssertEqual(created.title, "Museum")
    XCTAssertEqual(created.sourceType, "Item")
    XCTAssertEqual(created.start, expectedStart)
    XCTAssertNil(created.end)
    XCTAssertEqual(created.planningTimeZone?.id, "Asia/Tokyo")
    XCTAssertNotEqual(created.id, fixture.itemSchedule.id)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .schedule, id: created.id)))
    else { return XCTFail("Return the exact Schedule identity that was durably saved.") }
    XCTAssertEqual(saved.content.source, fixture.item)
    XCTAssertEqual(
      saved.content.form,
      PlannerScheduleForm.timed(start: expectedStart, end: nil, planningTimeZone: "Asia/Tokyo"))
    let after = try await readEstimateResetSources(fixture, planner: reopened, session: session)
    XCTAssertEqual(after.item.fieldHashes, before.item.fieldHashes)
    XCTAssertEqual(after.list.content, before.list.content)
    XCTAssertEqual(after.itinerary.fieldHashes, before.itinerary.fieldHashes)
    try await assertEstimateResetContextsAndBookings(fixture, planner: reopened, session: session)
  }
}
