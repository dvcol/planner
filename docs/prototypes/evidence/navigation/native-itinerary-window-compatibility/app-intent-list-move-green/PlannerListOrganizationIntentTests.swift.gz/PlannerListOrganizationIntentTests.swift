import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerListOrganizationIntentTests: XCTestCase {
  func testRemoveOnlyTheSelectedMembershipPreservesSharedItemOtherContextsOrderAndSchedule()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let museum = try await save(.createItem(content: .init(title: "Museum", notes: "Shared notes")))
    let item = try XCTUnwrap(museum.generated.first)
    let lunch = try await save(.createItem(content: .init(title: "Lunch")))
    let otherItem = try XCTUnwrap(lunch.generated.first)
    let first = try await save(.createList(content: .init(name: "Tokyo Food")))
    let sourceList = try XCTUnwrap(first.generated.first)
    let second = try await save(.createList(content: .init(name: "Wishlist")))
    let otherList = try XCTUnwrap(second.generated.first)
    let selected = try await save(
      .addMembership(itemId: item.id, listId: sourceList.id, placement: .last))
    let survivor = try await save(
      .addMembership(itemId: otherItem.id, listId: sourceList.id, placement: .last))
    let other = try await save(
      .addMembership(itemId: item.id, listId: otherList.id, placement: .last))
    guard case .membership(let removedIdentifier, _, _)? = selected.generatedReferences.first,
      case .membership(let survivorIdentifier, _, _)? = survivor.generatedReferences.first,
      case .membership(let otherIdentifier, _, _)? = other.generatedReferences.first
    else { return XCTFail("The fixture must retain each independent membership identity.") }
    let removedAppearance = PlannerAppearance.listMembership(
      listId: sourceList.id, membershipId: removedIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(removedAppearance), done: true))
    let createdPlan = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    let listEntry = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: sourceList, placement: .last))
    let direct = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: item, placement: .last))
    guard case .itineraryEntry(let directIdentifier, _, _)? = direct.generatedReferences.first
    else { return XCTFail("The direct route appearance must survive membership removal.") }
    let scheduleForm = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let booking = try await save(.createSchedule(source: item, form: scheduleForm))
    let schedule = try XCTUnwrap(booking.generated.first)
    guard
      case .source(.item(let before)) = await planner.read(
        session: session, request: .source(item))
    else { return XCTFail("Shared content must be readable before organization changes.") }
    let removing = RemovePlannerItemFromListIntent()
    removing.item = .init(id: item.id, title: "Obsolete title", done: true, archived: true)
    removing.list = .init(id: sourceList.id, name: "Obsolete List", archived: true)
    let _: Void = try await removing.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let after)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let savedList)) = await reopened.read(
        session: reopenedSession, request: .source(sourceList)),
      case .source(.list(let savedOther)) = await reopened.read(
        session: reopenedSession, request: .source(otherList)),
      case .source(.itinerary(let savedPlan)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let savedSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule)),
      case .appearance(let otherState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(.listMembership(listId: otherList.id, membershipId: otherIdentifier))),
      case .appearance(let directState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(
          .directItineraryItem(itineraryId: itinerary.id, entryId: directIdentifier))),
      case .failed(let removedFailure) = await reopened.read(
        session: reopenedSession, request: .appearance(removedAppearance))
    else { return XCTFail("Only the selected membership may disappear from reopened storage.") }
    XCTAssertEqual(after.content.title, "Museum")
    XCTAssertEqual(after.content.notes, "Shared notes")
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.updatedAt, before.updatedAt)
    XCTAssertEqual(after.state.globalDone, false)
    XCTAssertEqual(after.state.archived, false)
    XCTAssertEqual(
      savedList.references,
      [.membership(id: survivorIdentifier, list: sourceList, item: otherItem)]
        + listEntry.generatedReferences
    )
    XCTAssertEqual(savedList.content.name, "Tokyo Food")
    XCTAssertEqual(savedOther.references, other.generatedReferences)
    XCTAssertFalse(otherState.localDone)
    XCTAssertFalse(otherState.effectiveDone)
    XCTAssertFalse(directState.localDone)
    XCTAssertFalse(directState.effectiveDone)
    XCTAssertEqual(savedPlan.progress.totalCount, 2)
    XCTAssertEqual(savedPlan.progress.doneCount, 0)
    XCTAssertEqual(savedSchedule.content.form, scheduleForm)
    XCTAssertEqual(removedFailure.code, "missingReference")
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testMoveAtomicallyCreatesANewTodoMembershipAndPreservesOtherContextsSourceAndSchedule()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let museum = try await save(.createItem(content: .init(title: "Museum", notes: "Shared notes")))
    let item = try XCTUnwrap(museum.generated.first)
    let lunch = try await save(.createItem(content: .init(title: "Lunch")))
    let otherItem = try XCTUnwrap(lunch.generated.first)
    let first = try await save(.createList(content: .init(name: "From")))
    let sourceList = try XCTUnwrap(first.generated.first)
    let second = try await save(.createList(content: .init(name: "To")))
    let destinationList = try XCTUnwrap(second.generated.first)
    let third = try await save(.createList(content: .init(name: "Other")))
    let otherList = try XCTUnwrap(third.generated.first)
    let selected = try await save(
      .addMembership(itemId: item.id, listId: sourceList.id, placement: .last))
    let survivor = try await save(
      .addMembership(itemId: otherItem.id, listId: destinationList.id, placement: .last))
    let other = try await save(
      .addMembership(itemId: item.id, listId: otherList.id, placement: .last))
    guard case .membership(let originalIdentifier, _, _)? = selected.generatedReferences.first,
      case .membership(let otherIdentifier, _, _)? = other.generatedReferences.first
    else { return XCTFail("The original and unrelated memberships must have distinct identities.") }
    let originalAppearance = PlannerAppearance.listMembership(
      listId: sourceList.id, membershipId: originalIdentifier)
    let otherAppearance = PlannerAppearance.listMembership(
      listId: otherList.id, membershipId: otherIdentifier)
    _ = try await save(.setCompletion(scope: .appearance(originalAppearance), done: true))
    _ = try await save(.setCompletion(scope: .appearance(otherAppearance), done: true))
    let createdPlan = try await save(.createItinerary(content: .init(title: "Tokyo Weekend")))
    let itinerary = try XCTUnwrap(createdPlan.generated.first)
    let firstBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: sourceList, placement: .last))
    let secondBranch = try await save(
      .addItineraryEntry(itineraryId: itinerary.id, source: destinationList, placement: .last))
    guard case .itineraryEntry(let firstEntry, _, _)? = firstBranch.generatedReferences.first,
      case .itineraryEntry(let secondEntry, _, _)? = secondBranch.generatedReferences.first
    else { return XCTFail("Both source Lists must remain live route references.") }
    _ = try await save(
      .setCompletion(
        scope: .appearance(
          .expandedListItem(
            itineraryId: itinerary.id, listEntryId: firstEntry, membershipId: originalIdentifier)),
        done: true))
    let form = PlannerScheduleForm.allDay(
      start: .init(year: 2026, month: 10, day: 20), end: .init(year: 2026, month: 10, day: 21))
    let booking = try await save(.createSchedule(source: item, form: form))
    let schedule = try XCTUnwrap(booking.generated.first)
    guard
      case .source(.item(let before)) = await planner.read(session: session, request: .source(item))
    else { return XCTFail("The shared Item must be readable before Move.") }
    let moving = MovePlannerItemBetweenListsIntent()
    moving.item = .init(id: item.id, title: "Obsolete title", done: true, archived: true)
    moving.sourceList = .init(id: sourceList.id, name: "Obsolete From", archived: true)
    moving.destinationList = .init(id: destinationList.id, name: "Obsolete To", archived: true)
    let _: Void = try await moving.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.list(let savedSource)) = await reopened.read(
        session: reopenedSession, request: .source(sourceList)),
      case .source(.list(let savedDestination)) = await reopened.read(
        session: reopenedSession, request: .source(destinationList)),
      case .source(.list(let savedOther)) = await reopened.read(
        session: reopenedSession, request: .source(otherList)),
      case .source(.item(let after)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.itinerary(let savedPlan)) = await reopened.read(
        session: reopenedSession, request: .source(itinerary)),
      case .source(.schedule(let savedSchedule)) = await reopened.read(
        session: reopenedSession, request: .source(schedule))
    else {
      return XCTFail("Both sides of Move and unrelated shared sources must survive reopening.")
    }
    let memberships = savedDestination.references.filter { reference in
      if case .membership = reference { return true }
      return false
    }
    guard case .membership(let newIdentifier, let owner, let source)? = memberships.last,
      case .appearance(let newState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(
          .listMembership(listId: destinationList.id, membershipId: newIdentifier))),
      case .appearance(let newBranchState) = await reopened.read(
        session: reopenedSession,
        request: .appearance(
          .expandedListItem(
            itineraryId: itinerary.id, listEntryId: secondEntry, membershipId: newIdentifier))),
      case .appearance(let otherState) = await reopened.read(
        session: reopenedSession, request: .appearance(otherAppearance)),
      case .failed(let oldFailure) = await reopened.read(
        session: reopenedSession, request: .appearance(originalAppearance))
    else {
      return XCTFail("Move must remove the old context and create a separate destination context.")
    }
    XCTAssertEqual(savedSource.references, firstBranch.generatedReferences)
    XCTAssertEqual(memberships.count, 2)
    XCTAssertEqual(memberships.first, survivor.generatedReferences.first)
    XCTAssertTrue(
      savedDestination.references.contains(try XCTUnwrap(secondBranch.generatedReferences.first)))
    XCTAssertNotEqual(newIdentifier, originalIdentifier)
    XCTAssertEqual(owner, destinationList)
    XCTAssertEqual(source, item)
    XCTAssertFalse(newState.localDone)
    XCTAssertFalse(newState.effectiveDone)
    XCTAssertFalse(newBranchState.localDone)
    XCTAssertFalse(newBranchState.effectiveDone)
    XCTAssertEqual(savedOther.references, other.generatedReferences)
    XCTAssertTrue(otherState.localDone)
    XCTAssertTrue(otherState.effectiveDone)
    XCTAssertEqual(savedPlan.progress.totalCount, 2)
    XCTAssertEqual(savedPlan.progress.doneCount, 0)
    XCTAssertEqual(savedSchedule.content.form, form)
    XCTAssertEqual(after.content.notes, "Shared notes")
    XCTAssertEqual(after.fieldHashes, before.fieldHashes)
    XCTAssertEqual(after.updatedAt, before.updatedAt)
    XCTAssertEqual(after.state.globalDone, false)
    XCTAssertEqual(after.state.archived, false)
    XCTAssertEqual(savedSource.content.name, "From")
    XCTAssertEqual(savedDestination.content.name, "To")
    XCTAssertEqual(oldFailure.code, "missingReference")
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory.appending(
      path: "PlannerListOrganizationIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
