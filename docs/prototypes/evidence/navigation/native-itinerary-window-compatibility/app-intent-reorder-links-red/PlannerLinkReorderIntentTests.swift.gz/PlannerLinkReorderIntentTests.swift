import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerLinkReorderIntentTests: XCTestCase {
  func testAllPositionsUseExactIdentitiesAndRetainEveryBookmarkForBothOwners() async throws {
    let fixture = try await makeLinkIntentFixture()
    let before = try await readLinkIntentSources(fixture)
    try await applyLinkIntentFixtureCommand(
      fixture,
      .editItinerary(
        sourceId: fixture.itinerary.id,
        changes: .init(
          links: .set([
            .init(
              linkId: before.itinerary.content.links[0].linkId,
              originalUrl: "https://example.com/route", label: "First"),
            .init(originalUrl: "https://example.com/route", label: "Second"),
            .init(originalUrl: "https://example.com/last", label: nil),
          ])), expectedFieldHashes: before.itinerary.fieldHashes))
    let itemLinks = try await readLinksUsingIntent(fixture.item)
    let itineraryLinks = try await readLinksUsingIntent(fixture.itinerary)
    for (owner, links, foreign) in [
      (fixture.item, itemLinks, itineraryLinks[0]),
      (fixture.itinerary, itineraryLinks, itemLinks[0]),
    ] {
      try await reorderLinkUsingIntent(
        owner: owner, link: links[2], position: .before, relativeLink: links[0])
      var current = try await readLinksUsingIntent(owner)
      XCTAssertEqual(current.map(\.id), [links[2].id, links[0].id, links[1].id])
      try await reorderLinkUsingIntent(
        owner: owner, link: links[0], position: .after, relativeLink: links[1])
      current = try await readLinksUsingIntent(owner)
      XCTAssertEqual(current.map(\.id), [links[2].id, links[1].id, links[0].id])
      try await reorderLinkUsingIntent(
        owner: owner, link: links[2], position: .last, relativeLink: foreign)
      current = try await readLinksUsingIntent(owner)
      XCTAssertEqual(current.map(\.id), [links[1].id, links[0].id, links[2].id])
      try await reorderLinkUsingIntent(
        owner: owner, link: links[2], position: .first, relativeLink: nil)
      current = try await readLinksUsingIntent(owner)
      XCTAssertEqual(current.map(\.id), [links[2].id, links[1].id, links[0].id])
      XCTAssertEqual(current.map(\.position), [1, 2, 3])
      XCTAssertEqual(
        current.map(\.originalURL),
        [links[2].originalURL, links[1].originalURL, links[0].originalURL])
      XCTAssertEqual(current.map(\.label), [links[2].label, links[1].label, links[0].label])
    }
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}

@MainActor
private func reorderLinkUsingIntent(
  owner: PlannerEntityReference, link: PlannerLinkEntity, position: PlannerLinkReorderPosition,
  relativeLink: PlannerLinkEntity?
) async throws {
  if owner.kind == .item {
    let reordering = ReorderPlannerItemLinkIntent()
    reordering.item = .init(id: owner.id, title: "Cached Item", done: true, archived: true)
    reordering.link = link
    reordering.position = position
    reordering.relativeLink = relativeLink
    let _: Void = try await reordering.callAsFunction(donate: false)
    return
  }
  let reordering = ReorderPlannerItineraryLinkIntent()
  reordering.itinerary = .init(id: owner.id, title: "Cached Itinerary", archived: true)
  reordering.link = link
  reordering.position = position
  reordering.relativeLink = relativeLink
  let _: Void = try await reordering.callAsFunction(donate: false)
}
