import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerListIntentTests: XCTestCase {
  func testListEntityResolutionUsesCurrentNameAndArchiveWithoutInventingMissingIdentities()
    async throws
  {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    let cached = try await creation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .list, id: cached.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.list(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editList(
            sourceId: cached.id, changes: .init(name: .set("Revised Tokyo Food")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome,
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .setArchive(source: source, archived: true))
      ).outcome
    else { return XCTFail("Real Core edits must precede resolution of a cached List identity.") }
    var query = PlannerListEntityQuery()
    query.plannerStore = store
    let choices = try await query.entities(for: [cached.id, cached.id, UUID()])
    XCTAssertEqual(choices.map(\.id), [cached.id])
    XCTAssertEqual(choices.first?.name, "Revised Tokyo Food")
    XCTAssertEqual(choices.first?.archived, true)
    XCTAssertFalse(store.recoveryBlocked)
  }

  func testCreateListIntentReturnsTheSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (directory, configuration, store) = try makeStorage()
    defer { try? FileManager.default.removeItem(at: directory) }
    AppDependencyManager.shared.add(dependency: store)
    var creation = CreatePlannerListIntent()
    creation.name = "Tokyo Food"
    creation.notes = "Keep these places together"
    let list = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(list.name, "Tokyo Food")
    XCTAssertFalse(list.archived)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.list(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .list, id: list.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .list, archive: .all))))
    else { return XCTFail("The returned List must remain readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, list.id)
    XCTAssertEqual(current.content.name, "Tokyo Food")
    XCTAssertEqual(current.content.notes, "Keep these places together")
    XCTAssertEqual(current.state.archived, false)
    XCTAssertEqual(current.progress.state, .empty)
    XCTAssertEqual(current.progress.totalCount, 0)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .list, id: list.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  private func makeStorage() throws -> (
    directory: URL, configuration: PlannerStorageConfiguration, store: SavedPlannerStore
  ) {
    let directory = FileManager.default.temporaryDirectory
      .appending(path: "PlannerListIntentTests/\(UUID().uuidString)", directoryHint: .isDirectory)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appending(path: "store/Planner.sqlite"),
      controlURL: directory.appending(path: "control/writer"),
      recoveryDirectoryURL: directory.appending(path: "recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    return (directory, configuration, SavedPlannerStore(configuration: configuration))
  }
}
