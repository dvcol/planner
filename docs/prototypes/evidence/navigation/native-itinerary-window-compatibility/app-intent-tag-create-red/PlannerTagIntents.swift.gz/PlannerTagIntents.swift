#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerTagEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Tag")
    static var defaultQuery: PlannerTagEntityQuery { PlannerTagEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String) {
      self.id = id
      self.name = name
    }
  }

  struct PlannerTagEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag identity lookup is not implemented.")
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerTagEntity] {
      throw PlannerTagIntentFailure(message: "Tag suggestions are not implemented.")
    }
  }

  struct CreatePlannerTagIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Tag"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerTagEntity, Never, Never, IntentDialog>

    @MainActor func perform() async throws -> PerformResult {
      throw PlannerTagIntentFailure(message: "Tag creation is not implemented.")
    }
  }

  private struct PlannerTagIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
