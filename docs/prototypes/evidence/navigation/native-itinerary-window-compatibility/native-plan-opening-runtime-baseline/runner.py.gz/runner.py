from pathlib import Path
import gzip, hashlib, io, json, os, shutil, signal, subprocess, sys, tarfile
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
phase = sys.argv[1]
selected = sys.argv[2]
packet = repository / 'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility' / phase
packet.mkdir(parents=True, exist_ok=False)
root = Path('/private/tmp/PlannerNativeItemWindowSource')
root.mkdir(exist_ok=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
overlays = sorted({path for path in changed + new if (path.endswith('.swift') and path.startswith(('Packages/', 'Planner/', 'PlannerMCPTests/', 'PlannerNavigationUITests/', 'PlannerFixtureUITests/', 'PlannerFixtures/'))) or path.startswith(('Configuration/', 'Planner.xcodeproj/'))})
archive = subprocess.check_output(['git', 'archive', base, 'Configuration', 'Packages', 'Planner.xcodeproj', 'Planner', 'PlannerMCPTests', 'PlannerFixtures', 'PlannerFixtureUITests', 'PlannerNavigationUITests', 'PlannerShareMobile', 'PlannerShareMac', 'docs/fixtures'])
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
    for member in source.getmembers():
        if not member.isfile() or member.name in overlays: continue
        destination = root / member.name
        content = source.extractfile(member).read()
        if destination.is_file() and destination.read_bytes() == content: continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
for path in overlays:
    destination = root / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and destination.read_bytes() == (repository / path).read_bytes():
        continue
    shutil.copy2(repository / path, destination)
inputs = sorted(path for path in root.rglob('*') if path.is_file() and '.DS_Store' not in str(path))
hashes = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet / 'source-sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
(packet / 'source-root.json').write_text(json.dumps({'root': str(root), 'base':base, 'overlays':overlays}, indent=2) + '\n')
for path in overlays:
    (packet / (Path(path).name + '.gz')).write_bytes(gzip.compress((root / path).read_bytes(), mtime=0))
(packet / 'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
bundle = '/private/tmp/PlannerItemWindow-' + phase + '.xcresult'
command = ['xcodebuild', 'test', '-project', 'Planner.xcodeproj', '-scheme', 'Planner', '-destination', 'platform=macOS,arch=arm64', '-derivedDataPath', '/private/tmp/PlannerNativeItemWindowDerivedData', '-clonedSourcePackagesDirPath', '/private/tmp/PlannerCalendarMonthSourcePackages', '-disableAutomaticPackageResolution', '-parallel-testing-enabled', 'NO', '-jobs', '1', *['-only-testing:PlannerMCPTests/' + name for name in selected.split(',')], '-resultBundlePath', bundle, 'CODE_SIGNING_ALLOWED=YES', 'CODE_SIGN_IDENTITY=-', 'CODE_SIGN_STYLE=Manual', 'DEVELOPMENT_TEAM=', 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES']
(packet / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
log = Path('/private/tmp/PlannerItemWindow-' + phase + '.log')
with log.open('wb') as output:
    process = subprocess.Popen(command, cwd=root, env=dict(os.environ, DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'), stdout=output, stderr=subprocess.STDOUT)
    timed_out = False
    try:
        returncode = process.wait(timeout=240)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.send_signal(signal.SIGINT)
        try:
            returncode = process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                returncode = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                returncode = process.wait()
    result = subprocess.CompletedProcess(command, returncode)
(packet / 'startup-bound.json').write_text(json.dumps({'maximumSeconds':240,'timedOut':timed_out,'actualTestCaseStarted':"Test Case '-[PlannerMCPTests." in log.read_text(),'passingCredit':returncode == 0 and not timed_out},indent=2)+'\n')
(packet / 'test.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
(packet / 'exit.json').write_text(json.dumps({'exitCode':result.returncode, 'bundle':bundle}, indent=2) + '\n')
assert all(hashlib.sha256((root / path).read_bytes()).hexdigest() == digest for path, digest in hashes.items())
assert all((root / path).read_bytes() == (repository / path).read_bytes() for path in overlays)
print(phase, 'exit', result.returncode)
for line in log.read_text().splitlines():
    if line.startswith(('Test Case ', '** TEST', 'error:')) or ('Test ' in line and ('passed' in line or 'failed' in line)) or ': error:' in line or 'recorded an issue' in line:
        print(line[:1500])
raise SystemExit(result.returncode)
