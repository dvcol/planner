#if !PLANNER_FIXTURES
  import AppIntents
  import Foundation
  import PlannerCore

  struct PlannerCategoryEntity: AppEntity {
    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: "Category")
    static var defaultQuery: PlannerCategoryEntityQuery { PlannerCategoryEntityQuery() }
    let id: UUID
    @Property(title: "Name") var name: String
    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }

    init(id: UUID, name: String) {
      self.id = id
      self.name = name
    }
  }

  struct PlannerCategoryEntityQuery: EntityStringQuery {
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    @Dependency var plannerStore: SavedPlannerStore

    @MainActor func entities(for identifiers: [UUID]) async throws -> [PlannerCategoryEntity] {
      let (planner, session) = try await plannerStore.appIntentContext()
      var seenIdentifiers: Set<UUID> = []
      var entities: [PlannerCategoryEntity] = []
      for identifier in identifiers where seenIdentifiers.insert(identifier).inserted {
        try Task.checkCancellation()
        switch await planner.read(
          session: session, request: .source(.init(kind: .category, id: identifier)))
        {
        case .source(.category(let source)):
          entities.append(.init(id: source.source.id, name: source.content.name))
        case .failed(let reason) where reason.code == "missingReference": continue
        case .failed(let reason): throw PlannerCategoryIntentFailure(message: reason.message)
        default: throw PlannerCategoryIntentFailure(message: "Planner could not resolve this Category.")
        }
      }
      return entities
    }

    @MainActor func entities(matching string: String) async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category search is not implemented.")
    }

    @MainActor func suggestedEntities() async throws -> [PlannerCategoryEntity] {
      throw PlannerCategoryIntentFailure(message: "Category suggestions are not implemented.")
    }
  }

  struct CreatePlannerCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Create Category"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Name") var name: String
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<
      PlannerCategoryEntity, Never, Never, IntentDialog
    >

    @MainActor func perform() async throws -> PerformResult {
      let result = try await plannerStore.executeAppIntent(.createCategory(content: .init(name: name)))
      switch result.outcome {
      case .rejected(let reason): throw PlannerCategoryIntentFailure(message: reason.message)
      case .unverified:
        throw PlannerCategoryIntentFailure(
          message:
            "Planner could not verify this change. Open Planner to review recovery before making another change."
        )
      case .applied(let applied, let recovery):
        guard let source = applied.generated.first(where: { $0.kind == .category }) else {
          throw PlannerCategoryIntentFailure(
            message:
              "Planner applied this change without returning its Category. Open Planner to inspect the result."
          )
        }
        let dialog: IntentDialog
        switch recovery {
        case .complete: dialog = "Created \(name)."
        case .incomplete:
          dialog =
            "The Category was created on this device, but its recovery copy is incomplete. Open Planner before making more changes."
        }
        return .result(value: PlannerCategoryEntity(id: source.id, name: name), dialog: dialog)
      }
    }
  }

  struct GetPlannerCategoryIntent: AppIntent {
    static let title: LocalizedStringResource = "Get Category"
    static var allowedExecutionTargets: IntentExecutionTargets { .main }
    static var supportedModes: IntentModes { .background }
    static var authenticationPolicy: IntentAuthenticationPolicy { .alwaysAllowed }
    @Parameter(title: "Category") var category: PlannerCategoryEntity
    @Dependency private var plannerStore: SavedPlannerStore
    typealias PerformResult = IntentResultContainer<PlannerCategoryEntity, Never, Never, Never>

    @MainActor func perform() async throws -> PerformResult {
      let query = PlannerCategoryEntityQuery()
      query.plannerStore = plannerStore
      let matches = try await query.entities(for: [category.id])
      guard let current = matches.first else {
        throw PlannerCategoryIntentFailure(
          message: "This Category is no longer available in Planner's current data.")
      }
      return .result(value: current)
    }
  }

  private struct PlannerCategoryIntentFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
  }
#endif
