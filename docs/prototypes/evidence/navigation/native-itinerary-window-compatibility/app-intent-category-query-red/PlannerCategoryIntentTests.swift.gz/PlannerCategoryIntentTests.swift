import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerCategoryIntentTests: XCTestCase {
  func testCreateCategoryReturnsSavedIdentityAndPreservesItsContentAfterReopen() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerCategoryIntent()
    creation.name = "Museums"
    let category = try await creation.callAsFunction(donate: false)
    XCTAssertEqual(category.name, "Museums")
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.category(let current)) = await reopened.read(
        session: session, request: .source(.init(kind: .category, id: category.id))),
      case .snapshot(let catalog) = await reopened.query(
        .init(session: session, request: .catalog(.init(sourceKind: .category, archive: .all))))
    else { return XCTFail("The returned Category must be readable from reopened real storage.") }
    XCTAssertEqual(current.source.id, category.id)
    XCTAssertEqual(current.content.name, "Museums")
    XCTAssertNil(current.content.color)
    XCTAssertNil(current.content.iconName)
    XCTAssertNil(current.state.archived)
    XCTAssertNil(current.state.globalDone)
    XCTAssertTrue(current.references.isEmpty)
    XCTAssertEqual(catalog.rows, [.source(.init(kind: .category, id: category.id))])
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testIdentityLookupAndGetReturnLiveNamesInRequestedOrderWithoutWrongKindSources() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerCategoryIntent()
    creation.name = "Original category"
    let cached = try await creation.callAsFunction(donate: false)
    creation.name = "Second category"
    let second = try await creation.callAsFunction(donate: false)
    let itemCreation = CreatePlannerItemIntent()
    itemCreation.title = "This is an Item, not a Category"
    let item = try await itemCreation.callAsFunction(donate: false)
    let planner = PlannerCore.Planner(configuration: configuration)
    let source = PlannerEntityReference(kind: .category, id: cached.id)
    guard case .ready(let session) = await planner.bootstrap(),
      case .source(.category(let original)) = await planner.read(
        session: session, request: .source(source)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session,
          command: .editCategory(
            sourceId: cached.id, changes: .init(name: .set("Renamed category")),
            expectedFieldHashes: original.fieldHashes))
      ).outcome
    else { return XCTFail("The canonical shared Category must change before resolving its entity.") }
    let query = PlannerCategoryEntityQuery()
    query.plannerStore = store
    let resolved = try await query.entities(
      for: [second.id, UUID(), cached.id, second.id, item.id, cached.id])
    XCTAssertEqual(resolved.map(\.id), [second.id, cached.id])
    XCTAssertEqual(resolved.map(\.name), ["Second category", "Renamed category"])
    let reading = GetPlannerCategoryIntent()
    reading.category = cached
    let current = try await reading.callAsFunction(donate: false)
    XCTAssertEqual(current.id, cached.id)
    XCTAssertEqual(current.name, "Renamed category")
    reading.category = .init(id: UUID(), name: "Missing")
    do {
      _ = try await reading.callAsFunction(donate: false)
      XCTFail("Get Category must reject a missing identity without substituting another source.")
    } catch {
      XCTAssertTrue(error.localizedDescription.contains("no longer available"))
    }
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }

  func testCategoryChoicesUseCanonicalInsensitiveCumulativeSearchAndReadEveryPage() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    let planner = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    var identifiers: [UUID] = []
    for index in 0..<65 {
      guard
        case .applied(let created, .complete) = await planner.execute(
          .init(
            operationId: UUID(), session: session,
            command: .createCategory(
              content: .init(name: String(format: "Café %02d museums", index))))
        ).outcome, let source = created.generated.first
      else { return XCTFail("Every canonical Category must save before querying choices.") }
      identifiers.append(source.id)
    }
    let query = PlannerCategoryEntityQuery()
    query.plannerStore = store
    let matches = try await query.entities(matching: "MUSEUMS cafe")
    XCTAssertEqual(matches.map(\.id), identifiers)
    XCTAssertEqual(matches.first?.name, "Café 00 museums")
    XCTAssertEqual(matches.last?.name, "Café 64 museums")
    XCTAssertEqual(Set(matches.map(\.id)).count, 65)
    let suggestions = try await query.suggestedEntities()
    XCTAssertEqual(suggestions.map(\.id), identifiers)
    let absent = try await query.entities(matching: "cafe nonexistent")
    XCTAssertTrue(absent.isEmpty)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
