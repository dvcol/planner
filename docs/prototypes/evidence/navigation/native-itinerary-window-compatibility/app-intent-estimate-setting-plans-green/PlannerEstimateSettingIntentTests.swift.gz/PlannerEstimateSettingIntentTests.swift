import AppIntents
import Foundation
import PlannerCore
import SwiftData
import XCTest

@testable import Planner

@MainActor
final class PlannerEstimateSettingIntentTests: XCTestCase {
  func testManualPlanEstimatesPreserveChildrenAndIndependentBudgets() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let listCreation = CreatePlannerListIntent()
    listCreation.name = "Food"
    let list = try await listCreation.callAsFunction(donate: false)
    let itemCreation = CreatePlannerItemIntent()
    itemCreation.title = "Lunch"
    itemCreation.list = list
    let item = try await itemCreation.callAsFunction(donate: false)
    let itineraryCreation = CreatePlannerItineraryIntent()
    itineraryCreation.title = "Weekend"
    let itinerary = try await itineraryCreation.callAsFunction(donate: false)
    let listSetting = SetPlannerListEstimateIntent()
    listSetting.list = list
    listSetting.quantity = 2
    listSetting.unit = .hour
    listSetting.additionalMinutes = 5
    let _: Void = try await listSetting.callAsFunction(donate: false)
    let itinerarySetting = SetPlannerItineraryEstimateIntent()
    itinerarySetting.itinerary = itinerary
    itinerarySetting.quantity = 1
    itinerarySetting.unit = .day
    itinerarySetting.additionalMinutes = 30
    let _: Void = try await itinerarySetting.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.list(let savedList)) = await reopened.read(
        session: session, request: .source(.init(kind: .list, id: list.id))),
      case .source(.itinerary(let savedItinerary)) = await reopened.read(
        session: session, request: .source(.init(kind: .itinerary, id: itinerary.id))),
      case .source(.item(let savedItem)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: item.id)))
    else { return XCTFail("Both manual estimates and their original sources must persist.") }
    XCTAssertEqual(savedList.content.manualEstimate, .init(minutes: 125, displayUnit: .hour))
    XCTAssertEqual(savedList.estimates.fullEstimate, .exact(minutes: 125))
    XCTAssertEqual(savedList.progress.totalCount, 1)
    XCTAssertEqual(savedList.progress.state, .partial)
    XCTAssertEqual(savedItinerary.content.manualEstimate, .init(minutes: 1_470, displayUnit: .day))
    XCTAssertEqual(savedItinerary.estimates.fullEstimate, .exact(minutes: 1_470))
    XCTAssertEqual(savedItinerary.progress.state, .empty)
    XCTAssertNil(savedItem.content.estimate)
    XCTAssertEqual(savedItem.content.title, "Lunch")
    XCTAssertFalse(store.recoveryBlocked)
  }

  func testItemMixedEstimatePreservesOwnedContentAndPersistsExactMinutes() async throws {
    let (_, configuration, store) = try makePlannerIntentStorage()
    AppDependencyManager.shared.add(dependency: store)
    let creation = CreatePlannerItemIntent()
    creation.title = "Museum"
    creation.subtitle = "Keep subtitle"
    creation.notes = "Keep notes\n東京"
    let item = try await creation.callAsFunction(donate: false)
    let setting = SetPlannerItemEstimateIntent()
    setting.item = item
    setting.quantity = 2
    setting.unit = .hour
    setting.additionalMinutes = 5
    let _: Void = try await setting.callAsFunction(donate: false)
    let reopened = PlannerCore.Planner(configuration: configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.item(let saved)) = await reopened.read(
        session: session, request: .source(.init(kind: .item, id: item.id)))
    else { return XCTFail("The estimate must persist on the original Item.") }
    XCTAssertEqual(saved.content.estimate, .init(minutes: 125, displayUnit: .hour))
    XCTAssertEqual(saved.content.title, "Museum")
    XCTAssertEqual(saved.content.subtitle, "Keep subtitle")
    XCTAssertEqual(saved.content.notes, "Keep notes\n東京")
    XCTAssertEqual(saved.state.globalDone, false)
    XCTAssertEqual(saved.state.archived, false)
    XCTAssertFalse(store.recoveryBlocked)
    XCTAssertFalse(store.isSaving)
  }
}
