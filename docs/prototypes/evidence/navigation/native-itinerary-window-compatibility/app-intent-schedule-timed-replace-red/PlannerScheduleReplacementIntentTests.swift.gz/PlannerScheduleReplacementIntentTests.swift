import AppIntents
import Foundation
import PlannerCore
import XCTest

@testable import Planner

@MainActor
final class PlannerScheduleReplacementIntentTests: XCTestCase {
  func testTimedReplacementConvertsAllDayScheduleWithoutChangingItsOwnerOrOtherBookings()
    async throws
  {
    let fixture = try await makeScheduleReadIntentFixture()
    let action = SetPlannerScheduleTimedFormIntent()
    action.schedule = try PlannerScheduleEntity(
      schedule: fixture.allDay, owner: fixture.item, title: "Cached wrong owner type",
      form: .timed(
        start: fixture.instant, end: fixture.instant.addingTimeInterval(3600),
        planningTimeZone: "Asia/Tokyo"))
    action.start = .init(year: 2026, month: 11, day: 1, hour: 1, minute: 30)
    action.startOccurrence = .later
    action.planningTimeZone = try XCTUnwrap(PlannerTimeZoneEntity(identifier: "America/New_York"))
    let replaced = try await action.callAsFunction(donate: false)
    let expected = try Date.ISO8601FormatStyle().parse("2026-11-01T06:30:00Z")
    XCTAssertEqual(replaced.id, fixture.allDay.id)
    XCTAssertEqual(replaced.title, "Tokyo Weekend")
    XCTAssertEqual(replaced.sourceType, "Itinerary")
    XCTAssertEqual(replaced.start, expected)
    XCTAssertNil(replaced.end)
    XCTAssertNil(replaced.startDay)
    XCTAssertNil(replaced.endDay)
    let reopened = PlannerCore.Planner(configuration: fixture.configuration)
    guard case .ready(let session) = await reopened.bootstrap(),
      case .source(.schedule(let saved)) = await reopened.read(
        session: session, request: .source(fixture.allDay)),
      case .source(.schedule(let retained)) = await reopened.read(
        session: session, request: .source(fixture.timed)),
      case .source(.schedule(let outside)) = await reopened.read(
        session: session, request: .source(fixture.outside))
    else { throw CancellationError() }
    XCTAssertEqual(saved.content.source, fixture.itinerary)
    XCTAssertEqual(
      saved.content.form,
      PlannerScheduleForm.timed(start: expected, end: nil, planningTimeZone: "America/New_York"))
    XCTAssertEqual(
      retained.content.form,
      PlannerScheduleForm.timed(start: fixture.instant, end: nil, planningTimeZone: "Asia/Tokyo"))
    XCTAssertEqual(
      outside.content.form,
      PlannerScheduleForm.allDay(start: .init(year: 2026, month: 10, day: 12), end: nil))
    let query = PlannerScheduleEntityQuery()
    query.plannerStore = fixture.store
    let schedules = try await query.suggestedEntities()
    XCTAssertEqual(
      Set(schedules.map(\.id)), [fixture.timed.id, fixture.allDay.id, fixture.outside.id])
    XCTAssertFalse(fixture.store.recoveryBlocked)
  }
}
