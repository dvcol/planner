from pathlib import Path
import gzip,hashlib,json,uuid
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
expected_titles={f'Scale Item {index:05d}' for index in range(1,5001)}
for platform in ('phone','tablet'):
 phase=platform+'-native-every-item-final'
 packet=root/phase
 result=json.loads((packet/'exit.json').read_text())
 summary=json.loads((packet/'test-summary.json').read_text())
 assert result['exitCode']==0
 assert summary['result']=='Passed'
 assert summary['totalTestCount']==summary['passedTests']==1
 assert summary['failedTests']==summary['skippedTests']==summary['expectedFailures']==0
 captures=json.loads((packet/'selected-captures.json').read_text())
 identity_captures=[entry for entry in captures if entry['suggestedHumanReadableName'].startswith('Native Item traversal observed title and identity pairs')]
 assert len(identity_captures)==1
 identity_file=identity_captures[0]['exportedFileName']
 original=Path('/private/tmp/PlannerItineraryCompatibilityAttachments-'+phase)/identity_file
 data=original.read_bytes()
 assert gzip.decompress((packet/(identity_file+'.gz')).read_bytes())==data
 lines=data.decode('utf-8').splitlines()
 pairs=[line.split(': ',1) for line in lines]
 assert len(pairs)==5000
 assert all(len(pair)==2 for pair in pairs)
 titles=[pair[0] for pair in pairs]
 identities=[pair[1] for pair in pairs]
 assert len(set(titles))==5000 and set(titles)==expected_titles
 assert titles==sorted(titles)
 assert len(set(identities))==5000
 prefix='saved.item.'
 assert all(identity.startswith(prefix) for identity in identities)
 parsed_identifiers=[uuid.UUID(identity[len(prefix):]) for identity in identities]
 assert len(set(parsed_identifiers))==5000
 sources=json.loads((packet/'current-source-sha256.json').read_text())
 products=json.loads((packet/'product-sha256.json').read_text())
 assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in sources.items())
 assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items())
 appearance=json.loads((packet/'appearance.json').read_text())
 assert appearance['original']==appearance['restored']
 assert appearance['contrastOriginal']==appearance['contrastRestored']
 record={'result':'Passed','observedPairs':len(pairs),'expectedTitles':len(expected_titles),'uniqueTitles':len(set(titles)),'uniqueSourceIdentifiers':len(set(parsed_identifiers)),'completeExpectedTitleSet':True,'titlesSorted':True,'originalAttachment':identity_file,'originalSHA256':hashlib.sha256(data).hexdigest(),'committedAttachmentMatchesOriginal':True,'sourceAndProductHashesStillMatch':True,'appearanceRestored':True,'firstObservedPair':pairs[0],'lastObservedPair':pairs[-1],'scope':'Independent attachment/count/identity verification. Native frame and hittability assertions belong to the recorded real XCTest journey; no pixel, memory or physical-performance claim.'}
 (packet/'independent-identity-verification.json').write_text(json.dumps(record,indent=2)+'\n')
 (packet/'identity-verifier.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
 print(platform,': all 5,000 expected titles and unique native source identities verified; original attachment, hashes and restored appearance match.')
