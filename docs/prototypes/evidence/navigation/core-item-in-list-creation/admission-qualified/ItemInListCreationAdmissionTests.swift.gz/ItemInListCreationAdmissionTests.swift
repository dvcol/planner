import Foundation
import PlannerCore
import Testing

struct ItemInListCreationAdmissionTests {
  @Test func invalidContentAndUnavailableDestinationsRejectBeforeAnyGraphOrReceiptChange()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let result, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return result
    }
    let list = try #require(
      try await save(.createList(content: .init(name: "Tokyo"))).generated.first)
    let archived = try #require(
      try await save(.createList(content: .init(name: "Archived"))).generated.first)
    let deleted = try #require(
      try await save(.createList(content: .init(name: "Deleted"))).generated.first)
    _ = try await save(.setArchive(source: archived, archived: true))
    guard
      case .reviewed(let deletion) = await planner.prepareReview(
        session: session, command: .deleteSource(source: deleted)),
      case .applied(_, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: deletion.command,
          reviewToken: deletion.reviewToken)
      ).outcome,
      case .exported(let before) = await planner.exportData(session: session)
    else { throw CancellationError() }
    let missingIdentifier = UUID()
    let attempts: [(PlannerCommand, String)] = [
      (
        .createItem(content: .init(title: "Missing destination"), listId: missingIdentifier),
        "missingReference"
      ),
      (
        .createItem(content: .init(title: "Archived destination"), listId: archived.id),
        "missingReference"
      ),
      (
        .createItem(content: .init(title: "Deleted destination"), listId: deleted.id),
        "missingReference"
      ),
      (.createItem(content: .init(title: " \n\t"), listId: list.id), "invalidInput"),
      (
        .createItem(
          content: .init(
            title: "Invalid coordinates",
            location: .init(
              displayName: nil, formattedAddress: nil, coordinate: .init(latitude: 91, longitude: 0)
            )), listId: list.id), "invalidInput"
      ),
      (
        .createItem(
          content: .init(
            title: "Invalid link", links: [.init(originalUrl: "file:///private/tmp/invalid")]),
          listId: list.id), "invalidInput"
      ),
      (
        .createItem(
          content: .init(title: "Invalid label", categoryIds: [missingIdentifier]), listId: list.id),
        "missingReference"
      ),
    ]
    for (command, code) in attempts {
      let operationIdentifier = UUID()
      guard
        case .rejected(let failure) = await planner.execute(
          .init(operationId: operationIdentifier, session: session, command: command)
        ).outcome,
        case .noReliableEvidence = await planner.operationStatus(
          session: session, operationId: operationIdentifier),
        case .exported(let unchanged) = await planner.exportData(session: session)
      else {
        Issue.record(
          "Reject the entire invalid ordinary creation before saving data or operation evidence.")
        return
      }
      #expect(failure.code == code)
      #expect(unchanged == before)
    }
    let reopened = Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .exported(let retained) = await reopened.exportData(session: reopenedSession),
      case .snapshot(let empty) = await reopened.query(
        .init(session: reopenedSession, request: .items(.init(completion: .all, archive: .all)))),
      case .listedNamespaces(let namespaces) = await reopened.inspectRecovery(request: .namespaces),
      let namespace = namespaces.first
    else { throw CancellationError() }
    #expect(retained == before && empty.matchingCount == 0)
    #expect(namespace.preparedProposals.isEmpty)
    #expect(namespace.acknowledgedSnapshot?.checkpointGeneration == 5)
  }
}
