from pathlib import Path
import gzip, hashlib, json, os, re, subprocess, sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
selected=sys.argv[2] if len(sys.argv)>2 else 'ItemInListCreationTests'
packet=repository/'docs/prototypes/evidence/navigation/core-item-in-list-creation'/phase
packet.mkdir(parents=True,exist_ok=False)
inputs=sorted([*repository.glob('Packages/PlannerCore/Sources/**/*.swift'),*repository.glob('Packages/PlannerCore/Tests/**/*.swift'),repository/'Packages/PlannerCore/Package.swift'])
hashes={str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
(packet/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
archives = [
    'Packages/PlannerCore/Sources/PlannerCore/PlannerCore.swift',
    'Packages/PlannerCore/Sources/PlannerCore/PlannerValues.swift',
    'Packages/PlannerCore/Sources/PlannerCore/PlannerEncoding.swift',
    'Packages/PlannerCore/Sources/PlannerCore/PlannerReviewValues.swift',
] + [str(path.relative_to(repository)) for path in sorted(repository.glob('Packages/PlannerCore/Tests/PlannerCoreStoreTests/ItemInListCreation*.swift'))]
for path in archives:
    (packet/(Path(path).name+'.gz')).write_bytes(gzip.compress((repository/path).read_bytes(),mtime=0))
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
command=['xcrun','swift','test','--package-path','Packages/PlannerCore','--scratch-path','/private/tmp/PlannerQ93CoreBuild','--jobs','1','--filter',selected]
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerQ93-'+phase+'.log')
with log.open('wb') as output:
    result=subprocess.run(command,cwd=repository,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode},indent=2)+'\n')
for index, child_path in enumerate(re.findall(r'Q93 isolated write-fault child log: ([^\n]+)', log.read_text())):
    child = Path(child_path)
    assert child.name == 'child.log' and child.parent.name.startswith('PlannerQ93WriteFailure-')
    (packet / f'child-{index}.log.gz').write_bytes(gzip.compress(child.read_bytes(), mtime=0))

assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
for line in log.read_text().splitlines():
    if line.startswith(('error:', '✔','✘','Test Suite ','Test Case ', 'Q93 isolated write-fault child log:')) or ('.swift:' in line and ': error:' in line):
        print(line)
print(phase,'exit',result.returncode)
