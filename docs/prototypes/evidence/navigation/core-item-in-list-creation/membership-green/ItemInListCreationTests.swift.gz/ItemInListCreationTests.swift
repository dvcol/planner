import Foundation
import PlannerCore
import Testing

struct ItemInListCreationTests {
  @Test func ordinaryCreationKeepsRepeatedBookmarksAndOneTodoMembershipAcrossReplayAndReopen()
    async throws
  {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap() else {
      Issue.record("The disposable dataset must initialize.")
      return
    }
    let destination = try await save(
      .createList(content: .init(name: "Tokyo")), planner: planner, session: session)
    let other = try await save(
      .createList(content: .init(name: "Wishlist")), planner: planner, session: session)
    let list = try #require(destination.result.generated.first)
    let otherList = try #require(other.result.generated.first)
    let operationIdentifier = UUID()
    let command = PlannerCommand.createItem(
      content: .init(
        title: "Museum", notes: "Keep both authored bookmarks",
        links: [
          .init(originalUrl: "https://example.com/museum", label: "Tickets"),
          .init(originalUrl: "https://example.com/museum", label: "Exhibitions"),
        ]), listId: list.id)
    let created = try await save(
      command, planner: planner, session: session, operationIdentifier: operationIdentifier)
    let item = try #require(created.result.generated.first)
    guard
      case .membership(let membershipIdentifier, let owner, let source)? =
        created.result.generatedReferences.first
    else {
      Issue.record("Ordinary creation must also return its new List membership.")
      return
    }
    #expect(owner == list && source == item)
    #expect(created.result.generatedReferences.count == 1)
    #expect(created.result.affected.contains(list))
    #expect(created.checkpoint == 3)
    let reopened = Planner(configuration: configuration)
    guard case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.item(let retained)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let populated)) = await reopened.read(
        session: reopenedSession, request: .source(list)),
      case .source(.list(let untouched)) = await reopened.read(
        session: reopenedSession, request: .source(otherList)),
      case .appearance(let appearance) = await reopened.read(
        session: reopenedSession,
        request: .appearance(
          .listMembership(listId: list.id, membershipId: membershipIdentifier)))
    else {
      Issue.record("The complete ordinary Item and its contextual appearance must survive reopen.")
      return
    }
    #expect(retained.content.title == "Museum")
    #expect(retained.content.notes == "Keep both authored bookmarks")
    #expect(
      retained.content.links.map(\.originalUrl) == [
        "https://example.com/museum", "https://example.com/museum",
      ])
    #expect(retained.content.links.map(\.label) == ["Tickets", "Exhibitions"])
    #expect(Set(retained.content.links.map(\.linkId)).count == 2)
    #expect(populated.references == created.result.generatedReferences)
    #expect(populated.progress.totalCount == 1 && populated.progress.doneCount == 0)
    #expect(untouched.references.isEmpty && untouched.progress.state == .empty)
    #expect(!appearance.localDone && !appearance.globalDone && !appearance.effectiveDone)
    let replay = try await save(
      command, planner: reopened, session: reopenedSession,
      operationIdentifier: operationIdentifier)
    #expect(replay.result == created.result)
    #expect(replay.checkpoint == created.checkpoint)
    guard
      case .source(.item(let replayed)) = await reopened.read(
        session: reopenedSession, request: .source(item))
    else {
      Issue.record("Replay must keep the original owned links.")
      return
    }
    #expect(replayed.content.links == retained.content.links)
  }

  private func save(
    _ command: PlannerCommand, planner: Planner, session: PlannerDatasetSession,
    operationIdentifier: UUID = UUID()
  ) async throws -> (result: PlannerAppliedResult, checkpoint: Int64) {
    let result = await planner.execute(
      .init(operationId: operationIdentifier, session: session, command: command))
    guard case .applied(let applied, .complete(let checkpoint)) = result.outcome else {
      Issue.record("Expected a recoverable complete action: \(result.outcome)")
      throw FixtureFailure.unexpectedOutcome
    }
    return (applied, checkpoint)
  }

  private enum FixtureFailure: Error { case unexpectedOutcome }
}
