import Foundation
import PlannerCore
import SQLite3
import Testing

struct ItemInListCreationFailureTests {
  @Test func failedMembershipInsertRollsBackTheWholeCreationAndAllowsAnUnchangedRetry() async throws
  {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let configuration = PlannerStorageConfiguration(
      storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
      controlURL: directory.appendingPathComponent("control/writer"),
      recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
      processRole: .mainApplication, storageMode: .localOnly)
    let planner = Planner(configuration: configuration)
    guard case .ready(let session) = await planner.bootstrap(),
      case .applied(let listCreation, .complete) = await planner.execute(
        .init(
          operationId: UUID(), session: session, command: .createList(content: .init(name: "Tokyo"))
        )
      ).outcome,
      let list = listCreation.generated.first,
      case .exported(let before) = await planner.exportData(session: session)
    else { throw CancellationError() }

    /// Fail the actual database write; all behavioral assertions use public Planner interfaces.
    var database: OpaquePointer?
    try #require(sqlite3_open(configuration.storeURL.path, &database) == SQLITE_OK)
    defer {
      sqlite3_exec(database, "DROP TRIGGER IF EXISTS planner_reject_membership;", nil, nil, nil)
      sqlite3_close(database)
    }
    try #require(
      sqlite3_exec(
        database,
        "CREATE TRIGGER planner_reject_membership BEFORE INSERT ON ZMEMBERSHIP BEGIN SELECT RAISE(ABORT, 'Planner fixture rejects membership insert'); END;",
        nil, nil, nil) == SQLITE_OK)
    let operationIdentifier = UUID()
    let command = PlannerCommand.createItem(
      content: .init(
        title: "Museum", notes: "Keep on retry",
        links: [
          .init(originalUrl: "https://example.com/museum", label: "Tickets"),
          .init(originalUrl: "https://example.com/museum", label: "Exhibitions"),
        ]), listId: list.id)
    let failed = await planner.execute(
      .init(operationId: operationIdentifier, session: session, command: command))
    try #require(
      sqlite3_exec(database, "DROP TRIGGER planner_reject_membership;", nil, nil, nil) == SQLITE_OK)
    let reopened = Planner(configuration: configuration)
    guard case .rejected(let failure) = failed.outcome,
      case .ready(let reopenedSession) = await reopened.bootstrap(),
      case .source(.list(let retained)) = await reopened.read(
        session: reopenedSession, request: .source(list)),
      case .snapshot(let empty) = await reopened.query(
        .init(session: reopenedSession, request: .items(.init(completion: .all, archive: .all)))),
      case .exported(let after) = await reopened.exportData(session: reopenedSession)
    else {
      Issue.record(
        "The genuine failed membership write must leave the entire Item action unapplied: \(failed.outcome)"
      )
      return
    }
    #expect(failure.code == "persistenceFailure")
    #expect(retained.references.isEmpty && retained.progress.state == .empty)
    #expect(empty.matchingCount == 0)
    #expect(after == before)
    guard
      case .noReliableEvidence = await reopened.operationStatus(
        session: reopenedSession, operationId: operationIdentifier)
    else {
      Issue.record(
        "A known failed transaction must not retain applied or unverified operation evidence.")
      return
    }
    let retry = await reopened.execute(
      .init(operationId: operationIdentifier, session: reopenedSession, command: command))
    guard case .applied(let applied, .complete(let checkpoint)) = retry.outcome,
      let item = applied.generated.first,
      case .source(.item(let saved)) = await reopened.read(
        session: reopenedSession, request: .source(item)),
      case .source(.list(let populated)) = await reopened.read(
        session: reopenedSession, request: .source(list))
    else {
      Issue.record(
        "After removing the real fault, unchanged retry must create the complete graph once: \(retry.outcome)"
      )
      return
    }
    #expect(checkpoint == 2)
    #expect(saved.content.links.map(\.label) == ["Tickets", "Exhibitions"])
    #expect(saved.content.notes == "Keep on retry")
    #expect(populated.references.count == 1 && populated.progress.totalCount == 1)
  }
}
