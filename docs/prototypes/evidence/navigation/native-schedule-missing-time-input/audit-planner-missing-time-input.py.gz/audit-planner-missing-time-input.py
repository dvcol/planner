from pathlib import Path
import gzip, hashlib, json, re, subprocess
repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
packet = repository / 'docs/prototypes/evidence/navigation/native-schedule-missing-time-input'
def read_json(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
index = read_json(packet / 'historical-run-index.json')
epoch = packet / index['native']['epoch']
raw = gzip.decompress((epoch / 'test.log.gz').read_bytes()).decode()
functions = [{'function': function, 'outcome': outcome, 'seconds': float(seconds)} for function, outcome, seconds in re.findall(r"Test Case '-\[([^\]]+)\]' (passed|failed) \(([\d.]+) seconds\)\.", raw)]
assert functions == index['native']['functions'] and len(functions) == 1
assert functions[0]['outcome'] == 'failed' and functions[0]['seconds'] == 46.157
assert read_json(epoch / 'exit.json')['exitCode'] == index['native']['exitCode'] == 65
errors = [line for line in raw.splitlines() if ': error:' in line]
assert errors == index['native']['errors']
assert len([line for line in errors if 'SavedItemJourneyTests.swift:' in line and 'A nonexistent entered local time must not silently move to another hour.' in line]) == 1
assert any('unable to find utility "simctl"' in line for line in errors)
assert 'Set value of PickerWheel (Element at index 1) to 30' in raw
assert 'Set value of PickerWheel (Element at index 0) to 02' in raw
assert raw.count('Tap "DatePicker.PreviousMonth" Button') == 7
assert 'Tap "saved.schedule.save"' not in raw
source_path = 'PlannerNavigationUITests/SavedItemJourneyTests.swift'
source = gzip.decompress((epoch / 'diagnostic-test-source.swift.gz').read_bytes())
source_digest = hashlib.sha256(source).hexdigest()
assert (repository / source_path).read_bytes() == subprocess.check_output(['git', 'show', '978d8c9fecf0a855f5d6d24a6818be8c0e0959f4:' + source_path])
assert not subprocess.check_output(['git', 'diff', '978d8c9fecf0a855f5d6d24a6818be8c0e0959f4', '--name-only', '--', 'Planner', 'Packages', 'Configuration', 'Planner.xcodeproj', 'PlannerNavigationUITests'], text=True).strip()
for name, manifest_name, expected_count in [('mobile-missing-time-build', 'source-sha256.json', 945), ('tablet-missing-time', 'current-source-sha256.json', 469)]:
    current_epoch = packet / name
    hashes = read_json(current_epoch / manifest_name)
    assert len(hashes) == expected_count
    assert hashes[source_path] == source_digest
    assert all(digest(repository / path) == value for path, value in hashes.items() if path != source_path)
    products = read_json(current_epoch / 'product-sha256.json')
    assert len(products) == 6 and all(digest(Path(path)) == value for path, value in products.items())
assert read_json(epoch / 'current-source-sha256.json') == read_json(epoch / 'compiled-source-sha256.json')
compiled = packet / 'mobile-missing-time-build'
assert read_json(compiled / 'exit.json')['exitCode'] == 0
assert '** TEST BUILD SUCCEEDED **' in gzip.decompress((compiled / 'build.log.gz').read_bytes()).decode()
assert hashlib.sha256(gzip.decompress((compiled / 'SavedItemJourneyTests.swift.gz').read_bytes())).hexdigest() == source_digest
form = gzip.decompress((epoch / '2890A8AD-87B6-40E2-86F0-FC8F03B4C56E.txt.gz').read_bytes()).decode()
wheels = gzip.decompress((epoch / 'CF3FFBE8-2F05-4A6F-87F7-376E1CD22964.txt.gz').read_bytes()).decode()
assert 'value: 03:30, 8 Mar 2026' in form and 'Time zone, America/New_York' in form
assert 'value: 03 o’clock' in wheels and 'value: 30 minutes' in wheels
images = read_json(packet / 'visual-review.json')['images']
assert len(images) == 1 and images[0]['individuallyInspected'] and digest(packet / images[0]['path']) == images[0]['sha256']
assert len(list(epoch.glob('*.txt.gz'))) == 4
lint = read_json(packet / 'diagnostic-swift-lint.json')
assert lint['exitCode'] == 0 and lint['sourceSHA256'] == source_digest
lint = read_json(packet / 'affected-markdown-lint.json')
assert lint['exitCode'] == 0 and all(digest(repository / path) == value for path, value in lint['sourceSHA256'].items())
result = {'compilerPassed': True, 'nativeFunctions': 1, 'nativeRequirementFailures': 1, 'controllerFailures': 0, 'observedRequestedHour': '02', 'observedResult': '8Mar2026 03:30 America/New_York', 'scheduleSaveSubmitted': False, 'newModelImplemented': False, 'newUnitSeamTestsWritten': False, 'productionChanged': False, 'activeUITestSourceRestored': True, 'compilerInputs': 945, 'runtimeInputs': 469, 'productsRechecked': 6, 'inspectedOriginalPNGs': 1, 'postTestCleanupWarningRetained': True}
(packet / 'evidence-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
