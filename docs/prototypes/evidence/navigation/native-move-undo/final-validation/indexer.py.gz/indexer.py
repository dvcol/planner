from pathlib import Path
import gzip,hashlib,json,os,re,struct,subprocess
repository=Path.cwd()
assert repository==Path('/Users/dinh-van.colomban/Workspace/private/planner')
root=repository/'docs/prototypes/evidence/navigation/native-itinerary-window-compatibility'
packets=sorted(path for path in root.iterdir() if path.is_dir() and path.name.startswith(('move-native-','phone-move-undo-','tablet-move-undo-')))
assert len(packets)==11,len(packets)
validation=repository/'docs/prototypes/evidence/navigation/native-move-undo/final-validation'
validation.mkdir(parents=True,exist_ok=True)
observations=[]; comparisons=[]
final_epochs={'move-native-history-http-regressions','move-native-undo-final-mac-build','move-native-undo-qualified-mobile-build','phone-move-undo-final','tablet-move-undo-final'}
for packet in packets:
 result=json.loads((packet/'exit.json').read_text())
 log_file=next(path for path in [packet/'test.log.gz',packet/'build.log.gz'] if path.exists())
 log=gzip.decompress(log_file.read_bytes()).decode(errors='replace')
 observations.append({'epoch':packet.name,'exitCode':result['exitCode'],'executedSummaries':[line.strip() for line in log.splitlines() if ('Executed ' in line and ' test' in line) or 'Test run with ' in line][-4:]})
 hashes_file=next(path for path in [packet/'source-sha256.json',packet/'current-source-sha256.json'] if path.exists())
 hashes=json.loads(hashes_file.read_text())
 production={name:digest for name,digest in hashes.items() if name.endswith('.swift') and (name.startswith('Planner/') or '/Sources/' in name)}
 assert len(production)==149
 different=[name for name,digest in production.items() if hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
 all_differences=[name for name,digest in hashes.items() if not (repository/name).is_file() or hashlib.sha256((repository/name).read_bytes()).hexdigest()!=digest]
 if packet.name in final_epochs:
  assert result['exitCode']==0 and not all_differences,(packet.name,all_differences)
 comparisons.append({'epoch':packet.name,'productionInputs':len(production),'differentProductionInputs':different,'allDifferentCurrentInputs':all_differences})
 if packet.name in ['phone-move-undo-final','tablet-move-undo-final','move-native-undo-qualified-mobile-build','move-native-undo-final-mac-build']:
  product_hashes=json.loads((packet/'product-sha256.json').read_text())
  assert all(Path(name).is_file() and hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in product_hashes.items())
(validation/'observed-results.json').write_text(json.dumps(observations,indent=2)+'\n')
(validation/'source-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
for name in ['phone-move-undo-final','tablet-move-undo-final','move-native-history-http-regressions']:
 bundle=json.loads((root/name/'exit.json').read_text())['bundle']
 summary=subprocess.run(['xcrun','xcresulttool','get','test-results','summary','--path',bundle],env=environment,capture_output=True,text=True,check=True)
 data=json.loads(summary.stdout)
 assert data['result']=='Passed' and data['failedTests']==0
 (validation/(name+'-summary.json')).write_text(json.dumps(data,indent=2)+'\n')
visual=[]
for name in ['phone-move-undo-final','tablet-move-undo-final']:
 captures=json.loads((root/name/'selected-captures.json').read_text())
 images=[capture for capture in captures if capture['exportedFileName'].endswith('.png')]
 assert len(images)==3
 for capture in images:
  path=root/name/capture['exportedFileName']
  raw=path.read_bytes()
  assert raw.startswith(b'\x89PNG\r\n\x1a\n')
  width,height=struct.unpack('>II',raw[16:24])
  visual.append({'path':str(path.relative_to(repository)),'sha256':hashlib.sha256(raw).hexdigest(),'width':width,'height':height,'inspectedOriginal':True,'caption':capture['suggestedHumanReadableName']})
(validation/'visual-review.json').write_text(json.dumps({'originals':visual,'observations':['Both appearances show native Undo Move Item, the restored checked appearance/progress and an empty destination after relaunch.','The phone relaunch capture shows a partially clipped navigation title behind toolbar controls; retain for final UI polish.','The iPad unselected detail placeholder is intentional. No measured contrast, Increase Contrast or whole-app accessibility acceptance is claimed.']},indent=2)+'\n')
reports=['docs/prototypes/native-move-undo.md','docs/prototypes/core-move-undo.md','docs/open-decisions.md','docs/native-owned-association-undo-proposal.md']
swift_files=['Planner/Scenes/SavedPlannerStore.swift','Planner/Scenes/SavedMoveItemForm.swift','Planner/Scenes/SavedPlannerView.swift','PlannerMCPTests/SavedAssociationUndoHistoryTests.swift','PlannerNavigationUITests/SavedAppearanceJourneyTests.swift']
checks=[]
for index,command in enumerate([['xcrun','swift-format','lint','--strict',*swift_files],['pnpm','dlx','markdownlint-cli2','--config','/private/tmp/PlannerItemWindowMarkdownlint.json',*reports],['git','diff','--check']]):
 completed=subprocess.run(command,env=environment,capture_output=True,text=True)
 (validation/f'check-{index}.log.gz').write_bytes(gzip.compress((completed.stdout+completed.stderr).encode(),mtime=0))
 checks.append({'command':command,'exitCode':completed.returncode})
 assert completed.returncode==0,(command,completed.stdout,completed.stderr)
links=[]
for report in reports:
 for target in re.findall(r'\]\(([^)]+)\)',(repository/report).read_text()):
  if target.startswith(('http:','https:','#')):continue
  destination=(repository/report).parent.joinpath(target.split('#')[0]).resolve()
  assert destination.exists() or destination in [validation/'checks.json',validation/'evidence-sha256.json'],target
  links.append({'report':report,'target':target})
(validation/'checks.json').write_text(json.dumps({'commands':checks,'localLinksChecked':len(links),'missingLinks':[],'originalImagesInspected':len(visual),'finalSourceEpochs':sorted(final_epochs)},indent=2)+'\n')
patterns={'githubCredential':r'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}','privateKey':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','openaiCredential':r'sk-(?:proj-)?[A-Za-z0-9_-]{30,}'}
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
findings=[]
for path in files:
 data=path.read_bytes()
 if path.suffix=='.gz':data=gzip.decompress(data)
 for name,pattern in patterns.items():
  if re.search(pattern,data.decode(errors='replace')):findings.append({'path':str(path.relative_to(repository)),'pattern':name})
assert not findings
(validation/'credential-scan.json').write_text(json.dumps({'filesRead':len(files),'decompressedGzip':True,'findings':findings},indent=2)+'\n')
(validation/'indexer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=[path for packet in packets for path in packet.rglob('*') if path.is_file()]+[path for path in validation.iterdir() if path.is_file() and path.name!='evidence-sha256.json']
(validation/'evidence-sha256.json').write_text(json.dumps({str(path.relative_to(repository)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)},indent=2)+'\n')
assert all((repository/entry['report']).parent.joinpath(entry['target'].split('#')[0]).exists() for entry in links)
print('Verified 11 native epochs; five final source epochs match; six originals inspected;',len(files),'evidence files hashed; affected lint/links pass.')
