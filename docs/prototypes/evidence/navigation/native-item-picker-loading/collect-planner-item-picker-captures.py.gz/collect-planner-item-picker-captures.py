from pathlib import Path
import gzip,json,os,shutil,subprocess,sys
phase=sys.argv[1]
packet=Path('docs/prototypes/evidence/navigation/native-item-picker-loading')/phase
metadata=json.loads((packet/'exit.json').read_text())
out=Path('/private/tmp/PlannerItemPickerRuntime-'+phase+'-attachments')
result=subprocess.run(['xcrun','xcresulttool','export','attachments','--path',metadata['bundle'],'--output-path',str(out)],capture_output=True,text=True,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'))
assert result.returncode==0,result.stderr
selected=[]
prefixes=['Saved List with one shared Item after relaunch','Unlisted archived Item restored through the Items catalog','Saved List with contextual completion and details','Saved List with globally completed Item','Global completion overrides both saved List appearances']
for group in json.loads((out/'manifest.json').read_text()):
    for attachment in group['attachments']:
        title=attachment['suggestedHumanReadableName']
        name=attachment['exportedFileName']
        if title.startswith(tuple(prefixes)) and name.endswith('.png'):
            shutil.copy2(out/name,packet/name)
            selected.append(attachment)
        elif title.startswith(('Item editor own-app hierarchy before visibility failure','Draft navigation own-window hierarchy','Original List window after source Item deletion','Planner window identities after source Item deletion','Original Planner window after another window deletes its selection','Existing Item picker observed identities')) and name.endswith('.txt'):
            (packet/(name+'.gz')).write_bytes(gzip.compress((out/name).read_bytes(),mtime=0))
            selected.append(attachment)
(packet/'selected-captures.json').write_text(json.dumps(selected,indent=2)+'\n')
for item in selected:print(phase,item['exportedFileName'],item['suggestedHumanReadableName'])
