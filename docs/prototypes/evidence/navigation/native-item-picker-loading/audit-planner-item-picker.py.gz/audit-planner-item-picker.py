from pathlib import Path
import hashlib,json,gzip
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-item-picker-loading'
def read_json(path):
 return json.loads(path.read_text())
def sha256(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()
runs={value['epoch']:value for value in read_json(packet/'historical-run-index.json')['runs']}
for epoch in ['mobile-picker-compatible-controller-build','mac-picker-compatible-controller-build']:
 inputs=read_json(packet/epoch/'source-sha256.json')
 assert len(inputs)==945 and all(sha256(repository/path)==digest for path,digest in inputs.items())
 assert read_json(packet/epoch/'exit.json')['exitCode']==0
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
membership='PlannerNavigationUITests.SavedListMembershipJourneyTests testExistingItemCanBeAddedToAListWithoutDuplicatingItsSourceAfterRelaunch'
archive='PlannerNavigationUITests.SavedAppearanceJourneyTests testArchivedItemWithoutAListCanBeFoundAndUnarchivedInTheItemsCatalog'
completion='PlannerNavigationUITests.SavedAppearanceJourneyTests testListCompletionStaysLocalWhileGlobalCompletionOverridesAndReopeningRestoresIt'
for epoch in ['phone-picker-compatible-membership','tablet-picker-compatible-membership']:
 result=runs[epoch]
 assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
 assert {value['function'] for value in result['functions']}=={membership}
 assert all(value['outcome']=='passed' for value in result['functions']) and not result['startedWithoutCompletedOutcome']
 current=read_json(packet/epoch/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
 assert all(sha256(repository/path)==digest for path,digest in current.items())
 products=read_json(packet/epoch/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
previous_build=read_json(packet/'mobile-picker-on-demand-build'/'source-sha256.json')
for epoch in ['phone-picker-state-regressions','tablet-picker-on-demand']:
 result=runs[epoch]
 assert not result['skippedLines'] and not result['startedWithoutCompletedOutcome']
 functions={value['function']:value['outcome'] for value in result['functions']}
 assert functions[archive]==functions[completion]=='passed'
 if epoch=='phone-picker-state-regressions':
  assert result['exitCode']==0 and result['wholeInvocationPassed'] and len(functions)==2
 else:
  assert result['exitCode']==65 and not result['wholeInvocationPassed'] and functions[membership]=='failed' and len(functions)==3
 current=read_json(packet/epoch/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(packet/epoch/'compiled-source-sha256.json')
 assert all(previous_build[path]==digest for path,digest in current.items())
 differences=[path for path,digest in current.items() if sha256(repository/path)!=digest]
 assert differences==['PlannerNavigationUITests/SavedListMembershipJourneyTests.swift'],differences
 for path in ['Planner/Scenes/SavedAddItemForm.swift','Planner/Scenes/SavedBackupImportForm.swift','Planner/Scenes/SavedPlannerStore.swift','PlannerNavigationUITests/SavedAppearanceJourneyTests.swift']:
  assert sha256(repository/path)==current[path]
 assert read_json(packet/epoch/'source-variant.json')['qualifiesProductionImplementation']
visual=read_json(packet/'visual-review.json')['images']
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
assert len(visual)==12 and all(value['individuallyInspected'] and sha256(packet/value['path'])==value['sha256'] for value in visual)
lint=read_json(packet/'affected-swift-lint.json')
review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(sha256(repository/path)==digest for path,digest in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(sha256(repository/path)==digest for path,digest in markdown['sourceSHA256'].items())
result={'finalCompilerInputsPerPlatform':945,'frozenRuntimeInputsPerInvocation':469,'verifiedFinalProductsPerPlatform':6,'passingBehaviorFunctionsPerPlatform':{'phone':3,'tablet':3,'mac':0},'finalControllerPassingFunctionInvocations':2,'productionIdenticalRegressionPassingFunctionInvocations':4,'regressionSourceDifference':'Only SavedListMembershipJourneyTests helper changed; both production and executed SavedAppearanceJourneyTests are byte-identical. Initial iPad batch exit 65 retains two literal state-test passes and one controller failure; never credited as an all-pass batch.','retainedIndividuallyInspectedPNGs':12,'scope':'Form-owned on-demand existing-Item selection; Cancel, repeated Add, stable source and membership identities through relaunch; global/contextual completion and Archive/Unarchive catalog regressions. Core commands and query-generation lifetime unchanged. Mac compiler-only; no measured RAM/latency gain, full moving-window, delayed-failure/retry, signing, physical/account/CloudKit, accessibility or polish qualification.'}
(packet/'evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
