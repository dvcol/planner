from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
phase=sys.argv[1]
platform=sys.argv[2]
selected=sys.argv[3] if len(sys.argv)>3 else 'SavedCaptureJourneyTests/testReviewedCaptureEstimateShortcutsCancelWithoutSavingAndPersistOneInboxItem'
assert platform in ['phone','tablet','mac']
execution_allowance=sys.argv[5] if len(sys.argv)>5 else '300'
assert execution_allowance in ['300','360','480','600']
packet=repository/'docs/prototypes/evidence/navigation/native-catalog-add-menu'/phase
packet.mkdir(parents=True,exist_ok=False)
mobile=platform!='mac'
compiled=repository/'docs/prototypes/evidence/navigation/native-rich-creation'/('q93-mobile-editor-qualified' if mobile else 'q93-mac-editor-compile')
if len(sys.argv)>4:compiled=repository/sys.argv[4]
expected=json.loads((compiled/'product-sha256.json').read_text())
assert all(Path(path).is_file() and hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in expected.items())
compiled_hashes=json.loads((compiled/'source-sha256.json').read_text())
inputs={path:digest for path,digest in compiled_hashes.items() if path.endswith(('.swift','.pbxproj','.xcscheme','.xcconfig','.plist','.entitlements','.resolved'))}
differences=[path for path,digest in inputs.items() if not (repository/path).is_file() or hashlib.sha256((repository/path).read_bytes()).hexdigest()!=digest]
allowed_inactive=['Planner/AgentControl/PlannerMCPExecutionTool.swift','Planner/AgentControl/PlannerMCPReviewTool.swift'] if mobile else []
assert set(differences)<=set(allowed_inactive),differences
(packet/'compiled-source-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
current={path:hashlib.sha256((repository/path).read_bytes()).hexdigest() for path in inputs}
(packet/'current-source-sha256.json').write_text(json.dumps(current,indent=2)+'\n')
(packet/'build-link.json').write_text(json.dumps({'compiledEpoch':str(compiled.relative_to(repository)),'currentCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'inactiveMacOnlyDifferences':differences,'runtimeOnly':True},indent=2)+'\n')
(packet/'product-sha256.json').write_text(json.dumps(expected,indent=2)+'\n')
(packet/'runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
for path in ['PlannerNavigationUITests/SavedLabelsJourneyTests.swift','PlannerNavigationUITests/SavedCaptureJourneyTests.swift','Planner/Scenes/SavedNewItemForm.swift','Planner/Scenes/SavedPlannerStore.swift','Planner/Scenes/SavedPlannerView.swift','PlannerNavigationUITests/SavedAppearanceJourneyTests.swift','PlannerNavigationUITests/NativeNavigationElements.swift','Planner/Scenes/SavedActivityEstimateEditor.swift','Planner/Scenes/SavedAddItemForm.swift','Planner/Scenes/SavedBackupImportForm.swift','PlannerNavigationUITests/SavedListMembershipJourneyTests.swift','PlannerNavigationUITests/SavedItemJourneyTests.swift']:
    (packet/(Path(path).name+'.gz')).write_bytes(gzip.compress((repository/path).read_bytes(),mtime=0))
xctestrun=Path('/private/tmp/PlannerItemWindowCompatibilitymobileDerivedData/Build/Products/PlannerNavigation_iphonesimulator27.1-arm64.xctestrun')
if not mobile:
    candidates=list(Path('/private/tmp/PlannerNativeItemWindowDerivedData/Build/Products').glob('PlannerNavigation_macosx*-arm64.xctestrun'))
    assert len(candidates)==1,candidates
    xctestrun=candidates[0]
destination='platform=macOS,arch=arm64'
if mobile:
    identifier='2A49C66C-C8A4-435F-B98A-9A90706780DE' if platform=='phone' else 'FBD72DAB-1D40-4E64-912D-7F9763E00446'
    destination='platform=iOS Simulator,id='+identifier
bundle='/private/tmp/PlannerSceneAppearanceRuntime-'+phase+'.xcresult'
command=['xcodebuild','test-without-building','-xctestrun',str(xctestrun),'-destination',destination,'-destination-timeout','20','-parallel-testing-enabled','NO','-jobs','1','-test-timeouts-enabled','YES','-default-test-execution-time-allowance',execution_allowance,'-maximum-test-execution-time-allowance',execution_allowance,*[f'-only-testing:PlannerNavigationUITests/{name}' if '/' in name else f'-only-testing:PlannerNavigationUITests/SavedContainerEstimateJourneyTests/{name}' for name in selected.split(',')],'-resultBundlePath',bundle]
(packet/'command.json').write_text(json.dumps(command,indent=2)+'\n')
log=Path('/private/tmp/PlannerSceneAppearanceRuntime-'+phase+'.log')
with log.open('wb') as output:
    if mobile:
        result=subprocess.run(command,cwd=repository,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT)
    else:
        import signal
        process=subprocess.Popen(command,cwd=repository,env=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer'),stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            return_code=process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
            output.write(b'\nNative Mac UI runner exceeded the bounded 180-second check.\n')
            return_code=124
        result=subprocess.CompletedProcess(command,return_code)
(packet/'test.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
(packet/'exit.json').write_text(json.dumps({'exitCode':result.returncode,'bundle':bundle},indent=2)+'\n')
assert all(hashlib.sha256((repository/path).read_bytes()).hexdigest()==digest for path,digest in current.items())
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in expected.items())
print(phase,'exit',result.returncode)
for line in log.read_text().splitlines():
    if line.startswith(('Test Case ','** TEST','error:')) or line.lstrip().startswith('Executed ') or ('.swift:' in line and ': error:' in line):print(line[:1400])
