from pathlib import Path
import gzip, hashlib, json, subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
packet=repository/'docs/prototypes/evidence/navigation/native-rich-draft-layout'
def read_json(path):
 return json.loads(path.read_text())
def sha256(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()
runs={value['epoch']:value for value in read_json(packet/'historical-run-index.json')['runs']}
compiler_epochs=['mobile-rich-layout-identified-form-build','mac-rich-layout-identified-form-build']
for epoch in compiler_epochs:
 directory=packet/epoch
 inputs=read_json(directory/'source-sha256.json')
 assert len(inputs)==945 and all(sha256(repository/path)==digest for path,digest in inputs.items())
 assert read_json(directory/'exit.json')['exitCode']==0
 products=read_json(directory/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
expected={
 'PlannerNavigationUITests.SavedAppearanceJourneyTests testNewItemDraftRetainsItsFieldsAndOriginalListThroughLayoutChanges',
 'PlannerNavigationUITests.SavedAppearanceJourneyTests testNewItemFromListCancelsWithoutChangesAndSavesRichContentInItsOriginalList',
}
selected_final={
 'phone-rich-layout-identified-form':expected,
 'tablet-rich-layout-identified-form-retry':{next(value for value in expected if 'RetainsItsFields' in value)},
 'tablet-rich-creation-identified-form':{next(value for value in expected if 'CancelsWithoutChanges' in value)},
}
for epoch,expected_functions in selected_final.items():
 result=runs[epoch]
 assert result['exitCode']==0 and result['wholeInvocationPassed'] and not result['skippedLines']
 assert len(result['functions'])==len(expected_functions) and {value['function'] for value in result['functions']}==expected_functions
 assert all(value['outcome']=='passed' for value in result['functions'])
 assert not result['startedWithoutCompletedOutcome'] and not result['timedOutFunctions']
 directory=packet/epoch
 current=read_json(directory/'current-source-sha256.json')
 assert len(current)==469 and current==read_json(directory/'compiled-source-sha256.json')
 assert all(sha256(repository/path)==digest for path,digest in current.items())
 products=read_json(directory/'product-sha256.json')
 assert len(products)==6 and all(sha256(Path(path))==digest for path,digest in products.items())
visual=read_json(packet/'visual-review.json')['images']
assert {value['path'] for value in visual}=={str(path.relative_to(packet)) for path in packet.rglob('*.png')}
assert all(value['individuallyInspected'] and sha256(packet/value['path'])==value['sha256'] for value in visual)
lint=read_json(packet/'affected-swift-lint.json')
review=read_json(packet/'source-review.json')
assert lint['exitCode']==0 and lint['sourceSHA256']==review['sourceSHA256']
assert all(sha256(repository/path)==digest for path,digest in lint['sourceSHA256'].items())
assert review['standards']['remainingConfirmedFindings']==review['specification']['remainingConfirmedFindings']==0
markdown=read_json(packet/'affected-markdown-lint.json')
assert markdown['exitCode']==0 and all(sha256(repository/path)==digest for path,digest in markdown['sourceSHA256'].items())
source='PlannerNavigationUITests/SavedAppearanceJourneyTests.swift'
changed=subprocess.check_output(['git','diff','--name-only','109dfdb','--','*.swift'],text=True).splitlines()
assert set(changed)=={source,'Planner/Scenes/SavedEditItemForm.swift'},changed
result={'finalCompilerInputsPerPlatform':945,'frozenRuntimeInputsPerInvocation':469,'verifiedProductsPerPlatform':6,'passingFunctionsPerPlatform':{'phone':2,'tablet':2,'mac':0},'retainedIndividuallyInspectedPNGs':len(visual),'scope':'Rich New Item draft values and original List through simulator orientation changes, explicit Save and relaunch, plus existing rich-creation compatibility. Test/controller corrections plus an accessibility identity on the existing Edit Form. No authoring or persistence behavior changes. Mac compiler-only. Other layouts, labels Q94, physical/signing/CloudKit/Share, accessibility, performance and whole-app polish remain open.'}
(packet/'evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
