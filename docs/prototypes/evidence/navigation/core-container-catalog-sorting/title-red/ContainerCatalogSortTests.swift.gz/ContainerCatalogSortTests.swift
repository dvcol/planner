import Foundation
import PlannerCore
import Testing

struct ContainerCatalogSortTests {
  @Test func explicitTitleDirectionsKeepCatalogDefaultsTiesFiltersAndOrderedPages() async throws {
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: directory) }
    let planner = Planner(
      configuration: .init(
        storeURL: directory.appendingPathComponent("store/Planner.sqlite"),
        controlURL: directory.appendingPathComponent("control/writer"),
        recoveryDirectoryURL: directory.appendingPathComponent("recovery"),
        processRole: .mainApplication, storageMode: .localOnly))
    guard case .ready(let session) = await planner.bootstrap() else { throw CancellationError() }
    func save(_ command: PlannerCommand) async throws -> PlannerAppliedResult {
      guard
        case .applied(let applied, .complete) = await planner.execute(
          .init(operationId: UUID(), session: session, command: command)
        ).outcome
      else { throw CancellationError() }
      return applied
    }
    for kind in [PlannerEntityKind.list, .itinerary] {
      var sources: [PlannerEntityReference] = []
      for title in ["Zoo", "CAFÉ", "cafe", "Alpine", "Bee"] {
        let command: PlannerCommand
        if kind == .list {
          command = .createList(content: .init(name: title))
        } else {
          command = .createItinerary(content: .init(title: title))
        }
        sources.append(try #require(try await save(command).generated.first))
      }
      _ = try await save(.setArchive(source: sources[4], archived: true))
      guard case .exported(let before) = await planner.exportData(session: session) else {
        throw CancellationError()
      }
      let tied = [sources[1], sources[2]].sorted { $0.id.uuidString < $1.id.uuidString }
      let ascending = [sources[3], sources[4]] + tied + [sources[0]]
      let descending = [sources[0]] + tied + [sources[4], sources[3]]
      let examples: [(PlannerCatalogQuery.Sort?, [PlannerEntityReference])] = [
        (nil, ascending),
        (.init(mode: .title, direction: .ascending), ascending),
        (.init(mode: .title, direction: .descending), descending),
      ]
      for (sort, expected) in examples {
        guard
          case .snapshot(let snapshot) = await planner.query(
            .init(
              session: session,
              request: .catalog(.init(sourceKind: kind, archive: .all, sort: sort))))
        else { throw CancellationError() }
        #expect(snapshot.rows == expected.map(PlannerRowIdentity.source))
        #expect(snapshot.matchingCount == 5)
        for offset in [0, 2, 4, 0, 5] {
          guard
            case .rows(let window) = await planner.read(
              session: session,
              request: .rows(generation: snapshot.generation, offset: Int64(offset), limit: 2))
          else { throw CancellationError() }
          #expect(
            window.rows.map(\.identity)
              == expected.dropFirst(offset).prefix(2).map(PlannerRowIdentity.source))
          #expect(window.matchingCount == 5)
        }
      }
      for (archive, text, expected) in [
        (PlannerItemQuery.Archive.active, "", [sources[0]] + tied + [sources[3]]),
        (.archived, "", [sources[4]]),
        (.all, "  FE\nCA  ", tied),
      ] {
        guard
          case .snapshot(let snapshot) = await planner.query(
            .init(
              session: session,
              request: .catalog(
                .init(
                  sourceKind: kind, text: text, archive: archive,
                  sort: .init(mode: .title, direction: .descending)))))
        else { throw CancellationError() }
        #expect(snapshot.rows == expected.map(PlannerRowIdentity.source))
      }
      guard case .exported(let after) = await planner.exportData(session: session) else {
        throw CancellationError()
      }
      #expect(after == before)
    }
  }
}
