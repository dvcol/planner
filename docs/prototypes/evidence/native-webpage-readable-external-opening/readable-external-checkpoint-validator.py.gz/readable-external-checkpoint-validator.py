import gzip
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse

repository = Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve() == repository
root = repository / 'docs/prototypes/evidence/native-webpage-readable-external-opening'
phases = {'readable-external-phone-final': 3, 'readable-external-dark-tablet-final': 3}
reference = json.loads((root / 'readable-external-phone-final/source-sha256.json').read_text())
inspections = json.loads(Path('/private/tmp/PlannerReadableExternalInspectedOriginals.json').read_text())
results = []
captures = []
requests = []
for phase, expected_count in phases.items():
    packet = root / phase
    assert json.loads((packet / 'source-sha256.json').read_text()) == reference
    validation = json.loads((packet / 'boundary-validation.json').read_text())
    assert validation['exitCode'] == 0 and validation['passedTests'] == expected_count
    assert validation['failedTests'] == validation['skippedTests'] == 0
    assert not any(validation[name] for name in ['workspaceDifferences', 'stagedDifferences', 'productDifferences'])
    log = gzip.decompress((packet / 'test.log.gz').read_bytes()).decode()
    for forbidden in ['unlinked while open', 'vnode unlinked', 'Restarting after unexpected', 'unable to find utility "simctl"']:
        assert forbidden not in log, (phase, forbidden)
    results.append({'phase': phase, 'passedFunctions': expected_count, 'sqliteUnlinkDiagnostics': 0, 'harnessRestarts': 0})
    for attachment in json.loads((packet / 'selected-attachments.json').read_text())['attachments']:
        path = packet / attachment['retainedFileName']
        data = path.read_bytes()
        if path.name.endswith('.txt.gz'):
            data = gzip.decompress(data)
        assert hashlib.sha256(data).hexdigest() == attachment['originalSha256']
        if path.suffix == '.png':
            relative = str(path.relative_to(root))
            assert inspections[relative] == attachment['originalSha256']
            captures.append({'path': relative, 'sha256': attachment['originalSha256'], 'visuallyInspected': True})
        elif path.suffix == '.json':
            observation = json.loads(data)
            original = urlparse(observation['originalBookmark'])
            target = urlparse(observation['requestedExternalTarget'])
            assert original.scheme == target.scheme == 'http'
            assert original.netloc == target.netloc and original.hostname == 'localhost'
            assert original.path == '/guide' and target.path == '/garden'
            assert observation['requestLine'] == 'GET /garden HTTP/1.1'
            assert observation['browserBecameForeground'] is True
            assert observation['browserState'] == 4 and observation['plannerState'] == 3
            assert observation['plannerUserAgents']
            assert any(' Safari/' in value and value not in observation['plannerUserAgents'] for value in observation['externalUserAgents'])
            requests.append({'phase': phase, 'testIdentifier': attachment['testIdentifier'], 'originalAttachment': attachment['retainedFileName'], **observation})
assert len(captures) == 12 and len(requests) == 4
assert set(inspections) == {capture['path'] for capture in captures}
red = root / 'readable-external-phone-qualified-red'
red_manifest = json.loads((red / 'source-sha256.json').read_text())
assert set(red_manifest) == set(reference)
assert [name for name in reference if reference[name] != red_manifest[name]] == ['Planner/Scenes/SavedWebsiteView.swift']
red_result = json.loads((red / 'boundary-validation.json').read_text())
assert red_result['exitCode'] == 65 and red_result['failedTests'] == 1 and red_result['passedTests'] == 0
assert red_manifest['PlannerNavigationUITests/SavedBrowserJourneyTests.swift'] == reference['PlannerNavigationUITests/SavedBrowserJourneyTests.swift']
red_texts = [gzip.decompress(path.read_bytes()).decode() for path in red.glob('*.txt.gz')]
assert any('Garden guide fixture' in text and 'saved.browser.reload' in text and "label: 'Open in default browser'" not in text for text in red_texts)
compiler = root / 'readable-external-mac-final-compiler'
assert json.loads((compiler / 'source-sha256.json').read_text()) == reference
compiler_result = json.loads((compiler / 'boundary-validation.json').read_text())
assert compiler_result['exitCode'] == 0 and compiler_result['runtimeCredit'] is False
products = json.loads((compiler / 'product-sha256.json').read_text())
assert len(products) == 9
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest for name, digest in products.items())
assert all(hashlib.sha256((repository / name).read_bytes()).hexdigest() == digest for name, digest in reference.items())
appearance = json.loads((root / 'readable-external-dark-tablet-final/appearance-observation.json').read_text())
assert appearance['restoredToOriginal']
assert [value['output'] for value in appearance['observations'] if value['command'][-1] == 'appearance'] == ['dark', 'dark', 'dark']
report = {'nativeInputs': len(reference), 'nativeExecutions': results, 'totalPassedFunctions': 6, 'macBuild': compiler_result, 'macProductCount': len(products), 'actualSystemBrowserRequests': requests, 'originalCaptures': captures, 'correctedTracerUnchangedFromRed': True, 'redToFinalChangedInputs': ['Planner/Scenes/SavedWebsiteView.swift'], 'actualMacRuntimeCredit': False, 'physicalDeviceCredit': False, 'scope': 'Readable Garden opens through a native reader action with an actual Safari request, then returns to Planner and the unchanged Museum bookmark. Failed-page handoff and ordinary new-window history remain intact. Safari screenshots may still be loading; external page paint, Mac runtime, physical devices and full UI polish are unqualified.'}
(root / 'readable-external-checkpoint-reconciliation.json').write_text(json.dumps(report, indent=2) + '\n')
(root / 'readable-external-checkpoint-validator.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(json.dumps({'nativeInputs': len(reference), 'passedFunctions': 6, 'macProducts': len(products), 'inspectedOriginals': len(captures), 'actualSafariRequests': len(requests), 'unchangedCorrectedTracer': True}))
