from pathlib import Path
import gzip,hashlib,json,subprocess
repository=Path('/Users/dinh-van.colomban/Workspace/private/planner')
assert Path.cwd().resolve()==repository
root=repository/'docs/prototypes/evidence/native-calendar-mac-split-pane'
def read(phase,name):return json.loads((root/phase/name).read_text())
initial='calendar-inspector-regressions-dark-tablet'
final='calendar-month-viewport-regression-dark-tablet'
initial_sources=read(initial,'source-sha256.json')
final_sources=read(final,'source-sha256.json')
assert set(initial_sources)==set(final_sources)
source_differences=[name for name in final_sources if initial_sources[name]!=final_sources[name]]
assert source_differences==['Planner/Scenes/SavedCalendarView.swift']
assert all(hashlib.sha256((repository/name).read_bytes()).hexdigest()==digest for name,digest in final_sources.items())
executions=[]
for phase,expected_tests,expected_captures in [(initial,3,18),(final,1,6)]:
 summary=read(phase,'test-summary.json')
 assert summary['result']=='Passed' and summary['passedTests']==summary['totalTestCount']==expected_tests and summary['failedTests']==summary['skippedTests']==0
 boundary=read(phase,'boundary-validation.json')
 assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
 captures=read(phase,'capture-manifest.json')['captures']
 inspected=read(phase,'visual-inspection.json')['inspectedOriginalFiles']
 assert len(captures)==expected_captures and {entry['file'] for entry in captures}==set(inspected)
 for entry in captures:assert hashlib.sha256((root/phase/entry['file']).read_bytes()).hexdigest()==entry['sha256']
 assert read(phase,'appearance-observation.json')['restoredToOriginal']
 executions.append({'phase':phase,'passedFunctions':expected_tests,'inspectedOriginalCaptures':expected_captures,'sourceInputs':len(read(phase,'source-sha256.json')),'productsReconciledBeforeReuse':boundary['retainedProductCount']})
compilers=[]
for phase,expected_sources in [('calendar-split-pane-mac-compiler',initial_sources),('calendar-split-pane-month-viewport-mac-compiler',final_sources)]:
 assert read(phase,'source-sha256.json')==expected_sources
 boundary=read(phase,'boundary-validation.json')
 assert boundary['exitCode']==0 and not boundary['sourceDifferences'] and not boundary['productDifferences']
 compilers.append({'phase':phase,'retainedProductCount':boundary['retainedProductCount'],'runtimeCredit':False})
failed='calendar-split-pane-day-mac'
assert read(failed,'source-sha256.json')==initial_sources
outcome=read(failed,'exit.json')
assert outcome['exitCode']==65 and not outcome['actualTestCaseStarted'] and not outcome['passingCredit']
assert read(failed,'test-summary.json')['result']=='Failed'
assert not subprocess.check_output(['git','diff','--name-only','--','Packages','PlannerShareMobile','PlannerShareMac','PlannerNavigationUITests','PlannerFixtureUITests','PlannerFixtures'],text=True).strip()
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'initialSourceInputs':len(initial_sources),'finalSourceInputs':len(final_sources),'differenceBetweenEpochs':source_differences,'meaningOfDifference':'Mac-only Month viewport change. The final iPad Month execution matches the final Mac compiler exactly; preceding iPad Day/Week/Month results remain a distinct epoch.','nativeExecutions':executions,'totalPassedIpadExecutions':4,'totalInspectedOriginalCaptures':24,'macCompilers':compilers,'macRuntime':{'phase':failed,'requestedFunctionsStarted':0,'exitCode':65,'reason':'Timed out while enabling automation mode before the requested Day function started.','finalViewportExecutionCredit':False},'limits':['No passing actual Mac HSplitView/Month scrolling/resize interaction. The original inspector crash is not claimed fixed by compiler or iPad results.','Actual Mac Day/Week/Month widths, keyboard/accessibility, physical devices, signing and final whole-app acceptance remain open.','Core, Share and test interfaces remain unchanged; Q147/Q148 import implementations wait for concrete review.']}
(root/'final-reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'reconcile-checkpoint.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(record,indent=2))
