from pathlib import Path
import json,os,subprocess,sys
phase,selected=sys.argv[1:3]
packet=Path('/Users/dinh-van.colomban/Workspace/private/planner/docs/prototypes/evidence/native-webpage-failure-target')/phase
environment=dict(os.environ,DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer')
device='FBD72DAB-1D40-4E64-912D-7F9763E00446'
observations=[]
def observe(attribute):
 command=['xcrun','simctl','ui',device,attribute]
 result=subprocess.run(command,capture_output=True,env=environment)
 observations.append({'command':command,'exitCode':result.returncode,'output':result.stdout.decode().strip(),'error':result.stderr.decode().strip()})
 result.check_returncode()
 return result.stdout.decode().strip()
original=observe('appearance')
for attribute in ['increase_contrast','content_size']:observe(attribute)
changed=original!='dark'
if changed:subprocess.run(['xcrun','simctl','ui',device,'appearance','dark'],check=True,env=environment,capture_output=True)
observe('appearance')
try:
 result=subprocess.run(['python3','/private/tmp/PlannerBrowserFailureTargetTabletRuntime.py',phase,selected],env=environment)
finally:
 if changed:subprocess.run(['xcrun','simctl','ui',device,'appearance',original],check=True,env=environment,capture_output=True)
 restored=observe('appearance')
 if packet.exists():
  (packet/'appearance-observation.json').write_text(json.dumps({'observations':observations,'changedForTest':changed,'restoredToOriginal':restored==original},indent=2)+'\n')
  import gzip
  (packet/'appearance-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
raise SystemExit(result.returncode)
